import random
import numpy as np
import os
from bisect import bisect_left, insort
from collections import deque
import warnings
import traceback

warnings.filterwarnings('ignore')

random.seed(21)
np.random.seed(21)


# ------------------ 基础结构 ------------------
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.rank = [0, 0]
        self.z_value = 0

    def __repr__(self):
        return f"Point(x={self.x:.2f}, y={self.y:.2f}, z={self.z_value})"


# ------------------ 稳健的 RLS 更新（通用） ------------------
def rls_update_general(theta, P, phi, y, forgetting_factor=0.999, reg_alpha=1e-6,
                       lambda_min=0.95, lambda_max=0.9999, adapt_threshold=4.0):
    """
    通用 RLS 更新，输入 phi（向量），带数值保护、正则和简单自适应 λ（基于归一化创新 γ）。
    返回 (theta_new, P_new, e, lambda_used, gamma)
    """
    phi = np.asarray(phi, dtype=np.float64).reshape(-1)
    y_pred = float(np.dot(phi, theta))
    e = y - y_pred

    Pphi = P.dot(phi)
    denom_base = float(np.dot(phi, Pphi))

    # 计算归一化创新 gamma = e^2 / (phi^T P phi + eps)
    eps = 1e-12
    gamma = (e * e) / (denom_base + eps)

    # 简单自适应遗忘：当 gamma 很大时降低 lambda 以更快适应
    if gamma > adapt_threshold:
        lambda_k = max(lambda_min, forgetting_factor * 0.5)
    else:
        lambda_k = min(lambda_max, forgetting_factor)

    denominator = lambda_k + denom_base
    if denominator < 1e-12:
        denominator = 1e-12

    K = Pphi / denominator

    theta_new = theta + K * e

    # 带正则的协方差更新（并保持对称）
    P_new = (P - np.outer(K, phi.dot(P))) / lambda_k
    P_new += np.eye(P.shape[0]) * reg_alpha
    P_new = (P_new + P_new.T) / 2

    # 确保正定
    try:
        eigen_min = np.min(np.real(np.linalg.eigvals(P_new)))
    except Exception:
        eigen_min = 1.0
    if eigen_min < 1e-12:
        P_new += np.eye(P.shape[0]) * (1e-8 - min(0, eigen_min))

    return theta_new, P_new, e, lambda_k, gamma


# ------------------ 分段模型 ------------------
class Segment:
    """增强的分段多项式模型（默认二次）"""

    def __init__(self, z_min, z_max, segment_id=None, degree=2):
        self.z_min = z_min
        self.z_max = z_max
        self.segment_id = segment_id or 0
        self.degree = degree  # degree=2 -> features [z_s, z_s^2, 1]
        self.theta = np.zeros(self._feature_dim(), dtype=np.float64)
        self.P = np.eye(self._feature_dim(), dtype=np.float64) * 1e4  # 初始协方差更保守
        self.samples = []  # 历史样本 (z, y_true_placeholder)
        self.quantized_errors = deque(maxlen=200)  # 更长窗口用于稳定分裂判断

        # 超参
        self.reg_alpha = 1e-3
        self.forgetting_factor = 0.999
        self.rls_lambda_min = 0.95
        self.rls_lambda_max = 0.9999
        self.adapt_threshold = 4.0
        self.batch_retrain_threshold = 200  # 达到样本数后进行一次批量重拟合

    def _feature_dim(self):
        return self.degree + 1

    def feature_vector(self, z):
        # 归一化 z 到 [0,1]（基于当前 segment 的 z_min/z_max）
        span = (self.z_max - self.z_min) if (self.z_max - self.z_min) > 1e-9 else 1.0
        z_s = (z - self.z_min) / span
        if self.degree == 1:
            return np.array([z_s, 1.0], dtype=np.float64)
        else:
            return np.array([z_s, z_s * z_s, 1.0], dtype=np.float64)

    def predict_continuous(self, z):
        phi = self.feature_vector(z)
        return float(np.dot(phi, self.theta))

    def predict_block_id(self, z):
        continuous_pred = self.predict_continuous(z)
        return int(round(max(0.0, continuous_pred)))

    def add_sample(self, z, y_placeholder):
        self.samples.append((z, y_placeholder))
        if len(self.samples) > 2000:
            # 保持最近样本，防止内存爆炸
            self.samples = self.samples[-1200:]

    def retrain_from_samples(self, manager, block_size, reg_alpha=None):
        """用带正则的闭式批量最小二乘重新拟合（Ridge），并更新协方差的近似"""
        if len(self.samples) < (self._feature_dim() + 2):
            return

        if reg_alpha is None:
            reg_alpha = self.reg_alpha

        # 更新段的 z_min/z_max 以便归一化更准确
        zs = [z for z, _ in self.samples]
        self.z_min = min(self.z_min, min(zs))
        self.z_max = max(self.z_max, max(zs))

        Z = []
        Y = []
        for z, _ in self.samples:
            phi = self.feature_vector(z)
            Z.append(phi)
            Y.append(float(manager.get_true_block_id(z, block_size)))

        Z = np.vstack(Z)  # n x d
        Y = np.asarray(Y, dtype=np.float64).reshape(-1, 1)

        # 闭式岭回归： theta = (Z^T Z + alpha I)^-1 Z^T Y
        d = Z.shape[1]
        A = Z.T.dot(Z) + np.eye(d) * reg_alpha
        b = Z.T.dot(Y)
        try:
            theta_new = np.linalg.solve(A, b).flatten()
            P_new = np.linalg.inv(A)
        except np.linalg.LinAlgError:
            # 若矩阵病态，退回较大协方差
            theta_new = self.theta
            P_new = np.eye(d) * 1e4

        self.theta = theta_new
        self.P = (P_new + P_new.T) / 2
        # 将样本中的 y 替换为真实块号（便于后续离线评估和批量再训练）
        self.samples = [(z, float(manager.get_true_block_id(z, block_size))) for z, _ in self.samples]

    def should_split(self, error_threshold, min_window=25):
        """智能分裂判断：使用95分位数和中位数防止异常值触发"""
        if len(self.quantized_errors) < min_window:
            return False

        recent_errors = list(self.quantized_errors)[-min_window:]
        percentile_95 = np.percentile(recent_errors, 95)
        median_error = np.median(recent_errors)

        return (percentile_95 > error_threshold and
                median_error > error_threshold * 0.6 and
                len(self.samples) >= 30)


# ------------------ 索引管理器 ------------------
class IndexManager:
    """增强的索引状态管理器"""

    def __init__(self):
        self.global_z_list = []  # 全局z值排序
        self.segments = []  # 分段列表
        self.all_points = []  # 所有处理过的点
        self.segment_counter = 0  # 分段ID计数器

    def get_true_block_id(self, z_value, block_size):
        """正确计算真实块号（基于当前的全局排序）"""
        pos = bisect_left(self.global_z_list, z_value)
        return pos // block_size

    def add_point_to_global_order(self, point):
        """维护全局z值排序和点列表"""
        insort(self.global_z_list, point.z_value)
        self.all_points.append(point)

    def find_segment_for_z(self, z_value):
        """找到包含 z 值的分段（线性查找）"""
        for idx, segment in enumerate(self.segments):
            if segment.z_min <= z_value <= segment.z_max:
                return idx, segment
        return None, None

    def create_new_segment(self, z_min, z_max):
        """创建新分段"""
        self.segment_counter += 1
        return Segment(z_min, z_max, segment_id=self.segment_counter)

    def get_segment_statistics(self, segment, block_size):
        """计算分段的详细统计信息（基于整数预测误差）"""
        if not segment.samples:
            return {'mae': 0.0, 'max_error': 0, 'sample_count': 0, 'percentile_95': 0.0}

        errors = []
        for z, _ in segment.samples:
            y_true = self.get_true_block_id(z, block_size)
            y_pred_int = segment.predict_block_id(z)
            errors.append(abs(y_pred_int - y_true))

        return {
            'mae': float(np.mean(errors)),
            'max_error': int(np.max(errors)),
            'sample_count': len(errors),
            'percentile_95': float(np.percentile(errors, 95)) if errors else 0.0
        }

    def find_best_split_by_mae(self, segment, block_size, min_samples_each=15, candidates=9):
        """
        在 segment.samples 中按 z 的若干分位数测试分裂点，返回最佳 split z 或 None
        选择使左右加权 MAE 最小的点
        """
        if len(segment.samples) < 2 * min_samples_each:
            return None

        zs = np.array([z for z, _ in segment.samples])
        qs = np.linspace(0.2, 0.8, candidates)  # 在 20%~80% 范围内尝试
        best = None
        best_score = float('inf')

        for q in qs:
            z_split = float(np.quantile(zs, q))
            left = [(z, y) for z, y in segment.samples if z <= z_split]
            right = [(z, y) for z, y in segment.samples if z > z_split]
            if len(left) < min_samples_each or len(right) < min_samples_each:
                continue

            def train_and_mae(samples):
                # 局部二次拟合并计算 MAE（使用真实 block id）
                Z = []
                Y = []
                zmin = min(z for z, _ in samples)
                zmax = max(z for z, _ in samples)
                span = (zmax - zmin) if (zmax - zmin) > 1e-9 else 1.0
                for z, _ in samples:
                    z_s = (z - zmin) / span
                    phi = np.array([z_s, z_s * z_s, 1.0])
                    Z.append(phi)
                    Y.append(self.get_true_block_id(z, block_size))
                Z = np.vstack(Z)
                Y = np.asarray(Y, dtype=np.float64)
                A = Z.T.dot(Z) + np.eye(Z.shape[1]) * 1e-3
                try:
                    theta = np.linalg.solve(A, Z.T.dot(Y))
                except np.linalg.LinAlgError:
                    theta = np.linalg.lstsq(Z, Y, rcond=None)[0]
                preds = Z.dot(theta)
                preds_int = np.round(np.clip(preds, 0, None))
                return float(np.mean(np.abs(preds_int - Y)))

            mae_left = train_and_mae(left)
            mae_right = train_and_mae(right)
            score = (len(left) * mae_left + len(right) * mae_right) / (len(left) + len(right))
            if score < best_score:
                best_score = score
                best = z_split

        return best

    def split_segment_intelligently(self, seg_idx, error_threshold, block_size):
        """智能分段分裂：先判断，再尝试找到最佳分割点"""
        segment = self.segments[seg_idx]
        # 仅在 segment 自身认为应当分裂时尝试细致分裂
        if not segment.should_split(error_threshold):
            return False

        best_split = self.find_best_split_by_mae(segment, block_size)
        if best_split is None:
            return False

        z_split = best_split
        left_samples = [(z, y) for z, y in segment.samples if z <= z_split]
        right_samples = [(z, y) for z, y in segment.samples if z > z_split]

        if len(left_samples) >= 15 and len(right_samples) >= 15:
            left_segment = self.create_new_segment(segment.z_min, z_split)
            left_segment.samples = left_samples
            left_segment.retrain_from_samples(self, block_size)

            right_segment = self.create_new_segment(z_split, segment.z_max)
            right_segment.samples = right_samples
            right_segment.retrain_from_samples(self, block_size)

            # 替换原分段
            self.segments[seg_idx:seg_idx + 1] = [left_segment, right_segment]
            return True

        return False


# ------------------ Morton 编码 ------------------
def map_to_z(x: int, y: int) -> int:
    """Morton 编码 (Z 曲线映射)"""
    if x < 0 or y < 0:
        raise ValueError("x and y must be non-negative integers")
    code = 0
    i = 0
    while x or y:
        code |= (x & 1) << (2 * i)
        code |= (y & 1) << (2 * i + 1)
        x >>= 1
        y >>= 1
        i += 1
    return code


def load_points_from_file(filepath, n_points):
    """从文件随机采样点"""
    all_points = []
    with open(filepath, "r") as f:
        for line in f:
            parts = line.strip().split(",")
            if len(parts) != 2:
                continue
            try:
                x, y = float(parts[0]), float(parts[1])
                all_points.append(Point(x, y))
            except ValueError:
                continue

    if len(all_points) < n_points:
        raise RuntimeError(f"文件中点数不足 {n_points} 个，实际只有 {len(all_points)} 个")

    return random.sample(all_points, n_points)


def assign_rank(points, density_x, density_y):
    """分配 rank 值"""
    points_sorted_x = sorted(points, key=lambda p: p.x)
    for idx, p in enumerate(points_sorted_x):
        p.rank[0] = idx // density_x

    points_sorted_y = sorted(points, key=lambda p: p.y)
    for idx, p in enumerate(points_sorted_y):
        p.rank[1] = idx // density_y


def assign_z_from_rank(points):
    """计算 Z 值"""
    for p in points:
        p.z_value = map_to_z(int(p.rank[0]), int(p.rank[1]))


# ------------------ 初始训练阶段 ------------------
def initial_training_phase(points, block_size, error_threshold, manager):
    """初始训练：按 z 值排序，智能分段"""
    print("=== 初始训练阶段 ===")

    # 按 z 值排序并初始化全局状态（用于 get_true_block_id）
    z_sorted = sorted(points, key=lambda p: p.z_value)
    for p in z_sorted:
        manager.add_point_to_global_order(p)

    # 初始化单一分段覆盖全域
    current_segment = manager.create_new_segment(z_sorted[0].z_value, z_sorted[-1].z_value)
    all_errors = []

    print(f"开始初始训练，共 {len(z_sorted)} 个点...")

    for i, p in enumerate(z_sorted):
        z = p.z_value
        y_true = i // block_size  # 基于排序位置的真实块号

        # RLS 更新（使用段的特征向量）
        phi = current_segment.feature_vector(z)
        theta_new, P_new, _, _, _ = rls_update_general(
            current_segment.theta, current_segment.P, phi, float(y_true),
            forgetting_factor=current_segment.forgetting_factor,
            reg_alpha=1e-8,
            lambda_min=current_segment.rls_lambda_min,
            lambda_max=current_segment.rls_lambda_max,
            adapt_threshold=current_segment.adapt_threshold
        )
        current_segment.theta = theta_new
        current_segment.P = P_new

        current_segment.add_sample(z, float(y_true))

        # 计算整数块号误差
        y_pred_int = current_segment.predict_block_id(z)
        quantized_error = abs(y_pred_int - y_true)

        current_segment.quantized_errors.append(quantized_error)
        all_errors.append(quantized_error)

        # 智能分段判断（提前尝试细致分裂）
        if current_segment.should_split(error_threshold) and i > 100:
            # 如果当前分段在 manager 中不存在（第一次），先 append 然后尝试分裂
            if not manager.segments:
                manager.segments.append(current_segment)
                seg_idx = 0
            else:
                # 把当前 segment 放到末尾暂存
                manager.segments.append(current_segment)
                seg_idx = len(manager.segments) - 1

            # 尝试智能分裂
            if manager.split_segment_intelligently(seg_idx, error_threshold, block_size):
                # 如果分裂成功，把 current_segment 指向最后一个未被处理的区间（新建）
                current_segment = manager.create_new_segment(z, z_sorted[-1].z_value)
            else:
                # 分裂无效，开始新的空段以继续填充（避免无限增大当前段范围）
                current_segment = manager.create_new_segment(z, z_sorted[-1].z_value)

    # 处理最后一个分段
    if current_segment.samples:
        manager.segments.append(current_segment)
        stats = manager.get_segment_statistics(current_segment, block_size)
        print(f"  创建分段 {current_segment.segment_id}: "
              f"z=[{current_segment.z_min:.2f}, {current_segment.z_max:.2f}], "
              f"样本={stats['sample_count']}, MAE={stats['mae']:.4f}")

    # 重训练所有分段以修复标签漂移（批量闭式回归）
    print("\n初始训练后标签修正:")
    for segment in manager.segments:
        segment.retrain_from_samples(manager, block_size)
        stats = manager.get_segment_statistics(segment, block_size)
        print(f"  分段 {segment.segment_id}: MAE={stats['mae']:.4f}, "
              f"MAXE={stats['max_error']}, 样本={stats['sample_count']}")

    overall_mae = np.mean(all_errors) if all_errors else 0.0
    overall_max = np.max(all_errors) if all_errors else 0
    print(f"\n初始训练完成: 段数={len(manager.segments)}, "
          f"MAE={overall_mae:.4f}, MAXE={overall_max}")
    print("-" * 80)

    return all_errors


# ------------------ 更新训练阶段 ------------------
def update_training_phase(new_points, block_size, error_threshold, manager):
    """更新阶段：正确监督信号 + 智能分裂 + 周期性批量重拟合"""
    print("=== 更新训练阶段 ===")

    all_errors = []
    split_count = 0

    print(f"开始更新训练，共 {len(new_points)} 个新点...")

    for i, p in enumerate(new_points):
        z = p.z_value

        # 核心修复：正确计算监督信号
        y_true = manager.get_true_block_id(z, block_size)

        # 找到对应分段
        seg_idx, segment = manager.find_segment_for_z(z)

        # 边界处理：创建或扩展分段
        if segment is None:
            if not manager.segments:
                segment = manager.create_new_segment(z, z)
                manager.segments.append(segment)
                seg_idx = 0
            elif z < manager.segments[0].z_min:
                segment = manager.segments[0]
                segment.z_min = z
                seg_idx = 0
            else:
                segment = manager.segments[-1]
                segment.z_max = z
                seg_idx = len(manager.segments) - 1

        # RLS 更新（用 segment 的特征）
        phi = segment.feature_vector(z)
        theta_new, P_new, _, _, _ = rls_update_general(
            segment.theta, segment.P, phi, float(y_true),
            forgetting_factor=segment.forgetting_factor,
            reg_alpha=1e-8,
            lambda_min=segment.rls_lambda_min,
            lambda_max=segment.rls_lambda_max,
            adapt_threshold=segment.adapt_threshold
        )
        segment.theta = theta_new
        segment.P = P_new

        segment.add_sample(z, float(y_true))

        # 当样本数达到阈值时进行批量重拟合以清除 RLS 累积偏差
        if len(segment.samples) >= segment.batch_retrain_threshold:
            segment.retrain_from_samples(manager, block_size)

        # 计算整数块号误差
        y_pred_int = segment.predict_block_id(z)
        quantized_error = abs(y_pred_int - y_true)
        all_errors.append(quantized_error)
        segment.quantized_errors.append(quantized_error)

        # 智能分裂判断（更细致）
        if segment.should_split(error_threshold):
            if manager.split_segment_intelligently(seg_idx, error_threshold, block_size):
                split_count += 1
                print(f"  分裂 {split_count}: 在z≈{z:.2f} 附近分裂, 误差={quantized_error}")

        # 更新全局状态
        manager.add_point_to_global_order(p)

        # 周期性日志输出
        if (i + 1) % 5000 == 0:
            print(f"  已处理 {i + 1}/{len(new_points)} 个点, 当前段数={len(manager.segments)}")

    # 更新训练后整体批量修正
    print("\n更新训练后标签修正:")
    for segment in manager.segments:
        segment.retrain_from_samples(manager, block_size)
        stats = manager.get_segment_statistics(segment, block_size)
        print(f"  分段 {segment.segment_id}: MAE={stats['mae']:.4f}, "
              f"MAXE={stats['max_error']}, 样本={stats['sample_count']}")

    overall_mae = np.mean(all_errors) if all_errors else 0.0
    overall_max = np.max(all_errors) if all_errors else 0
    print(f"\n更新训练完成: 段数={len(manager.segments)}, 分裂次数={split_count}, "
          f"MAE={overall_mae:.4f}, MAXE={overall_max}")
    print("-" * 80)

    return all_errors


# ------------------ 完整验证模块 ------------------
def comprehensive_validation(manager, block_size):
    """完整验证：逐行输出所有点的预测结果"""
    print("=== 模型验证阶段 ===")
    print("对所有处理过的点进行验证...")
    print(f"{'X':<10} {'Y':<10} {'Z值':<12} {'预测块号':<10} {'真实块号':<10} {'绝对误差':<10}")
    print("-" * 70)

    all_errors = []
    exact_predictions = 0

    for point in manager.all_points:
        z = point.z_value

        # 获取真实块号
        y_true = manager.get_true_block_id(z, block_size)

        # 模型预测
        _, segment = manager.find_segment_for_z(z)
        if segment is not None:
            y_pred_int = segment.predict_block_id(z)
        else:
            # 边界保护
            if manager.segments:
                if z < manager.segments[0].z_min:
                    y_pred_int = manager.segments[0].predict_block_id(z)
                else:
                    y_pred_int = manager.segments[-1].predict_block_id(z)
            else:
                y_pred_int = 0

        # 计算误差
        error = abs(y_pred_int - y_true)
        all_errors.append(error)

        if error == 0:
            exact_predictions += 1

        # 逐行输出（注意大量点会很长）
        print(f"{point.x:<10.2f} {point.y:<10.2f} {z:<12} {y_pred_int:<10} "
              f"{y_true:<10} {error:<10}")

    # 详细统计分析
    mae = float(np.mean(all_errors)) if all_errors else 0.0
    rmse = float(np.sqrt(np.mean([e ** 2 for e in all_errors]))) if all_errors else 0.0
    max_error = int(np.max(all_errors)) if all_errors else 0

    print("-" * 70)
    print(f"验证统计结果:")
    print(f"  总点数: {len(all_errors)}")
    print(f"  平均绝对误差 (MAE): {mae:.6f}")
    print(f"  均方根误差 (RMSE): {rmse:.6f}")
    print(f"  最大误差: {max_error}")
    print(f"  精确预测数量: {exact_predictions} ({exact_predictions / len(all_errors) * 100:.2f}%)")

    # 误差分布统计
    print(f"\n误差分布统计:")
    thresholds = [0, 1, 2, 5, 10, 20]
    for threshold in thresholds:
        count = sum(1 for e in all_errors if e <= threshold)
        percentage = count / len(all_errors) * 100 if all_errors else 0.0
        print(f"  误差 ≤ {threshold}: {count} 个点 ({percentage:.2f}%)")

    return mae, all_errors


# ------------------ 主程序 ------------------
if __name__ == "__main__":
    # 参数配置
    data_path = os.path.join("..", "data", "200W_P0_chd.txt")
    n_points = 40000
    density_x, density_y = 10, 10
    block_size = 200
    error_threshold = 5.0

    print(f"配置参数: 点数={n_points}, 块大小={block_size}, 误差阈值={error_threshold}")
    print("=" * 80)

    # 初始化管理器
    manager = IndexManager()

    try:
        # === 第一阶段：初始训练 ===
        print("加载初始训练数据...")
        points = load_points_from_file(data_path, n_points)
        assign_rank(points, density_x, density_y)
        assign_z_from_rank(points)

        errors_init = initial_training_phase(points, block_size, error_threshold, manager)

        # === 第二阶段：更新训练 ===
        print("加载更新训练数据...")
        points_new = load_points_from_file(data_path, n_points)
        assign_rank(points_new, density_x, density_y)
        assign_z_from_rank(points_new)

        errors_update = update_training_phase(points_new, block_size, error_threshold, manager)

        # === 第三阶段：完整验证 ===
        final_mae, validation_errors = comprehensive_validation(manager, block_size)

        # === 最终统计 ===
        all_training_errors = np.array(errors_init + errors_update) if errors_init or errors_update else np.array([])
        print("=" * 80)
        print(f"最终统计结果:")
        print(f"  总段数: {len(manager.segments)}")
        print(f"  总点数: {len(manager.all_points)}")
        if all_training_errors.size > 0:
            print(f"  训练阶段 MAE: {np.mean(all_training_errors):.6f}")
            print(f"  训练阶段 MAXE: {np.max(all_training_errors):.6f}")
        else:
            print("  训练阶段 MAE: N/A")
            print("  训练阶段 MAXE: N/A")
        print(f"  验证阶段 MAE: {final_mae:.6f}")
        print(f"  验证阶段 MAXE: {np.max(validation_errors) if validation_errors else 0}")

        # 模型效率评估
        total_points = len(manager.all_points)
        perfect_rate = sum(1 for e in validation_errors if e == 0) / total_points * 100 if total_points else 0.0
        good_rate = sum(1 for e in validation_errors if e <= 1) / total_points * 100 if total_points else 0.0

        print(f"\n模型效率评估:")
        print(f"  完美预测率: {perfect_rate:.2f}%")
        print(f"  优秀预测率 (误差≤1): {good_rate:.2f}%")
        print(f"  模型复杂度: {len(manager.segments)} 个分段")

        print("=" * 80)
        print("学习型索引训练和验证完成！")

    except FileNotFoundError:
        print(f"错误：找不到数据文件 {data_path}")
        print("请确保数据文件路径正确")
    except Exception as e:
        print(f"运行错误：{e}")
        traceback.print_exc()
