import os
import math
import numpy as np


# =========================
# 1) 读数据与读查询
# =========================

def load_points_2d(path):
    """
    读取二维点(x, y)，你的例子是 (space, time)。
    按要求：全部四舍五入取整 -> int
    返回: (N,2) int64
    """
    pts = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            a, b = line.split(",")
            x = int(round(float(a)))
            y = int(round(float(b)))
            pts.append((x, y))
    return np.asarray(pts, dtype=np.int64)


def load_queries_2d(path):
    """
    每行: xmin,ymin,xmax,ymax
    全部四舍五入取整 -> int
    规范化: 确保 xmin<=xmax, ymin<=ymax
    返回: (Q,4) int64
    """
    qs = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            v = [int(round(float(x))) for x in line.split(",")]
            if len(v) != 4:
                raise ValueError(f"Bad query line: {line}")
            xmin, ymin, xmax, ymax = v
            if xmin > xmax:
                xmin, xmax = xmax, xmin
            if ymin > ymax:
                ymin, ymax = ymax, ymin
            qs.append((xmin, ymin, xmax, ymax))
    return np.asarray(qs, dtype=np.int64)


def load_bmc_order(path):
    """
    从文件中读取 BMC 位排列

    文件格式：
      pos \t dim \t bit
    忽略以 # 开头的注释行

    返回：
      order : list[(dim, bit)]
      order[pos] = (dim, bit)
    """
    order = []

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            pos, dim, bit = line.split()
            order.append((int(dim), int(bit)))

    return order


# =========================
# 2) 位编码：把二维整数点编码成 bit-vector
# =========================

def needed_bits(max_value):
    """至少 1 bit；例如 max=0 -> 1bit"""
    if max_value <= 0:
        return 1
    return int(math.floor(math.log2(max_value)) + 1)


def encode_bits_2d(points, b1, b2):
    """
    points: (N,2) int
    b1,b2: 每维 bit 数
    输出: V (N, L) ，L=b1+b2
         bit 顺序：先维0从低位->高位，再维1从低位->高位
    """
    x = points[:, 0].astype(np.int64)
    y = points[:, 1].astype(np.int64)
    N = points.shape[0]
    L = b1 + b2
    V = np.zeros((N, L), dtype=np.float64)

    # dim0 bits
    for k in range(b1):
        V[:, k] = (x >> k) & 1

    # dim1 bits
    for k in range(b2):
        V[:, b1 + k] = (y >> k) & 1

    return V


def bit_meta_2d(b1, b2):
    """
    给每个 bit 一个 (dim, bit_index_in_dim) 的元信息（与 encode_bits 顺序一致）
    """
    meta = []
    for k in range(b1):
        meta.append((0, k))  # dim0, low->high
    for k in range(b2):
        meta.append((1, k))  # dim1, low->high
    return meta  # len L


def bmc_key_2d(point, order):
    """
    根据 BMC 位排列，将二维整数点映射为一维整数键值

    参数
    ----
    point : tuple(int, int)
        二维整数点 (x, y)
    order : list of (dim, bit)
        BMC 位排列
        - dim ∈ {0,1} : 0->x维, 1->y维
        - bit >= 0    : 该维度中的第 bit 位（bit=0 是最低位）
        - order[0]    : 一维值的最低有效位
        - order[-1]   : 一维值的最高有效位

    返回
    ----
    key : int
        一维整数键值
    """
    x, y = point
    key = 0

    for pos, (dim, bit) in enumerate(order):
        if dim == 0:
            v = (x >> bit) & 1
        else:
            v = (y >> bit) & 1

        key |= (v << pos)

    return key


# =========================
# 3) Sinkhorn：把矩阵投影回“双随机矩阵”
# =========================

def sinkhorn_doubly_stochastic(A, iters=30, eps=1e-12):
    """
    交替归一化行/列，使 A 近似双随机。
    假设 A 非负。
    """
    A = A.copy()
    for _ in range(iters):
        # normalize rows
        row_sum = A.sum(axis=1, keepdims=True) + eps
        A = A / row_sum
        # normalize cols
        col_sum = A.sum(axis=0, keepdims=True) + eps
        A = A / col_sum
    return A


def init_soft_assignment(L, seed=0):
    rng = np.random.default_rng(seed)
    A = rng.random((L, L), dtype=np.float64) + 1e-3
    A = sinkhorn_doubly_stochastic(A, iters=80)
    return A


# =========================
# 4) soft key：k(p) = v_p^T A w
# =========================

def soft_keys(V, A, w):
    """
    V: (N,L) bits float
    A: (L,L)
    w: (L,) weights 2^pos
    return: (N,) float
    """
    # (N,L) @ (L,L) -> (N,L) ; then dot with w
    return (V @ A) @ w


# =========================
# 5) 用“查询负载”构造正/负样本对
# =========================

def points_in_query_mask(points, q):
    xmin, ymin, xmax, ymax = q
    x = points[:, 0]
    y = points[:, 1]
    return (x >= xmin) & (x <= xmax) & (y >= ymin) & (y <= ymax)


def sample_pairs_from_queries(points, queries, pos_pairs, neg_pairs, seed=0, max_tries=50):
    """
    pos: 同一 query 内抽两点
    neg: query 内抽一点 + query 外抽一点
    返回:
      pos_idx: (P,2) indices
      neg_idx: (N,2) indices
    """
    rng = np.random.default_rng(seed)
    N = points.shape[0]
    Q = queries.shape[0]

    pos = []
    neg = []

    # 预先对每个 query 存 inside indices，加速采样
    inside_lists = []
    outside_lists = []
    all_idx = np.arange(N)

    for qi in range(Q):
        mask = points_in_query_mask(points, queries[qi])
        inside = all_idx[mask]
        outside = all_idx[~mask]
        inside_lists.append(inside)
        outside_lists.append(outside)

    # 采样正对
    tries = 0
    while len(pos) < pos_pairs and tries < pos_pairs * max_tries:
        tries += 1
        qi = rng.integers(0, Q)
        inside = inside_lists[qi]
        if inside.size < 2:
            continue
        a, b = rng.choice(inside, size=2, replace=False)
        pos.append((a, b))

    # 采样负对
    tries = 0
    while len(neg) < neg_pairs and tries < neg_pairs * max_tries:
        tries += 1
        qi = rng.integers(0, Q)
        inside = inside_lists[qi]
        outside = outside_lists[qi]
        if inside.size < 1 or outside.size < 1:
            continue
        a = int(rng.choice(inside))
        b = int(rng.choice(outside))
        neg.append((a, b))

    if len(pos) == 0:
        raise RuntimeError("无法采到正样本：你的查询窗口可能都太小/数据太稀。")
    if len(neg) == 0:
        raise RuntimeError("无法采到负样本：你的查询窗口可能覆盖了几乎所有点。")

    return np.asarray(pos, dtype=np.int64), np.asarray(neg, dtype=np.int64)


# =========================
# 6) 训练：对比损失 + 手动梯度 + Sinkhorn
# =========================

def train_soft_assignment(
        V,  # (N,L) bit vectors
        points, queries,  # for sampling
        epochs=50,
        pos_pairs=2000,
        neg_pairs=2000,
        lr=0.05,
        margin=50.0,  # hinge margin in key-space（可调）
        sinkhorn_iters=40,
        seed=0,
        verbose=True
):
    """
    使用简化版对比学习：
      L_pos = mean( (diff)^2 )
      L_neg = mean( max(0, margin - |diff| )^2 )
    diff = (v_i - v_j)^T A w
    梯度:
      d/dA (diff) = (v_i - v_j)[:,None] * w[None,:]
      对应 L_pos / L_neg 再链式
    """
    rng = np.random.default_rng(seed)
    N, L = V.shape
    w = (2.0 ** np.arange(L)).astype(np.float64)  # 位权重，pos 越大权重越大
    A = init_soft_assignment(L, seed=seed)

    eps = 1e-12

    for ep in range(1, epochs + 1):
        pos_idx, neg_idx = sample_pairs_from_queries(
            points, queries,
            pos_pairs=pos_pairs,
            neg_pairs=neg_pairs,
            seed=int(rng.integers(0, 1_000_000))
        )

        # ------- 计算 diff -------
        Vi = V[pos_idx[:, 0]]  # (P,L)
        Vj = V[pos_idx[:, 1]]  # (P,L)
        dpos = Vi - Vj  # (P,L)

        Vk = V[neg_idx[:, 0]]  # (M,L)
        Vl = V[neg_idx[:, 1]]  # (M,L)
        dneg = Vk - Vl  # (M,L)

        # diff = d @ A @ w
        diff_pos = (dpos @ A) @ w  # (P,)
        diff_neg = (dneg @ A) @ w  # (M,)

        # ------- loss -------
        Lpos = np.mean(diff_pos ** 2)

        abs_neg = np.abs(diff_neg)
        hinge = np.maximum(0.0, margin - abs_neg)
        Lneg = np.mean(hinge ** 2)

        loss = Lpos + Lneg

        # ------- gradient accumulate -------
        # grad_pos = mean( 2*diff * d[:,None]*w[None,:] )
        # (P,L) -> (P,L,1) * (1,1,L) => (P,L,L)
        # 为了不爆内存，使用矩阵方式：
        # 对每个样本贡献: 2*diff * (d^T) outer w
        # sum over samples: (sum_i 2*diff_i * d_i) outer w
        gpos_vec = (2.0 * diff_pos)[:, None] * dpos  # (P,L)
        gpos = (gpos_vec.mean(axis=0))[:, None] * w[None, :]  # (L,L)

        # grad_neg: hinge^2, if abs<margin:
        # loss_i = (margin - |diff|)^2
        # dloss/ddiff = 2*(margin - |diff|)*(-sign(diff))
        active = abs_neg < margin
        if np.any(active):
            sign = np.sign(diff_neg[active])
            dL_dd = 2.0 * (margin - abs_neg[active]) * (-sign)  # (A,)
            gneg_vec = dL_dd[:, None] * dneg[active]  # (A,L)
            gneg = (gneg_vec.mean(axis=0))[:, None] * w[None, :]  # (L,L)
        else:
            gneg = np.zeros((L, L), dtype=np.float64)

        grad = gpos + gneg

        # ------- update -------
        A = A - lr * grad

        # 投影到非负（避免出现负概率）
        A = np.maximum(A, eps)

        # Sinkhorn 投影回双随机
        A = sinkhorn_doubly_stochastic(A, iters=sinkhorn_iters)

        if verbose and (ep == 1 or ep % 5 == 0 or ep == epochs):
            print(f"[epoch {ep:03d}] loss={loss:.6f}  Lpos={Lpos:.6f}  Lneg={Lneg:.6f}")

    return A


# =========================
# 7) 贪心恢复“单调位排列”(算法2)
# =========================

def greedy_monotone_order(A, b1, b2):
    """
    根据论文算法2思想：
      每个位置 j，从每个维度的“当前候选位”(该维尚未分配的最低位)里选概率最大的那个
    约束保证：同一维度内 bit 顺序不变（low->high）

    返回:
      order_bits: 长度 L 的列表，每项是 (dim, bit_index_in_dim)
    """
    L = A.shape[0]
    assert L == b1 + b2

    # 每维已分配到哪个 bit（从低到高）
    ptr = [0, 0]
    dims_bits = [b1, b2]

    # bit_id(dim, k) -> global bit index i in [0,L)
    def global_bit_index(dim, k):
        return k if dim == 0 else b1 + k

    order = []
    for pos in range(L):
        best_dim = None
        best_prob = -1.0

        for dim in [0, 1]:
            if ptr[dim] >= dims_bits[dim]:
                continue
            i = global_bit_index(dim, ptr[dim])  # 当前候选位
            prob = A[i, pos]
            if prob > best_prob:
                best_prob = prob
                best_dim = dim

        # 放置 best_dim 的当前候选位
        k = ptr[best_dim]
        order.append((best_dim, k))
        ptr[best_dim] += 1

    return order


# =========================
# 8) 主程序：训练并输出结果
# =========================

def main():
    DATA_FILE = r"D:\StudyFile\YanEr\Test_Code\data\200W_P0.txt"
    QUERY_FILE = r"D:\StudyFile\YanEr\Test_Code\data\range_query.txt"

    points = load_points_2d(DATA_FILE)
    queries = load_queries_2d(QUERY_FILE)

    # 自动决定每维 bit 数（基于最大值）
    max_x = int(points[:, 0].max())
    max_y = int(points[:, 1].max())
    b1 = needed_bits(max_x)
    b2 = needed_bits(max_y)

    print(f"Loaded points: {points.shape[0]}, queries: {queries.shape[0]}")
    print(f"Auto bit length: dim0={b1}, dim1={b2}  (max_x={max_x}, max_y={max_y})")

    V = encode_bits_2d(points, b1, b2)  # (N,L)
    L = V.shape[1]
    print(f"Total bits L = {L}")

    # 训练软分配矩阵 A
    A = train_soft_assignment(
        V=V,
        points=points,
        queries=queries,
        epochs=50,
        pos_pairs=2000,
        neg_pairs=2000,
        lr=0.05,
        margin=50.0,
        sinkhorn_iters=40,
        seed=0,
        verbose=True
    )

    # 贪心恢复单调位排列
    order = greedy_monotone_order(A, b1, b2)

    # 打印结果
    print("\nLearned Monotone BMC Order (from low->high positions):")
    # pos=0 是最低有效位，pos=L-1 是最高有效位
    for pos, (dim, k) in enumerate(order):
        print(f"pos {pos:02d}: dim={dim}, bit={k}")

    # 保存到文件（可选）
    out_path = os.path.join(os.path.dirname(DATA_FILE), "learned_bmc_order.txt")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(f"# dim0_bits={b1}, dim1_bits={b2}\n")
        for pos, (dim, k) in enumerate(order):
            f.write(f"{pos}\t{dim}\t{k}\n")
    print(f"\nSaved order to: {out_path}")


if __name__ == "__main__":
    # main()
    ORDER_FILE = r".\index\learned_bmc_order.txt"

    # 1. 读取 BMC 位排列
    order = load_bmc_order(ORDER_FILE)

    # 2. 一个二维整数点（示例）
    point = (8399, 1407079460)

    # 3. 计算一维映射值
    key = bmc_key_2d(point, order)

    print("BMC key =", key)
