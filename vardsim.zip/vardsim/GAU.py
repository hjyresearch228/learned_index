"""基于北京四环路网生成 14 期 GAU 轨迹数据。

工作日和周末使用各自固定的时空分布，事件期重新抽取分布参数。
每期输出 200 万个 pos,time 点，保存为 period_N.txt。
"""
from __future__ import annotations

import argparse
import csv
import heapq
import json
import math
import multiprocessing as mp
import sys
import time
import xml.etree.ElementTree as ET
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np


# 常用参数
NETWORK_XML = Path(
    r"E:\路网\Beijing_join_addLanes1-1.net.xml"
)
ROAD_CSV = Path(
    r"E:\暑期工作代码\数据提取\路段排序结果\road_features_extracted_with_upstream_connections.csv"
)
ROAD_POSITION_JSON = Path(
    r"E:\暑期工作代码\数据提取\路段排序结果\spectral_road_position.json"
)
OUTPUT_ROOT = Path(r"E:\暑期工作代码\DATA\v1")
DATASET_NAME = "GAU"
POINTS_PER_PERIOD = 2_000_000     # 每期目标点数
PERIODS = 14                     # 周期数
MAX_TRAJECTORY_POINTS = 1000      # 单条轨迹点数上限
SAMPLE_INTERVAL = 10              # 采样间隔：秒
SEED = 42                         # 随机种子
SPATIAL_COMPONENTS = 50           # 出发位置的高斯分量数
TIME_COMPONENTS = 3               # 出发时间的高斯分量数
WEEKEND_REPLACEMENTS = 25         # 周末替换的空间热点中心数
EVENT_REPLACEMENTS = 15           # 每个事件替换的空间热点中心数
EVENT_COUNT = 4                   # 事件期数
DESTINATIONS_PER_ROAD = 3         # 每条出发道路最多 3 个候选终点
FULL_COVERAGE = True              # 每期覆盖全部实验道路

# 容量参数
ROAD_CAP_FACTOR = 2.0             # 道路日容量系数
ROAD_HOUR_CAP_FACTOR = 1.5        # 小时容量系数

# 执行参数
WORKERS = 4                       # 同一期并行进程数
HIST_BINS = 50                    # TV 统计网格：50×50
BATCH_TRAJECTORIES = 4096         # 每批尝试生成的轨迹条数
TASK_TRAJECTORIES = 64            # 每个并行任务的轨迹条数
VEHICLE_CLASS = "passenger"       # SUMO 车辆类型
HOUR_COUNT = 24                   # 一天 24 个容量时段

SECONDS_PER_DAY = 86_400
TIME_REFERENCE = SECONDS_PER_DAY / 3
_NETWORK = None


def lane_allowed(lane: ET.Element, vehicle: str) -> bool:
    allow = set(lane.get("allow", "").split())
    disallow = set(lane.get("disallow", "").split())
    return (
        (not allow or "all" in allow or vehicle in allow)
        and "all" not in disallow
        and vehicle not in disallow
    )


def read_road_table(csv_path: Path, position_json_path: Path) -> list[dict]:
    """道路顺序取自 JSON，道路属性取自 CSV。"""
    with Path(csv_path).open(encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        required = {"路段id", "长度", "车道数", "连接数", "放缩值"}
        if reader.fieldnames is None or not required.issubset(reader.fieldnames):
            missing = sorted(required - set(reader.fieldnames or ()))
            raise ValueError(f"道路属性 CSV 缺少字段：{missing}")
        attributes = {}
        for line, row in enumerate(reader, 2):
            edge_id = row["路段id"].strip()
            if not edge_id:
                raise ValueError(f"道路属性 CSV 第 {line} 行的路段id为空")
            if edge_id in attributes:
                raise ValueError(f"道路属性 CSV 存在重复路段id：{edge_id}")
            length = float(row["长度"])
            lanes = int(float(row["车道数"]))
            connections = int(float(row["连接数"]))
            q = float(row["放缩值"])
            if not math.isfinite(length) or not math.isfinite(q) or length <= 0 or lanes <= 0 or connections < 0 or q < 0:
                raise ValueError(f"道路属性 CSV 第 {line} 行参数非法")
            attributes[edge_id] = dict(lane_count=lanes, connection_count=connections, q=q)

    with Path(position_json_path).open(encoding="utf-8") as file:
        positions = json.load(file)
    if not isinstance(positions, dict) or not positions:
        raise ValueError("道路位置 JSON 必须是非空的路段ID到位置参数映射")

    rows = []
    previous_end = None
    for index, (raw_edge_id, position) in enumerate(positions.items()):
        edge_id = str(raw_edge_id)
        if edge_id not in attributes:
            raise ValueError(f"道路位置 JSON 中的道路 {edge_id} 在属性 CSV 中不存在")
        try:
            start_pos, length = float(position["start_pos"]), float(position["length"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"道路位置 JSON 中道路 {edge_id} 的位置参数无效") from exc
        if not math.isfinite(start_pos) or not math.isfinite(length) or start_pos < 0 or length <= 0:
            raise ValueError(f"道路位置 JSON 中道路 {edge_id} 的位置参数非法")
        if index == 0 and not math.isclose(start_pos, 0.0, abs_tol=1e-6, rel_tol=0.0):
            raise ValueError("道路位置 JSON 的第一条道路必须从 start_pos=0 开始")
        if previous_end is not None and not math.isclose(start_pos, previous_end, abs_tol=1e-5, rel_tol=0.0):
            raise ValueError(f"道路位置 JSON 顺序不连续：{edge_id} 从 {start_pos} 开始，上一条道路结束于 {previous_end}")
        attr = attributes[edge_id]
        rows.append(dict(edge_id=edge_id, start_pos=start_pos, length=length,
                         lane_count=attr["lane_count"], connection_count=attr["connection_count"], q=attr["q"]))
        previous_end = start_pos + length
    if not any(row["q"] > 0 for row in rows):
        raise ValueError("实验道路的放缩值全部为 0")
    return rows



def read_network(
    xml_path: Path, csv_path: Path, position_json_path: Path, vehicle: str = "passenger"
) -> dict:
    """读取实验道路的车道、限速和连接关系。"""
    road_rows = read_road_table(csv_path, position_json_path)
    requested = {row["edge_id"] for row in road_rows}
    print(f"读取路网，位置 JSON 含 {len(road_rows)} 条已排序实验道路…", flush=True)

    edges = {}
    lane_key = {}
    lane_ids = []
    lane_lengths = []
    lane_speeds = []
    lane_edge_ids = []
    context = ET.iterparse(xml_path, events=("start", "end"))
    _, root = next(context)
    for event, element in context:
        if event != "end":
            continue
        if element.tag == "edge":
            edge_id = element.get("id", "")
            lanes = []
            if (
                edge_id in requested
                and not edge_id.startswith(":")
                and element.get("function") != "internal"
            ):
                for lane in element.findall("lane"):
                    length = float(lane.get("length", "0"))
                    speed = float(lane.get("speed", "0"))
                    if length <= 0 or speed <= 0 or not lane_allowed(lane, vehicle):
                        continue
                    index = len(lane_lengths)
                    lane_key[(edge_id, lane.get("index", "0"))] = index
                    lanes.append(index)
                    lane_ids.append(lane.get("id", ""))
                    lane_lengths.append(length)
                    lane_speeds.append(speed)
                    lane_edge_ids.append(edge_id)
            if lanes:
                edges[edge_id] = (
                    element.get("from"),
                    element.get("to"),
                    tuple(lanes),
                )
            element.clear()
            root.clear()
        elif element.tag in ("junction", "connection", "tlLogic"):
            element.clear()
            root.clear()

    missing = [row["edge_id"] for row in road_rows if row["edge_id"] not in edges]
    if missing:
        preview = ", ".join(missing[:10])
        raise ValueError(
            f"道路表中有 {len(missing)} 条道路在路网中不存在或不允许 {vehicle} 通行：{preview}"
        )

    outgoing_old = [[] for _ in lane_lengths]
    for _, element in ET.iterparse(xml_path, events=("end",)):
        if element.tag == "connection":
            source_edge = element.get("from", "")
            target_edge = element.get("to", "")
            source = lane_key.get((source_edge, element.get("fromLane", "0")))
            target = lane_key.get((target_edge, element.get("toLane", "0")))
            if source is not None:
                if element.get("via"):
                    raise ValueError(
                        "路网连接含 via 内部车道，当前实现不能跳过内部距离"
                    )
                source_info = edges[source_edge]
                target_info = edges.get(target_edge)
                reverse = bool(
                    target_info
                    and source_info[0] == target_info[1]
                    and source_info[1] == target_info[0]
                )
                if element.get("dir") not in ("t", "T") and not reverse:
                    # 不保留实验道路集合以外的连接。
                    outgoing_old[source].append(-1 if target is None else target)
            element.clear()
        elif element.tag in ("edge", "junction", "tlLogic"):
            element.clear()

    edge_ids = tuple(row["edge_id"] for row in road_rows)
    rank = {edge_id: i + 1 for i, edge_id in enumerate(edge_ids)}
    live = [lane for edge_id in edge_ids for lane in edges[edge_id][2]]
    remap = {old: new for new, old in enumerate(live)}

    outgoing = []
    for old in live:
        by_edge = {}
        for target in outgoing_old[old]:
            if target < 0:
                by_edge.setdefault("__OUTSIDE__", set()).add(-1)
                continue
            target_edge = lane_edge_ids[target]
            if target_edge not in rank:
                by_edge.setdefault("__OUTSIDE__", set()).add(-1)
            else:
                by_edge.setdefault(target_edge, set()).add(remap[target])
        outgoing.append(
            tuple(tuple(sorted(values)) for _, values in sorted(by_edge.items()))
        )

    road_starts = np.asarray([row["start_pos"] for row in road_rows], dtype=np.float64)
    road_lengths = np.asarray([row["length"] for row in road_rows], dtype=np.float64)
    q = np.asarray([row["q"] for row in road_rows], dtype=np.float64)
    total_length = float(np.max(road_starts + road_lengths))
    net = dict(
        edge_ids=edge_ids,
        edge_lanes=tuple(tuple(remap[lane] for lane in edges[edge_id][2]) for edge_id in edge_ids),
        lane_ids=tuple(lane_ids[lane] for lane in live),
        lane_rank=np.asarray([rank[lane_edge_ids[lane]] for lane in live], dtype=np.int32),
        lane_lengths=np.asarray([lane_lengths[lane] for lane in live], dtype=np.float64),
        lane_speeds=np.asarray([lane_speeds[lane] for lane in live], dtype=np.float64),
        outgoing=tuple(outgoing),
        road_starts=road_starts,
        road_lengths=road_lengths,
        road_lane_counts=np.asarray([row["lane_count"] for row in road_rows], dtype=np.int32),
        road_connection_counts=np.asarray(
            [row["connection_count"] for row in road_rows], dtype=np.int32
        ),
        q=q,
        q_cumulative=np.cumsum(q),
        total_length=total_length,
        vehicle=vehicle,
    )
    print(
        f"路网读取完成：{len(edge_ids)} 条道路、{len(live)} 条可通行车道，"
        f"位置轴 [0,{total_length})",
        flush=True,
    )
    return net


def sample_hotspot_roads(
    rng: np.random.Generator, net: dict, count: int, excluded=()
) -> np.ndarray:
    """排除已有热点，按 q 不放回抽样。"""
    q = np.asarray(net["q"], dtype=np.float64)
    eligible = q > 0
    excluded = np.asarray(excluded, dtype=np.int64).ravel()
    if excluded.size:
        eligible[excluded - 1] = False
    candidates = np.flatnonzero(eligible)
    if len(candidates) < count:
        raise ValueError(
            f"可选热点道路不足：需要 {count} 条，仅剩 {len(candidates)} 条正权重道路"
        )
    probabilities = q[candidates] / q[candidates].sum()
    return (rng.choice(candidates, size=count, replace=False, p=probabilities) + 1).astype(np.int32)


def spatial_weights(hotspot_roads: np.ndarray, net: dict) -> np.ndarray:
    values = net["q"][hotspot_roads - 1].astype(np.float64)
    if values.sum() <= 0:
        raise ValueError("热点道路的 q 权重之和为 0")
    return values / values.sum()


def build_spatial_templates(net: dict, seed: int) -> dict[str, tuple]:
    road_count = len(net["edge_ids"])

    base_rng = np.random.default_rng(np.random.SeedSequence([seed, 2000, 0]))
    base_roads = sample_hotspot_roads(base_rng, net, SPATIAL_COMPONENTS)
    base = (
        spatial_weights(base_roads, net),
        base_roads.astype(np.float64),
        np.full(SPATIAL_COMPONENTS, 0.04 * road_count, dtype=np.float64),
        np.asarray([], dtype=np.int32),
    )

    # 所有周末共用同一组参数。
    weekend_rng = np.random.default_rng(np.random.SeedSequence([seed, 2000, 1]))
    weekend_roads = base_roads.copy()
    selected = np.sort(
        weekend_rng.choice(
            SPATIAL_COMPONENTS, WEEKEND_REPLACEMENTS, replace=False
        )
    )
    weekend_roads[selected] = sample_hotspot_roads(
        weekend_rng, net, WEEKEND_REPLACEMENTS, excluded=base_roads
    )
    weekend_stds = base[2].copy()
    weekend_stds[selected] = weekend_rng.uniform(0.036, 0.044, len(selected)) * road_count
    weekend = (
        spatial_weights(weekend_roads, net),
        weekend_roads.astype(np.float64),
        weekend_stds,
        selected,
    )
    return {"BASE": base, "WEEKEND": weekend}


def event_spatial_parameters(
    background: tuple, net: dict, seed: int, period: int, excluded_roads
) -> tuple:
    # 保留未选中分量的均值和标准差。
    rng = np.random.default_rng(np.random.SeedSequence([seed, 2000, 2, period]))
    roads = background[1].astype(np.int32).copy()
    selected = np.sort(
        rng.choice(SPATIAL_COMPONENTS, EVENT_REPLACEMENTS, replace=False)
    )
    roads[selected] = sample_hotspot_roads(
        rng, net, EVENT_REPLACEMENTS, excluded=excluded_roads
    )
    stds = background[2].copy()
    stds[selected] = rng.uniform(0.02, 0.06, len(selected)) * len(net["edge_ids"])
    return (
        spatial_weights(roads, net),
        roads.astype(np.float64),
        stds,
        selected,
    )


def map_time_reference(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """将 [0,44) 映射到日内时间；白天、早高峰、晚高峰、夜间密度为 2、4、4、1。"""
    means = np.empty(len(values), dtype=np.float64)
    densities = np.empty(len(values), dtype=np.float64)
    for i, value in enumerate(values):
        if value < 16:
            hours = 9 + (value / 16) * 8
            density = 2
        elif value < 24:
            hours = 7 + ((value - 16) / 8) * 2
            density = 4
        elif value < 32:
            hours = 17 + ((value - 24) / 8) * 2
            density = 4
        else:
            hours = 19 + ((value - 32) / 12) * 12
            density = 1
        means[i] = (hours * 3600) % SECONDS_PER_DAY
        densities[i] = density
    return means, densities


def create_time_template(seed: int, kind: str, period: int = 0) -> tuple:
    code = {"BASE": 0, "WEEKEND": 1, "EVENT": 2}[kind]
    rng = np.random.default_rng(
        np.random.SeedSequence([seed, 4000, code, period])
    )
    # 按中心所在时段的密度计算分量权重。
    reference_values = rng.uniform(0.0, 44.0, TIME_COMPONENTS)
    means, densities = map_time_reference(reference_values)
    weights = densities / densities.sum()
    if kind == "BASE":
        stds = np.full(TIME_COMPONENTS, 0.4 * TIME_REFERENCE)
    elif kind == "WEEKEND":
        stds = rng.uniform(0.34, 0.46, TIME_COMPONENTS) * TIME_REFERENCE
    else:
        stds = rng.uniform(0.2, 0.6, TIME_COMPONENTS) * TIME_REFERENCE
    return weights, means, stds, reference_values


def build_time_templates(seed: int) -> dict[str, tuple]:
    return {
        "BASE": create_time_template(seed, "BASE"),
        "WEEKEND": create_time_template(seed, "WEEKEND"),
    }


def event_schedule(seed: int, periods: int) -> dict[int, str]:
    event_count = min(EVENT_COUNT, max(0, periods - 1))
    if event_count == 0:
        return {}
    rng = np.random.default_rng(np.random.SeedSequence([seed, 1000]))
    selected = np.sort(
        rng.choice(np.arange(2, periods + 1), event_count, replace=False)
    )
    labels = rng.permutation(list("ABCD"))[:event_count]
    return {int(period): str(label) for period, label in zip(selected, labels)}


def build_period_parameters(
    net: dict,
    seed: int,
    periods: int,
    spatial_templates: dict,
    time_templates: dict,
) -> list[dict]:
    events = event_schedule(seed, periods)
    rows = []
    for period in range(1, periods + 1):
        background = "WEEKEND" if (period - 1) % 7 >= 5 else "BASE"
        event = events.get(period, "")
        if event:
            spatial = event_spatial_parameters(
                spatial_templates[background], net, seed, period,
                excluded_roads=np.union1d(
                    spatial_templates["BASE"][1], spatial_templates["WEEKEND"][1]
                ),
            )
            temporal = create_time_template(seed, "EVENT", period)
            distribution = event
        else:
            spatial = spatial_templates[background]
            temporal = time_templates[background]
            distribution = background
        rows.append(
            dict(
                period=period,
                background=background,
                event=event,
                distribution=distribution,
                spatial=spatial,
                temporal=temporal,
            )
        )
    return rows


def truncated_normal(
    rng: np.random.Generator, mean: float, std: float, low: float, high: float
) -> float:
    """在 [low, high) 内用拒绝抽样生成截断正态值。"""
    if not math.isfinite(mean) or not math.isfinite(std) or std <= 0:
        raise ValueError("截断高斯的均值和标准差非法")
    if not math.isfinite(low) or not math.isfinite(high) or low >= high:
        raise ValueError("截断高斯的区间非法")

    a = (low - mean) / std
    b = (high - mean) / std
    mode = min(max(0.0, a), b)
    peak_square = mode * mode
    for _ in range(100000):
        z = float(rng.uniform(a, b))
        acceptance = math.exp(min(0.0, -0.5 * (z * z - peak_square)))
        if float(rng.random()) <= acceptance:
            value = mean + std * z
            return min(max(value, low), np.nextafter(high, low))
    raise RuntimeError("截断高斯抽样未收敛，请检查均值与标准差")


def gaussian_mass(mean: float, std: float, low: float, high: float) -> float:
    a = (low - mean) / (std * math.sqrt(2))
    b = (high - mean) / (std * math.sqrt(2))
    if a >= 0:
        return 0.5 * (math.erfc(a) - math.erfc(b))
    if b <= 0:
        return 0.5 * (math.erfc(-b) - math.erfc(-a))
    return 0.5 * (math.erf(b) - math.erf(a))


def sample_start_coordinate(
    rng: np.random.Generator,
    spatial: tuple,
    road_count: int,
    forced_road: int | None = None,
) -> tuple[int, float]:
    weights, means, stds, _ = spatial
    if forced_road is None:
        component = int(rng.choice(SPATIAL_COMPONENTS, p=weights))
        coordinate = truncated_normal(
            rng, means[component], stds[component], 0.5, road_count + 0.5
        )
        road = int(math.floor(coordinate + 0.5))
        fraction = coordinate - (road - 0.5)
        return road, min(max(fraction, 0.0), np.nextafter(1.0, 0.0))

    road = int(forced_road)
    low, high = road - 0.5, road + 0.5
    masses = np.asarray(
        [gaussian_mass(mu, sigma, low, high) for mu, sigma in zip(means, stds)]
    ) * weights
    if masses.sum() <= 0:
        # 概率质量下溢时，在指定道路内均匀取点。
        return road, float(rng.random())
    component = int(rng.choice(SPATIAL_COMPONENTS, p=masses / masses.sum()))
    coordinate = truncated_normal(
        rng, means[component], stds[component], low, high
    )
    fraction = coordinate - low
    return road, min(max(fraction, 0.0), np.nextafter(1.0, 0.0))


def sample_start_time(rng: np.random.Generator, temporal: tuple) -> int:
    weights, means, stds, _ = temporal
    component = int(rng.choice(TIME_COMPONENTS, p=weights))
    seconds = int(round(float(rng.normal(means[component], stds[component]))))
    return seconds % SECONDS_PER_DAY


def routes_for_origin(net: dict, seed: int, road: int) -> tuple[tuple[int, ...], ...]:
    """以车道长度/限速为代价，执行多源 Dijkstra。"""
    lengths = net["lane_lengths"]
    speeds = net["lane_speeds"]
    ranks = net["lane_rank"]
    distance = {}
    parent = {}
    path_length = {}
    queue = []
    for lane in net["edge_lanes"][road - 1]:
        distance[lane] = float(lengths[lane] / speeds[lane])
        path_length[lane] = float(lengths[lane])
        parent[lane] = None
        heapq.heappush(queue, (distance[lane], lane))

    destinations = {}
    while queue:
        cost, lane = heapq.heappop(queue)
        if cost != distance[lane]:
            continue
        target = int(ranks[lane])
        if target != road and target not in destinations:
            destinations[target] = lane
        for group in net["outgoing"][lane]:
            for following in group:
                if following < 0:
                    continue
                candidate = cost + float(lengths[following] / speeds[following])
                if candidate < distance.get(following, float("inf")):
                    distance[following] = candidate
                    parent[following] = lane
                    path_length[following] = (
                        path_length[lane] + float(lengths[following])
                    )
                    heapq.heappush(queue, (candidate, following))

    ordered = sorted(
        destinations.values(),
        key=lambda lane: (path_length[lane], int(ranks[lane])),
    )
    if not ordered:
        lane = min(
            net["edge_lanes"][road - 1],
            key=lambda item: (lengths[item] / speeds[item], item),
        )
        return ((int(lane),),)

    rng = np.random.default_rng(np.random.SeedSequence([seed, 3000, road]))
    # 将可达终点按路径长度分组，每组抽取一个固定终点。
    groups = np.array_split(
        np.asarray(ordered), min(DESTINATIONS_PER_ROAD, len(ordered))
    )
    routes = []
    for group in groups:
        lane = int(group[int(rng.integers(len(group)))])
        path = []
        while lane is not None:
            path.append(lane)
            lane = parent[lane]
        routes.append(tuple(reversed(path)))
    return tuple(routes)


def init_worker(net: dict) -> None:
    global _NETWORK
    _NETWORK = net


def route_library_task(task: tuple[int, int]):
    seed, road = task
    return routes_for_origin(_NETWORK, seed, road)


def build_route_library(net: dict, seed: int, workers: int) -> None:
    print("建立跨周期共享的固定候选终点与最快路径库…", flush=True)
    routes = []
    tasks = ((seed, road) for road in range(1, len(net["edge_ids"]) + 1))

    def collect(iterator):
        for road, paths in enumerate(iterator, 1):
            routes.append(paths)
            if road % 1000 == 0:
                print(
                    f"路径库完成 {road}/{len(net['edge_ids'])} 条出发道路",
                    flush=True,
                )

    if workers == 1:
        collect(routes_for_origin(net, seed, road) for seed, road in tasks)
    else:
        with ProcessPoolExecutor(
            max_workers=workers,
            mp_context=mp.get_context("spawn"),
            initializer=init_worker,
            initargs=(net,),
        ) as executor:
            collect(executor.map(route_library_task, tasks, chunksize=32))
    net["route_library"] = tuple(routes)
    print(
        f"路径库完成，共 {sum(map(len, routes))} 条候选路径；所有周期共享",
        flush=True,
    )


def position_from_lane(net: dict, lane: int, offset: float) -> tuple[float, int]:
    road = int(net["lane_rank"][lane])
    road_length = float(net["road_lengths"][road - 1])
    inside = min(max(offset, 0.0), np.nextafter(road_length, 0.0))
    return float(net["road_starts"][road - 1] + inside), road


def simulate_trajectory(
    net: dict,
    seed: int,
    period: int,
    label_code: int,
    trajectory_id: int,
    spatial: tuple,
    temporal: tuple,
    max_points: int,
    interval: int,
    forced_road: int | None = None,
    forced_time: int | None = None,
    point_limit: int | None = None,
) -> np.ndarray:
    rng = np.random.default_rng(
        np.random.SeedSequence([seed, period, label_code, trajectory_id])
    )
    road_count = len(net["edge_ids"])
    road, fraction = sample_start_coordinate(
        rng, spatial, road_count, forced_road=forced_road
    )
    routes = net["route_library"][road - 1]
    route = routes[int(rng.integers(len(routes)))]  # 对该出发道路的固定候选路径等概率选择
    route_index = 0
    lane = route[route_index]
    offset = fraction * float(net["lane_lengths"][lane])
    start_time = (
        sample_start_time(rng, temporal)
        if forced_time is None
        else int(forced_time) % SECONDS_PER_DAY
    )
    desired_speed = float(rng.uniform(8.0, 12.0))  # 每条轨迹抽一次期望速度，单位 m/s
    maximum = min(max_points, point_limit) if point_limit is not None else max_points

    pos, current_road = position_from_lane(net, lane, offset)
    rows = [(pos, float(start_time), float(current_road))]
    stopped = False
    for step in range(1, maximum):
        remaining = float(interval)
        while remaining > 1e-10:
            speed = min(desired_speed, float(net["lane_speeds"][lane]))  # 不超过当前车道限速
            until_end = max(0.0, float(net["lane_lengths"][lane]) - offset) / speed
            if remaining < until_end:
                offset += remaining * speed
                remaining = 0.0
            else:
                remaining -= until_end
                if route_index + 1 >= len(route):
                    stopped = True
                    break
                route_index += 1
                lane = route[route_index]
                offset = 0.0
        if stopped:
            break
        pos, current_road = position_from_lane(net, lane, offset)
        timestamp = (start_time + step * interval) % SECONDS_PER_DAY
        rows.append((pos, float(timestamp), float(current_road)))
    return np.asarray(rows, dtype=np.float64)


def trajectory_task(task):
    (
        seed,
        period,
        label_code,
        first_id,
        count,
        spatial,
        temporal,
        maximum,
        interval,
        forced,
        forced_times,
        cap,
    ) = task
    arrays = []
    for index, trajectory_id in enumerate(range(first_id, first_id + count)):
        arrays.append(
            simulate_trajectory(
                _NETWORK,
                seed,
                period,
                label_code,
                trajectory_id,
                spatial,
                temporal,
                maximum,
                interval,
                forced_road=None if forced is None else int(forced[index]),
                forced_time=None
                if forced_times is None
                else int(forced_times[index]),
                point_limit=cap,
            )
        )
    return np.concatenate(arrays), np.asarray([len(item) for item in arrays], dtype=np.int32)


def spatial_road_probabilities(spatial: tuple, road_count: int) -> np.ndarray:
    """在道路编号处计算高斯密度，归一化得到道路概率的近似值。"""
    weights, means, stds, _ = spatial
    roads = np.arange(1, road_count + 1, dtype=np.float64)[:, None]
    z = (roads - means[None, :]) / stds[None, :]
    density = np.sum(
        np.exp(-0.5 * z * z) * (weights / stds)[None, :], axis=1
    )
    density = np.maximum(density, np.finfo(np.float64).tiny)
    return density / density.sum()


def temporal_hour_probabilities(temporal: tuple) -> np.ndarray:
    """按分钟中点积分得到小时概率，累加相邻日分布处理跨午夜部分。"""
    weights, means, stds, _ = temporal
    minute_centres = (np.arange(24 * 60, dtype=np.float64) + 0.5) * 60.0
    density = np.zeros_like(minute_centres)
    for weight, mean, std in zip(weights, means, stds):
        for shift in range(-3, 4):
            z = (minute_centres + shift * SECONDS_PER_DAY - mean) / std
            density += (weight / std) * np.exp(-0.5 * z * z)
    hourly = density.reshape(24, 60).sum(axis=1)
    hourly = np.maximum(hourly, np.finfo(np.float64).tiny)
    return hourly / hourly.sum()


def hour_index(seconds: float) -> int:
    """返回日内小时编号（0—23）。"""
    return (int(seconds) % SECONDS_PER_DAY) // 3600


def hour_indices(seconds: np.ndarray) -> np.ndarray:
    values = np.asarray(seconds, dtype=np.int64) % SECONDS_PER_DAY
    return (values // 3600).astype(np.int8)


def sample_times_in_hours(rng: np.random.Generator, hours: np.ndarray) -> np.ndarray:
    """在指定小时内抽取整数秒。"""
    hours = np.asarray(hours, dtype=np.int8)
    if np.any((hours < 0) | (hours >= 24)):
        raise ValueError("小时编号必须在 [0, 24) 内")
    low = hours.astype(np.int64) * 3600
    high = (hours.astype(np.int64) + 1) * 3600
    return rng.integers(low, high, size=len(hours))


def road_capacities(
    net: dict,
    total_points: int,
    pilot_counts: np.ndarray,
    pilot_hour_counts: np.ndarray,
    temporal: tuple,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """结合道路属性和试生成流量估计日容量，再分配到各小时。"""
    ROAD_CAP_ATTRIBUTE_EXPONENT = 0.9
    ROAD_CAP_Q_WEIGHT = 0.3
    ROAD_CAP_MAX_MEAN_MULTIPLE = 60.0
    ROAD_HOUR_SMOOTHING = 20.0
    q = np.asarray(net["q"], dtype=np.float64)
    attribute_score = np.power(q, ROAD_CAP_ATTRIBUTE_EXPONENT)
    q_probability = attribute_score / attribute_score.sum()
    route_probability = np.asarray(pilot_counts, dtype=np.float64)
    if route_probability.sum() <= 0:
        raise RuntimeError("道路容量试生成没有产生轨迹点")
    route_probability /= route_probability.sum()
    capacity_probability = (
        ROAD_CAP_Q_WEIGHT * q_probability
        + (1.0 - ROAD_CAP_Q_WEIGHT) * route_probability
    )
    capacities = np.maximum(
        1, np.ceil(ROAD_CAP_FACTOR * total_points * capacity_probability)
    ).astype(np.int32)
    maximum_capacity = int(math.ceil(ROAD_CAP_MAX_MEAN_MULTIPLE * total_points / len(q)))
    capacities = np.minimum(capacities, maximum_capacity)
    if int(capacities.astype(np.int64).sum()) < total_points:
        raise RuntimeError("道路容量总额小于当期点数，请提高容量系数")

    global_hour_probability = temporal_hour_probabilities(temporal)
    pilot_hour_counts = np.asarray(pilot_hour_counts, dtype=np.float64)
    if pilot_hour_counts.shape != (len(q), HOUR_COUNT):
        raise ValueError("试生成的道路小时计数形状错误")
    if not np.allclose(pilot_hour_counts.sum(axis=1), pilot_counts):
        raise ValueError("试生成的道路小时计数与道路总计数不一致")
    hour_probability = (
        pilot_hour_counts
        + ROAD_HOUR_SMOOTHING * global_hour_probability[None, :]
    ) / (pilot_counts[:, None] + ROAD_HOUR_SMOOTHING)
    hour_capacities = np.maximum(
        1, np.ceil(ROAD_HOUR_CAP_FACTOR * capacities[:, None] * hour_probability)
    ).astype(np.int32)
    return capacities, hour_capacities, capacity_probability, q_probability, route_probability, global_hour_probability



def generate_period(
    net: dict,
    executor,
    args,
    period: int,
    label: str,
    spatial: tuple,
    temporal: tuple,
):
    ENFORCE_ROAD_CAP = True
    ENFORCE_ROAD_HOUR_CAP = True
    ROAD_CAP_PILOT_TRAJECTORIES = 4096
    result = np.empty((args.points, 3), dtype=np.float64)
    done = 0
    next_id = 0
    generated_points = 0
    generated_tracks = 0
    used_tracks = 0
    shortened = 0
    coverage_tracks = 0
    coverage_points = 0
    quota_truncated_tracks = 0
    targeted_batches = 0
    accepted_starts = []
    label_code = {"BASE": 0, "WEEKEND": 1, "A": 2, "B": 3, "C": 4, "D": 5}[label]
    road_count = len(net["edge_ids"])
    if args.full_coverage and args.points < road_count:
        raise ValueError(f"点数 {args.points} 小于道路数 {road_count}，无法全覆盖")

    def make_tasks(batch, forced_roads=None, forced_times=None, point_cap=None):
        nonlocal next_id
        tasks = [
            (
                args.seed,
                period,
                label_code,
                next_id + index,
                min(args.task_size, batch - index),
                spatial,
                temporal,
                args.max_points,
                args.interval,
                None if forced_roads is None else forced_roads[index : index + args.task_size],
                None if forced_times is None else forced_times[index : index + args.task_size],
                point_cap,
            )
            for index in range(0, batch, args.task_size)
        ]
        next_id += batch
        return tasks

    if ENFORCE_ROAD_CAP:
        pilot_counts = np.zeros(road_count, dtype=np.int64)
        pilot_hour_counts = np.zeros(
            (road_count, HOUR_COUNT), dtype=np.int64
        )
        pilot_trajectories = min(
            ROAD_CAP_PILOT_TRAJECTORIES,
            max(256, args.points // max(args.max_points, 1)),
        )
        tasks = make_tasks(pilot_trajectories)
        iterator = (
            executor.map(trajectory_task, tasks)
            if executor
            else map(trajectory_task, tasks)
        )
        pilot_points = 0
        for data, _ in iterator:
            road_indices = data[:, 2].astype(np.int64) - 1
            pilot_counts += np.bincount(
                road_indices, minlength=road_count
            )
            hour_ids = hour_indices(data[:, 1])
            pilot_hour_counts += np.bincount(
                road_indices * HOUR_COUNT + hour_ids,
                minlength=road_count * HOUR_COUNT,
            ).reshape(road_count, HOUR_COUNT)
            pilot_points += len(data)
        (
            capacities,
            hour_capacities,
            capacity_probability,
            q_probability,
            route_probability,
            global_hour_probability,
        ) = road_capacities(
            net,
            args.points,
            pilot_counts,
            pilot_hour_counts,
            temporal,
        )
        print(
            f"  P{period}: 容量试生成 {pilot_trajectories:,} 条轨迹、"
            f"{pilot_points:,} 个点；道路容量总额 {int(capacities.sum()):,}",
            flush=True,
        )
    else:
        capacities = np.full(
            road_count, np.iinfo(np.int32).max, dtype=np.int32
        )
        q_probability = np.asarray(net["q"], dtype=np.float64)
        q_probability /= q_probability.sum()
        route_probability = q_probability.copy()
        capacity_probability = q_probability.copy()
        hour_capacities = np.full(
            (road_count, HOUR_COUNT),
            np.iinfo(np.int32).max,
            dtype=np.int32,
        )
        global_hour_probability = temporal_hour_probabilities(temporal)
        pilot_trajectories = 0
        pilot_points = 0
    used_by_road = np.zeros(road_count, dtype=np.int32)
    used_by_hour = np.zeros(
        (road_count, HOUR_COUNT), dtype=np.int32
    )

    def accept_candidates(data, lengths, is_coverage=False):
        nonlocal done, generated_points, generated_tracks, used_tracks
        nonlocal shortened, coverage_tracks, coverage_points, quota_truncated_tracks
        generated_points += len(data)
        generated_tracks += len(lengths)
        cursor = 0
        for length in lengths:
            trajectory = data[cursor : cursor + int(length)]
            cursor += int(length)
            accepted = 0
            quota_stopped = False
            first_accepted = None
            for point in trajectory:
                if done >= args.points:
                    break
                road_index = int(point[2]) - 1
                hour_id = hour_index(point[1])
                road_full = used_by_road[road_index] >= capacities[road_index]
                hour_full = (
                    ENFORCE_ROAD_HOUR_CAP
                    and used_by_hour[road_index, hour_id]
                    >= hour_capacities[road_index, hour_id]
                )
                if road_full or hour_full:
                    quota_stopped = True
                    break
                result[done] = point
                used_by_road[road_index] += 1
                used_by_hour[road_index, hour_id] += 1
                if first_accepted is None:
                    first_accepted = point[:2].copy()
                done += 1
                accepted += 1
            if quota_stopped:
                quota_truncated_tracks += 1
            if accepted:
                used_tracks += 1
                accepted_starts.append(first_accepted)
                if is_coverage:
                    coverage_tracks += 1
                    coverage_points += accepted
                if accepted < args.max_points:
                    shortened += 1

    # 先为每条道路补一个覆盖点。
    if args.full_coverage:
        forced_roads = np.arange(1, road_count + 1, dtype=np.int32)
        tasks = make_tasks(
            road_count, forced_roads=forced_roads, forced_times=None, point_cap=1
        )
        iterator = executor.map(trajectory_task, tasks) if executor else map(trajectory_task, tasks)
        for data, lengths in iterator:
            accept_candidates(data, lengths, is_coverage=True)
        if coverage_tracks != road_count:
            raise AssertionError(
                f"道路起点覆盖失败：{coverage_tracks}/{road_count}"
            )

    no_progress_batches = 0
    while done < args.points:
        # 连续三批未接收新点后，按剩余容量补点。
        targeted = no_progress_batches >= 3
        forced_roads = forced_times = None
        if targeted:
            remaining_capacity = capacities.astype(np.int64) - used_by_road
            if ENFORCE_ROAD_HOUR_CAP:
                remaining_hours = (
                    hour_capacities.astype(np.int64) - used_by_hour
                )
                effective_capacity = np.minimum(
                    remaining_hours, remaining_capacity[:, None]
                )
                positive = np.flatnonzero(effective_capacity.ravel() > 0)
                values = effective_capacity.ravel()[positive].astype(np.float64)
            else:
                positive = np.flatnonzero(remaining_capacity > 0)
                values = remaining_capacity[positive].astype(np.float64)
            if not len(positive):
                raise RuntimeError(
                    f"道路或小时容量已用完，仍缺 {args.points-done} 个点"
                )
            batch = min(args.batch, args.points - done)
            rng = np.random.default_rng(
                np.random.SeedSequence(
                    [args.seed, period, label_code, 9000, targeted_batches]
                )
            )
            chosen = rng.choice(positive, size=batch, replace=True, p=values / values.sum())
            if ENFORCE_ROAD_HOUR_CAP:
                selected_hours = (chosen % HOUR_COUNT).astype(np.int8)
                forced_roads = (
                    chosen // HOUR_COUNT + 1
                ).astype(np.int32)
                forced_times = sample_times_in_hours(rng, selected_hours)
            else:
                forced_roads = (chosen + 1).astype(np.int32)
            targeted_batches += 1
        else:
            accepted_per_track = done / generated_tracks if generated_tracks else args.max_points
            batch = min(
                args.batch,
                max(
                    1,
                    math.ceil(
                        (args.points - done) / max(accepted_per_track, 1.0)
                    ),
                ),
            )

        tasks = make_tasks(
            batch,
            forced_roads=forced_roads,
            forced_times=forced_times,
            point_cap=None,
        )
        before = done
        iterator = executor.map(trajectory_task, tasks) if executor else map(trajectory_task, tasks)
        for data, lengths in iterator:
            accept_candidates(data, lengths, is_coverage=False)
        no_progress_batches = no_progress_batches + 1 if done == before else 0
        if targeted_batches > 100 and done == before:
            raise RuntimeError(
                f"容量定向补充连续失败，仍缺 {args.points-done} 个点"
            )
        print(
            f"  P{period}: {done:,}/{args.points:,} 点",
            flush=True,
        )

    histogram = np.histogram2d(
        result[:, 0],
        result[:, 1],
        bins=args.bins,
        range=((0, net["total_length"]), (0, SECONDS_PER_DAY)),
    )[0]
    histogram /= args.points
    starts = np.asarray(accepted_starts, dtype=np.float64)
    start_histogram = np.histogram2d(
        starts[:, 0],
        starts[:, 1],
        bins=args.bins,
        range=((0, net["total_length"]), (0, SECONDS_PER_DAY)),
    )[0]
    start_histogram /= start_histogram.sum()
    order = np.lexsort((result[:, 0], result[:, 1]))
    result = result[order]
    covered = len(np.unique(result[:, 2].astype(np.int64)))
    utilization = used_by_road / capacities
    hour_utilization = used_by_hour / hour_capacities
    stats = dict(
        trajectories=used_tracks,
        generated_trajectories=generated_tracks,
        short_trajectories_including_coverage=shortened,
        mean_kept_points=args.points / used_tracks,
        coverage_supplement_trajectories=coverage_tracks,
        coverage_supplement_points=coverage_points,
        covered_roads=covered,
        road_capacity_total=int(capacities.astype(np.int64).sum()),
        road_saturated_count=int(np.count_nonzero(used_by_road >= capacities)),
        capacity_pilot_trajectories=pilot_trajectories,
        capacity_pilot_points=pilot_points,
        quota_truncated_trajectories=quota_truncated_tracks,
        quota_targeted_batches=targeted_batches,
        maximum_road_utilization=float(utilization.max()),
        mean_road_utilization=float(utilization.mean()),
        maximum_road_points=int(used_by_road.max()),
        maximum_road_capacity=int(capacities.max()),
        road_hour_saturated_count=int(
            np.count_nonzero(used_by_hour >= hour_capacities)
        ),
        maximum_road_hour_utilization=float(hour_utilization.max()),
        maximum_road_hour_points=int(used_by_hour.max()),
        maximum_road_hour_capacity=int(hour_capacities.max()),
        maximum_capacity_probability=float(capacity_probability.max()),
        maximum_q_probability=float(q_probability.max()),
        maximum_route_probability=float(route_probability.max()),
        night_probability=float(
            global_hour_probability[:7].sum() + global_hour_probability[19:].sum()
        ),
        morning_peak_probability=float(global_hour_probability[7:9].sum()),
        daytime_probability=float(global_hour_probability[9:17].sum()),
        evening_peak_probability=float(global_hour_probability[17:19].sum()),
        pos_min=float(result[:, 0].min()),
        pos_max=float(result[:, 0].max()),
        time_min=int(result[:, 1].min()),
        time_max=int(result[:, 1].max()),
    )
    if args.full_coverage and covered != road_count:
        raise AssertionError(
            f"道路覆盖检查失败：{covered}/{road_count}，拒绝写入数据"
        )
    return result[:, :2], histogram, start_histogram, stats


def clean_output_directory(directory: Path, periods: int) -> None:
    """清理旧周期文件和临时文件。"""
    directory.mkdir(parents=True, exist_ok=True)
    for pattern in ("period_*.txt", "period_*.txt.part"):
        for child in directory.glob(pattern):
            if child.is_file() or child.is_symlink():
                child.unlink()


def install_period(directory: Path, period: int, data: np.ndarray, points: int) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / f"period_{period}.txt"
    temporary = directory / f"period_{period}.txt.part"
    if temporary.exists():
        temporary.unlink()
    np.savetxt(temporary, data, delimiter=",", fmt=("%.6f", "%d"))
    temporary.replace(target)
    return target


def clock_text(seconds: float) -> str:
    value = int(round(seconds)) % SECONDS_PER_DAY
    return f"{value // 3600:02d}:{(value % 3600) // 60:02d}:{value % 60:02d}"


def generate_dataset(
    net: dict,
    executor,
    args,
    dataset: str,
    parameters: list[dict],
) -> None:
    directory = args.output_root / dataset
    events = [
        (item["period"], item["event"])
        for item in parameters
        if item["event"]
    ]
    print(f"{dataset} 事件安排：{events or '无'}", flush=True)
    if args.prepare_only:
        for item in parameters:
            clocks = ", ".join(clock_text(x) for x in item["temporal"][1])
            print(
                f"  P{item['period']:02d} {item['distribution']:<7} 时间中心 {clocks}",
                flush=True,
            )
        return

    if not args.overwrite and any(directory.glob("period_*.txt")):
        raise FileExistsError(f"已有数据，--no-overwrite 禁止覆盖：{directory}")
    clean_output_directory(directory, args.periods)

    first_histogram = None
    previous_histogram = None
    first_start_histogram = None
    previous_start_histogram = None
    for item in parameters:
        period = item["period"]
        label = item["distribution"]
        print(
            f"[{dataset}] P{period}/{args.periods} {label}，开始生成",
            flush=True,
        )
        started = time.perf_counter()
        data, histogram, start_histogram, info = generate_period(
            net,
            executor,
            args,
            period,
            label,
            item["spatial"],
            item["temporal"],
        )
        if len(data) != args.points:
            raise AssertionError(
                f"P{period} 点数错误：{len(data)} != {args.points}"
            )
        if first_histogram is None:
            first_histogram = histogram
            first_start_histogram = start_histogram
        tv_to_p1 = float(0.5 * np.abs(histogram - first_histogram).sum())
        tv_to_previous = (
            None
            if previous_histogram is None
            else float(0.5 * np.abs(histogram - previous_histogram).sum())
        )
        start_tv_to_p1 = float(
            0.5 * np.abs(start_histogram - first_start_histogram).sum()
        )
        start_tv_to_previous = (
            None
            if previous_start_histogram is None
            else float(
                0.5 * np.abs(start_histogram - previous_start_histogram).sum()
            )
        )
        target = install_period(directory, period, data, args.points)
        seconds = time.perf_counter() - started
        print(
            f"  已写入 {target}；点数={len(data):,}，道路={info['covered_roads']:,}，"
            f"平均轨迹点数={info['mean_kept_points']:.2f}，"
            f"耗时={seconds:.1f}s",
            flush=True,
        )
        previous_histogram = histogram
        previous_start_histogram = start_histogram

    expected_files = {
        directory / f"period_{period}.txt"
        for period in range(1, args.periods + 1)
    }
    actual_files = {
        item for item in directory.glob("period_*.txt") if item.is_file()
    }
    if actual_files != expected_files:
        extra = sorted(str(item) for item in actual_files - expected_files)
        missing = sorted(str(item) for item in expected_files - actual_files)
        raise AssertionError(
            f"周期 TXT 检查失败，extra={extra}，missing={missing}"
        )
    print(
        f"{dataset} 生成完成：{args.periods} 期，每期 {args.points:,} 点，"
        f"共 {args.periods * args.points:,} 点；根目录中包含 {args.periods} 个最终周期 TXT。",
        flush=True,
    )


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--network", type=Path, default=NETWORK_XML)
    parser.add_argument("--road-csv", type=Path, default=ROAD_CSV)
    parser.add_argument("--road-positions", type=Path, default=ROAD_POSITION_JSON)
    parser.add_argument("--output-root", type=Path, default=OUTPUT_ROOT)
    parser.add_argument("--workers", type=int, default=WORKERS)
    parser.add_argument("--points", type=int, default=POINTS_PER_PERIOD)
    parser.add_argument(
        "--periods",
        type=int,
        default=PERIODS,
        help="生成周期数",
    )
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--bins", type=int, default=HIST_BINS)
    parser.add_argument("--batch", type=int, default=BATCH_TRAJECTORIES)
    parser.add_argument("--task-size", type=int, default=TASK_TRAJECTORIES)
    parser.add_argument("--max-points", type=int, default=MAX_TRAJECTORY_POINTS)
    parser.add_argument("--interval", type=int, default=SAMPLE_INTERVAL)
    parser.add_argument(
        "--no-overwrite", dest="overwrite", action="store_false", default=True
    )
    parser.add_argument(
        "--no-full-coverage",
        dest="full_coverage",
        action="store_false",
        default=FULL_COVERAGE,
    )
    parser.add_argument(
        "--prepare-only",
        action="store_true",
        help="检查路网、模板和事件安排",
    )
    args = parser.parse_args()
    if (
        min(
            args.workers,
            args.points,
            args.periods,
            args.bins,
            args.batch,
            args.task_size,
            args.max_points,
            args.interval,
        )
        <= 0
        or args.seed < 0
    ):
        parser.error("数量和间隔必须为正数，seed 不能为负数")
    if not args.prepare_only and args.output_root.resolve() == OUTPUT_ROOT.resolve():
        if args.points != POINTS_PER_PERIOD or args.periods != PERIODS:
            parser.error(
                "单期或小规模测试请使用其他 --output-root，避免覆盖正式数据"
            )
    return args


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    args = parse_args()
    net = read_network(args.network, args.road_csv, args.road_positions, VEHICLE_CLASS)
    if args.full_coverage and args.points < len(net["edge_ids"]):
        raise ValueError("每期点数少于道路数，不可能完成全覆盖")

    spatial_templates = build_spatial_templates(net, args.seed)
    time_templates = build_time_templates(args.seed)
    parameters = build_period_parameters(
        net,
        args.seed,
        args.periods,
        spatial_templates,
        time_templates,
    )

    if args.prepare_only:
        generate_dataset(
            net,
            None,
            args,
            DATASET_NAME,
            parameters,
        )
        return

    build_route_library(net, args.seed, args.workers)
    init_worker(net)
    if args.workers == 1:
        generate_dataset(
            net,
            None,
            args,
            DATASET_NAME,
            parameters,
        )
    else:
        with ProcessPoolExecutor(
            max_workers=args.workers,
            mp_context=mp.get_context("spawn"),
            initializer=init_worker,
            initargs=(net,),
        ) as executor:
            generate_dataset(
                net,
                executor,
                args,
                DATASET_NAME,
                parameters,
            )


if __name__ == "__main__":
    mp.freeze_support()
    main()
