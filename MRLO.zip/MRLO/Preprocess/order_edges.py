"""道路排序"""

import xml.etree.ElementTree as ET
import pandas as pd
import os
from utils.file_utils import *
import sys

dt_num = '2000w'
data_num = 20000000
os.chdir("..")
cur_dir = os.getcwd()
print(cur_dir )
connections_info_file = r'F:\sim_data\ep\Beijing_center.net.xml'
csv_path = 'F:\两周数据集\simulation_8000\day1\\'
output_file = f'{cur_dir}\\Data\\day1.csv'
ordered_edges_file = f'{cur_dir}\\preprocess\\edges_ordered_8000.pkl'
pos_t_file = f'{cur_dir}\\Data\\{dt_num}_sim.txt'
ordered_edges_csv=f'{cur_dir}\\preprocess\\edges_ordered.csv'
rou_file="F:/sim_data/ep/routes_10000/d1_8000.rou.xml"


def get_edges_from_rou(rou_file):
    tree = ET.parse(rou_file)
    root = tree.getroot()
    edges_set = set()

    # 遍历所有 vehicle 下的 route
    for v in root.findall("vehicle"):
        route = v.find("route")
        if route is not None:
            edges = route.attrib.get("edges", "").split()
            edges_set.update(edges)
    print("共有道路数：",len(edges_set))
    return edges_set

def get_csv_edge(csv_file):
    """获取样本文件中的所有道路ID"""
    df = pd.read_csv(csv_file)
    # 分离出道路ID，现在舍去路段了
    df['edge'] = df['edgeID']
    return set(df['edge'])



def get_data(csv_path):
    """读取csv_path目录下所有CSV文件并合并为一个DataFrame"""
    data_size = 0
    data = pd.DataFrame()

    # 获取目录下所有csv文件
    file_list = [f for f in os.listdir(csv_path) if f.endswith('.csv')]
    # file_list.sort()  # 如果希望按文件名字母序/数字序排序

    print(f"发现CSV文件数量: {len(file_list)}")

    for file in file_list:
        file_path = os.path.join(csv_path, file)  # 拼接完整路径
        df = pd.read_csv(file_path)

        data_size += df.shape[0]
        print(f"{file} 已加载，当前总数据量: {data_size}")

        if not df.empty:
            data = pd.concat([data, df], ignore_index=True)
    print(f"一天的总数据量：{data_size}条")
    return


def parse_connections(file_path, edges):
    # 解析XML文件，获取所有道路的连通信息
    tree = ET.parse(file_path)
    root = tree.getroot()
    # 创建一个字典来存储连接信息
    connections_dict = {}
    # 查找所有的连接元素
    for connection in root.findall('.//connection'):
        from_id = connection.get('from')
        to_id = connection.get('to')
        if from_id not in connections_dict:
            connections_dict[from_id] = set()
        connections_dict[from_id].add(to_id)
    return connections_dict


def edge_order(connections, edges):
    '''dfs排序道路'''
    ordered_edges = []  # 排序之后的道路
    visited = set()  # 标记已访问数组
    # 随机选择一条道路
    first_edge = next(iter(edges))
    ordered_edges.append(first_edge)
    visited.add(first_edge)
    ordered_edges += dfs(first_edge, connections, edges, visited)
    for edge in connections.keys():
        if edge in edges and edge not in visited:
            ordered_edges.append(edge)
            visited.add(edge)
            ordered_edges += dfs(edge, connections, edges, visited)
    return ordered_edges


def dfs(edge, connections, edges, visited):
    ordered_edges = []
    if (("-" + edge) in connections[edge] and ("-" + edge) not in visited and ("-" + edge) in edges):
        ordered_edges.append(("-" + edge))
        visited.add(("-" + edge))
        connections[edge].remove("-" + edge)
    stack = list(set(edges) & set(connections[edge]))
    while stack:
        next_edge = stack.pop()
        if next_edge not in visited:
            visited.add(next_edge)
            ordered_edges.append(next_edge)
            if next_edge in connections.keys():
                if ("-" + edge) in connections[next_edge] and ("-" + edge) not in visited and ("-" + edge) in edges and next_edge in connections:
                    ordered_edges.append(("-" + edge))
                    visited.add(("-" + edge))
                    connections[next_edge].remove(("-" + edge))
                for con in connections[next_edge]:
                    if con not in visited and con in edges:
                        stack.append(con)
    return ordered_edges


def sort_data_by_edges(data_csv_path, sorted_edges):
    # 读取CSV文件
    df = pd.read_csv(data_csv_path)
    # 新增一列，提取纯道路ID（去掉#及后面的路段ID部分）
    df['pure_edgeID'] = df['edgeID'].apply(lambda x: x.split('#')[0])
    # 新增一列，提取路段ID
    df['segmentID'] = df['edgeID'].apply(lambda x: int(x.split('#')[1]) if '#' in x else 0)
    # 按照sorted_edges顺序排序
    sorted_df = pd.DataFrame()
    for edge in sorted_edges:
        edge_str = str(edge)
        # 找出匹配的子数据框
        temp_df = df[df['pure_edgeID'] == edge_str]
        # 按照segmentID进一步排序
        temp_df = temp_df.sort_values(by=['segmentID'])
        # 追加到结果数据框
        sorted_df = pd.concat([sorted_df, temp_df], ignore_index=True)
    # 删除临时列
    sorted_df.drop(columns=['segmentID'], inplace=True)
    return sorted_df


def main():

#     print('---------处理道路----------')
    if not os.path.exists(ordered_edges_file):
        # 获得所有道路ID
        edges = get_edges_from_rou(rou_file)
        print()
        # edges = list(map(int, edges))
        connection_info = parse_connections(connections_info_file, edges)
        ordered_edge = edge_order(connection_info, edges)
        dump_model(ordered_edge, ordered_edges_file)
    else:
        # get_data(csv_path)
        edges = get_edges_from_rou(rou_file)
        ordered_edge = load_model(ordered_edges_file)
        df = pd.DataFrame(ordered_edge, columns=['edge_id'])
        df.to_csv(ordered_edges_csv,index=False)
        print(ordered_edge)
        print(len(ordered_edge))



if __name__ == '__main__':
    main()


