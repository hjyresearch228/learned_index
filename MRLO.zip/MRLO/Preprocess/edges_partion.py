from collections import defaultdict

import numpy as np
import pandas as pd

from utils.file_utils import *
from collections import OrderedDict
#计算每个道路所包含的轨迹点数
def calculate_frequency(data_file,edges_file):
    edges=load_model(edges_file)
    print(edges)
    sort_segment = {}
    for i in range(len(edges)):
      sort_segment[edges[i]]=i+1
    print(sort_segment)
    # 创建一个defaultdict来存储频次，默认值为0
    frequency_map = defaultdict(int)
    # 打开并读取文件
    with open(data_file, 'r') as file:
        next(file)
        for line in file:
            # 拆分每一行，获取第二列的道路ID
            columns = line.strip().split()
            road_id = columns[1]  # 获取井号前的部分

            # 更新该道路ID的频次
            frequency_map[sort_segment[road_id]] += 1

    return OrderedDict(sorted(frequency_map.items(), key=lambda x: x[0]))



def partition_by_sum_fast(freq_map, num_parts):
    keys = list(freq_map.keys())
    freq_list = list(freq_map.values())
    total_sum = sum(freq_list)
    target_sum = total_sum / num_parts

    split_points=[]
    current_sum = 0
    start_index = 0
    category_id = 0

    for i in range(len(freq_list)):
        current_sum += freq_list[i]
        # 当累积值达到目标分区总和时记录分割点
        if current_sum >= target_sum and len(split_points) < num_parts - 1:
            split_points.append(keys[i])  # 在这里记录分割道路的“编号”
            current_sum = 0  # 重置累计值

    return split_points
def partition_by_sum(freq_map, num_parts):
    # 获取频次列表和原字典的键
    keys = list(freq_map.keys())
    freq_list = list(freq_map.values())
    n = len(freq_list)

    # 计算频次总和
    total_sum = sum(freq_list)

    # 计算期望每部分的总和
    target_sum = total_sum / num_parts

    # 初始化动态规划表
    dp = np.inf * np.ones((n + 1, num_parts + 1))  # dp[i][j] 表示前 i 个元素分成 j 个部分的最小误差
    dp[0][0] = 0  # 0 个元素分成 0 部分误差为 0

    # 计算累计频次和
    prefix_sum = [0] * (n + 1)
    for i in range(1, n + 1):
        prefix_sum[i] = prefix_sum[i - 1] + freq_list[i - 1]
    # 填充动态规划表
    for i in range(1, n + 1):
        for j in range(1, num_parts + 1):
            for k in range(i):
                # 计算从 k 到 i 的部分的总和
                segment_sum = prefix_sum[i] - prefix_sum[k]
                # 计算分割误差，误差为该部分总和与目标总和的差异
                dp[i][j] = min(dp[i][j], dp[k][j - 1] + abs(segment_sum - target_sum))

    result = []
    i = n
    j = num_parts
    while j > 0:
        for k in range(i - 1, -1, -1):
            segment_sum = prefix_sum[i] - prefix_sum[k]
            if dp[i][j] == dp[k][j - 1] + abs(segment_sum - target_sum):
                result.append(i)  # 只记录分区结束位置
                i = k
                j -= 1
                break

    result.reverse()
    # 去掉最后一个分区的结束位置（即总长度），只保留前 num_parts-1 个分割点
    split_points = result[:-1] if len(result) > 1 else []

    # 将索引转换为道路序号
    split_points = [keys[idx-1] for idx in split_points]

    return split_points
    # return partitions_dict

def main():
    cur_dir = os.getcwd()
    print(cur_dir)
    os.chdir("..")
    cur_dir1 = os.getcwd()
    ordered_edges_file = f'{cur_dir}\\edges_ordered_8000.pkl'
    data_file = f'{cur_dir1}\\Data\\sim_200w\\day1.txt'
    freq_map_file=f'{cur_dir}\\freq_map.pkl'
    cluster_file=f'{cur_dir}\\edges_partion.pkl'
    if not os.path.exists(freq_map_file):
        freq_map=calculate_frequency(data_file,ordered_edges_file)
        dump_model(freq_map,freq_map_file)
    else:

        freq_map=load_model(freq_map_file)



    num_parts = 10  # 想要分成的部分数量
    # 调用函数
    partitions_dict = partition_by_sum(freq_map, num_parts)
    print(partitions_dict)
    dump_model(partitions_dict,cluster_file)

    #partitions_dict:
    # key:为位置区域0-9
    #value:道路排序后的唯


if __name__ == '__main__':
    main()