import os
import pickle

def clean_file(file_path):
    """
    清空文件内容，如果文件不存在则创建。
    """
    print(file_path)
    try:
        with open(file_path, 'w') as f:
            f.truncate(0)  # 清空文件
    except Exception as e:
        print(f"无法清理文件 {file_path}，错误: {e}")


def save_sort_segs_to_file(sort_segs, filename):
    with open(filename, 'wb') as file:
        pickle.dump(sort_segs, file)

def dump_model(data, file_path):
    """
    将数据序列化保存到文件。
    :param data: 要保存的数据。
    :param file_path: 保存路径。
    """
    try:
        with open(file_path, 'wb') as f:
            pickle.dump(data, f)
    except Exception as e:
        print(f"无法保存数据到文件 {file_path}，错误: {e}")


def load_model(file_path):
    """
    从文件中加载序列化数据。
    :param file_path: 文件路径。
    :return: 加载的数据。
    """
    try:
        with open(file_path, 'rb') as f:
            return pickle.load(f)
    except Exception as e:
        print(f"无法从文件 {file_path} 加载数据，错误: {e}")
        return None
