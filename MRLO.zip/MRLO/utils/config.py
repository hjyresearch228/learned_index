"""配置文件"""
#保证数据一致性
import os
import sys
from utils import file_viewer

PAGE_SIZE = 8192  # 块大小
DATA_SIZE = 16  # 单个数据点大小



class Config(object):
    """Configuration class."""

    class __Singleton(object):
        """Singleton design pattern."""

        def __init__(self):

            self.data_dim = 2  # 数据维度
            self.T_each_dim = 240  # 每个维度的分割组数

            self.n_piecewise_models =5

            self.min_value = 0  # 每个维度的数值下界
            self.max_value = 1e50  # 每个维度的数值上界
            self.target_error=200  #误差阈值
            self.max_base_model=6 #基础模型的最大数目
            self.eta = 0.01  #
            self.lr = 1e-1
            self.gamma=1.15 #间隙因子

            self.grid_threshold=256 #网格划分数据量阈值
            self.max_regions=40 #最大分段数

            # 获取当前文件所在的绝对路径，并去掉 `\src\utils\core` 部分，得到项目的根目录路径
            self.home_dir = os.path.abspath(os.path.dirname(__file__)).replace('\\utils', '')
            self.models_dir = os.path.join(self.home_dir, 'CHD_index','CHD_models')
            # 定义模型数据存储目录
            self.data_dir = os.path.join(self.home_dir,'CHD_index','CHD_datas')
            # 定义数据存储目录 `data/`
            self.data_save = os.path.join(self.home_dir, 'CHD_dataset')

            file_viewer.detect_and_create_dir(self.home_dir)  # 确保项目根目录存在
            file_viewer.detect_and_create_dir(self.models_dir)  # 确保模型目录存在
            file_viewer.detect_and_create_dir(self.data_dir)  # 确保模型数据目录存在
            file_viewer.detect_and_create_dir(self.data_save)  # 确保数据目录存在

            # 打印初始化完成信息
            print('------------------------------------Config is initialized------------------------------------')

    # 定义 `Config` 类的单例实例
    instance = None

    def __new__(cls):
        """返回 `Config` 类的单例实例"""
        if not Config.instance:
            Config.instance = Config.__Singleton()  # 仅在首次调用时创建单例实例
        return Config.instance

    def __getattr__(self, name):
        """获取单例实例的属性"""
        return getattr(self.instance, name)

    def __setattr__(self, name):
        """设置单例实例的属性"""
        return setattr(self.instance, name)
