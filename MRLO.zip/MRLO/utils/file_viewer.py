import os  # 导入os模块，用于与操作系统交互，处理文件和目录
import shutil  # 导入shutil模块，用于执行高级文件操作，如删除目录
import struct  # 导入struct模块，用于与C风格的二进制数据进行交互

# 加载文件内容，返回每行去除首尾空格的列表
def load_list(path):
    with open(path, 'r') as reader:  # 打开文件进行读取
        lines = reader.readlines()  # 读取所有行
    res = [s.strip() for s in lines]  # 对每一行去除首尾空白字符
    return res  # 返回处理后的列表

# 检查目录是否存在，如果不存在则创建该目录
def detect_and_create_dir(dir: str):
    if not os.path.exists(dir):  # 如果目录不存在
        os.makedirs(dir)  # 创建目录及必要的父目录

# 检查目录是否存在，如果存在则删除该目录及其中的所有内容
def detect_and_delete_dir(dir: str):
    if os.path.exists(dir):  # 如果目录存在
        shutil.rmtree(dir)  # 删除目录及其中的所有内容（包括子目录和文件）

# 检查目录是否存在，如果存在且为空，则删除该目录
def detect_and_delete_empty_dir(dir: str):
    if os.path.exists(dir):  # 如果目录存在
        os.removedirs(dir)  # 删除空目录

# 将字节数据写入指定路径的文件
def save_bytes_file(src: str, buffer: bytes):
    with open(src, 'wb+') as writer:  # 以二进制写入模式打开文件
        writer.write(buffer)  # 将字节数据写入文件

# 从指定路径的二进制文件中读取数据，并使用指定格式解包为元组
def load_bytes_file(src: str, fmt: str) -> tuple:
    with open(src, 'rb') as reader:  # 以二进制读取模式打开文件
        content = reader.read()  # 读取所有二进制数据
    tuple_ = struct.unpack(fmt, content)  # 使用指定格式解包数据
    return tuple_  # 返回解包后的元组

# 从指定路径的二进制文件中读取数据，使用指定格式解包并返回列表
def load_bytes_list(src: str, fmt: str) -> list:
    with open(src, 'rb') as reader:  # 以二进制读取模式打开文件
        content = reader.read()  # 读取所有二进制数据
    ele_num = int(len(content) / 4)  # 计算元素个数，假设每个元素是4字节
    tuple_ = struct.unpack(fmt * ele_num, content)  # 使用格式字符串解包数据
    return list(tuple_)  # 将解包后的元组转换为列表并返回


