"""MRLO 消融实验入口。"""

import csv
import gc
import importlib
import json
import logging
import os
import sys
import time
from multiprocessing import Pool
from pathlib import Path


MODEL_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = MODEL_DIR.parent
DATA_ROOT = Path(r"D:\MRLO - 副本")
QUERY_ROOT = Path(r"E:\Com_data")
OUTPUT_ROOT = PROJECT_ROOT / "benchmark_results" / "ablation"

EXPERIMENTS = (
    {"target": "CHD", "periods": 14, "target_error": 200},
    {"target": "SIM", "periods": 14, "target_error": 250},
)
REGIONS = tuple(range(1, 11))
VARIANTS = ("no_combination", "no_layout")
NUM_PROCESSES = 5

core = None
active_variant = None
last_reuse_kind = None


def ablation_reuse(t, c, current_maps, pool_ids, prediction_cache):
    global last_reuse_kind
    last_reuse_kind = None
    np = core.np
    config = core.Config()
    target_error = config.target_error
    expected = np.floor(np.arange(len(current_maps)) * config.gamma).astype(core.NP_IDX_TYPE)
    if not pool_ids:
        return None

    candidates = []
    split_indices = {}
    for mid in pool_ids:
        predictions, indices = core.candidate_prediction(mid, t, c, current_maps, prediction_cache)
        split_indices[mid] = indices
        error = float(np.max(np.abs(predictions - expected)))
        if error <= target_error:
            last_reuse_kind = "SINGLE"
            return {"mode": "SINGLE", "id": mid, "data_num": len(current_maps),
                    "base_sp_idxs": split_indices, "max_err": error}
        candidates.append({"id": mid, "preds": predictions, "error": error})

    if active_variant == "no_combination":
        best = min(candidates, key=lambda item: item["error"])
        error, positions = core.optimize_current_layout(best["preds"], t, c)
        if error > target_error:
            return None
        optimizer = core.AdaptivePiecewiseOptimizer(
            [best["id"]], target_error, config.max_regions)
        optimizer.params = np.array([0.0, 1.0])
        optimizer.knots = []
        optimizer.epsilon = error
        last_reuse_kind = "SINGLE_LAYOUT"
        return {"mode": "COMBINATION_LAYOUT", "optimizer": optimizer,
                "PL": positions, "data_num": len(current_maps),
                "base_sp_idxs": split_indices}

    if active_variant != "no_layout":
        raise ValueError(f"未知消融配置：{active_variant}")

    for item in candidates:
        item["score"] = 1.0 / (1.0 + np.var(expected - item["preds"]))
    candidates.sort(key=lambda item: item["score"], reverse=True)
    selected_ids = []
    selected_preds = []
    for item in candidates:
        selected_ids.append(item["id"])
        selected_preds.append(item["preds"])
        matrix = np.vstack(selected_preds).T
        optimizer = core.AdaptivePiecewiseOptimizer(
            selected_ids[:], target_error, config.max_regions)
        _, error, _ = optimizer.fit(current_maps, matrix, expected)
        if error <= target_error:
            last_reuse_kind = "COMBINATION"
            return {"mode": "COMBINATION", "optimizer": optimizer,
                    "data_num": len(current_maps), "base_sp_idxs": split_indices}
    return None


def set_paths(exp, variant):
    global core, active_variant
    sys.path.insert(0, str(PROJECT_ROOT))
    sys.path.insert(0, str(MODEL_DIR))
    os.chdir(DATA_ROOT)
    core = importlib.import_module("MRLO")
    active_variant = variant
    root = OUTPUT_ROOT / exp["target"] / variant
    config = core.Config()
    config.models_dir = str(root / "models")
    config.data_dir = str(root / "datas")
    config.data_save = str(root / "dataset")
    config.target_error = exp["target_error"]
    core.try_evolutionary_reuse = ablation_reuse


def prepare_run(exp, variant, processes):
    root = OUTPUT_ROOT / exp["target"] / variant
    if root.exists() and any(root.iterdir()):
        raise FileExistsError(f"结果目录非空：{root}")

    dataset_root = DATA_ROOT / "DATA" / exp["target"]
    partition_file = dataset_root / "edges_partion.pkl"
    if not partition_file.is_file():
        raise FileNotFoundError(partition_file)
    for period in range(1, exp["periods"] + 1):
        for region in REGIONS:
            path = dataset_root / f"Day_{period}" / f"{period}_{region}.txt"
            if not path.is_file():
                raise FileNotFoundError(path)
        query_dir = QUERY_ROOT / exp["target"] / f"EP{period}"
        for name in ("point_query.txt", "range_query.txt"):
            path = query_dir / name
            if not path.is_file():
                raise FileNotFoundError(path)

    for name in ("models", "datas", "dataset", "logs"):
        (root / name).mkdir(parents=True, exist_ok=True)
    set_paths(exp, variant)
    partitions = core.load_model(str(partition_file))
    if len(partitions) < max(REGIONS):
        raise ValueError(f"分区边界数量不足：{partition_file}")
    config = core.Config()
    settings = dict(exp, variant=variant, regions=REGIONS,
                    processes=processes, k=config.max_base_model,
                    gamma=config.gamma, max_regions=config.max_regions,
                    data_root=str(DATA_ROOT), query_root=str(QUERY_ROOT))
    (root / "experiment_config.json").write_text(
        json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")
    return root, partitions


def process_region(job, exp, variant, partitions):
    global last_reuse_kind
    period, region = job
    root = OUTPUT_ROOT / exp["target"] / variant
    logging.basicConfig(
        level=logging.INFO,
        format=f"REGION_{region} - %(levelname)s - %(message)s",
        handlers=[logging.FileHandler(root / "logs" / f"region_{region}.log", encoding="utf-8")],
        force=True)
    core.MAX_EG = partitions[region - 1] + 1
    core.MIN_EG = 1 if region == 1 else partitions[region - 2]
    core.Point.max_pos = -1.0
    core.Point.min_pos = float("inf")
    core.Point.maxTime = 0
    core.Point.minTime = float("inf")
    last_reuse_kind = None

    start = time.perf_counter()
    core.MRLO_BIULD(period, region, exp["target"], flag=1)
    elapsed = time.perf_counter() - start

    config = core.Config()
    model_dir = Path(config.models_dir) / str(period) / f"{period}_{region}"
    strategy = json.loads((model_dir / "reuse_strategy.txt").read_text(encoding="utf-8"))
    mode = "BASE" if strategy["mode"] == "BASE" else last_reuse_kind
    if mode is None:
        raise RuntimeError(f"无法确定第 {period} 期区域 {region} 的消融策略")
    error_path = (Path(config.data_dir) / str(period) / f"{period}_{region}" /
                  "model_maxloss.npy") if mode == "BASE" else model_dir / "model_params" / "epsilon.npy"
    max_error = float(core.np.asarray(core.np.load(error_path)).reshape(-1)[0])
    gc.collect()
    return {"region": region, "strategy": mode, "max_error": max_error,
            "build_seconds": elapsed}


def clear_query_cache():
    core.buffer.memory_page_ids.clear()
    core.buffer.memory_page_data.clear()
    core.IO = 0


def query_period(period, partitions, target):
    query_dir = QUERY_ROOT / target / f"EP{period}"
    point_queries = core.get_query(str(query_dir / "point_query.txt"))
    range_queries = core.get_query(str(query_dir / "range_query.txt"))
    if not point_queries or not range_queries:
        raise ValueError(f"第 {period} 期查询文件为空")

    manager = core.MRLOGlobalQueryManager(period, partitions, core.Config().data_dir)
    clear_query_cache()
    start = time.perf_counter()
    point_hits = sum(manager.global_point_query(p[0], p[1]) is not None for p in point_queries)
    point_seconds = time.perf_counter() - start
    point_io = core.IO
    del manager

    manager = core.MRLOGlobalQueryManager(period, partitions, core.Config().data_dir)
    clear_query_cache()
    start = time.perf_counter()
    result_count = sum(len(manager.global_range_query(q[0], q[2], q[1], q[3]))
                       for q in range_queries)
    range_seconds = time.perf_counter() - start
    range_io = core.IO
    del manager
    clear_query_cache()
    return {"point_query_count": len(point_queries), "point_hits": point_hits,
            "point_total_io": point_io, "point_avg_io": point_io / len(point_queries),
            "point_avg_seconds": point_seconds / len(point_queries),
            "range_query_count": len(range_queries), "range_result_count": result_count,
            "range_total_io": range_io, "range_avg_io": range_io / len(range_queries),
            "range_avg_seconds": range_seconds / len(range_queries)}


def append_csv(path, row):
    new_file = not path.exists()
    with path.open("a", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(row))
        if new_file:
            writer.writeheader()
        writer.writerow(row)


def save_period_results(exp, variant, period, results, wall_seconds, partitions):
    root = OUTPUT_ROOT / exp["target"] / variant
    for result in sorted(results, key=lambda item: item["region"]):
        append_csv(root / "region_metrics.csv", dict(
            target=exp["target"], variant=variant, period=period, **result))

    counts = {mode: sum(result["strategy"] == mode for result in results)
              for mode in ("BASE", "SINGLE", "COMBINATION", "SINGLE_LAYOUT")}
    query_metrics = query_period(period, partitions, exp["target"])
    row = dict(target=exp["target"], variant=variant, period=period,
               target_error=exp["target_error"], k=core.Config().max_base_model,
               region_seconds_sum=sum(result["build_seconds"] for result in results),
               period_wall_seconds=wall_seconds,
               base_regions=counts["BASE"], single_regions=counts["SINGLE"],
               combination_regions=counts["COMBINATION"],
               single_layout_regions=counts["SINGLE_LAYOUT"], **query_metrics)
    append_csv(root / "period_metrics.csv", row)
    print(f"{exp['target']} | {variant} | 第 {period} 期 | "
          f"区域构建时间之和 {row['region_seconds_sum']:.2f}s | "
          f"点查询 I/O {row['point_avg_io']:.3f} | "
          f"范围查询 I/O {row['range_avg_io']:.3f}", flush=True)
    gc.collect()


def main():
    for exp in EXPERIMENTS:
        for variant in VARIANTS:
            root, partitions = prepare_run(exp, variant, processes=1)
            for period in range(1, exp["periods"] + 1):
                start = time.perf_counter()
                results = [process_region((period, region), exp, variant, partitions)
                           for region in REGIONS]
                wall_seconds = time.perf_counter() - start
                save_period_results(exp, variant, period, results, wall_seconds, partitions)
            print(f"结果已保存：{root}", flush=True)


def main1():
    for exp in EXPERIMENTS:
        for variant in VARIANTS:
            root, partitions = prepare_run(exp, variant, processes=NUM_PROCESSES)
            print(f"开始 {exp['target']} / {variant}，进程数：{NUM_PROCESSES}", flush=True)
            with Pool(NUM_PROCESSES, initializer=set_paths, initargs=(exp, variant)) as pool:
                for period in range(1, exp["periods"] + 1):
                    jobs = [((period, region), exp, variant, partitions) for region in REGIONS]
                    start = time.perf_counter()
                    results = pool.starmap(process_region, jobs)
                    wall_seconds = time.perf_counter() - start
                    save_period_results(exp, variant, period, results, wall_seconds, partitions)
            print(f"结果已保存：{root}", flush=True)


if __name__ == "__main__":
    main1()
