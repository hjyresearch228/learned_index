
import os
import time
import numpy as np
import pandas as pd
from scipy.optimize import linprog
import time

from utils.config import Config
NP_DATA_TYPE = np.float64
NP_IDX_TYPE = np.int64
def ceil(x):
    if x == int(x):
        return int(x)
    return int(x) + 1 if x > 0 else int(x)-1

MODEL_INDICES = [1,2,4,5]
def load_data(cur_dir, t='9'):
    """加载用户提供的所有数据文件 """
    paths = [
        os.path.join(cur_dir, 'later_pre', f'{t}_1', f'pre_idxs{i}.csv') for i in MODEL_INDICES
    ]
    maps_path = os.path.join(cur_dir, 'later_pre', f'{t}_1', 'maps.csv')

    try:
        arrays = [pd.read_csv(p, header=None).values.flatten() for p in paths]
        D_preds = np.vstack(arrays).T  # Shape: (N, K) -> K=6个旧模型的预测结果
        N = D_preds.shape[0]
        # Y_true = np.arange(0, N, dtype=np.int32)
        Y_true=np.floor(np.arange(N) * Config().gamma).astype(NP_IDX_TYPE)
        X_maps = pd.read_csv(maps_path, header=None).values.flatten()

        # 确保数据长度一致
        if len(Y_true) != len(X_maps) or len(Y_true) != D_preds.shape[0]:
            min_len = min(len(Y_true), len(X_maps), D_preds.shape[0])
            Y_true = Y_true[:min_len]
            X_maps = X_maps[:min_len]
            D_preds = D_preds[:min_len, :]

        return X_maps, D_preds, Y_true

    except FileNotFoundError as e:
        print(f"错误：文件未找到。")



def ceil(x):
    if x == int(x):
        return int(x)
    return int(x) + 1 if x > 0 else int(x) - 1




class AdaptivePiecewiseOptimizer: #不进行精简回溯，找CCD最小
    def __init__(self, base_model, target_err, max_regions=5):
        self.K = len(base_model)  # 旧模型数量
        self.reuse_model = base_model
        self.max_regions = max_regions  # 最大区域限制
        self.knots = []  # 分区边界
        self.params = None
        self.epsilon = None  # 最小最大误差
        self.target_err = target_err
        self.X_min = None
        self.X_max = None

        # 利用独特的区间元组 (low_bound, high_bound) 作为字典 Key，不重复计算历史分段
        self.history_cache = {}

    def _get_region_index(self, X_map):
        """根据 X_map 值 and 自适应节点，确定数据点所属区域 [0, M-1]"""
        if not self.knots:
            return np.zeros_like(X_map, dtype=int)
        return np.searchsorted(self.knots, X_map)

    def _solve_lp_for_region(self, region_D, region_Y):
        """
        只针对单一分段内的数据独立求解线性规划 (最小化当前段的最大绝对误差)
        """
        N_r = region_D.shape[0]
        if N_r == 0:
            return np.zeros(self.K + 1, dtype=np.float64)
        K = region_D.shape[1]

        # 变量定义: [beta_m, w_1, ..., w_K, epsilon_local]
        c = np.zeros(K + 2)
        c[-1] = 1.0  # 本地优化目标

        # 约束条件构建
        A_ub = np.zeros((2 * N_r, K + 2))
        b_ub = np.zeros(2 * N_r)

        A_ub[:N_r, 0] = 1.0  # beta
        A_ub[:N_r, 1:K + 1] = region_D  # w
        A_ub[:N_r, -1] = -1.0  # -epsilon_local
        b_ub[:N_r] = region_Y

        A_ub[N_r:, 0] = -1.0
        A_ub[N_r:, 1:K + 1] = -region_D
        A_ub[N_r:, -1] = -1.0
        b_ub[N_r:] = -region_Y

        # 变量边界: 历史复用权重 w >= 0 死守严格单调性底线
        bounds = [(None, None)] + [(0, None)] * K + [(0, None)]

        res = linprog(
            c, A_ub=A_ub, b_ub=b_ub, bounds=bounds,
            method='highs',
            options={'threads': 1, 'presolve': True}
        )

        if res.success:
            return res.x[:-1].astype(np.float64)
        else:
            fallback = np.zeros(K + 1, dtype=np.float64)
            fallback[1:] = 1.0 / K
            return fallback

    def _smooth_data(self, data, window_size=5):
        """应用移动平均平滑数据"""
        return pd.Series(data).rolling(window=window_size, center=True, min_periods=1).mean().values

    def _rebuild_and_align_params(self, X_map, D_preds, Y_true):

        M = len(self.knots) + 1
        flat_list = []

        for m in range(M):
            low_bound = self.knots[m - 1] if m > 0 else X_map[0]
            high_bound = self.knots[m] if m < len(self.knots) else X_map[-1] + 1e-6

            key = (float(low_bound), float(high_bound))

            # 增量策略：只要边界没变（没被切到），说明是历史段，直接复用，绝不重复调用 LP
            if key in self.history_cache:
                w_opt = self.history_cache[key]
            else:
                idx = (X_map >= low_bound) & (X_map < high_bound)
                w_opt = self._solve_lp_for_region(D_preds[idx], Y_true[idx])
                self.history_cache[key] = w_opt

            flat_list.append(w_opt)

        return np.concatenate(flat_list)

    def fit(self, X_map_full, D_preds_full, Y_true_full):
        """
        自适应切分过程
        """
        start_time = time.time()
        self.X_min = X_map_full.min()
        self.X_max = X_map_full.max()

        sort_indices = np.argsort(X_map_full)
        X_map = X_map_full[sort_indices]
        D_preds = D_preds_full[sort_indices, :]
        Y_true = Y_true_full[sort_indices]
        N = len(Y_true)

        # 初始化
        self.knots = []
        self.history_cache.clear()

        self.params = self._rebuild_and_align_params(X_map, D_preds, Y_true)

        residuals_all_k = Y_true[:, None] - D_preds
        avg_residual = np.mean(residuals_all_k, axis=1)
        avg_residual_smoothed = self._smooth_data(avg_residual, window_size=max(5, int(N / 1000)))

        iteration = 0
        while True:
            # 计算当前划分下，全盘真正的每个数据点的绝对残差
            Y_pred_current = self.predict(X_map, D_preds)
            all_errors = np.abs(Y_true - Y_pred_current)
            self.epsilon = ceil(np.max(all_errors))


            if len(self.knots) + 1 >= self.max_regions or self.epsilon <= self.target_err:
                break

            regions = self._get_region_index(X_map)

            global_max_error_idx = np.argmax(all_errors)

            m_star = regions[global_max_error_idx]

            mask_m_star = (regions == m_star)
            indices_m_star = np.where(mask_m_star)[0]
            N_m = len(indices_m_star)

            search_start_idx = max(1, int(N_m * 0.30))
            search_end_idx = min(N_m - 1, int(N_m * 0.70))

            if search_end_idx <= search_start_idx:
                break

            X_residual = avg_residual_smoothed[indices_m_star]
            search_step = max(1, int(N_m * 0.001))

            min_mse = float('inf')
            best_split_idx = -1
            for m in range(search_start_idx, search_end_idx + 1, search_step):
                X1 = X_residual[:m]
                X2 = X_residual[m:]
                mse_score = (m * np.var(X1)) + ((N_m - m) * np.var(X2))
                if mse_score < min_mse:
                    min_mse = mse_score
                    best_split_idx = m

            X_map_m_star = X_map[indices_m_star]
            candidate_knot = X_map_m_star[best_split_idx]

            # 插入并更新参数
            if candidate_knot is not None and candidate_knot not in self.knots:
                self.knots.append(candidate_knot)
                self.knots.sort()  # 全局重新洗牌对齐
                self.params = self._rebuild_and_align_params(X_map, D_preds, Y_true)
            else:
                break

            iteration += 1

        Y_pred_final = self.predict(X_map, D_preds)
        self.epsilon = ceil(np.max(np.abs(Y_true - Y_pred_final)))

        return self.params, self.epsilon, self.knots

    def predict(self, X_map, D_preds):
        if self.params is None:
            return None
        N = len(X_map)

        max_m_idx = (len(self.params) // (self.K + 1)) - 1
        regions = self._get_region_index(X_map)
        regions = np.clip(regions, 0, max_m_idx)

        Y_pred = np.zeros(N)
        for i in range(N):
            m = regions[i]
            start_idx = m * (self.K + 1)
            beta_m = self.params[start_idx]
            w_m = self.params[start_idx + 1: start_idx + 1 + self.K]

            val = beta_m + np.dot(w_m, D_preds[i, :])
            Y_pred[i] = max(0, val)

        return np.ceil(Y_pred).astype(int)




def ceil(x):
    if x == int(x):
        return int(x)
    return int(x) + 1 if x > 0 else int(x) - 1


def save_apt_model_params(optimizer, model_dir,base_model_sp_idxs):
    """
    将模型参数分开存储为独立的二进制文件，确保极致性能。
    """
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)

    # 存储模型参数
    np.save(os.path.join(model_dir, 'base_model.npy'), np.array(optimizer.reuse_model))
    np.save(os.path.join(model_dir, 'knots.npy'), np.array(optimizer.knots))
    np.save(os.path.join(model_dir, 'params.npy'), optimizer.params)
    np.save(os.path.join(model_dir, 'epsilon.npy'), np.array([optimizer.epsilon]))
    np.save(os.path.join(model_dir, 'all_base_sp_idxs.npy'), base_model_sp_idxs)


def load_apt_model_params(model_dir):
    """
    从目录中分别加载各个 NPY 文件并重建优化器对象。
    """
    # 加载标量并取回数值
    base_model = np.load(os.path.join(model_dir, 'base_model.npy'))
    knots = np.load(os.path.join(model_dir, 'knots.npy')).tolist()
    params = np.load(os.path.join(model_dir, 'params.npy'))
    epsilon = int(np.load(os.path.join(model_dir, 'epsilon.npy'))[0])

    # 实例化并复原
    opt = AdaptivePiecewiseOptimizer(base_model,Config().target_error)
    opt.knots = knots
    opt.params = params
    opt.epsilon = epsilon
    return opt



if __name__ == '__main__':
    os.chdir('..')
    cur_dir = os.getcwd()
    t = '6'
    MODEL_DIR = os.path.join(cur_dir, 'pre_test_j', f'{t}_1', 'omp', 'model_params')
    pre_csv_path = os.path.join(cur_dir, 'pre_test_j', f'{t}_1', 'omp', 'p.csv')
    # 加载数据
    X_map, D_preds, Y_true = load_data(cur_dir, t)

    # 训练模型
    print("--- 开始自适应分段训练 (分开存储模式) ---")
    t1=time.time()
    optimizer = AdaptivePiecewiseOptimizer(MODEL_INDICES,Config().target_error, max_regions=40)
    optimizer.fit(X_map, D_preds, Y_true)
    t2=time.time()
    print("模型运行时间：",t2-t1)
    save_apt_model_params(optimizer, MODEL_DIR,MODEL_INDICES)

    loaded_opt = load_apt_model_params(MODEL_DIR)
    Y_pred = loaded_opt.predict(X_map, D_preds)

    pd.DataFrame(Y_pred).to_csv(pre_csv_path, index=False, header=False)
    error = np.abs(Y_true - Y_pred)
    print(f"\n" + "=" * 40)
    print(f"最终理论误差 (Epsilon): {loaded_opt.epsilon}")
    print(f"实际运行最大残差: {np.max(error)}")
    print("=" * 40)
