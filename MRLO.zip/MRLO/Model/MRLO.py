import bisect
import csv
import json
import logging
import math
import os
import struct
import time
import struct as st

import logging
from utils.config import Config
import numpy as np
from numpy import random
from utils import file_viewer
from utils import common_utils
from Dp import frechet_distance
import utils.hilbertFromGithub as hbg

from PLModle1 import PiecewiseModel
from utils.file_utils import load_model, dump_model
from PLC import AdaptivePiecewiseOptimizer,load_apt_model_params,save_apt_model_params

NP_DATA_TYPE = common_utils.NP_DATA_TYPE
NP_IDX_TYPE = common_utils.NP_IDX_TYPE

#网格范围
BLOCK_SIZE=512 #逻辑块存储的点数目，一个二位点16B，一个逻辑块存储8kb
MIN_TIME=0
MAX_TIME=86400
global MAX_EG,MIN_EG


class ModelParameters:
    '''
    用来封装训练后模型的参数
    '''

    def __init__(self, data_dir,piecewise_models_dir):
        # 改为初始化空列表，不再使用 np.zeros
        self.Alphas = []
        self.Betas = []


        for i in range(Config().n_piecewise_models):
            model_dir = os.path.join(piecewise_models_dir, str(i))
            # model_path = os.path.join(model_dir, 'model.npy')
            alphas_path = os.path.join(model_dir, 'alphas.npy')
            betas_path = os.path.join(model_dir, 'betas.npy')

            if os.path.exists(alphas_path) and os.path.exists(betas_path):
                # 直接 append 加载的数组，每个数组的长度可以不同
                # data = np.load(model_path, allow_pickle=True).item()
                # self.Alphas.append(data["alphas"])
                # self.Betas.append(data["betas"])
                self.Alphas.append(np.load(alphas_path))
                self.Betas.append(np.load(betas_path))

            else:
                # 如果模型不存在，存入 None 或者 0 长度数组，保持索引对齐
                self.Alphas.append(None)
                self.Betas.append(None)

        self.x_scale = self._load_npy(data_dir, 'x_scale.npy')
        self.y_scale = self._load_npy(data_dir, 'y_scale.npy')
        self.model_sp_mps = self._load_npy(data_dir, 'model_sp_mps.npy')  # 模型分割映射值
        self.col_split_idxs = self._load_npy(data_dir, 'col_split_idxs.npy')  # 模型分割索引值
        self.col_min_map=self._load_npy(data_dir,'Pmodel_min_map.npy')




    def _load_npy(self, directory, filename):
        full_path = os.path.join(directory, filename)
        if not os.path.exists(full_path):
            raise FileNotFoundError(f"文件未找到: {full_path}")
        return np.load(full_path, allow_pickle=True)

    def __repr__(self):
        return f"ModelParameters(keys={list(self.__dict__.keys())})"

class Block:
    def __init__(self, max_size, b_id, s_id):
        self.block_id = -1  # 逻辑块号
        self.storage_id = -1  # 存储块号
        self.hilbert_keys = []  # 存储Hilbert序号的列表
        self.points_list = []  # 存储每个Hilbert序号对应的点列表
        self.points_count = 0  # 当前逻辑块中的点数量总和
        self.max_size = max_size  # 逻辑块的最大容量
        self.block_id = b_id
        self.storage_id = s_id

    def add_grid(self, hilbert_key, points):
        """将一个新的网格及其点列表添加到逻辑块中"""
        if self.points_count + len(points) <= self.max_size:
            self.hilbert_keys.append(hilbert_key)
            # for p in points:
            #     self.points_list.append(p)
            self.points_list.append(points)
            self.points_count += len(points)
            return True
        else:
            return False

    def is_full(self):
        """检查逻辑块是否达到最大容量"""
        return self.points_count >= self.max_size



    def __str__(self):
        """打印逻辑块的详细信息"""
        details = (f"Block ID: {self.block_id}\n"
                   f"Storage ID: {self.storage_id}\n"
                   f"Hilbert Keys: {self.hilbert_keys}\n"
                   f"Total Points: {self.points_count}/{self.max_size}\n"
                   "Points List:\n")
        for key, points in zip(self.hilbert_keys, self.points_list):
            for p in points:
                details += f"  Hilbert Key: {key}, Points: {p.pos}\n"


class Point:
    # 用来存储当前路段中间的边界
    maxX = -1
    maxY = -1
    minX = float('inf')
    minY = float('inf')
    maxHilbert = 0
    minHilbert = float('inf')
    maxTime = 0  # 所有数据点t的最大值
    minTime = float('inf')  # 所有数据点t的最小值
    # pos的边界
    max_pos = -1.0
    min_pos = float('inf')

    # 轨迹点的定义方式
    def __init__(self, x, y):
        '''
        :param x: 经度
        :param y: 纬度
        '''
        # x为经度，y为纬度,希尔伯特值和时间戳默认为-1
        self.x = x
        self.y = y
        self.time = None
        self.hilbert = None
        self.hilbert_id = None
        self.traId = None
        self.SortId = None
        self.edgeId = None
        self.nearEdge = set()
        self.pos = None  # segmentId.pos
        self.mapping=None

    def __eq__(self, other):
        '''
        判断两个对象是否相同
        :param other: 要比较的对象
        :return: Bool类型
        '''
        return self.x == other.x and self.y == other.y and self.time == other.time

    def __hash__(self):
        return hash(self.x) * hash(self.y) + hash(self.time)

    def __lt__(self, other):
        if self.x < other.x:
            return True
        elif self.x == other.x:
            if self.y <= other.y:
                return True
            else:
                return False
        else:
            return False

    def __str__(self):
        return str(self.x) + ',' + str(self.y) + ',' + str(self.time)
#  二维坐标样本点
class Sample:
    def __init__(self, pos, time):
        self.pos = pos
        self.time = time
        self.x = None
        self.y = None
        self.id = None
        self.hilbert = None
        self.mapping=None
        self.addr = None

    def __eq__(self, other):
        '''
        判断两个对象是否相同
        :param other: 要比较的对象
        :return: Bool类型
        '''
        return self.pos == other.pos and self.time == other.time

    def __hash__(self):
        return hash(self.pos) * hash(self.time)
class P:
    Expend = 1
    Dat = 'Period1.dat'
    # 以下参数boost中会用到
    FirstSuccessNum = 0
    SecondSuccessNum = 0
    ThirdSuccessNum = 0
    OutDataNum = 0

class DataBlock:
    DataMaxBlock = 0  # 数据存储的块数
    OutDataBlockSize = 0  # 溢出块的个数
    BlockSize = 512  # 块容量
    BlockSize2 = 4



class buffer:
    '''
    缓存空间设置
    '''
    memory_page_ids = []
    memory_page_data = {}

def read_datasets(path):
    '''
    读取制表符分割的TXT数据集，提取第2列为时间，第1列为位置
    :param path: txt文件路径
    :return: List[Sample]
    '''
    datasets = []

    with open(path, 'r', encoding='utf-8-sig') as fo:  # 加上 encoding 防乱码
        for line in fo:
            if not line.strip():
                continue  # 跳过空行
            parts = line.strip().split(',')
            if len(parts) < 2:
                continue  # 跳过字段不足的行

            try:
                p = Sample(float(parts[0]), float(parts[1]))  # 第1列是pos，第2列是t
                # 更新Point类中的全局最大/最小
                Point.max_pos = max(Point.max_pos, p.pos)
                Point.min_pos = min(Point.min_pos, p.pos)
                Point.maxTime = max(Point.maxTime, p.time)
                Point.minTime = min(Point.minTime, p.time)
                datasets.append(p)
            except ValueError:
                print(f"跳过无法转换为float的行: {line.strip()}")
    return datasets

#得到查询结果

def get_query(query_file):
    with open(query_file, 'r') as fp:
        data = fp.readlines()
    query_list = []  # 查询列表
    for line in data:
        quer = list(map(float, line.strip().split(',')))
        query_list.append(quer)
    return query_list

#读取范围
def read_range(file_name):
    range_query = []
    tempData = []
    fo = open(file_name)
    line = fo.readline()
    while line:
        tempData.append(line)
        line = fo.readline()
    fo.close()
    splitData = []
    for i in range(len(tempData)):
        splitData.append(tempData[i].split(","))
    for j in range(len(splitData)):
        pos_min = float(splitData[j][0])
        pos_max = float(splitData[j][1])
        time_min = float(splitData[j][2])
        time_max = float(splitData[j][3])
        range_query.append([pos_min, pos_max, time_min, time_max])
    return range_query
#读取一系列点
def read_range_point_query(file_name):
    range_query = []
    tempData = []
    fo = open(file_name)
    line = fo.readline()
    while line:
        tempData.append(line)
        line = fo.readline()
    fo.close()
    splitData = []
    for i in range(len(tempData)):
        splitData.append(tempData[i].split(","))
    for j in range(len(splitData)):
        pos= float(splitData[j][0])

        time= float(splitData[j][1])

        range_query.append([pos, time])
    return range_query

# =================================================================
# =================================================================
def get_density_splits(data_1d, points_per_interval):
    sorted_vals = np.sort(data_1d)
    splits = [sorted_vals[0], sorted_vals[-1]]
    count, last_val = 0, sorted_vals[0]
    for i in range(1, len(sorted_vals)):
        count += 1
        if count >= points_per_interval:
            mid_split = (sorted_vals[i] + last_val) / 2
            if mid_split not in splits:
                splits.append(mid_split)
            count = 0
            last_val = sorted_vals[i]
    splits.sort()
    return splits


# =================================================================
# =================================================================
def refine_grids_targeted(points, x_scale, y_scale, threshold):
    final_x = list(x_scale)
    final_y = list(y_scale)

    while True:
        # 计算当前所有格子的点数
        ix = np.clip(np.searchsorted(final_x, points[:, 0]) - 1, 0, len(final_x) - 2)
        iy = np.clip(np.searchsorted(final_y, points[:, 1]) - 1, 0, len(final_y) - 2)

        combined_ids = ix.astype(np.int64) * 1000000 + iy.astype(np.int64)
        unique_ids, counts = np.unique(combined_ids, return_counts=True)


        max_idx = np.argmax(counts)
        max_val = counts[max_idx]

        # 如果当前所有网格都已达标，则退出物理划分
        if max_val <=threshold:
            break

        # 解码最拥挤格子的位置
        best_id = unique_ids[max_idx]
        best_ix = int(best_id // 1000000)
        best_iy = int(best_id % 1000000)


        # 这里判断：哪个维度的物理跨度相对较大，就在哪切，保证网格形状趋向正方形
        dx = final_x[best_ix + 1] - final_x[best_ix]
        dy = final_y[best_iy + 1] - final_y[best_iy]

        if dx >= dy:
            final_x.insert(best_ix + 1, (final_x[best_ix] + final_x[best_ix + 1]) / 2)
            final_x.sort()
        else:
            final_y.insert(best_iy + 1, (final_y[best_iy] + final_y[best_iy + 1]) / 2)
            final_y.sort()

        if(len(final_x)>=512) or (len(final_y)>=512):
            break
    return final_x, final_y


# =================================================================
# =================================================================
def smart_pad_to_power_of_2(points, x_scale, y_scale):
    max_n = max(len(x_scale) - 1, len(y_scale) - 1)
    k = int(math.ceil(math.log2(max_n)))
    target_n = 2 ** k

    while len(x_scale) - 1 < target_n or len(y_scale) - 1 < target_n:
        ix = np.clip(np.searchsorted(x_scale, points[:, 0]) - 1, 0, len(x_scale) - 2)
        iy = np.clip(np.searchsorted(y_scale, points[:, 1]) - 1, 0, len(y_scale) - 2)
        combined_ids = ix.astype(np.int64) * 1000000 + iy.astype(np.int64)
        unique_ids, counts = np.unique(combined_ids, return_counts=True)

        max_idx = np.argmax(counts)
        best_id = unique_ids[max_idx]
        best_ix, best_iy = int(best_id // 1000000), int(best_id % 1000000)

        can_pad_x = len(x_scale) - 1 < target_n
        can_pad_y = len(y_scale) - 1 < target_n

        if can_pad_x and (
                not can_pad_y or (x_scale[best_ix + 1] - x_scale[best_ix] >= y_scale[best_iy + 1] - y_scale[best_iy])):
            x_scale.insert(best_ix + 1, (x_scale[best_ix] + x_scale[best_ix + 1]) / 2)
        elif can_pad_y:
            y_scale.insert(best_iy + 1, (y_scale[best_iy] + y_scale[best_iy + 1]) / 2)
        else:
            break
    return k, x_scale, y_scale


def split_grid(points, threshold=256):
    """
    points: 传入的是 List[Sample]
    """

    # 提取所有 Sample 对象的 pos 和 time，构建成真正的 2D 数值数组
    features = np.array([[p.pos, p.time] for p in points], dtype=np.float64)

    total_points = len(features)
    # 计算初始步长
    expected_intervals = int(math.sqrt(total_points / threshold))
    step = total_points // max(1, expected_intervals)

    # 现在可以使用 [:, 0] 和 [:, 1] 了，因为 features 是一个真正的 2D numpy 数组
    x_init = get_density_splits(features[:, 0], step)
    y_init = get_density_splits(features[:, 1], step)

    # 步骤 2: 靶向物理细分 (注意后续函数也要传入 features 数组)
    x_ref, y_ref = refine_grids_targeted(features, x_init, y_init, threshold)

    # 步骤 3: 逻辑补齐
    k, x_final, y_final = smart_pad_to_power_of_2(features, x_ref, y_ref)

    return x_final, y_final




def z_order_index(row, col, k):
    """
    k: 网格阶数，即 log2(网格数-1)
    """
    z = 0
    for i in range(k):
        # 将 row 的第 i 位移到 2i+1 位，col 的第 i 位移到 2i 位
        z |= (row & (1 << i)) << (i + 1) | (col & (1 << i)) << i
    return z

def hilbert_order_grid_new(x_scale, y_scale, point):
    """

    :param x_scale: pos网格分割值
    :param y_scale: t网格分割值
    :param point:
    :return: hilbert_point：每个网格的数据点,maps：映射值
    """

    sub = lambda a, b: a - b
    list1 = []
    list1.extend(x_scale)
    list1.pop(0)
    list2 = []
    list2.extend(x_scale)
    list2.pop()
    interval_x = []
    min_x = x_scale[0] - Point.min_pos
    interval_x.append(min_x)
    interval_x.extend(list(map(sub, list1, list2)))
    list11 = []
    list11.extend(y_scale)
    list11.pop(0)
    list22 = []
    list22.extend(y_scale)
    list22.pop()
    interval_y = []
    min_y = y_scale[0] - Point.minTime
    interval_y.append(min_y)
    interval_y.extend(list(map(sub, list11, list22)))
    if len(x_scale) >= len(y_scale):
        x1 = math.log(len(x_scale)-1, 2)
        dx1 = int(x1)
        while x1 - dx1 != 0.0:
            max_in = np.argmax(np.mat(interval_x))  # 间隔最大
            scale_tmp = (x_scale[0] + Point.min_pos) / 2
            if max_in > 0:
                scale_tmp = (x_scale[max_in] + x_scale[max_in - 1]) / 2
            x_scale.append(scale_tmp)
            x_scale.sort()
            interval_x.insert(max_in, interval_x[max_in] / 2)
            interval_x[max_in + 1] = interval_x[max_in] / 2
            x1 = math.log(len(x_scale)-1, 2)
            dx1 = int(x1)
        while len(y_scale) < len(x_scale):
            max_in = np.argmax(np.mat(interval_y))  # 间隔最大
            scale_tmp = (y_scale[0] + Point.minTime) / 2
            if max_in > 0:
                scale_tmp = (y_scale[max_in] + y_scale[max_in - 1]) / 2
            y_scale.append(scale_tmp)
            y_scale.sort()
            interval_y.insert(max_in, interval_y[max_in] / 2)
            interval_y[max_in + 1] = interval_y[max_in] / 2
    else:
        x1 = math.log(len(y_scale)-1, 2)
        dx1 = int(x1)
        while x1 - dx1 != 0.0:
            max_in = np.argmax(np.mat(interval_y))  # 间隔最大
            scale_tmp = (y_scale[0] + Point.minTime) / 2
            if max_in > 0:
                scale_tmp = (y_scale[max_in] + y_scale[max_in - 1]) / 2
            y_scale.append(scale_tmp)
            y_scale.sort()
            interval_y.insert(max_in, interval_y[max_in] / 2)
            interval_y[max_in + 1] = interval_y[max_in] / 2
            x1 = math.log(len(y_scale)-1, 2)
            dx1 = int(x1)
        while len(x_scale) < len(y_scale):
            max_in = np.argmax(np.mat(interval_x))  # 间隔最大
            scale_tmp = (x_scale[0] + Point.min_pos) / 2
            if max_in > 0:
                scale_tmp = (x_scale[max_in] + x_scale[max_in - 1]) / 2
            x_scale.append(scale_tmp)
            x_scale.sort()
            interval_x.insert(max_in, interval_x[max_in] / 2)
            interval_x[max_in + 1] = interval_x[max_in] / 2
    mp_vals = []  # 所有映射值
    hilbert_point = {}
    # 补齐后，网格数量 (len(x_scale)-1) 一定是 2 的幂次
    # 计算阶数 k
    grid_count_per_axis = len(x_scale) - 1
    k = int(math.log2(grid_count_per_axis))

    mp_vals = []
    hilbert_point = {}

    for p in point:
        col = min(grid_count_per_axis - 1, bisect.bisect_right(x_scale, p.pos) - 1)
        row = min(grid_count_per_axis - 1, bisect.bisect_right(y_scale, p.time) - 1)
        hilbert = hbg.hilbert_index(2, int(math.log(len(y_scale) - 1, 2)), [row, col])
        # 传入计算出的 k
        # z_idx = z_order_index(row, col, k)

        width = x_scale[col + 1] - x_scale[col]
        height = y_scale[row + 1] - y_scale[row]
        area = width * height

        p.hilbert = hilbert
        # 映射公式：Z序整数部分 + 单元格内偏移占比
        p.mapping = hilbert + (p.pos - x_scale[col]) * (p.time - y_scale[row]) / area

        if hilbert not in hilbert_point:
            hilbert_point[hilbert] = [p]
        else:
            hilbert_point[hilbert].append(p)
        mp_vals.append(p.mapping)


    mp_vals.sort()
    maps=np.array(mp_vals)
    maps = maps.astype(NP_DATA_TYPE)
    # 对 hilbert_point 中的每个数组（即按 hilbert 值存储的点的列表）按 mapping 进行排序
    for hilbert in hilbert_point:
        hilbert_point[hilbert].sort(key=lambda p: p.mapping)
        # 统计网格点数
        grid_counts = [len(pts) for pts in hilbert_point.values()]
    return hilbert_point,maps

def construct_block(hilbert_point, block_size,gamma):
    '''
    创建带间隔的逻辑块，用（-1，-1）填充
    :param hilbert_point:
    :param block_size:
    :param gamma:
    :return:
    '''
    # 所有点按 mapping 全局排序
    all_points = []
    for grid_points in hilbert_point.values():
        all_points.extend(grid_points)
    all_points.sort(key=lambda p: p.mapping)

    # 间隔存储
    N = len(all_points)
    # scale_factor = 1.2
    positions = np.floor(np.arange(N) * gamma).astype(int)
    max_pos = positions[-1] if N > 0 else 0

    #  构建完整序列：真实点 + 空位 (-1,-1)
    full_sequence = [Sample(-1.0, -1.0) for _ in range(max_pos + 1)]
    for idx, pos in enumerate(positions):
        full_sequence[pos] = all_points[idx]

    # 固定大小切块
    blocks = []
    b_id = 0
    s_id = 0
    for i in range(0, len(full_sequence), block_size):
        chunk = full_sequence[i:i + block_size]
        block = Block(block_size, b_id, s_id)
        block.add_grid(-1, chunk)
        blocks.append(block)
        b_id += 1
        s_id += 1

    return blocks


def layout_block(hilbert_point, block_size, PL):
    '''
    位置调整后的逻辑块分配
    :param hilbert_point: 按 Hilbert 分组后的点集合
    :param block_size: 每个数据块的大小
    :param PL: 每个点最终存储的物理位置，严格单调递增、无重复、长度=点数
    :return: 分块完成后的 blocks 列表（空位填 -1）
    '''
    all_points = []
    for grid_points in hilbert_point.values():
        all_points.extend(grid_points)
    all_points.sort(key=lambda p: p.mapping)

    N = len(all_points)

    positions = PL
    max_pos = positions[-1]  # 递增序列 → 最后一个就是最大值

    full_sequence = [Sample(-1.0, -1.0) for _ in range(max_pos + 1)]

    for idx, pos in enumerate(positions):
        full_sequence[pos] = all_points[idx]

    blocks = []
    b_id = 0
    s_id = 0
    for i in range(0, len(full_sequence), block_size):
        chunk = full_sequence[i:i + block_size]
        block = Block(block_size, b_id, s_id)
        block.add_grid(-1, chunk)
        blocks.append(block)
        b_id += 1
        s_id += 1

    return blocks

def check_unique(data: np.ndarray):
    _ = np.unique(data)
    return len(_) == len(data)

def check_order(mappings) -> bool:
    """检查映射值的次序，要求映射值整数部分单调递增"""
    count = 0
    for i in range(mappings.shape[0] - 1):
        if int(mappings[i]) > int(mappings[i + 1]):
            count += 1

    if count > 0:
        return False
    return True


#计算点的映射值
def later_hilbert(x_scale, y_scale, point):
    """
    第二期以后数据计算映射值序列
    """
    hilbert_point = {}
    mp_vals = []

    grid_count_per_axis = len(x_scale) - 1
    k = int(math.log2(grid_count_per_axis))

    for p in point:
        col = min(grid_count_per_axis - 1, bisect.bisect_right(x_scale, p.pos) - 1)
        row = min(grid_count_per_axis - 1, bisect.bisect_right(y_scale, p.time) - 1)

        # 计算 Hilbert 编码
        hilbert = hbg.hilbert_index(2, k, [row, col])

        # 使用 col 和 row 作为左下角基准，计算网格宽高
        width = x_scale[col + 1] - x_scale[col]
        height = y_scale[row + 1] - y_scale[row]
        area = width * height

        p.hilbert = hilbert
        # 映射公式：hilbert 整数部分 + (当前坐标 - 左下角坐标) 占比
        p.mapping = hilbert + (p.pos - x_scale[col]) * (p.time - y_scale[row]) / area

        # 存入结果
        if hilbert not in hilbert_point:
            hilbert_point[hilbert] = [p]
        else:
            hilbert_point[hilbert].append(p)
        mp_vals.append(p.mapping)

    # 后处理逻辑保持一致
    mp_vals.sort()
    maps = np.array(mp_vals).astype(NP_DATA_TYPE)

    # 对每个网格内的点按映射值排序
    for h_key in hilbert_point:
        hilbert_point[h_key].sort(key=lambda x: x.mapping)

    return hilbert_point, maps


def write_data3(file_name, blocks):
    # 将数据点的二维坐标写入指定文件中
    with open(file_name, 'wb') as file:  # 打开文件以二进制方式写入
        total_points = 0
        for blo in blocks:
            total_points += blo.points_count  # 计算总的点数

        # 直接用逻辑块的数量作为物理块的数量
        block_num = len(blocks)

        DataBlock.DataMaxBlock = block_num - 1  # 设置最大数据块数
        block_id = 0
        while block_id < block_num:
            count = 0  # 统计当前物理块内点的数量
            blo = blocks[block_id]  # 获取当前逻辑块

            # 遍历当前逻辑块的所有点
            for point in blo.points_list:
                for p in point:
                    # 依次将点的坐标写入文件
                    b2 = st.pack('d', p.pos)  # 打包坐标
                    b3 = st.pack('d', p.time)  # 打包时间
                    file.write(b2)  # 写入坐标
                    file.write(b3)  # 写入时间
                    count += 1  # 更新已写入点数

            block_id += 1  # 处理下一个块

def _get_data_from_disk(cls, path, region_id, page_id: int, unpack_size: int, fmt: str):
    """
    cls: 传入 buffer 类对象
    region_id: 区域 ID (1-10)，用于构造全局唯一缓存键
    """
    global T
    IO = 0
    # 构造全局唯一键，防止不同区域的 page_id 冲突
    global_cache_key = f"{region_id}_{page_id}"

    if global_cache_key in cls.memory_page_ids:
        return cls.memory_page_data[global_cache_key], IO

    res_data = []
    offset = page_id * BLOCK_SIZE * unpack_size

    if not os.path.exists(path):
        return [], 0
    # t1=time.time()
    try:
        with open(path, 'rb') as reader:
            reader.seek(offset)
            content = reader.read(BLOCK_SIZE * unpack_size)
            IO += 1

            # 解析二进制数据
            for i in range(0, len(content), unpack_size):
                part_bytes = content[i: i + unpack_size]
                if len(part_bytes) < unpack_size:
                    break
                pos, t = struct.unpack(fmt, part_bytes)
                res_data.append([pos, t])
    except Exception as e:
        print(f"读取区域 {region_id} 磁盘文件失败: {e}")
        return [], 0

    if len(cls.memory_page_ids) >= 256:
        del_key = cls.memory_page_ids.pop(0)
        cls.memory_page_data.pop(del_key, None)

    cls.memory_page_ids.append(global_cache_key)
    cls.memory_page_data[global_cache_key] = res_data
    t2=time.time()
    # io_time=t2-t1
    # T=T+io_time
    return res_data, IO

def model_sp_maps(mp_vals:np.ndarray,n_models:int):
    """
    计算模型的分割映射值
    :param mp_vals: 映射值
    :param n_models: 模型数量
    :return: 模型分割映射值数组
    """
    max_mp = mp_vals.max()  # 映射值上界

    split_mps = np.zeros(shape=[n_models], dtype=NP_DATA_TYPE)  # 映射值分割点序列
    split_mps[-1] = max_mp + 1

    offset = int(mp_vals.shape[0] / n_models)
    for i_ in range(1, n_models):
        idx = i_ * offset
        m = (mp_vals[idx] + mp_vals[idx - 1]) / 2
        split_mps[i_ - 1] = m

    sp_idxs = np.searchsorted(mp_vals, split_mps, side='right')

    model_sp_mps = np.zeros(shape=[sp_idxs.shape[0]])
    model_sp_mps[0:-1] = mp_vals[sp_idxs[:-1]]
    model_sp_mps[-1] = max_mp + 1
    return model_sp_mps

def model_split_idxs(mps:np.ndarray,model_sp_mps) -> tuple:
    """将排序后的数据映射到一维，并获取分组索引序列
    return:映射值和模型分割索引
    """
    col_idxs = np.searchsorted(model_sp_mps, mps, side='right')  #返回对应的索引
    N = col_idxs[-1]
    col_split_idxs = [0] * (N + 1)

    for i in range(col_idxs.shape[0]):
        idx_ = col_idxs[i]
        col_split_idxs[idx_] += 1

        # if col_split_idxs[idx_] > 3:

    count = col_split_idxs[0]
    for i in range(1, N + 1):
        count += col_split_idxs[i]
        col_split_idxs[i] = count
    col_split_idxs = np.insert(col_split_idxs, 0, 0)
    col_split_idxs = np.array(col_split_idxs)

    return col_split_idxs


def get_base_model_prediction(self: ModelParameters, mappings, model_sp_idx,t,cluster,m=1) -> np.ndarray:

    n1 = self.col_split_idxs[-1]
    model_sp_mps=self.model_sp_mps

    positions=np.floor(np.arange(mappings.shape[0]) * Config().gamma).astype(NP_IDX_TYPE)
    # 使用 np.searchsorted 查找索引
    col_idxes = np.searchsorted(model_sp_mps, mappings, side='right')
    # 使用 np.clip 对结果进行裁剪，确保每个元素不超过最大值
    col_idxes = np.clip(col_idxes, a_min=None, a_max=model_sp_mps.shape[0] - 1)


    pred_idxs = np.zeros(mappings.shape[0], dtype=NP_IDX_TYPE)


    # 核心修改：按唯一的模型 ID 分组预测
    unique_model_ids = np.unique(col_idxes)
    # 局部限制范围
    scale = mappings.shape[0] / n1
    for m_id in unique_model_ids:
        mask = (col_idxes == m_id)
        if self.Alphas[m_id] is None:
            continue

        alphas = self.Alphas[m_id]
        betas = self.Betas[m_id]
        trans_mps = mappings[mask] - self.col_min_map[m_id]
        A = np.maximum(0, trans_mps.reshape(-1, 1) - betas.reshape(1, -1))


        # model_sp_idx[m_id+1] 是当前块的结束，model_sp_idx[m_id] 是开始
        max_range = model_sp_idx[m_id + 1] - model_sp_idx[m_id]

        # 计算该模型内部的预测相对位置
        local_pred = (A.dot(alphas) * scale)
        pred_idxs[mask] = np.minimum(local_pred, max_range*Config().gamma).astype(NP_IDX_TYPE)

        # 还原到全局坐标：前面模型预测偏移 + 现模型起始基准位置

    pre_value=pred_idxs+np.floor(model_sp_idx[col_idxes]*Config().gamma).astype(NP_IDX_TYPE)
    erro=pre_value-positions
    err_max=max(erro)
    err_min=min(erro)
    if err_max>=(-err_min):
        logging.info(f'最大误差：{err_max}')
    else:
        logging.info(f'最大误差：{-err_min}')

    return pre_value


def  base_model_train(t,c,path):
    '''
    模型训练
    '''

    cur_dir = os.getcwd()

    t1 = time.time()
    s_count = 0

    point = read_datasets(path)
    if(t==1): #第一期数据，需要划分网格
        # point = point[:10000]
        #  x_scale, y_scale, grid_points = split_grid(point)
         x_scale, y_scale= split_grid(point,threshold=Config().grid_threshold)
         hilbert_point,maps= hilbert_order_grid_new(x_scale, y_scale, point)  # 对数据点排序
         y_scale[0] = MIN_TIME
         y_scale[-1] = MAX_TIME
         x_scale[0] = MIN_EG
         x_scale[-1] = MAX_EG
    else:#后期数据沿用第一期网格分割
        models_dir = Config().models_dir
        data_dir = Config().data_dir
        data_dir = os.path.join(data_dir, '1',f'1_{c}')
        models_dir = os.path.join(models_dir,'1', f'1_{c}')
        models_dir = os.path.join(models_dir, '1',"piecewise")
        params = ModelParameters(data_dir, models_dir)
        x_scale = params.x_scale
        y_scale = params.y_scale
        hilbert_point, maps = later_hilbert(x_scale, y_scale, point)  # 对数据点排序

    gamma = Config().gamma
    blocks= construct_block(hilbert_point , 512,gamma)
    # 计算最大点数
    max_points_per_grid = max(len(p_list) for p_list in hilbert_point.values())
    block_num=[]
    for blo in blocks:
        # blo.__str__()
        block_num.append(blo.points_count)
        for key, points in zip(blo.hilbert_keys, blo.points_list):
            for p in points:
                p.addr = blo.storage_id
                s_count += 1
    n_models=Config().n_piecewise_models
    model_sp_mps=model_sp_maps(maps,n_models)
    col_split_idxs=model_split_idxs(maps,model_sp_mps)
    col_min_mps = []
    start=0
    for i in range(n_models):
        end =col_split_idxs[i+1]
        Sort_point = maps[start:end]
        one_dm_input=Sort_point.tolist()
        min_mp = min(one_dm_input)
        col_min_mps.append(min_mp)
        start=end
    col_min_mps=np.array(col_min_mps,dtype=NP_DATA_TYPE)
    models_dir=Config().models_dir
    data_dir=Config().data_dir
    data_dir=os.path.join(data_dir,f'{t}',f'{t}_{c}')
    models_dir=os.path.join(models_dir,f'{t}',f'{t}_{c}')
    os.makedirs(data_dir, exist_ok=True)
    os.makedirs(models_dir, exist_ok=True)
    #保存模型类型，方便后面进行索引
    strategy_path=os.path.join(models_dir, 'reuse_strategy.txt')
    maps_pth = os.path.join(data_dir, 'maps.npy')
    with open(strategy_path, 'w') as f:
        strategy = {
            "mode": "BASE",
            "data_num":len(maps)
        }
        f.write(json.dumps(strategy))

    x_scale_pth = os.path.join(data_dir, 'x_scale.npy')
    y_scale_pth = os.path.join(data_dir, 'y_scale.npy')
    model_sp_mps_pth=os.path.join(data_dir, 'model_sp_mps.npy')  #模型分割映射值
    col_split_idxs_pth=os.path.join(data_dir, 'col_split_idxs.npy')
    block_split_idx_pth=os.path.join(data_dir, 'block_split_idx.npy')#逻辑块分割索引值
    block_num_pth=os.path.join(data_dir, ' block_num.npy')#每个逻辑块的数据点数量
    Pmodel_min_map_pth=os.path.join(data_dir,'Pmodel_min_map.npy')

    np.save(Pmodel_min_map_pth,col_min_mps)
    np.save(x_scale_pth, x_scale)
    np.save(y_scale_pth, y_scale)
    np.save(model_sp_mps_pth,model_sp_mps)
    np.save(col_split_idxs_pth,col_split_idxs)

    piece_params_dir = os.path.join(models_dir, 'piecewise')
    P.Dat = f'{Config().data_save}\\{t}_{c}.dat'
    write_data3(P.Dat, blocks)  # 把数据写到外存
    models_maxloss=[]
    start=0
    target_error=Config().target_error
    for i_ in range(n_models):  # 为每个分区训练一个线性回归模型
        if i_ > 0:
            start = col_split_idxs[i_]
        end = col_split_idxs[i_+1]
        one_dim_input = maps[start:end]
        # pm = PiecewiseModel(i_, one_dim_input, sigma)
        pm = PiecewiseModel(i_, one_dim_input, target_error,500,gamma)
        model_dir = os.path.join(piece_params_dir, str(i_))
        if not os.path.exists(model_dir):
            pm.train()
            file_viewer.detect_and_create_dir(model_dir)
            pm.save(model_dir)
            pm.maxloss = pm.max_absolute_error()
            models_maxloss.append(pm.maxloss)
    models_maxloss=np.array(models_maxloss)
    max_model_loss = np.ceil(np.max(models_maxloss)).astype(NP_IDX_TYPE)
    models_maxloss_pth = os.path.join(data_dir, 'model_maxloss.npy')
    np.save(models_maxloss_pth, max_model_loss)


    t2 = time.time()
    time1 = t2 - t1


def evolutionary_build_logic(t, c, current_maps,path):
    config = Config()
    target_err = config.target_error
    gamma = config.gamma

    # 准备真实存储位置（预设位置序列）
    N = len(current_maps)
    Y_true = np.floor(np.arange(N) * gamma).astype(NP_IDX_TYPE)
    base_model_pool_path=os.path.join(Config().models_dir,f"base_model_poll_{c}.npy")
    base_model_pool=np.load(base_model_pool_path).tolist()
    
    # base_model_pool = [1, 2, 3, 4, 5]
    model_results = []
    captured_sp_idxs={}
    for m_id in base_model_pool:
        models_dir = Config().models_dir
        data_dir = Config().data_dir
        data_dir = os.path.join(data_dir, f'{m_id}', f'{m_id}_{c}')
        models_dir = os.path.join(models_dir, f'{m_id}', f'{m_id}_{c}')
        models_dir = os.path.join(models_dir, "piecewise")
        params = ModelParameters(data_dir, models_dir)
        # 预测序列
        model_sp_mps=params.model_sp_mps
        model_sp_mps[-1]=current_maps[-1]
        current_sp_idx = model_split_idxs(current_maps, model_sp_mps)

        captured_sp_idxs[m_id] = current_sp_idx
        preds = get_base_model_prediction(params, current_maps, current_sp_idx,t, c, m_id)
        # 计算该模型的最大误差
        max_err = np.max(np.abs(preds - Y_true))

        # 如果单一模型达标，直接复用
        if max_err <= target_err:
            return {"mode": "SINGLE", "id": m_id,"data_num":N,"base_sp_idxs":captured_sp_idxs,"max_err":max_err}

        # 计算相似度评分：1 / (1 + 残差方差)
        score = 1.0 / (1.0 + np.var(Y_true - preds))
        model_results.append({'id': m_id, 'score': score, 'preds': preds})

    # 按评分降序排列
    model_results.sort(key=lambda x: x['score'], reverse=True)

    # 按需递增复用基础模型进行组合拟合
    selected_preds = []
    selected_ids = []

    for res in model_results:
        selected_ids.append(res['id'])
        selected_preds.append(res['preds'])
        # 构造组合矩阵 D (N x K)
        D_matrix = np.vstack(selected_preds).T

        # 调用 PLC.py 中的自适应分段优化器

        optimizer = AdaptivePiecewiseOptimizer(selected_ids, Config().target_error,Config().max_regions)

        # 执行 PLC 中的线性规划、变点估计和回溯精简
        params, eps_min, knots = optimizer.fit(current_maps, D_matrix, Y_true)

        if eps_min <= target_err:
            DL=optimizer.predict(current_maps, D_matrix)
            err = np.abs(DL - np.floor(np.arange(len(DL)) * Config().gamma).astype(int))
            logging.info(f"当前平均误差：{err.sum() / len(err)}")
            return {"mode": "COMBINATION", "optimizer": optimizer,"data_num":N,"base_sp_idxs":captured_sp_idxs}

    cur_dir=os.getcwd()
    file = os.path.join(os.getcwd(), 'pd', 'pd.txt')
    os.makedirs(os.path.dirname(file), exist_ok=True)
    if not os.path.exists(file):
        open(file, 'w').close()
    logging.info(f"组合不成功，位置调整前最大误差{optimizer.epsilon}")
    DL=optimizer.predict(current_maps, D_matrix)
    err = np.abs(DL - np.floor(np.arange(len(DL)) * Config().gamma).astype(int))
    logging.info(f"位置调整前平均误差：{err.sum() / len(err)}")
    PL = list(range(0, 0 + math.ceil(len(DL) * Config().gamma)))
    max_err, match_result = frechet_distance(DL, PL, file,eps_min*2,Config().gamma)
    optimizer.epsilon=max_err
    ers = []
    for item in match_result:
        # 计算第一列（index=0）与第二列（index=1）的差值
        diff = abs(item[1] - item[0])
        ers.append(diff)
    abs_sum = sum(ers)
    logging.info(f"位置调整后最大误差{max_err}")
    logging.info(f"位置调整后平均误差：{abs_sum / len(ers)}" )
    try:
        os.remove(file)
    except Exception as e:
        print(f'⚠️ 删除临时文件失败: {e}')
    if (len(model_results) < Config().max_base_model and max_err>(target_err+6)):
        base_model_train(t, c,path)
        base_model_pool.append(t)
        return {"mode": "BASE", "base_model_pool": base_model_pool}
    else:
        PL_matched = [item[1] for item in match_result]
        return {"mode": "COMBINATION_LAYOUT", "optimizer": optimizer,"PL":PL_matched,"data_num":N,"base_sp_idxs":captured_sp_idxs}


def MRLO_BIULD(t,c,target,flag=0):
    '''模型训练'''
    cur_dir = os.getcwd()
    #chd数据
    data_path = f'{cur_dir}\\DATA\\{target}\\Day_{t}\\{t}_{c}.txt'
    #sim数据
    # cluster_file = f'{cur_dir}\\Preprocess\\edges_partion.pkl'
    # data_path = f'{cur_dir}\\Data_SIM\\Day_{t}\\{t}_{c}.txt'
    base_model_pool_path = os.path.join(Config().models_dir, f'base_model_poll_{c}.npy')
    if flag == 0 or t==1:
        if os.path.exists(base_model_pool_path):
            # 如果文件存在，加载已有的模型列表
            base_model_pool = np.load(base_model_pool_path).tolist()
        else:
            # 如果不存在，初始化为空列表
            base_model_pool = []
        t1=time.time()

        #训练基础模型
        base_model_train(t, c,data_path)
        #存入基础模型
        base_model_pool.append(t)
        np.save(base_model_pool_path,base_model_pool)
        t2=time.time()
        data_dir = Config().data_dir
        data_dir = os.path.join(data_dir, f'{t}', f'{t}_{c}')
        model_maxloss_pth = os.path.join(data_dir, 'model_maxloss.npy')
        erro = np.load(model_maxloss_pth)

    else:
        '''--用前面模型预测后期数据-----'''

        point = read_datasets(data_path)

        #沿用第一期的数据
        models_dir = Config().models_dir
        data_dir = Config().data_dir
        data_dir = os.path.join(data_dir, f'1', f'1_{c}')
        models_dir = os.path.join(models_dir, f'1', f'1_{c}')
        models_dir = os.path.join(models_dir, "piecewise")
        params = ModelParameters(data_dir, models_dir)
        x_scale = params.x_scale
        y_scale = params.y_scale
        t1=time.time()
        # hilbert_point, maps = hilbert_order_grid_new(x_scale, y_scale, point)  # 对数据点排序
        hilbert_point, maps = later_hilbert(x_scale, y_scale, point)

        result=evolutionary_build_logic(t, c, maps,data_path)

        # 确定保存路径
        save_dir = os.path.join(Config().models_dir, f'{t}', f'{t}_{c}')
        os.makedirs(save_dir, exist_ok=True)
        reuse_info_path=os.path.join(save_dir,'reuse_strategy.txt')
        base_model_pool_path=os.path.join(Config().models_dir,f'base_model_poll_{c}.npy')
        apt_model_path = os.path.join(save_dir, 'model_params')
        P.Dat = f'{Config().data_save}\\{t}_{c}.dat'
        if result["mode"] == "SINGLE":
            #  单个模型复用成功
            best_id = result["id"]
            final_sp_idxs = {best_id: result["base_sp_idxs"][best_id]}
            np.save(os.path.join(apt_model_path, 'all_base_sp_idxs.npy'), final_sp_idxs)
            max_err=result["max_err"]
            np.save(os.path.join(apt_model_path, 'epsilon.npy'), max_err)
            blocks=construct_block(hilbert_point,BLOCK_SIZE,Config().gamma)
            write_data3(P.Dat, blocks)  # 把数据写到外存
            with open(reuse_info_path, 'w') as f:
                strategy = {
                    "mode": "SINGLE",
                    "source_id": int(result["id"]),
                    "data_num":result["data_num"],
                }
                f.write(json.dumps(strategy))
            logging.info(f">>> 决策：第{t}期直接复用第{best_id}期的模型参数。")
            logging.info(f"最大误差：{max_err}")

        elif result["mode"] == "BASE":
            # 重新训练了 Base 模型（因为现有的都不达标）
            new_pool = result["base_model_pool"]
            np.save(base_model_pool_path,new_pool)
            logging.info(f">>> 决策：重新训练基础模型")


        elif result["mode"] == "COMBINATION":
            # 组合复用成功
            logging.info(f">>> 决策：组合复用成功")
            optimizer = result["optimizer"]
            target_sp_idxs = result["base_sp_idxs"]

            final_sp_idxs = {mid: target_sp_idxs[mid] for mid in optimizer.reuse_model}

            blocks = construct_block(hilbert_point, BLOCK_SIZE, Config().gamma)
            # P.Dat = f'{cur_dir}\Data_save\\{t}_{c}.dat'
            write_data3(P.Dat, blocks)  # 把数据写到外存
            save_apt_model_params(optimizer, apt_model_path,final_sp_idxs)
            logging.info(f"最大误差：{optimizer.epsilon}")
            with open(reuse_info_path, 'w') as f:
                strategy = {
                    "mode": "COMBINATION",
                    "data_num": result["data_num"]
                }
                f.write(json.dumps(strategy))

        elif result["mode"] == "COMBINATION_LAYOUT":
            # 位置变化
            with open(reuse_info_path, 'w') as f:
                strategy = {
                    "mode": "COMBINATION",
                    "data_num": result["data_num"]
                }
                f.write(json.dumps(strategy))
            logging.info(f">>> 决策：组合复用并位置调优")
            optimizer = result["optimizer"]
            target_sp_idxs = result["base_sp_idxs"]
            final_sp_idxs = {mid: target_sp_idxs[mid] for mid in optimizer.reuse_model}
            logging.info(f"最大误差：{optimizer.epsilon}")
            save_apt_model_params(optimizer, apt_model_path,final_sp_idxs)
            position=result["PL"]
            blocks= layout_block(hilbert_point,BLOCK_SIZE,position)
            write_data3(P.Dat, blocks)

        t2=time.time()
        logging.info(f"---------模型执行时间：{t2 - t1}s---------")


class MRLOQuery:
    """
    查询类
    """

    def __init__(self, t, c, first_day_grid_dir, preloaded_strategy=None, preloaded_data=None,
                 global_history_pool=None):
        self.t, self.c = t, c
        self.config = Config()
        self.model_dir = os.path.join(self.config.models_dir, f'{t}', f'{t}_{c}')
        self.data_save_dir = f'{Config().data_save}\\{t}_{c}.dat'
        self.data_dir = os.path.join(self.config.data_dir, f'{t}', f'{t}_{c}')
        self.global_history_pool = global_history_pool

        self.x_scale = np.load(os.path.join(first_day_grid_dir, 'x_scale.npy'))
        self.y_scale = np.load(os.path.join(first_day_grid_dir, 'y_scale.npy'))
        self.grid_k = int(math.log2(len(self.x_scale) - 1))
        self.x_len_m2 = len(self.x_scale) - 2
        self.y_len_m2 = len(self.y_scale) - 2

        if preloaded_strategy is not None:
            self.strategy = preloaded_strategy
        else:
            strategy_path = os.path.join(self.model_dir, 'reuse_strategy.txt')
            if os.path.exists(strategy_path):
                with open(strategy_path, 'r') as f:
                    self.strategy = json.load(f)
            else:
                exit()

        self.data_num = self.strategy["data_num"]
        self.mode = self.strategy["mode"]

        self.source_id = self.strategy.get("source_id", None)
        self.gamma = Config().gamma  # 提取为局部高频标量，消减对象属性查找开销

        self._setup_predictor(preloaded_data)

    def _setup_predictor(self, preloaded_data=None):
        mode = self.mode
        apt_path = os.path.join(self.model_dir, 'model_params')

        if preloaded_data is not None:
            if mode == "SINGLE":
                self.base_sp_idxs = preloaded_data["base_sp_idxs"]
                self.predictor = preloaded_data["predictor"]
                self.epsilon = preloaded_data["epsilon"]
            elif mode == "COMBINATION":
                self.base_sp_idxs = preloaded_data["base_sp_idxs"]
                self.optimizer = preloaded_data["optimizer"]
                self.epsilon = self.optimizer.epsilon

                self.base_pool = {}
                for mid in self.optimizer.reuse_model:
                    if self.global_history_pool and mid in self.global_history_pool:
                        hist_node = self.global_history_pool[mid]["data"]
                        if "predictor" in hist_node:
                            self.base_pool[mid] = hist_node["predictor"]
                        elif "base_pool" in hist_node and mid in hist_node["base_pool"]:
                            self.base_pool[mid] = hist_node["base_pool"][mid]
                        elif "base_pool" in hist_node and len(hist_node["base_pool"]) > 0:
                            first_avail_key = list(hist_node["base_pool"].keys())[0]
                            self.base_pool[mid] = hist_node["base_pool"][first_avail_key]
                        else:
                            d_p = os.path.join(self.config.data_dir, f'{mid}', f'{mid}_{self.c}')
                            m_p = os.path.join(self.config.models_dir, f'{mid}', f'{mid}_{self.c}', "piecewise")
                            self.base_pool[mid] = ModelParameters(d_p, m_p)
                    else:
                        d_p = os.path.join(self.config.data_dir, f'{mid}', f'{mid}_{self.c}')
                        m_p = os.path.join(self.config.models_dir, f'{mid}', f'{mid}_{self.c}', "piecewise")
                        self.base_pool[mid] = ModelParameters(d_p, m_p)
            else:
                self.predictor = preloaded_data["predictor"]
                self.epsilon = preloaded_data["epsilon"]
            return

        if mode == "SINGLE":
            sp_idx_file = os.path.join(apt_path, 'all_base_sp_idxs.npy')
            if os.path.exists(sp_idx_file):
                self.base_sp_idxs = np.load(sp_idx_file, allow_pickle=True).item()
            src_id = self.source_id
            data_path = os.path.join(self.config.data_dir, f'{src_id}', f'{src_id}_{self.c}')
            piece_path = os.path.join(self.config.models_dir, f'{src_id}', f'{src_id}_{self.c}', "piecewise")
            self.predictor = ModelParameters(data_path, piece_path)
            self.epsilon = np.load(os.path.join(apt_path, 'epsilon.npy'))
        elif mode == "COMBINATION":
            sp_idx_file = os.path.join(apt_path, 'all_base_sp_idxs.npy')
            if os.path.exists(sp_idx_file):
                self.base_sp_idxs = np.load(sp_idx_file, allow_pickle=True).item()
            self.optimizer = load_apt_model_params(apt_path)
            self.epsilon = self.optimizer.epsilon
            self.base_pool = {}
            for mid in self.optimizer.reuse_model:
                d_p = os.path.join(self.config.data_dir, f'{mid}', f'{mid}_{self.c}')
                m_p = os.path.join(self.config.models_dir, f'{mid}', f'{mid}_{self.c}', "piecewise")
                self.base_pool[mid] = ModelParameters(d_p, m_p)
        else:
            self.predictor = ModelParameters(self.data_dir, os.path.join(self.model_dir, "piecewise"))
            self.epsilon = np.load(os.path.join(self.data_dir, 'model_maxloss.npy'))

    def get_mapping(self, pos, time):
        col = min(self.x_len_m2, bisect.bisect_right(self.x_scale, pos) - 1)
        row = min(self.y_len_m2, bisect.bisect_right(self.y_scale, time) - 1)
        hilbert = hbg.hilbert_index(2, int(math.log(len(self.y_scale), 2)), [row, col])
        area = (self.x_scale[col + 1] - self.x_scale[col]) * (self.y_scale[row + 1] - self.y_scale[row])
        return hilbert + (pos - self.x_scale[col]) * (time - self.y_scale[row]) / area

    def point_query(self, pos, time_val):
        global IO
        mapping = self.get_mapping(pos, time_val)
        pred_pos = self._predict(mapping)

        start_page = max(0, int((pred_pos - self.epsilon) // 512))
        end_page = int((pred_pos + self.epsilon) // 512)

        for page_id in range(start_page, end_page + 1):
            data, io = _get_data_from_disk(buffer, self.data_save_dir, self.c, page_id, 16, 'dd')
            IO += io
            for p_pos, p_time in data:
                if p_pos == -1.0: continue
                if abs(p_pos - pos) < 1e-7 and abs(p_time - time_val) < 1e-7:
                    return [p_pos, p_time]
        return None

    def _predict(self, mapping):
        mode = self.mode
        if mode == "SINGLE":
            return self._predict_base(self.predictor, mapping, m_id=self.source_id)
        elif mode == "BASE":
            return self._predict_base(self.predictor, mapping)
        else:
            d_vals = []
            for mid in self.optimizer.reuse_model:
                pred = self._predict_base(self.base_pool[mid], mapping, m_id=mid)
                d_vals.append(pred)
            D_matrix = np.array(d_vals).reshape(1, -1)
            return self.optimizer.predict(np.array([mapping]), D_matrix)[0]

    def _predict_base(self, params: ModelParameters, mapping, m_id=None):

        p_alphas = params.Alphas
        p_betas = params.Betas
        p_col_min_map = params.col_min_map
        p_model_sp_mps = params.model_sp_mps

        if m_id is not None and hasattr(self, 'base_sp_idxs') and self.base_sp_idxs is not None:
            model_sp_idx = self.base_sp_idxs.get(m_id, params.col_split_idxs)
        else:
            model_sp_idx = params.col_split_idxs


        col_idx = bisect.bisect_right(p_model_sp_mps, mapping)
        col_idx = min(col_idx, len(p_alphas) - 1)

        if p_alphas[col_idx] is None:
            return 0

        alphas = p_alphas[col_idx]
        betas = p_betas[col_idx]
        trans_mp = mapping - p_col_min_map[col_idx]

        A = np.maximum(0.0, trans_mp - betas)
        scale = self.data_num / model_sp_idx[-1]
        local_offset = A.dot(alphas) * scale

        max_points_in_segment = model_sp_idx[col_idx + 1] - model_sp_idx[col_idx]
        gamma = self.gamma

        constrained_offset = min(local_offset, max_points_in_segment * gamma)
        global_base_pos = math.floor(model_sp_idx[col_idx] * gamma)
        return constrained_offset + global_base_pos

    def in_windows(self, row, col, q):
        if row < 0 or row >= (self.y_len_m2 + 1) or col < 0 or col >= (self.x_len_m2 + 1):
            return False
        x_left, x_right = self.x_scale[col], self.x_scale[col + 1]
        y_bottom, y_top = self.y_scale[row], self.y_scale[row + 1]
        return (x_left < q[1] and x_right > q[0] and y_bottom < q[3] and y_top > q[2])

    def range_query(self, p_min, p_max, t_min, t_max):
        global IO
        query_range = [p_min, p_max, t_min, t_max]

        c_min = max(0, bisect.bisect_right(self.x_scale, p_min) - 1)
        c_max = min(self.x_len_m2, bisect.bisect_right(self.x_scale, p_max) - 1)
        r_min = max(0, bisect.bisect_right(self.y_scale, t_min) - 1)
        r_max = min(self.y_len_m2, bisect.bisect_right(self.y_scale, t_max) - 1)

        intervals = []
        max_h = (2 ** (2 * self.grid_k)) - 1

        for r in range(r_min, r_max + 1):
            for c in range(c_min, c_max + 1):
                if r not in (r_min, r_max) and c not in (c_min, c_max):
                    continue

                h = hbg.hilbert_index(2, self.grid_k, [r, c])

                if h == 0:
                    is_start = True
                else:
                    pr, pc = hbg.hilbert_point(2, self.grid_k, h - 1)
                    is_start = not self.in_windows(pr, pc, query_range)

                if h == max_h:
                    is_end = True
                else:
                    nr, nc = hbg.hilbert_point(2, self.grid_k, h + 1)
                    is_end = not self.in_windows(nr, nc, query_range)

                if is_start:
                    intervals.append({'type': 'start', 'h': h})
                if is_end:
                    intervals.append({'type': 'end', 'h': h})

        starts = []
        ends = []
        open_start = None

        for item in sorted(intervals, key=lambda x: x['h']):
            if item['type'] == 'start':
                open_start = item['h']
            elif item['type'] == 'end' and open_start is not None:
                starts.append(open_start)
                ends.append(item['h'])
                open_start = None

        merged = []
        if starts:
            cb, ce = starts[0], ends[0]
            for b, e in zip(starts[1:], ends[1:]):
                if b <= ce + 1:
                    ce = max(ce, e)
                else:
                    merged.append((cb, ce))
                    cb, ce = b, e
            merged.append((cb, ce))

        merged_intervals = merged
        final_results = []
        candidate_pages = set()

        for h_start, h_end in merged_intervals:
            p_s = self._predict(float(h_start)) - self.epsilon
            p_e = self._predict(float(h_end) + 1) + self.epsilon

            for pid in range(max(0, int(p_s // 512)), int(p_e // 512) + 1):
                candidate_pages.add(pid)

        for pid in sorted(list(candidate_pages)):
            data, io = _get_data_from_disk(buffer, self.data_save_dir, self.c, pid, 16, 'dd')
            IO += io
            for p_pos, p_time in data:
                if p_pos == -1.0: continue
                if p_min <= p_pos <= p_max and t_min <= p_time <= t_max:
                    final_results.append((p_pos, p_time))
        return final_results


class MRLOGlobalQueryManager:
    def __init__(self, t, partitions_list, first_day_base_dir):
        self.t = t
        self.partitions_list = partitions_list
        self.first_day_base_dir = first_day_base_dir
        self.config = Config()
        self.engines = {}
        self._preload_all_history_periods()

    def _preload_all_history_periods(self):
        self.preloaded_pool = {}
        total_regions = len(self.partitions_list) + 1

        for c in range(1, total_regions + 1):
            self.preloaded_pool[c] = {}

            for hist_t in range(1, self.t + 1):
                model_dir = os.path.join(self.config.models_dir, f'{hist_t}', f'{hist_t}_{c}')
                strategy_path = os.path.join(model_dir, 'reuse_strategy.txt')

                if not os.path.exists(strategy_path):
                    continue

                with open(strategy_path, 'r') as f:
                    strategy = json.load(f)

                mode = strategy["mode"]
                apt_path = os.path.join(model_dir, 'model_params')
                region_data = {}

                if mode == "SINGLE":
                    sp_idx_file = os.path.join(apt_path, 'all_base_sp_idxs.npy')
                    region_data["base_sp_idxs"] = np.load(sp_idx_file, allow_pickle=True).item() if os.path.exists(
                        sp_idx_file) else None

                    src_id = strategy["source_id"]
                    data_path = os.path.join(self.config.data_dir, f'{src_id}', f'{src_id}_{c}')
                    piece_path = os.path.join(self.config.models_dir, f'{src_id}', f'{src_id}_{c}', "piecewise")
                    region_data["predictor"] = ModelParameters(data_path, piece_path)
                    region_data["epsilon"] = np.load(os.path.join(apt_path, 'epsilon.npy'))

                elif mode == "COMBINATION":
                    sp_idx_file = os.path.join(apt_path, 'all_base_sp_idxs.npy')
                    region_data["base_sp_idxs"] = np.load(sp_idx_file, allow_pickle=True).item() if os.path.exists(
                        sp_idx_file) else None

                    optimizer = load_apt_model_params(apt_path)
                    region_data["optimizer"] = optimizer

                    base_pool = {}
                    for mid in optimizer.reuse_model:
                        d_p = os.path.join(self.config.data_dir, f'{mid}', f'{mid}_{c}')
                        m_p = os.path.join(self.config.models_dir, f'{mid}', f'{mid}_{c}', "piecewise")
                        base_pool[mid] = ModelParameters(d_p, m_p)
                    region_data["base_pool"] = base_pool

                else:
                    data_dir = os.path.join(self.config.data_dir, f'{hist_t}', f'{hist_t}_{c}')
                    region_data["predictor"] = ModelParameters(data_dir, os.path.join(model_dir, "piecewise"))
                    region_data["epsilon"] = np.load(os.path.join(data_dir, 'model_maxloss.npy'))

                self.preloaded_pool[c][hist_t] = {
                    "strategy": strategy,
                    "data": region_data
                }

    def _get_region_id(self, pos):
        idx = bisect.bisect_right(self.partitions_list, pos)
        return min(len(self.partitions_list), idx + 1)

    def get_engine(self, c):
        if c not in self.engines:
            region_grid_dir = os.path.join(self.first_day_base_dir, '1', f'1_{c}')

            current_preload = self.preloaded_pool[c].get(self.t, {"strategy": None, "data": None})
            history_pool_for_region = self.preloaded_pool[c]

            self.engines[c] = MRLOQuery(
                self.t, c, region_grid_dir,
                preloaded_strategy=current_preload["strategy"],
                preloaded_data=current_preload["data"],
                global_history_pool=history_pool_for_region
            )
        return self.engines[c]

    def global_point_query(self, pos, time_val):
        return self.get_engine(self._get_region_id(pos)).point_query(pos, time_val)

    def global_range_query(self, p_min, p_max, t_min, t_max):
        results = []
        for c in range(self._get_region_id(p_min), self._get_region_id(p_max) + 1):
            res = self.get_engine(c).range_query(p_min, p_max, t_min, t_max)
            if res:
                results.extend(res)
        return list(set(results))

def verify_from_txt_fast(path, target_point=None, query_range=None):
    """
    通过 NumPy 向量化加速真值统计，
    """
    try:
        data = np.loadtxt(path, delimiter=',', dtype=np.float64)
    except Exception as e:
        # 如果 loadtxt 报错（如存在空行），改用 genfromtxt
        data = np.genfromtxt(path, delimiter=',', dtype=np.float64)

    pos_col = data[:, 0]
    time_col = data[:, 1]

    is_exist = False
    actual_range_count = 0

    # 验证单点是否存在（向量化判断）
    if target_point is not None:
        # 利用 abs(diff) < 1e-7 的逻辑
        mask_pos = np.abs(pos_col - target_point[0]) < 1e-7
        mask_time = np.abs(time_col - target_point[1]) < 1e-7
        is_exist = np.any(mask_pos & mask_time)

    #  统计范围内点数（向量化掩码）
    if query_range is not None:
        # query_range: [p_min, p_max, t_min, t_max]
        mask = (pos_col >= query_range[0]) & (pos_col <= query_range[1]) & \
               (time_col >= query_range[2]) & (time_col <= query_range[3])
        actual_range_count = np.sum(mask)

    return is_exist, int(actual_range_count)



def get_query(query_file):
    with open(query_file, 'r') as fp:
        data = fp.readlines()
    query_list = []  # 查询列表
    for line in data:
        quer = list(map(float, line.strip().split(',')))
        query_list.append(quer)
    return query_list

def main():
    global IO, MIN_TIME, MAX_EG, MIN_EG
    os.chdir("..")
    cur_dir = os.getcwd()
    log_dir = f"{cur_dir}/结果"
    # target='SIM','CHD'
    target = 'CHD'
    os.makedirs(log_dir, exist_ok=True)
    log_file_path = os.path.join(log_dir, f"results_{target}.log")
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s - %(message)s",
        datefmt="%Y/%m/%d %I:%M:%S %p",
        handlers=[
            logging.FileHandler(log_file_path, encoding="utf-8"),
            logging.StreamHandler()
        ]
    )
    logging.info(f"---------- 间隙因子={Config().gamma}, 误差阈值={Config().target_error}，网格阈值={Config().grid_threshold} ----------")
# 加载分区边界
    cluster_file = f'{cur_dir}\\DATA\\{target}\\edges_partion.pkl'
    partitions_dict = load_model(cluster_file)
    first_day_base_dir = Config().data_dir
    for t in range(1,4):
        T=0
        for c in range(1, 2):
            MAX_EG = partitions_dict[c - 1] + 1
            if c == 1:
                MIN_EG = 1
            else:
                MIN_EG = partitions_dict[c - 2]
            path=os.path.join(Config().models_dir, f'{t}', f'{t}_{c}')
            if not os.path.exists(path):
                logging.info(f"------------- 第{t}期，第{c}区域-------------")
                MRLO_BIULD(t, c,target,1)  # 构建/复用逻辑

        # range_dir=f'{cur_dir}\query\\{target}'
        # logging.info(f"--- 第 {t} 期点查询 ---")
        # manager = MRLOGlobalQueryManager(t, partitions_dict, Config().data_dir)
        # buffer.memory_page_ids.clear()
        # buffer.memory_page_data.clear()
        #
        # raw_point_path = f'{range_dir}\\EP{t}\\point_query.txt'
        # point_list = get_query(raw_point_path)
        # raw_range_query_path = f'{range_dir}\\EP{t}\\range_query.txt'
        # data_path = f'{range_dir}\\EP{t}\\200W_P{t}.txt'
        # range_list = get_query(raw_range_query_path)
        #
        # IO = 0
        # start_t = time.time()
        # results_count = 0
        #
        # for p in point_list:
        #     res = manager.global_point_query(p[0], p[1])
        #     if res:
        #         results_count += 1
        #
        # avg_io = IO / len(point_list)
        # logging.info(f"点查询平均 IO: {avg_io:.2f}, 平均耗时: {(time.time() - start_t) / len(point_list):.6f}s")
        #
        # logging.info(f"========== 开始测试第 {t} 期范围查询==========")
        # manager = MRLOGlobalQueryManager(t, partitions_dict, first_day_base_dir)
        #
        # buffer.memory_page_ids.clear()
        # buffer.memory_page_data.clear()
        #
        # start_time = time.time()
        # IO = 0
        #
        # query_count = 0
        # for ran in range_list:
        #     res = manager.global_range_query(ran[0], ran[2], ran[1], ran[3])
        #     query_count += len(res)
        # print(f'查询数量：{query_count}')
        #
        # elapsed = time.time() - start_time
        # logging.info(f"范围查询: 平均 IO={IO/len(range_list):.2f}, 平均耗时={elapsed / len(range_list):.6f}s")

if __name__ == "__main__":
    main()
