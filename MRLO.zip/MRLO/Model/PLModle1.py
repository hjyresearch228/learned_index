import os
import sys
import numpy as np

# 模拟原有的通用工具定义，确保代码可运行
NP_DATA_TYPE = np.float64
NP_IDX_TYPE = np.int64


class PiecewiseModel:
    def __init__(self, id, sorted_mappings, target_error=10.0, max_sigma=500,gamma=1.2):
        self.id = id
        self.target_error = target_error
        self.max_sigma = max_sigma

        # 数据预处理
        self.min_value = sorted_mappings.min()
        # 归一化输入值，防止大数运算溢出
        self.sorted_mappings = (sorted_mappings - self.min_value).astype(NP_DATA_TYPE)
        self.sorted_mappings_reshape = np.reshape(self.sorted_mappings, [-1, 1])
        # self.positions = np.arange(0, self.sorted_mappings.shape[0], dtype=NP_IDX_TYPE)
        #带有扩展因子的位置
        self.positions = np.floor(np.arange(self.sorted_mappings.shape[0]) * gamma).astype(NP_IDX_TYPE )
        # 模型参数
        self.sigma = 16 # 初始分段数
        self.alphas = None
        self.betas = None
        self.maxloss = float('inf')

    def train(self):
        """
        启发式训练主函数：通过倍增探测边界，再通过二分精确定位最小 sigma
        """

        low_sigma = 16
        current_sigma = 16

        while current_sigma <= self.max_sigma:
            self._optimize_fixed_sigma(current_sigma)
            err = self.max_absolute_error()

            if err <= self.target_error:
                # 已经达标，记录当前 sigma 作为上限
                high_sigma = current_sigma
                break

            low_sigma = current_sigma
            current_sigma *= 2

            if current_sigma > self.max_sigma:
                # 达到最大限制，以 max_sigma 运行最后一次
                self._optimize_fixed_sigma(self.max_sigma)
                return

        # 目标：在 [low_sigma, high_sigma] 之间找到满足误差的最小 sigma
        final_alphas, final_betas = self.alphas, self.betas

        while low_sigma <= high_sigma:
            mid_sigma = (low_sigma + high_sigma) // 2
            if mid_sigma == low_sigma or mid_sigma == high_sigma:
                break

            self._optimize_fixed_sigma(mid_sigma)
            err = self.max_absolute_error()

            if err <= self.target_error:
                # 记录当前最优解，尝试更小的 sigma
                final_alphas, final_betas = self.alphas, self.betas
                high_sigma = mid_sigma
            else:
                low_sigma = mid_sigma

        # 恢复最优结果
        self.alphas, self.betas = final_alphas, final_betas
        self.sigma = len(self.betas)
        self.maxloss = self.max_absolute_error()

    def save(self, model_dir):
        """
        保存模型的 alphas, betas 以及元数据
        """
        if not os.path.exists(model_dir):
            os.makedirs(model_dir)

        alphas_path = os.path.join(model_dir, 'alphas.npy')
        betas_path = os.path.join(model_dir, 'betas.npy')
        # meta_path = os.path.join(model_dir, 'meta.txt')

        if self.alphas is not None and self.betas is not None:
            np.save(alphas_path, self.alphas)
            np.save(betas_path, self.betas)
            # # 记录一些元数据方便后续排查
            # with open(meta_path, 'w') as f:
            #     f.write(f"id: {self.id}\n")
            #     f.write(f"sigma: {self.sigma}\n")
            #     f.write(f"max_error: {self.maxloss}\n")
            #     f.write(f"min_value: {self.min_value}\n")
        else:
            return

    def _optimize_fixed_sigma(self, sigma):
        """
        在固定 sigma 下进行梯度下降优化
        """
        self.sigma = sigma
        # 初始化节点位置
        n_each_cell = max(1, int(self.sorted_mappings.shape[0] / self.sigma))
        split_idxs = (np.arange(0, self.sigma) * n_each_cell).astype(NP_IDX_TYPE)
        self.betas = self.sorted_mappings[split_idxs].reshape([-1])

        # 初始 Alpha 计算
        self.alphas, _ = self._cal_alphas(self.betas)

        # 如果 lstsq 无法求解，使用基础初始化
        if self.alphas is None:
            self.alphas = self._cal_init_alphas(self.betas)

        # 梯度下降迭代
        k = 0
        while k < 5:  # 动态分段时，单次优化迭代次数可适当减少
            betas_prev = self.betas.copy()
            alphas_curr, A = self._cal_alphas(self.betas)

            if A is None or alphas_curr is None:
                break

            init_loss = self._cal_loss(A, alphas_curr)

            # 单调性检查与修正
            if not self._check_valid(alphas_curr, self.betas):
                alphas_curr = self._cal_alphas_with_monotone_constrain(self.betas, alphas_curr)
                init_loss = self._cal_loss(A, alphas_curr)

            # 计算梯度方向 (基于你原有的梯度公式)
            G = -np.sign(A).transpose()
            r = A.dot(alphas_curr).clip(min=0, max=self.positions.shape[0]) - self.positions
            K = np.diag(alphas_curr)
            g = 2 * K.dot((G.dot(r))) / self.sorted_mappings.shape[0]

            # 使用二阶导信息 (Hessian 近似)
            G_sq = np.matmul(G, G.transpose())
            Y = 2 * np.matmul(np.matmul(K, G_sq), K) / self.sorted_mappings.shape[0]

            # 确定搜索方向 s
            if np.linalg.cond(Y) < 1 / sys.float_info.epsilon:
                s = -np.linalg.inv(Y).dot(g)
            else:
                s = -g

            # 步长搜索
            lr, loss, betas_new, alphas_new = self._lr_search(s, self.betas, init_loss)

            if lr > 0:
                self.betas, self.alphas = betas_new, alphas_new
            else:
                # 尝试简单梯度方向
                if s is not -g:
                    lr, loss, betas_new, alphas_new = self._lr_search(-g, self.betas, init_loss)
                    if lr > 0:
                        self.betas, self.alphas = betas_new, alphas_new
                    else:
                        break
                else:
                    break
            k += 1

    def _cal_alphas(self, betas):
        """
        用 np.linalg.lstsq 求逆
        """
        A = self.ReLu(np.tile(self.sorted_mappings_reshape, [1, self.sigma]) - betas.reshape(1, -1))
        try:
            # rcond=None 自动处理奇异矩阵，提供最稳健的最小二乘解
            alphas, residuals, rank, s = np.linalg.lstsq(A, self.positions, rcond=None)
            return alphas, A
        except:
            return None, None

    def max_absolute_error(self):
        """计算当前模型的最大绝对误差"""
        if self.alphas is None or self.betas is None:
            return float('inf')
        A = self.ReLu(np.tile(self.sorted_mappings_reshape, [1, self.sigma]) - self.betas.reshape(1, -1))
        pred = A.dot(self.alphas).clip(min=0, max=self.positions.max())
        return np.max(np.abs(pred - self.positions))

    @staticmethod
    def ReLu(A):
        res = np.copy(A)
        res[res < 0] = 0
        return res

    def _cal_loss(self, A, alphas):
        r = A.dot(alphas).clip(min=0, max=self.sorted_mappings.shape[0]) - self.positions
        return np.sum(r * r)

    def _lr_search(self, s, init_betas, init_loss):
        lrs = [0.01, 0.1, 0.5, 1.0]
        best_lr, best_loss = -1, init_loss
        best_b, best_a = None, None

        for lr in lrs:
            b_test = np.sort(init_betas + lr * s)
            a_test, A_test = self._cal_alphas(b_test)
            if a_test is not None:
                loss = self._cal_loss(A_test, a_test)
                if loss < best_loss:
                    best_loss, best_lr = loss, lr
                    best_b, best_a = b_test, a_test
        return best_lr, best_loss, best_b, best_a

    def _check_valid(self, alphas, betas):
        if (betas[1:] - betas[:-1]).min() <= 0: return False
        if np.cumsum(alphas).min() < 0: return False
        return True

    def _predict_idxs(self, mappings=None, betas=None, alphas=None):
        if betas is None:
            betas = self.betas
        if mappings is None:
            mappings = self.sorted_mappings
        if alphas is None:
            alphas = self.alphas
        A = self.ReLu(np.tile(np.reshape(mappings, [-1, 1]), [1, self.sigma]) - betas.transpose())
        # A = self.ReLu(np.tile(self.sorted_mappings_reshape, [1, self.sigma]) - betas.transpose())
        pred_idxes = A.dot(alphas)
        return pred_idxes

    def _cal_init_alphas(self, betas):
        idxs = np.searchsorted(self.sorted_mappings, betas, side='right')
        pred_positions = (idxs - 0.5).clip(min=0)
        alphas = np.zeros(shape=[self.sigma], dtype=NP_DATA_TYPE)

        for i in range(1, pred_positions.shape[0]):
            v = 0
            beta_i = betas[i]
            for j in range(i - 1):
                v += alphas[j] * (beta_i - betas[j])
            diff = (beta_i - betas[i - 1])
            if diff <= 0:
                alphas[i - 1] = 0
            else:
                alphas[i - 1] = (pred_positions[i] - v) / diff

        v = 0
        for j in range(1, self.sigma):
            v += alphas[j] * (betas[j] - betas[j - 1])

        max_mp = self.sorted_mappings[-1]
        d_ = max_mp - betas[-1]
        if d_ == 0:
            d_ = 1e-6
        alphas[-1] = (self.sorted_mappings.shape[0] - 1) / (d_)

        alphas_cumsum = np.cumsum(alphas)
        if alphas_cumsum[-1] < 0:
            alphas[-1] = -alphas_cumsum[-2]
        return np.zeros(self.sigma)

    def _cal_alphas_with_monotone_constrain(self, betas, old_alphas):
        pred_positions = self._predict_idxs(betas, betas, old_alphas).clip(min=0, max=self.sorted_mappings.shape[0])
        pred_positions = np.sort(pred_positions)
        assert (abs(pred_positions[0]) < 1e-4)

        alphas = np.zeros(shape=[self.sigma], dtype=np.float64)
        for i in range(1, pred_positions.shape[0]):
            v_ = 0
            beta_i = betas[i]
            for j in range(i - 1):
                v_ += alphas[j] * (beta_i - betas[j])
            alphas[i - 1] = (pred_positions[i] - v_) / (beta_i - betas[i - 1])

        max_mp = self.sorted_mappings[-1]
        alphas[-1] = (self.sorted_mappings.shape[0] - 1) / (max_mp - betas[-1])

        alphas_cumsum = np.cumsum(alphas)
        if alphas_cumsum[-1] < 0:
            alphas[-1] = -alphas_cumsum[-2]

        pred_idxs = self._predict_idxs(self.sorted_mappings, betas, alphas).clip(min=0,
                                                                                 max=self.sorted_mappings.shape[0])

        act_idxs = np.arange(0, self.sorted_mappings.shape[0], dtype=NP_DATA_TYPE)

        diff = (pred_idxs - act_idxs)
        # 此处保留你原代码中的 _cal_alphas_with_monotone_constrain 实现...
        return old_alphas



if __name__ == "__main__":
    n_points = 50000
    np.random.seed(42)
    raw_data = np.sort(np.random.randint(0, 100000, size=n_points))

    # 设置目标最大误差为 5.0
    pm = PiecewiseModel(id=1, sorted_mappings=raw_data, target_error=50.0)
    pm.train()

    print(f"\nFinal Result:")
    print(f"Total Segments (Sigma): {pm.sigma}")
    print(f"Max Absolute Error: {pm.maxloss:.4f}")
