'''
动态规划方法调整
'''
import math
import struct
import time
from copyreg import pickle
import numpy as np
import pandas as pd
from utils.file_utils import *
from sqlalchemy import false
from utils import file_viewer
MAX = 100000000
import os
import struct
import numpy as np
import struct
import math
import struct
import time
import numpy as np
import pandas as pd
import os
from numba import njit


@njit
def compute_block_core(DL_block, PL, starts_j, prev_row_dp, prev_start_j, W, M, MAX_VAL, start_idx_global):
    """
    start_idx_global 用于判断是否是整个序列的绝对起点。
    """
    block_h = DL_block.shape[0]
    block_dp = np.full((block_h, W), MAX_VAL, dtype=np.int32)

    for i_local in range(block_h):
        s_curr = starts_j[i_local]

        # 块内第一行参考 prev_row_dp，其余行参考 block_dp 的上一行
        if i_local == 0:
            s_prev = prev_start_j
            ref_row = prev_row_dp  #上一块
        else:
            s_prev = starts_j[i_local - 1]
            ref_row = block_dp[i_local - 1]

        dl_val = DL_block[i_local]

        for j_idx in range(W):
            j_global = s_curr + j_idx
            if j_global >= M:
                break

            # 计算局部距离
            current_lr = int(abs(dl_val - PL[j_global]))

            # 处理全局起点 (0,0) 的特殊情况
            if start_idx_global == 0 and i_local == 0 and j_global == 0:
                block_dp[i_local, j_idx] = current_lr
                continue

            # idx_p 对应 (i-1, j), idx_pd 对应 (i-1, j-1)
            idx_p = j_global - s_prev
            idx_pd = (j_global - 1) - s_prev

            # 从参考行中获取值
            val_p = ref_row[idx_p] if 0 <= idx_p < W else MAX_VAL
            val_pd = ref_row[idx_pd] if 0 <= idx_pd < W else MAX_VAL

            term1 = max(val_pd, current_lr)
            if start_idx_global == 0 and i_local == 0: #：F[0][j]=min(F[0][j-1],E(0,j))
                term1 = current_lr
            # horizontal = 当前行左侧格子的值
            horizontal = block_dp[i_local, j_idx - 1] if j_idx > 0 else MAX_VAL

            # 当前格子的值 = min(term1, horizontal)
            block_dp[i_local, j_idx] = min(term1, horizontal)

    return block_dp


def frechet_distance(DL, PL, file, W=840, sigma=1.2):
    """
    保留原有参数：DL(预测), PL(真实), file(磁盘缓存), W(窗口宽度)
    """
    N, M = len(DL), len(PL)

    cache_number = 10000
    MAX_VAL = 100000000

    DL_np = np.array(DL, dtype=np.float64)
    PL_np = np.array(PL, dtype=np.float64)

    # 预分配磁盘空间
    with open(file, 'wb') as f:
        f.truncate(N * W * 4)

    # 初始化衔接变量
    prev_row_dp = np.full(W, MAX_VAL, dtype=np.int32)
    prev_start_j = 0

    # 顺序分块计算并写入磁盘
    with open(file, 'rb+') as f:
        for start_idx in range(0, N, cache_number):
            end_idx = min(start_idx + cache_number, N)

            # 计算当前块每一行的 start_j
            block_indices = np.arange(start_idx, end_idx)
            center_j = (block_indices * sigma).astype(np.int32)
            # j 必须 >= i，且围绕预测中心，不能超过 M 边界
            starts_j = np.maximum(block_indices, np.minimum(center_j - W // 2, M - W))

            # 执行加速计算
            block_dp = compute_block_core(
                DL_np[start_idx:end_idx],
                PL_np,
                starts_j,
                prev_row_dp,
                prev_start_j,
                W, M, MAX_VAL,
                start_idx  # 传入全局偏移量
            )

            # 顺序大块写入磁盘，极大提升 I/O 效率
            f.seek(start_idx * W * 4)
            f.write(block_dp.tobytes())

            # 更新下一块的衔接数据
            prev_row_dp = block_dp[-1].copy()
            prev_start_j = starts_j[-1]

    match_results = []
    curr_j = M - 1

    with open(file, 'rb') as f_back:
        def read_f(row, col):
            center = int(row * sigma)
            s_j = max(row, min(center - W // 2, M - W))
            idx = col - s_j
            if 0 <= idx < W:
                f_back.seek((row * W + idx) * 4)
                data = f_back.read(4)
                return struct.unpack('i', data)[0] if len(data) == 4 else MAX_VAL
            return MAX_VAL

        last_epsilon = read_f(N - 1, M - 1)
        # 反向回溯路径
        for i in range(N - 1, -1, -1):
            n1 = curr_j
            v1 = read_f(i, n1)
            n2 = n1 - 1
            # 在当前行寻找满足 DP 值的最小 j
            while n2 >= i:
                v2 = read_f(i, n2)
                if v2 == v1:
                    if abs(DL[i] - PL[n2]) < abs(DL[i] - PL[n1]):
                        n1 = n2
                        n2 = n1 - 1
                    else:
                        break
                else:
                    break

            match_results.append([DL[i], PL[n1]])
            # 强制单射性：下一次匹配的 j 必须严格小于当前 j
            curr_j = n1 - 1

    return last_epsilon, sorted(match_results, key=lambda x: x[1])

def main():
    os.chdir('..')
    cur_dir = os.getcwd()
    D1_path = f'{cur_dir}\\pre_test_j\\6_1\\omp\\p.csv'
    DL = pd.read_csv(D1_path).values.flatten().tolist()
    DL=DL
    print(len(DL))
    # err=DL-list(range(40000,40000+len(DL)))
    import numpy as np


    PL = list(range(0,0+math.ceil(len(DL) * 1.2)))

    ratio = 1.2
    chunk_size = len(DL)
    overlap = 0

    max_errors = []  # 最大误差
    start_PL =0
    result=[]
    t1=time.time()
    file = f'{cur_dir}\\pre_test_j\\6_1\\pd_block.txt'
    if not os.path.exists(file):
        open(file, 'w').close()

    max_, result = frechet_distance(DL,PL,file)
    # path = f'{cur_dir}\\pre_test_j\\9_1\\omp\\e.csv'
    # err = pd.read_csv(path)
    err= np.abs(DL-np.floor(np.arange(len(DL)) * 1.2).astype(int))
    print("当前平均误差：",err.sum()/len(err))
    diff_sequence=[item[0]-item[1] for item in result]
    max_errors.append({
        "- max_error": min(diff_sequence),
        "+max_error":max(diff_sequence)
    })
    file_size = os.path.getsize(file)
    print(f"当前文件大小: {file_size/1024} KB")
    # 删除中间缓存文件
    try:
        os.remove(file)
    except Exception as e:
        print(f'⚠️ 删除临时文件失败: {e}')

    print(err[400:450])
    print("原始最大误差：",  err.max())
    print(f"- 当前max_error{min(diff_sequence)},max_error{max(diff_sequence)}")
    t2 = time.time()
    print("总时间：",t2-t1)
    ers=[]
    for item in result:
        # 计算第一列（index=0）与第二列（index=1）的差值
        diff = item[1] - item[0]
        ers.append(diff)
    abs_ers = [abs(x) for x in ers]
    abs_sum = sum(abs_ers)
    print(len(ers))
    print("平均误差：",abs_sum/len(ers))
   #  result_df = pd.DataFrame(max_errors)
   #  save_path = f'{cur_dir}\\pre_test\\2_1\\max_errors.csv'
    result_path= f'{cur_dir}\\pre_test_j\\6_1\\match_result.pkl'
    dump_model(result,result_path)
   #  result_df.to_csv(save_path, index=False, encoding='utf-8-sig')
   #  result=load_model(result_path)

# def main():
# #
#     os.chdir('..')
#     cur_dir=os.getcwd()
# #     D1_path=f'{cur_dir}\\pre_test\\2_1\\pre_idxs1.csv'
# #     DL=pd.read_csv(D1_path).values.flatten()  # 变成一维数组
# #     # ML=np.arange(0, DL.shape[0], dtype=np.int32)
# #     PL= list(range(math.ceil(DL.shape[0]*1.05)))
# #     DL = DL.tolist()
# #
# #
#     file = f'{cur_dir}\\pre_test\\2_1\\pd.txt'
# #
# #     if not os.path.exists(file):
# #         open(file, 'w').close()
# #
#     DL = [10,10,10]
#     PL = [8,9,10,11,12]
#
#     #
#     DL = [5,5,5,6,6,7,7,8,8,8,15,17,17,18]
#     PL = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17]
#
#     DL = [1,3,7,7,8,9]
#     PL = [1,2,3,4,5,6,7,8,9]
#     #
#     # DL = [5, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 15, 17]
#     # PL = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17]
#     TL=[1,2,3,4,6,7,9,10,11,12,13,14,15,16]
#
#
#     TL = [1, 2, 4, 5, 7, 8]
#
#     # TL=list(range(1,len(DL)+1))
#     diff_abs=[abs(d - p) for d, p in zip(DL, TL)]
#     max_diff=max(diff_abs)
#     max_, match_results=frechet_distance(DL,PL,file)

if __name__ == "__main__":
    main()
