"""获取成都道路的连接信息"""
import pandas as pd
import ast
import pickle
from collections import defaultdict
road_info_file = rf'E:\成都数据\道路信息.csv'
chd_road_connections_info_file = rf'E:\成都数据\chd_road_connections_info.pkl'


if __name__ == '__main__':
    # 创建一个字典来存储连接信息
    connections_dict = defaultdict(set)
    road_start_and_end_segment = {}  # 保存每个道路的起始和结尾路段编号
    road_info = pd.read_csv(road_info_file)
    road_info = road_info[['id', 'segment']]
    for index, row in road_info.iterrows():
        road_id = int(row['id'])
        row['segment'] = ast.literal_eval(row['segment'])
        start_segment_id = row['segment'][0][0]
        end_segment_id = row['segment'][-1][-1]
        if road_id not in road_start_and_end_segment.keys():
            road_start_and_end_segment[road_id] = (int(start_segment_id), int(end_segment_id))

    # 创建一个字典，用于记录每个路段ID对应的道路ID
    segment_to_road = {}
    for road_id, (start_seg, end_seg) in road_start_and_end_segment.items():
        segment_to_road[start_seg] = road_id
        segment_to_road[end_seg] = road_id

    # 遍历所有道路，检查连接关系
    for road_id, (start_seg, end_seg) in road_start_and_end_segment.items():
        # 如果当前道路的起始路段是其他道路的结尾路段，则连接
        if start_seg in segment_to_road:
            connected_road_id = segment_to_road[start_seg]
            if connected_road_id != road_id:  # 排除自身
                connections_dict[road_id].add(connected_road_id)
        # 如果当前道路的结尾路段是其他道路的起始路段，则连接
        if end_seg in segment_to_road:
            connected_road_id = segment_to_road[end_seg]
            if connected_road_id != road_id:  # 排除自身
                connections_dict[road_id].add(connected_road_id)

    print(connections_dict)
    with open(chd_road_connections_info_file, 'wb') as f:
        pickle.dump(connections_dict, f)
