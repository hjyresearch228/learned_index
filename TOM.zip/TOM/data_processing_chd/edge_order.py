"""
1   抽取一定数量的样本轨迹数据
2   从道路连接信息文件中获取该样本中存在的道路，然后对该样本中的道路进行排序
3   将排序好的道路持久化入磁盘
4   按照排序好的道路对轨迹进行排序，并将排序好的轨迹写入磁盘，该文件保留5个字段：[时间，道路ID，路段ID，相对路段起始点的距离，路段长度]
"""
from natsort import natsorted
import pickle
from utils.file_utils import *
import pandas as pd
import os
from get_connection_info import chd_road_connections_info_file

data_parent_path = 'E:/成都数据/成都数据-分期csv/'
# out_put_dir = 'E://Python_Projects//Learned_Index//TOM//data//REAL//'
out_put_dir = '/\\data\\REAL\\'
data_num = 2000000
dt_num = '200W'

period_num = 7



def get_data(dir):
    """取样200w数据"""
    data_size = 0
    data = pd.DataFrame()
    file_list = natsorted(os.listdir(dir))
    # print(file_list[0], file_list[-1])
    for i in range(0, len(file_list), 11):
        print(file_list[i])
        if data_size >= data_num:
            break
        df = pd.read_csv(f'{dir}{file_list[i]}')
        data_size += df.shape[0]
        print(f'当前总数据量: {data_size}')
        if not df.empty:
            data = pd.concat([data, df], ignore_index=True)
    return data


def edge_order(connections, data, edges):
    '''dfs排序道路'''
    ordered_edges = []  # 排序之后的道路
    visited = set()  # 标记已访问数组
    # 随机选择一条道路
    # first_edge = int(str(data['way_id']).str.split('#').str[0][0])
    first_edge = int(data['way_id'][0])
    ordered_edges.append(first_edge)
    visited.add(first_edge)
    ordered_edges += dfs(first_edge, connections, edges, visited)
    for edge in connections.keys():
        if edge in edges and edge not in visited:
            ordered_edges.append(edge)
            visited.add(edge)
            ordered_edges += dfs(edge, connections, edges, visited)
    return ordered_edges


def dfs(edge, connections, edges, visited):
    ordered_edges = []
    if -edge in connections[edge] and -edge not in visited and -edge in edges:
        ordered_edges.append(-edge)
        visited.add(-edge)
        connections[edge].remove(-edge)
    stack = list(set(edges) & set(connections[edge]))
    while stack:
        next_edge = stack.pop()
        if next_edge not in visited:
            visited.add(next_edge)
            ordered_edges.append(next_edge)
            if next_edge in connections.keys():
                if -next_edge in connections[next_edge] and -next_edge not in visited and -next_edge in edges and next_edge in connections:
                    ordered_edges.append(-next_edge)
                    visited.add(-next_edge)
                    connections[next_edge].remove(-next_edge)
                for con in connections[next_edge]:
                    if con not in visited and con in edges:
                        stack.append(con)
    return ordered_edges


def sort_data_by_edges(data, sorted_edges):
    # 读取CSV文件
    df = data
    # 新增一列，提取纯道路ID（去掉#及后面的路段ID部分）
    df['pure_edgeID'] = df['way_id'].apply(lambda x: str(x).split('#')[0])
    # 新增一列，提取路段ID
    df['segmentID'] = df['segment_id'].apply(lambda x: int(str(x).split('.')[0]))
    # 按照sorted_edges顺序排序
    sorted_df = pd.DataFrame()
    for edge in sorted_edges:
        edge_str = str(edge)
        # 找出匹配的子数据框
        temp_df = df[df['pure_edgeID'] == edge_str]
        # 按照segmentID进一步排序
        temp_df = temp_df.sort_values(by=['segmentID'])
        # 追加到结果数据框
        sorted_df = pd.concat([sorted_df, temp_df], ignore_index=True)
    # 删除临时列
    sorted_df.drop(columns=['segmentID'], inplace=True)
    return sorted_df


if __name__ == '__main__':
    with open(chd_road_connections_info_file, 'rb') as f:
        connection_info = pickle.load(f)
    for i in range(period_num):
        pos_t_file = f'{out_put_dir}EP{i}/200W_P{i}_chd.txt'
        out_put_file = f'{out_put_dir}EP{i}\\{dt_num}_P{i}.csv'
        chd_data_path = f'{data_parent_path}/period_{i}/'
        # file_list = sorted(os.listdir(chd_data_path))
        if not os.path.exists(out_put_file):
            data = get_data(dir=chd_data_path)
            data.to_csv(out_put_file, index=False)
        else:
            data = pd.read_csv(out_put_file)
        # 获得样本轨迹中的所有道路ID
        edges = set(data['way_id'])
        edges = list(map(int, edges))
        print('---------处理道路----------')
        ordered_edge = edge_order(connection_info, data, edges)
        print(f'------道路排序完成, 写入文件-----')
        # dump_model(ordered_edge, ordered_edges_file)
        dump_model(ordered_edge, f'{out_put_dir}EP{i}/ordered_edges.pkl')
        print(f'--------排序轨迹----------')
        sorted_df = sort_data_by_edges(data, ordered_edge)
        sorted_data = sorted_df[['time', 'way_id', 'segment_id', 'dist', 'segment_length']]
        print(f'------轨迹排序完成，写入文件------')
        sorted_data.to_csv(pos_t_file, header=False, index=False, sep=',')
        # print(f'道路已排序至文件 {out_put_dir}EP{i}/ordered_edges.pkl')
        # print(ordered_edge, len(ordered_edge))
        print(f'第{i}期 {dt_num}数据已经抽取到文件 {pos_t_file}')