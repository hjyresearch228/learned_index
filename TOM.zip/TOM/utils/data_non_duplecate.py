"""数据去重"""

import pandas as pd
import os

# 主目录路径
main_directory = r'E:\Python_Projects\Learned_Index\TOM_update\data\REAL'  # 替换为你的主目录路径


# 遍历子目录 EPi
for i in range(7):
    unique_rows = []
    seen_rows = set()
    duplicate_rows = []
    sub_directory = f'EP{i}'  # 子目录名称
    file_path = os.path.join(main_directory, sub_directory, '200W_P{}.txt'.format(i))  # 构造文件路径

    # 尝试加载数据
    try:
        data = pd.read_csv(file_path, header=None, delimiter=',')  # 假设数据以逗号分隔

        for row in data.itertuples(index=False, name=None):
            row_tuple = tuple(row)  # 将行转换为元组
            if row_tuple in seen_rows:
                duplicate_rows.append(row)
            else:
                seen_rows.add(row_tuple)
                unique_rows.append(row)  # 保持原始顺序
    except Exception as e:
        print(f"无法加载文件 {file_path}: {e}")

    # 将唯一数据行写入新文件
    output_file_path = file_path
    with open(output_file_path, 'w') as f:
        for x, y in unique_rows:
            f.write(f'{x},{y}\n')
    print(f"唯一数据行已写入 {output_file_path}")