import pickle
import os
import numpy as np
import src.const as const
import pandas as pd
import shutil
import random



def generate_knn_query_data(data_file, query_file, query_num=100, k_list=None, patten='SIM'):
    """随机生成n个knn查询"""
    if k_list is None:
        k_list = [i for i in range(2, 21, 2)]
    data_list = read_txt_to_list(data_file)
    selected_points = random.sample(data_list, query_num)
    with open(query_file, 'w') as f:
        for k in k_list:
            for p in selected_points:
                f.write(f'{p[0]}, {p[1]}, {k}\n')


def generate_point_query_data(query_file, data_file, query_num=100, patten='SIM'):
    data_list = read_txt_to_list(data_file)
    random_points = random.sample(data_list, query_num)
    with open(query_file, 'w') as f:
        for x, y in random_points:
            f.write(f'{x}, {y}\n')


def generate_range_query_data(data_file, query_file, query_num=100, patten="SIM"):
    data_df = pd.read_csv(data_file, delimiter=',', header=None, names=['pos', 't'])
    # max_pos = data_df['pos'].astype(float).max()
    if patten == "SIM":
        max_pos = const.MAX_POS_SIM
    else:
        max_pos = const.MAX_POS_REAL
    # min_pos = data_df['pos'].astype(float).min()
    if patten == 'SIM':
        min_pos = const.MIN_POS_SIM
    else:
        min_pos = const.MIN_POS_REAL
    # max_t = data_df['t'].astype(float).max()
    if patten == 'SIM':
        max_t = const.MAX_T_SIM
    else:
        max_t = const.MAX_T_REAL
    # min_t = data_df['t'].astype(float).min()
    if patten == 'SIM':
        min_t = const.MIN_T_SIM
    else:
        min_t = const.MIN_T_REAL
    assert min_t >= 0
    assert max_t >= 0
    assert max_pos >= 0
    assert min_pos >= 0
    area = (max_t - min_t) * (max_pos - min_pos)
    # print(area)
    # list_ = [0.00001, 0.0005, 0.0001, 0.005]
    list_ = [0.005]
    with open(query_file, 'w') as fff:
        for l_ in list_:
            area_part = area * l_
            # print(area_part)
            for i in range(query_num // len(list_)):
                lt = random.uniform(min_t, max_t - area_part ** 0.5)
                lp = random.uniform(min_pos, max_pos - area_part ** 0.5)
                # 计算右上角坐标
                rt = lt + area_part ** 0.5
                rp = lp + area_part ** 0.5
                assert lp >= 0
                assert lt >= 0
                assert rp >= 0
                assert rt >= 0
                fff.write(f'{np.round(lp, 3)},{np.round(lt, 3)},{np.round(rp, 3)},{np.round(rt, 3)}\n')


def decimal_to_binary_str(decimal, length):
    """将十进制转成二进制串"""
    binary_str = bin(decimal)[2:]  # 转换为二进制并去掉前缀 '0b'
    # 补零或截断
    return binary_str.zfill(length)[-length:]


def dump_model(models, model_file):
    with open(model_file, 'wb') as f:
        pickle.dump(models, f)


def load_model(model_file):
    with open(model_file, 'rb') as f:
        return pickle.load(f)


def clean_batch(file_lit):
    for file in file_lit:
        if os.path.exists(file):
            os.remove(file)


def clean_file(file):
    if os.path.exists(file):
        os.remove(file)


def read_txt_to_list(file_txt):
    dt = []
    with open(file_txt, 'r') as f:
        data = f.readlines()
        for line in data:
            d = tuple(map(float, line.strip().split(',')))
            dt.append(d)
    return dt


def read_txt_to_np(file):
    dt = []
    with open(file, 'r') as f:
        data = f.readlines()
        for line in data:
            d = tuple(map(float, line.strip().split(',')))
            dt.append(d)
    return np.array(dt)


def print_max_min(file):
    data = read_txt_to_np(file)
    max_pos = np.max(data[:,0])
    min_pos = np.min(data[:,0])
    max_t = np.max(data[:,1])
    min_t = np.min(data[:,1])
    print(f'max_pos = {max_pos}, min_pos = {min_pos}\nmax_t = {max_t}, min_t = {min_t}')


def check_dir(path):
    if not os.path.exists(path):
        os.mkdir(path)



data_patten = const.PATTEN
for i in range(0, const.PERIOD_NUM):
    period_knn_file = const.KNN_QUERY_FILE[data_patten][i]
    if os.path.exists(period_knn_file):
        clean_file(period_knn_file)
    if not os.path.exists(period_knn_file):
        generate_point_query_data(data_file=const.ORI_FILE[data_patten][i], query_file=const.KNN_QUERY_FILE[data_patten][i], patten=data_patten)
        # generate_knn_query_data(data_file=const.ORI_FILE[data_patten][i],
        #                         query_file=const.KNN_QUERY_FILE[data_patten][i], patten=data_patten)


def is_same_list(tmp_result, np_array_list, tol=1e-3):
    sorted_tmp_result = sorted(tmp_result, key=lambda x: (x[0], x[1]))
    sorted_real_result = sorted(np_array_list, key=lambda x: (x[0], x[1]))
    for tup, arr in zip(sorted_tmp_result, sorted_real_result):
        arr2tup = tuple(arr)
        if not all(abs(a - b) < tol for a, b in zip(tup, arr2tup)):
            return False
    return True


def get_distance(self, p1, p2):
    return (p1[0] - p2[0])**2 + (p1[1] - p2[1])**2


patten = ['SIM', 'REAL']
for p in patten:
    for i in range(const.PERIOD_NUM):
        check_dir(rf'../query/{p}/EP{i}')
        shutil.copy(const.low_se_query_file[p][i], rf'../query/{p}/EP{i}/low_query_0.00001.txt')
        # generate_range_query_data(const.ORI_FILE[p][i], query_file=const.high_se_query_file[p][i], query_num=100, patten=p)
