import pickle
import os
import numpy as np
import src.const as const
import pandas as pd
import random


def generate_point_query_data(query_file, data_file, query_num=100, patten='SIM'):
    data_list = read_txt_to_list(data_file)
    random_points = random.sample(data_list, query_num)
    with open(query_file, 'w') as f:
        for x, y in random_points:
            f.write(f'{x}, {y}\n')


def generate_range_query_data(data_file, query_file, query_num=100, patten="SIM"):
    data_df = pd.read_csv(data_file, delimiter=',', header=None, names=['pos', 't'])
    # max_pos = data_df['pos'].astype(float).max()
    if patten == "SIM":
        max_pos = const.MAX_POS_SIM
    else:
        max_pos = const.MAX_POS_REAL
    # min_pos = data_df['pos'].astype(float).min()
    if patten == 'SIM':
        min_pos = const.MIN_POS_SIM
    else:
        min_pos = const.MIN_POS_REAL
    # max_t = data_df['t'].astype(float).max()
    if patten == 'SIM':
        max_t = const.MAX_T_SIM
    else:
        max_t = const.MAX_T_REAL
    # min_t = data_df['t'].astype(float).min()
    if patten == 'SIM':
        min_t = const.MIN_T_SIM
    else:
        min_t = const.MIN_T_REAL
    assert min_t >= 0
    assert max_t >= 0
    assert max_pos >= 0
    assert min_pos >= 0
    area = (max_t - min_t) * (max_pos - min_pos)
    # print(area)
    list_ = [0.00001, 0.0005, 0.0001, 0.005]
    with open(query_file, 'w') as fff:
        for l_ in list_:
            area_part = area * l_
            # print(area_part)
            for i in range(query_num // len(list_)):
                lt = random.uniform(min_t, max_t - area_part ** 0.5)
                lp = random.uniform(min_pos, max_pos - area_part ** 0.5)
                # 计算右上角坐标
                rt = lt + area_part ** 0.5
                rp = lp + area_part ** 0.5
                assert lp >= 0
                assert lt >= 0
                assert rp >= 0
                assert rt >= 0
                fff.write(f'{np.round(lp, 3)},{np.round(lt, 3)},{np.round(rp, 3)},{np.round(rt, 3)}\n')


def decimal_to_binary_str(decimal, length):
    """将十进制转成二进制串"""
    binary_str = bin(decimal)[2:]  # 转换为二进制并去掉前缀 '0b'
    # 补零或截断
    return binary_str.zfill(length)[-length:]


def dump_model(models, model_file):
    with open(model_file, 'wb') as f:
        pickle.dump(models, f)


def load_model(model_file):
    with open(model_file, 'rb') as f:
        return pickle.load(f)


def clean_batch(file_lit):
    for file in file_lit:
        if os.path.exists(file):
            os.remove(file)


def clean_file(file):
    if os.path.exists(file):
        os.remove(file)


def read_txt_to_list(file_txt):
    dt = []
    with open(file_txt, 'r') as f:
        data = f.readlines()
        for line in data:
            d = tuple(map(float, line.strip().split(',')))
            dt.append(d)
    return dt


def read_txt_to_np(file):
    dt = []
    with open(file, 'r') as f:
        data = f.readlines()
        for line in data:
            d = tuple(map(float, line.strip().split(',')))
            dt.append(d)
    return np.array(dt)


def print_max_min(file):
    data = read_txt_to_np(file)
    max_pos = np.max(data[:,0])
    min_pos = np.min(data[:,0])
    max_t = np.max(data[:,1])
    min_t = np.min(data[:,1])
    print(f'max_pos = {max_pos}, min_pos = {min_pos}\nmax_t = {max_t}, min_t = {min_t}')


def check_dir(path):
    if not os.path.exists(path):
        os.mkdir(path)

