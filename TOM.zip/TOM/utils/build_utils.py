"""构建TOM使需要的一些工具"""

import src.const as const
import numpy as np
from utils.file_utils import *


def find_left_non_default_on_partition(stripe_list, stripe_id):
    """如果有一期的斜条数据是0，那么需要延伸到整个partition"""
    for s_id in range(stripe_id - 1, -1, -1):
        stripe = stripe_list[s_id]
        region_list = stripe.region_list
        for region_id in range(len(region_list)):
            if region_list[region_id].zero_period_block_range != const.DEFAULT_REGION_BLOCK_RANGE:
                return region_list[region_id].e_b_id
        return None


def find_right_non_default_on_partition(stripe_list, stripe_id):
    """如果有一期的斜条数据是0，那么需要延伸到整个partition"""
    for s_id in range(stripe_id + 1, len(stripe_list), 1):
        stripe = stripe_list[s_id]
        region_list = stripe.region_list
        for region_id in range(len(region_list)):
            if region_list[region_id].zero_period_block_range != const.DEFAULT_REGION_BLOCK_RANGE:
                return region_list[region_id].s_b_id
        return None


def find_left_non_default(region_list, idx):
    """当前期的非溢出块范围是默认值时，需要在周边搜索第一个非默认值的region,用来填充第三个维度"""
    for i in range(idx - 1, -1, -1):
        if region_list[i].zero_period_block_range != const.DEFAULT_REGION_BLOCK_RANGE:
            return region_list[i].e_b_id
    return None


def find_right_non_default(region_list, idx):
    for i in range(idx + 1, len(region_list)):
        if region_list[i].zero_period_block_range != const.DEFAULT_REGION_BLOCK_RANGE:
            return region_list[i].s_b_id
    return None


def make_consecutive_incrementing(lst):
    """使列表的元素单调且步长是1"""
    if len(lst) <= 1:
        return lst, [], []
    sorted_lst = sorted(lst)
    full_lst = list(range(sorted_lst[0], sorted_lst[-1] + 1))
    added_values = [x for x in full_lst if x not in sorted_lst]
    return full_lst, added_values


def is_consecutive_incrementing(lst):
    """检查列表的元素是否单调且步长是1"""
    if len(lst) <= 1:
        return True
    sorted_lst = sorted(lst)
    for i in range(len(sorted_lst) - 1):
        if sorted_lst[i + 1] - sorted_lst[i] != 1:
            return False
    return True


def is_monotonic_increasing_with_step_1(lst):
    if not lst:
        return True  # 空列表视为满足条件
    non_continuous_parts = []
    for i in range(1, len(lst)):
        if lst[i] != lst[i - 1] + 1:
            # 记录不连续的位置及其周围数据
            start = max(0, i - 2)  # 取前两个元素
            end = min(len(lst), i + 2)  # 取后两个元素
            non_continuous_parts.append(lst[start:end])
    if not non_continuous_parts:
        return True  # 列表单调递增且步长为 1
    else:
        print("列表不满足单调递增且步长为 1 的条件。不连续的部分如下：")
        for part in non_continuous_parts:
            print(part)
        return False


def cal_cur_model_base_pos_t(ps_arr, t_arr, rd_0, init_dv, rd_arr_cur):
    """计算当前期数的模型参数：ps_cur, t_cur"""
    # assert len(ps_arr) == len(t_arr) == len(rd_arr_cur), print(f'后期数据各个维度的长度不一致')
    N = len(ps_arr)
    psc_cur = (init_dv[0] / init_dv[2]) * (rd_0 - (1 / N) * np.sum(rd_arr_cur)) + (1 / N) * np.sum(ps_arr)
    tc_cur = (init_dv[1] / init_dv[2]) * (rd_0 - (1 / N) * np.sum(rd_arr_cur)) + (1 / N) * np.sum(t_arr)
    return psc_cur, tc_cur


def cal_model_max_error_over_pre(Ak, P0, m0, n0, i, k, pscj: list, psk, tcj: list, tk):
    """
    计算集成模型在前期某一期特定期数数据的误差上界
    Ak: 特定期数模型的最大误差
    P0: 初期的z轴系数
    m0： 初期x轴系数
    n0：初期y轴系数
    i: 当前集成模型所属的期数，即Ak所在的期数
    k： 前期特定期数
    pscj: 第k期后面期数的基点pos,假设当前在第2期,即i=2，设k=0,则此值为[1期pos,2期pos].当前在第3期,k=1 =>[2期pos,3期pos]
    psk: 第k期的基点pos
    tcj：第k期之后期数的基点t，
    tk：第k期的基点t
    """
    # 计算 ∑2^(j-k-1) * pscj - (2^(i-k) - 1) * psk
    psc_sum = sum(2 ** (j - k - 1) * pscj[j - (k + 1)] for j in range(k + 1, i + 1))
    psc_term = abs(psc_sum - (2 ** (i - k) - 1) * psk)
    psc_factor = (P0 / (2 ** (i - k + 1) * m0))
    # 计算 ∑2^(j-k-1) * tcj - (2^(i-k) - 1) * tk
    tc_sum = sum(2 ** (j - k - 1) * tcj[j - (k + 1)] for j in range(k + 1, i + 1))
    tc_term = abs(tc_sum - (2 ** (i - k) - 1) * tk)
    tc_factor = (P0 / (2 ** (i - k + 1) * n0))
    result = (Ak + psc_factor * psc_term + tc_factor * tc_term)
    return result


def find_differences(*lists):
    differences = {}
    if not lists:
        return differences
    length = len(lists[0])
    for i in range(length):
        values = [lst[i] for lst in lists]
        tuple_values = [tuple(item) if isinstance(item, list) else item for item in values]
        if len(set(tuple_values)) > 1:
            differences[i] = values
    return differences


# 示例使用
lists = []
pat = const.PATTEN
for i in range(1, const.PERIOD_NUM):
    lists.append(load_model(const.PERIOD_MODEL_ERROR_BOUND_FILE[pat][i]))
result = find_differences(*lists)
for index, values in result.items():
    print(f"索引 {index} 处不同，值分别为: {values}")
