
"""以可视化的形式显示出网格数据和斜条的分布，并将保存的空间直线投射到该二维网格中"""

import matplotlib.pyplot as plt
import os
from collections import defaultdict
import numpy as np

# 设置中文字体，以下为常见的中文字体名称
plt.rcParams['font.sans-serif'] = ['SimHei']  # 黑体
plt.rcParams['axes.unicode_minus'] = False    # 用来正常显示负号

dir = '..\\data\\data'
model_dir = '..\\result\\models'
file_list = []
for file in os.listdir(dir):
    if file.endswith('.pkl'):
        file_list.append(file)
from src.const import *
from utils.file_utils import *
from src.curves import *

cell_plot_dir = '..\\study\\cell_plot'
cell_stripe_model_plot_dir = '..\\study\\模拟10期_第一期'

models_dir = '..\\data\\models'
model_path_list = []
for f in os.listdir(models_dir):
    if f.endswith('.pkl'):
        model_path_list.append(f)

boundary_x = load_model(x_boundary_file)
boundary_y = load_model(y_boundary_file)



for k in range(len(boundary_x) - 1):
    for j in range(len(boundary_y) - 1):
        bx = [boundary_x[k], boundary_x[k+1]]
        by = [boundary_y[j], boundary_y[j+1]]
        hilbert_v = k * N_ROWS + j
        points_list = []
        model_file_list = []
        # for file in file_list:
        #     file_split = file.split('.')

            # 确定cell的序号
            # 获得某个cell的所有斜条序号,然后加入斜条数据列表
        result = [item.split('.')[1] for item in file_list if int(item.split('.')[0]) == hilbert_v]
        for stripe_id in result:
            points_list.append(dir+'\\'+str(hilbert_v)+'.'+stripe_id+'.pkl')
            model_id = []
            for item in model_path_list:
                if (int(item.split('.')[0])==hilbert_v and item.split('.')[1]==stripe_id):
                    model_id.append(item.split('.')[2])
            for id in model_id:
                model_file_list.append(models_dir+'\\'+str(hilbert_v)+'.'+stripe_id+'.'+id+'.pkl')
        array_list = []
        for points in points_list:
            array_list.append(load_model(points))
        model_list = defaultdict(list)
        for model in model_file_list:
            stripe_id = model.split('.')[3]
            model_list[stripe_id].append(load_model(model))

        plt.figure(figsize=(10, 6))
        # 绘制矩形边界
        plt.plot([bx[0], bx[1], bx[1], bx[0], bx[0]], [by[0], by[0], by[1], by[1], by[0]], color='red', linewidth=2, label='Boundary')

        # 遍历每个 NumPy 数组
        # 定义颜色映射

        assert len(model_list) == len(array_list)
        for i, array in enumerate(array_list):
            array = np.array(array)
            x = array[:, 0]  # 提取 x 坐标
            y = array[:, 1]  # 提取 y 坐标
            plt.scatter(x, y, alpha=0.5, label=f'斜条{i}')  # 绘制散点图

            colors = ['red', 'blue', 'green', 'black', 'purple', 'yellow', 'cyan', 'orange', 'gray', 'brown']
            # 绘制直线
            for s_id, models in model_list.items():
                for model in models:
                    # 定义直线参数
                    [x0, y0, z0] = model[2]  # 基点
                    [m, n, p] = model[3]  # 方向向量

                    # 定义 x 的范围
                    x_low, x_high = model[0], model[1]

                    # 根据 x 的范围计算 t 的范围
                    t_low = (x_low - x0) / m
                    t_high = (x_high - x0) / m
                    # 生成 t 的值
                    t = np.linspace(t_low, t_high, 100)  # 在[t_low, t_high]区间内生成100个点
                    # 计算直线坐标
                    x = x0 + m * t
                    y = y0 + n * t
                    z = z0 + p * t  # 这个值在投影中不会使用，但依然计算出来以保持一致性
                    # plt.plot(x, y, color='r')
                    # plt.plot(x, y, color=colors[i % len(colors)])
                    plt.plot(x, y, color=colors[int(s_id)])

        # 设置坐标轴范围
        plt.xlim(bx[0], bx[1])
        plt.ylim(by[0], by[1])

        # 添加标题和标签
        plt.title('cell'+str(hilbert_v)+'数据分布')
        plt.xlabel('X-axis')
        plt.ylabel('Y-axis')
        plt.legend()
        # plt.grid(True)
        plt.savefig(cell_stripe_model_plot_dir+'\\'+str(hilbert_v)+'.png', dpi=300)
        plt.show()