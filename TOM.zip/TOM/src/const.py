import math
import struct
import sys
from enum import Enum

"""
现在(2025.2.20)每一期的每个region在查询时的误差根据公式计算的最大值来，而不是我们设定的阈值，现在这个设定
的阈值仅仅是作为后期重组region的根据
也就是说，现在每一期都需要为每个region保存对应的最大误差。
"""

TOM2 = False
DEFAULT_REGION_BLOCK_RANGE = [222222222, 222222222]  # 默认region的非溢出块范围
DEFAULT_OVERFLOW_BLOCKS = [222222222, 222222222]  # 后期region默认的溢出块范围

MAX_POS_SIM = 1.225e7  # 模拟数据最大的pos,需要将该值修改为实际最大值+10(稍大即可)
MAX_T_SIM = 65000  # 模拟数据最大t，需要将该值修改为实际最大值+10(稍大即可)

PATTEN = 'SIM'
PERIOD_NUM = 7

MAX_POS_REAL = 1.935e6  # 真实数据最大pos
MAX_T_REAL = 1407110400  # 成都数据最大t

MIN_POS_SIM = 0  # 以下为最小的pos和t，也需要修改为实际最小值减1(稍微比最小值小即可)
MIN_T_SIM = 0

MIN_POS_REAL = 0
MIN_T_REAL = 1407016799

# 保存实际的查询结果数量
actual_period_result_num_file = {
    'SIM': {
        0: '..\\result\\SIM\\EP0\\actual_result_num.txt',
        1: '..\\result\\SIM\\EP1\\actual_result_num.txt',
        2: '..\\result\\SIM\\EP2\\actual_result_num.txt',
        3: '..\\result\\SIM\\EP3\\actual_result_num.txt',
        4: '..\\result\\SIM\\EP4\\actual_result_num.txt',
        5: '..\\result\\SIM\\EP5\\actual_result_num.txt',
        6: '..\\result\\SIM\\EP6\\actual_result_num.txt',
    },
    'REAL': {
        0: '..\\result\\REAL\\EP0\\actual_result_num.txt',
        1: '..\\result\\REAL\\EP1\\actual_result_num.txt',
        2: '..\\result\\REAL\\EP2\\actual_result_num.txt',
        3: '..\\result\\REAL\\EP3\\actual_result_num.txt',
        4: '..\\result\\REAL\\EP4\\actual_result_num.txt',
        5: '..\\result\\REAL\\EP5\\actual_result_num.txt',
        6: '..\\result\\REAL\\EP6\\actual_result_num.txt',
    }
}

# 保存实际的物理块（通过暴力搜索）
actual_period_physical_block_ids_file = {
    'SIM': {
        0: '..\\result\\SIM\\EP0\\actual_physical_ids.txt',
        1: '..\\result\\SIM\\EP1\\actual_physical_ids.txt',
        2: '..\\result\\SIM\\EP2\\actual_physical_ids.txt',
        3: '..\\result\\SIM\\EP3\\actual_physical_ids.txt',
        4: '..\\result\\SIM\\EP4\\actual_physical_ids.txt',
        5: '..\\result\\SIM\\EP5\\actual_physical_ids.txt',
        6: '..\\result\\SIM\\EP6\\actual_physical_ids.txt',
    },
    'REAL': {
        0: '..\\result\\REAL\\EP0\\actual_physical_ids.txt',
        1: '..\\result\\REAL\\EP1\\actual_physical_ids.txt',
        2: '..\\result\\REAL\\EP2\\actual_physical_ids.txt',
        3: '..\\result\\REAL\\EP3\\actual_physical_ids.txt',
        4: '..\\result\\REAL\\EP4\\actual_physical_ids.txt',
        5: '..\\result\\REAL\\EP5\\actual_physical_ids.txt',
        6: '..\\result\\REAL\\EP6\\actual_physical_ids.txt',
    }
}
# 保存查询时的物理块
query_period_physical_block_ids_file = {
    'SIM': {
        0: '..\\result\\SIM\\EP0\\query_physical_ids.txt',
        1: '..\\result\\SIM\\EP1\\query_physical_ids.txt',
        2: '..\\result\\SIM\\EP2\\query_physical_ids.txt',
        3: '..\\result\\SIM\\EP3\\query_physical_ids.txt',
        4: '..\\result\\SIM\\EP4\\query_physical_ids.txt',
        5: '..\\result\\SIM\\EP5\\query_physical_ids.txt',
        6: '..\\result\\SIM\\EP6\\query_physical_ids.txt',
    },
    'REAL': {
        0: '..\\result\\REAL\\EP0\\query_physical_ids.txt',
        1: '..\\result\\REAL\\EP1\\query_physical_ids.txt',
        2: '..\\result\\REAL\\EP2\\query_physical_ids.txt',
        3: '..\\result\\REAL\\EP3\\query_physical_ids.txt',
        4: '..\\result\\REAL\\EP4\\query_physical_ids.txt',
        5: '..\\result\\REAL\\EP5\\query_physical_ids.txt',
        6: '..\\result\\REAL\\EP6\\query_physical_ids.txt',
    }
}
query_period_result_num_file = {
    'SIM': {
        0: '..\\result\\SIM\\EP0\\query_result_num.txt',
        1: '..\\result\\SIM\\EP1\\query_result_num.txt',
        2: '..\\result\\SIM\\EP2\\query_result_num.txt',
        3: '..\\result\\SIM\\EP3\\query_result_num.txt',
        4: '..\\result\\SIM\\EP4\\query_result_num.txt',
        5: '..\\result\\SIM\\EP5\\query_result_num.txt',
        6: '..\\result\\SIM\\EP6\\query_result_num.txt',
    },
    'REAL': {
        0: '..\\result\\REAL\\EP0\\query_result_num.txt',
        1: '..\\result\\REAL\\EP1\\query_result_num.txt',
        2: '..\\result\\REAL\\EP2\\query_result_num.txt',
        3: '..\\result\\REAL\\EP3\\query_result_num.txt',
        4: '..\\result\\REAL\\EP4\\query_result_num.txt',
        5: '..\\result\\REAL\\EP5\\query_result_num.txt',
        6: '..\\result\\REAL\\EP6\\query_result_num.txt',
    }
}

# 各期查询结果保存文件
PERIOD_QUERY_RESULT_FILE = {
    'SIM': {
        0: '..\\data\\SIM\\EP0\\query_result.txt',
        1: '..\\data\\SIM\\EP1\\query_result.txt',
        2: '..\\data\\SIM\\EP2\\query_result.txt',
        3: '..\\data\\SIM\\EP3\\query_result.txt',
        4: '..\\data\\SIM\\EP4\\query_result.txt',
        5: '..\\data\\SIM\\EP5\\query_result.txt',
        6: '..\\data\\SIM\\EP6\\query_result.txt',
    },
    'REAL': {
        0: '..\\data\\REAL\\EP0\\query_result.txt',
        1: '..\\data\\REAL\\EP1\\query_result.txt',
        2: '..\\data\\REAL\\EP2\\query_result.txt',
        3: '..\\data\\REAL\\EP3\\query_result.txt',
        4: '..\\data\\REAL\\EP4\\query_result.txt',
        5: '..\\data\\REAL\\EP5\\query_result.txt',
        6: '..\\data\\REAL\\EP6\\query_result.txt',
    }
}
# 各期索引构建结果保存文件
PERIOD_BUILDING_RESULT_FILE = {
    'SIM': {
        0: '..\\data\\SIM\\EP0\\build_result.txt',
        1: '..\\data\\SIM\\EP1\\build_result.txt',
        2: '..\\data\\SIM\\EP2\\build_result.txt',
        3: '..\\data\\SIM\\EP3\\build_result.txt',
        4: '..\\data\\SIM\\EP4\\build_result.txt',
        5: '..\\data\\SIM\\EP5\\build_result.txt',
        6: '..\\data\\SIM\\EP6\\build_result.txt',
    },
    'REAL': {
        0: '..\\data\\REAL\\EP0\\build_result.txt',
        1: '..\\data\\REAL\\EP1\\build_result.txt',
        2: '..\\data\\REAL\\EP2\\build_result.txt',
        3: '..\\data\\REAL\\EP3\\build_result.txt',
        4: '..\\data\\REAL\\EP4\\build_result.txt',
        5: '..\\data\\REAL\\EP5\\build_result.txt',
        6: '..\\data\\REAL\\EP6\\build_result.txt',
    }
}


# 后期每一期有一个溢出文件存放region的溢出数据
OVERFLOW_DATA_FILE = {
    'SIM': {
        0: '..\\data\\SIM\\EP0\\overflow.dat',
        1: '..\\data\\SIM\\EP1\\overflow.dat',
        2: '..\\data\\SIM\\EP2\\overflow.dat',
        3: '..\\data\\SIM\\EP3\\overflow.dat',
        4: '..\\data\\SIM\\EP4\\overflow.dat',
        5: '..\\data\\SIM\\EP5\\overflow.dat',
        6: '..\\data\\SIM\\EP6\\overflow.dat',
    },
    'REAL': {
        0: '..\\data\\REAL\\EP0\\overflow.dat',
        1: '..\\data\\REAL\\EP1\\overflow.dat',
        2: '..\\data\\REAL\\EP2\\overflow.dat',
        3: '..\\data\\REAL\\EP3\\overflow.dat',
        4: '..\\data\\REAL\\EP4\\overflow.dat',
        5: '..\\data\\REAL\\EP5\\overflow.dat',
        6: '..\\data\\REAL\\EP6\\overflow.dat',
    }
}


INDEX_FILE = {
    'SIM': {
        0: '..\\data\\SIM\\EP0\\200W_P0.idx',
        1: '..\\data\\SIM\\EP1\\200W_P1.idx',
        2: '..\\data\\SIM\\EP2\\200W_P2.idx',
        3: '..\\data\\SIM\\EP3\\200W_P3.idx',
        4: '..\\data\\SIM\\EP4\\200W_P4.idx',
        5: '..\\data\\SIM\\EP5\\200W_P5.idx',
        6: '..\\data\\SIM\\EP6\\200W_P6.idx',
    },
    'REAL': {
        0: '..\\data\\REAL\\EP0\\200W_P0.idx',
        1: '..\\data\\REAL\\EP1\\200W_P1.idx',
        2: '..\\data\\REAL\\EP2\\200W_P2.idx',
        3: '..\\data\\REAL\\EP3\\200W_P3.idx',
        4: '..\\data\\REAL\\EP4\\200W_P4.idx',
        5: '..\\data\\REAL\\EP5\\200W_P5.idx',
        6: '..\\data\\REAL\\EP6\\200W_P6.idx',
    }
}

PERIOD_MODEL_ERROR_BOUND_FILE = {
    'SIM': {
        0: '..\\data\\SIM\\EP0\\model_error_bound_file.pkl',
        1: '..\\data\\SIM\\EP1\\model_error_bound_file.pkl',
        2: '..\\data\\SIM\\EP2\\model_error_bound_file.pkl',
        3: '..\\data\\SIM\\EP3\\model_error_bound_file.pkl',
        4: '..\\data\\SIM\\EP4\\model_error_bound_file.pkl',
        5: '..\\data\\SIM\\EP5\\model_error_bound_file.pkl',
        6: '..\\data\\SIM\\EP6\\model_error_bound_file.pkl',
    },
    'REAL': {
        0: '..\\data\\REAL\\EP0\\model_error_bound_file.pkl',
        1: '..\\data\\REAL\\EP1\\model_error_bound_file.pkl',
        2: '..\\data\\REAL\\EP2\\model_error_bound_file.pkl',
        3: '..\\data\\REAL\\EP3\\model_error_bound_file.pkl',
        4: '..\\data\\REAL\\EP4\\model_error_bound_file.pkl',
        5: '..\\data\\REAL\\EP5\\model_error_bound_file.pkl',
        6: '..\\data\\REAL\\EP6\\model_error_bound_file.pkl',
    }
}

# 存储每一期每个region的误差，查询时用这个误差而不是设定的阈值，其实效果差距不大
PERIOD_MODEL_ERROR_FILE = {
    'SIM': {
        0: '..\\data\\SIM\\EP0\\model_error_file.pkl',
        1: '..\\data\\SIM\\EP1\\model_error_file.pkl',
        2: '..\\data\\SIM\\EP2\\model_error_file.pkl',
        3: '..\\data\\SIM\\EP3\\model_error_file.pkl',
        4: '..\\data\\SIM\\EP4\\model_error_file.pkl',
        5: '..\\data\\SIM\\EP5\\model_error_file.pkl',
        6: '..\\data\\SIM\\EP6\\model_error_file.pkl',
    },
    'REAL': {
        0: '..\\data\\REAL\\EP0\\model_error_file.pkl',
        1: '..\\data\\REAL\\EP1\\model_error_file.pkl',
        2: '..\\data\\REAL\\EP2\\model_error_file.pkl',
        3: '..\\data\\REAL\\EP3\\model_error_file.pkl',
        4: '..\\data\\REAL\\EP4\\model_error_file.pkl',
        5: '..\\data\\REAL\\EP5\\model_error_file.pkl',
        6: '..\\data\\REAL\\EP6\\model_error_file.pkl',
    }
}


DATA_FILE = {
    'SIM': {
        0: '..\\data\\SIM\\EP0\\200W_P0.dat',
        1: '..\\data\\SIM\\EP1\\200W_P1.dat',
        2: '..\\data\\SIM\\EP2\\200W_P2.dat',
        3: '..\\data\\SIM\\EP3\\200W_P3.dat',
        4: '..\\data\\SIM\\EP4\\200W_P4.dat',
        5: '..\\data\\SIM\\EP5\\200W_P5.dat',
        6: '..\\data\\SIM\\EP6\\200W_P6.dat',
    },
    'REAL': {
        0: '..\\data\\REAL\\EP0\\200W_P0.dat',
        1: '..\\data\\REAL\\EP1\\200W_P1.dat',
        2: '..\\data\\REAL\\EP2\\200W_P2.dat',
        3: '..\\data\\REAL\\EP3\\200W_P3.dat',
        4: '..\\data\\REAL\\EP4\\200W_P4.dat',
        5: '..\\data\\REAL\\EP5\\200W_P5.dat',
        6: '..\\data\\REAL\\EP6\\200W_P6.dat',
    }
}

ORI_FILE = {
    'SIM': {
        0: '..\\data\\SIM\\EP0\\200W_P0.txt',
        1: '..\\data\\SIM\\EP1\\200W_P1.txt',
        2: '..\\data\\SIM\\EP2\\200W_P2.txt',
        3: '..\\data\\SIM\\EP3\\200W_P3.txt',
        4: '..\\data\\SIM\\EP4\\200W_P4.txt',
        5: '..\\data\\SIM\\EP5\\200W_P5.txt',
        6: '..\\data\\SIM\\EP6\\200W_P6.txt',
    },
    'REAL': {
        0: '..\\data\\REAL\\EP0\\200W_P0.txt',
        1: '..\\data\\REAL\\EP1\\200W_P1.txt',
        2: '..\\data\\REAL\\EP2\\200W_P2.txt',
        3: '..\\data\\REAL\\EP3\\200W_P3.txt',
        4: '..\\data\\REAL\\EP4\\200W_P4.txt',
        5: '..\\data\\REAL\\EP5\\200W_P5.txt',
        6: '..\\data\\REAL\\EP6\\200W_P6.txt',
    }
}


MODEL_ONE_PERIOD_INDEX_DIR = {
    'SIM': {
        0: '..\\data\\SIM\\EP0\\period_range_sim\\',
        1: '..\\data\\SIM\\EP1\\period_range_sim\\',
        2: '..\\data\\SIM\\EP2\\period_range_sim\\',
        3: '..\\data\\SIM\\EP3\\period_range_sim\\',
        4: '..\\data\\SIM\\EP4\\period_range_sim\\',
        5: '..\\data\\SIM\\EP5\\period_range_sim\\',
        6: '..\\data\\SIM\\EP6\\period_range_sim\\',
    },
    'REAL': {
        0: '..\\data\\REAL\\EP0\\period_range_real\\',
        1: '..\\data\\REAL\\EP1\\period_range_real\\',
        2: '..\\data\\REAL\\EP2\\period_range_real\\',
        3: '..\\data\\REAL\\EP3\\period_range_real\\',
        4: '..\\data\\REAL\\EP4\\period_range_real\\',
        5: '..\\data\\REAL\\EP5\\period_range_real\\',
        6: '..\\data\\REAL\\EP6\\period_range_real\\',
    }
}


# 存储各期所有模型的块范围
MODEL_ONE_PERIOD_INDEX_FILE = {
    'SIM': {
        0: '..\\data\\SIM\\EP0\\period_range_sim\\period_0_range_block.idx',
        1: '..\\data\\SIM\\EP1\\period_range_sim\\period_1_range_block.idx',
        2: '..\\data\\SIM\\EP2\\period_range_sim\\period_2_range_block.idx',
        3: '..\\data\\SIM\\EP3\\period_range_sim\\period_3_range_block.idx',
        4: '..\\data\\SIM\\EP4\\period_range_sim\\period_4_range_block.idx',
        5: '..\\data\\SIM\\EP5\\period_range_sim\\period_5_range_block.idx',
        6: '..\\data\\SIM\\EP6\\period_range_sim\\period_6_range_block.idx',
    },
    'REAL': {
        0: '..\\data\\REAL\\EP0\\period_range_real\\period_0_range_block.idx',
        1: '..\\data\\REAL\\EP1\\period_range_real\\period_1_range_block.idx',
        2: '..\\data\\REAL\\EP2\\period_range_real\\period_2_range_block.idx',
        3: '..\\data\\REAL\\EP3\\period_range_real\\period_3_range_block.idx',
        4: '..\\data\\REAL\\EP4\\period_range_real\\period_4_range_block.idx',
        5: '..\\data\\REAL\\EP5\\period_range_real\\period_5_range_block.idx',
        6: '..\\data\\REAL\\EP6\\period_range_real\\period_6_range_block.idx',
    }
}

POINT_QUERY_FILE = {
    'SIM': {
        0: '..\\data\\SIM\\EP0\\point_query.txt',
        1: '..\\data\\SIM\\EP1\\point_query.txt',
        2: '..\\data\\SIM\\EP2\\point_query.txt',
        3: '..\\data\\SIM\\EP3\\point_query.txt',
        4: '..\\data\\SIM\\EP4\\point_query.txt',
        5: '..\\data\\SIM\\EP5\\point_query.txt',
        6: '..\\data\\SIM\\EP6\\point_query.txt',
    },
    'REAL': {
        0: '..\\data\\REAL\\EP0\\point_query.txt',
        1: '..\\data\\REAL\\EP1\\point_query.txt',
        2: '..\\data\\REAL\\EP2\\point_query.txt',
        3: '..\\data\\REAL\\EP3\\point_query.txt',
        4: '..\\data\\REAL\\EP4\\point_query.txt',
        5: '..\\data\\REAL\\EP5\\point_query.txt',
        6: '..\\data\\REAL\\EP6\\point_query.txt',
    }
}

RANGE_QUERY_FILE = {
    'SIM': {
        0: '..\\data\\SIM\\EP0\\range_query.txt',
        1: '..\\data\\SIM\\EP1\\range_query.txt',
        2: '..\\data\\SIM\\EP2\\range_query.txt',
        3: '..\\data\\SIM\\EP3\\range_query.txt',
        4: '..\\data\\SIM\\EP4\\range_query.txt',
        5: '..\\data\\SIM\\EP5\\range_query.txt',
        6: '..\\data\\SIM\\EP6\\range_query.txt',
    },
    'REAL': {
        0: '..\\data\\REAL\\EP0\\range_query.txt',
        1: '..\\data\\REAL\\EP1\\range_query.txt',
        2: '..\\data\\REAL\\EP2\\range_query.txt',
        3: '..\\data\\REAL\\EP3\\range_query.txt',
        4: '..\\data\\REAL\\EP4\\range_query.txt',
        5: '..\\data\\REAL\\EP5\\range_query.txt',
        6: '..\\data\\REAL\\EP6\\range_query.txt',
    }
}

common_building_result_file = '..\\result\\build_result.txt'  # 所有期数的索引结果保存文件
common_query_result_file = '..\\result\\query_result.txt'  # 所有期数的查询结果保存文件
common_index_dir = '..\\index\\'  # 通用辅助结构的保存目录
x_boundary_file = '..\\index\\x_boundary_file.pkl'  # 辅助结构，pos轴的分割点
y_boundary_file = '..\\index\\y_boundary_file.pkl'  # 辅助结构，t轴分割点
model_dir = '..\\data\\models'  # 存储所有模型，调试用
cum_stripes_num_list = '..\\index\\cum_stripe_num_list.pkl'  # 辅助结构，partition累计斜条数量列表
partition_range_file = '..\\index\\partition_range.pkl'  # 辅助结构，保存partition的矩形范围，为了方便直接使用pickle，实际上这个范围可以通过2个维度的分割点获取
stripe_data_dir = '..\\data\\data\\'  # 保存stripe的数据，调试用

# 存储partition的信息，调试用
partition_file = {
    'SIM': {
        0: '..\\result\\SIM\\EP0\\partition_info.txt',
        1: '..\\result\\SIM\\EP1\\partition_info.txt',
        2: '..\\result\\SIM\\EP2\\partition_info.txt',
        3: '..\\result\\SIM\\EP3\\partition_info.txt',
        4: '..\\result\\SIM\\EP4\\partition_info.txt',
        5: '..\\result\\SIM\\EP5\\partition_info.txt',
        6: '..\\result\\SIM\\EP6\\partition_info.txt',
    },
    'REAL': {
        0: '..\\result\\REAL\\EP0\\partition_info.txt',
        1: '..\\result\\REAL\\EP1\\partition_info.txt',
        2: '..\\result\\REAL\\EP2\\partition_info.txt',
        3: '..\\result\\REAL\\EP3\\partition_info.txt',
        4: '..\\result\\REAL\\EP4\\partition_info.txt',
        5: '..\\result\\REAL\\EP5\\partition_info.txt',
        6: '..\\result\\REAL\\EP6\\partition_info.txt',
    }
}

# 存储stripe的信息，调试用
stripe_file = {
    'SIM': {
        0: '..\\result\\SIM\\EP0\\stripe_info.txt',
        1: '..\\result\\SIM\\EP1\\stripe_info.txt',
        2: '..\\result\\SIM\\EP2\\stripe_info.txt',
        3: '..\\result\\SIM\\EP3\\stripe_info.txt',
        4: '..\\result\\SIM\\EP4\\stripe_info.txt',
        5: '..\\result\\SIM\\EP5\\stripe_info.txt',
        6: '..\\result\\SIM\\EP6\\stripe_info.txt',
    },
    'REAL': {
        0: '..\\result\\REAL\\EP0\\stripe_info.txt',
        1: '..\\result\\REAL\\EP1\\stripe_info.txt',
        2: '..\\result\\REAL\\EP2\\stripe_info.txt',
        3: '..\\result\\REAL\\EP3\\stripe_info.txt',
        4: '..\\result\\REAL\\EP4\\stripe_info.txt',
        5: '..\\result\\REAL\\EP5\\stripe_info.txt',
        6: '..\\result\\REAL\\EP6\\stripe_info.txt',
    }
}

# 存储region信息，调试用
model_info_file = {
    'SIM': {
        0: '..\\result\\SIM\\EP0\\model_info.txt',
        1: '..\\result\\SIM\\EP1\\model_info.txt',
        2: '..\\result\\SIM\\EP2\\model_info.txt',
        3: '..\\result\\SIM\\EP3\\model_info.txt',
        4: '..\\result\\SIM\\EP4\\model_info.txt',
        5: '..\\result\\SIM\\EP5\\model_info.txt',
        6: '..\\result\\SIM\\EP6\\model_info.txt',
    },
    'REAL': {
        0: '..\\result\\REAL\\EP0\\model_info.txt',
        1: '..\\result\\REAL\\EP1\\model_info.txt',
        2: '..\\result\\REAL\\EP2\\model_info.txt',
        3: '..\\result\\REAL\\EP3\\model_info.txt',
        4: '..\\result\\REAL\\EP4\\model_info.txt',
        5: '..\\result\\REAL\\EP5\\model_info.txt',
        6: '..\\result\\REAL\\EP6\\model_info.txt',
    }
}

# 保存partition对象，调试用
partition_pkl = {
    'SIM': {
        0: '..\\data\\SIM\\EP0\\partition.pkl',
        1: '..\\data\\SIM\\EP1\\partition.pkl',
        2: '..\\data\\SIM\\EP2\\partition.pkl',
        3: '..\\data\\SIM\\EP3\\partition.pkl',
        4: '..\\data\\SIM\\EP4\\partition.pkl',
        5: '..\\data\\SIM\\EP5\\partition.pkl',
        6: '..\\data\\SIM\\EP6\\partition.pkl',
    },
    'REAL': {
        0: '..\\data\\REAL\\EP0\\partition.pkl',
        1: '..\\data\\REAL\\EP1\\partition.pkl',
        2: '..\\data\\REAL\\EP2\\partition.pkl',
        3: '..\\data\\REAL\\EP3\\partition.pkl',
        4: '..\\data\\REAL\\EP4\\partition.pkl',
        5: '..\\data\\REAL\\EP5\\partition.pkl',
        6: '..\\data\\REAL\\EP6\\partition.pkl',
    }
}

"""
注：所有的计数和编号都从0开始

1   处理溢出问题：需要再最后一个逻辑块保存溢出信息，那怎么知道是cell的最后一块呢？
答：在分区信息中保存一个最后一块逻辑块号的信息，现在不保存斜条数量，但是斜条参数需要保存模型数量

2   在查询的时候，预测的逻辑块之后需要根据误差阈值在左右搜索，搜索范围在[0,max_logic_id]之间，
所以需要保存这个最大的逻辑块号，就保存在存储起始斜条块位置的前面吧。8188-4 = 8184字节处
"""

"""
好像要有一个计数器计算模型全局序号。

设定前面3块索引块只存储partition参数，后面的块存储斜条参数和模型参数，在块头需要保存一些信息
例如：0代表分区参数，1代表斜条参数，2代表模型参数，这个用int即4字节表示

现在斜条就不用保存底部和顶部截距了，现在分区需要保存最底部的截距，然后通过公式可以计算分区内斜条号，
例如分区最底部截距是10，斜条宽度是2，先通过t = slope * pos + intercept算出查询点对应的截距，
然后通过intercept <= N * t_intercal + bottom_intercept算出最小的N，则斜条序号就是N-1。


我想的是把每个索引块都放满，但是这样会出现一个问题就是有可能一个分区内的斜条会存储在2个不同的索引块中。
事先需要保存每个分区中斜条的数量，维护这个列表，例如列表是[10,20,12,13,9,19,18,16]
斜条所属的块号可以通过公式计算，即假如一块斜条索引块可以保存510个斜条参数，
假如查询点所在的分区序号是3，斜条序号是2，则全局的斜条索引项序号是10+20+12+2=44//510=0,
即查询点的斜条参数所在的索引块是第一个斜条块。


对应模型参数来说，模型所属的斜条则需要保存模型对应的索引块和块中的偏移量(或者说是模型的全局序号)。

对应模型参数来说，斜条保存的是该模型相对于保存模型起始索引块的序号(但是在内存中还需要维护一张表，
即保存分区、斜条和模型对应的起始块)，例如第3个分区的第2个斜条的模型所在的序号是25，然后通过
25 * REGION_PARAM_SIZE就能算出相对模型起始块的偏移量设为offset，然后通过offset // BLOCK_SIZE
+ 模型起始块号就能得出此斜条的模型所在的索引块。

计算模型所属的索引块：
输入：起始模型索引块,start_region_block_id，模型全局序号,global_region_num
输出：模型所属的索引块号:output_id
rale_region_block_id = global_region_num // REGION_BLOCK_ITEM_NUM
output_id = rale_region_block_id + start_region_block_id

"""

# 三种索引块枚举
PARATION = 0
STRIPE = 1
REGION = 2

# 设置模型参数大小
RECORD_SIZE = struct.calcsize('dd')  # 每条记录大小占用字节数
PARTITION_PARAM_SIZE = struct.calcsize('4d')  # 24字节，斜率(现在是W), t_interval, 底部截距
STRIPE_PARAM_SIZE = struct.calcsize('<2I')  # 模型全局序号，模型数量，斜条数据的mbr
REGION_PARAM_SIZE = struct.calcsize('<4dI2dI')  # 56个字节，每个区域的参数：pos上下边界，基点，方向向量

# 设置块大小和缓冲
LOGIC_BLOCK_SIZE = int(0.5 * 1024)  # 逻辑块大小
LOGIC_BLOCK_CONTENT_SIZE = (LOGIC_BLOCK_SIZE - 16) // RECORD_SIZE  # 一个逻辑块的容量, 16表示每块额外存储块号，块内数据量，溢出块号和溢出块数量
BLOCK_SIZE = 8 * 1024  # 物理块大小, 每次IO从8kb的倍数开始读8kb大小的数据
BUFFER_SIZE = 2 * 1024 * 1024  # 缓冲大小
BUFFER_NUM = BUFFER_SIZE // BLOCK_SIZE  # 缓冲容量
# 物理块大小比逻辑块大小的比例
LOGIC_PHYSICAL_PROPOTION = BLOCK_SIZE // LOGIC_BLOCK_SIZE

N_ROWS = 3  # 网格的列数和行数（参数）
N_COLS = 600
ID_ROAD_LENGTH_FILE = '../data_processing_sim\\id_road_length_map.pkl'  # 道路长度列表
RESULT_DIR = '..\\result'

IO_COUNT = 0  # 计算总IO
ERROR_THRESHOLD = LOGIC_PHYSICAL_PROPOTION  # 模型误差阈值，用于道格拉斯分段,默认设置为一个物理块
SCALE_FACTOR = 2  # 改版后的比例因子，即论文中的lambda
FOLLOW_ERROR = 4  # 后期误差阈值，即论文中的et


DATA_BLOCK_ITEM_NUM = (BLOCK_SIZE - 16) // RECORD_SIZE  # 一块数据块最大容量，13代表数据块当前数据量(int),数据块号, 是否最后一块, 溢出块指针
DATA_BLOCK_COUNT = 0  # 数据块计数

STRIPE_BLOCK_ITEM_NUM = (BLOCK_SIZE - 12) // STRIPE_PARAM_SIZE  #8kb 1023一块斜条块存储的索引项数量
PARTITION_BLOCK_ITEM_NUM = (BLOCK_SIZE - 12) // PARTITION_PARAM_SIZE  # 8kb，340一块分区块所能存储的索引项数量，剩余20字节
REGION_BLOCK_ITEM_NUM = (BLOCK_SIZE - 12) // REGION_PARAM_SIZE  # 8kb，146一块模型块所能存储的索引项数量

# 存储region的块范围（包括非溢出块范围和溢出块范围），共10期
# 模型的序号通过斜条参数获得
MODEL_BLOCK_RANGE_PARAM_SIZE_ONE_PERIOD = struct.calcsize('4I')  # 每期每个模型存储起始和结尾逻辑块，后期还要存放起始溢出块和结尾溢出块
# 8KB能保存511个模型的块范围
PERIOD_RANGE_BLOCK_ITEM_NUM = (BLOCK_SIZE - 8) // MODEL_BLOCK_RANGE_PARAM_SIZE_ONE_PERIOD

# start_partition_block_id
START_PARTITION_BLOCK_ID = 0
# start_stripe_block_id
START_STRIPE_BLOCK_ID = (N_ROWS * N_COLS // PARTITION_BLOCK_ITEM_NUM) + 1
# 起始region块号由斜条总数在运行时确定, 这个值保存在起始斜条块字节数-4处，
# 例如8kb，可以保存292个分区，当分区少于292时起始斜条块就是1, 即1 * 8192 - 4 = 8088字节处
START_REGION_BLOCK_ID = -1
MAX_LOGIC_BLOCK_ID = -1
MAX_OVERFLOW_LOGIC_BLOCK_ID = -1


"""以下为各种参数的序列化，包括partition参数、stripe参数、region参数和region block range"""


class Record:
    def __init__(self, pos, t):
        self.pos = pos
        self.t = t

    def pack(self):
        bin = struct.pack('2d', self.pos, self.t)
        return bin


class PartitionParam:
    # def __init__(self, slope, t_interval, low_inte):
    def __init__(self, W, t_interval, low_inte):
        self.W = W
        self.t_interval = t_interval
        self.low_intercept = low_inte

    def pack(self):
        bin_info = struct.pack('4d', *(self.W), self.t_interval, self.low_intercept)
        return bin_info


class StripeParam:
    def __init__(self, region_id, region_num):
        self.region_num = region_num
        self.region_id = region_id

    def get_region_block(self, region_block):
        self.region_id = region_block

    def pack(self):
        bin_info = struct.pack('<2I', self.region_id, self.region_num)
        return bin_info


class RegionParam:
    # def __init__(self, start_pos, end_pos, pos, t, logic_index, m, n, p):
    def __init__(self, start_mv, end_mv, pos, t, logic_index, m, n, p):
        self.start_mv = start_mv
        self.end_mv = end_mv
        self.pos = pos  # pos,t,index,m,n,p, 这里的index指的是斜条内部的序号
        self.t = t
        self.logic_index = logic_index
        self.m = m
        self.n = n
        self.p = p

    def pack(self):
        bin_info = struct.pack('<4dI2dI', self.start_mv, self.end_mv, self.pos,
                               self.t, self.logic_index, self.m,
                               self.n, int(self.p))
        return bin_info


class PeriodBlockRangeParam:
    """每一期的模型块范围"""
    def __init__(self, s_id, e_id, s_of_id, e_of_id):
        self.s_id = s_id
        self.e_id = e_id
        self.s_of_id = s_of_id
        self.e_of_id = e_of_id

    def pack(self):
        bin_info = struct.pack('4I', self.s_id, self.e_id, self.s_of_id, self.e_of_id)
        return bin_info

