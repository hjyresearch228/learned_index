"""获取实际的物理块信息（暴力搜索）"""
import src.storage as storage
from utils.file_utils import *
import sys
import numpy as np
from src.geometry import Rectangle, Point
import struct


def get_query_result(query_range, p_num, data_patten='SIM'):
# def get_query_result(query_range, max_l_id, p_num, data_patten='SIM'):
    """获取实际的物理块"""
    result_ids = set()
    result_of_ids = set()
    data_num = 0
    result = []
    with open(const.DATA_FILE[data_patten][p_num], 'rb') as f:
        for i in range(max_logic_id+1):
            # print(f'第{i}个逻辑块')
            f.seek(i * const.LOGIC_BLOCK_SIZE)
            data_bin = f.read(const.LOGIC_BLOCK_SIZE)
            logic_block = storage.DataBlock.unpack(data_bin)
            points = np.array(logic_block.data_points)
            if len(points) != 0:
                max_pos = np.max(points[:,0])
                min_pos = np.min(points[:,0])
                max_t = np.max(points[:,1])
                min_t = np.min(points[:,1])
                if Rectangle(min_pos,min_t,max_pos,max_t).is_intersect(Rectangle(query_range[0],query_range[1],query_range[2],query_range[3])):
                    for x, y in points:
                        if Rectangle(query[0],query[1],query[2],query[3]).is_contained(Point(x,y)):
                            result_ids.add(i//const.LOGIC_PHYSICAL_PROPOTION)
                            data_num += 1

    with open(const.OVERFLOW_DATA_FILE[data_patten][p_num], 'rb') as f:
        for i in range(max_of_logic_id + 1):
            # print(f'第{i}个逻辑块')
            f.seek(i * const.LOGIC_BLOCK_SIZE)
            data_bin = f.read(const.LOGIC_BLOCK_SIZE)
            logic_block = storage.DataBlock.unpack(data_bin)
            points = np.array(logic_block.data_points)
            if len(points) != 0:
                max_pos = np.max(points[:, 0])
                min_pos = np.min(points[:, 0])
                max_t = np.max(points[:, 1])
                min_t = np.min(points[:, 1])
                if Rectangle(min_pos, min_t, max_pos, max_t).is_intersect(
                        Rectangle(query_range[0], query_range[1], query_range[2], query_range[3])):
                    for x, y in points:
                        if Rectangle(query[0], query[1], query[2], query[3]).is_contained(Point(x, y)):
                            result_of_ids.add(i // const.LOGIC_PHYSICAL_PROPOTION)
                            data_num += 1

    return result_ids, result_of_ids, len(result_ids), len(result_of_ids), data_num




data_patten = 'SIM'
for i in range(1, const.PERIOD_NUM):
    max_logic_id = struct.unpack('I', storage.Buffer.load(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 8,
                                                          data_size=4, p_num=i, patten=data_patten))[0]
    start_region_block_id = struct.unpack('I', storage.Buffer.load(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 4,
                                           data_size=4, p_num=i, patten=data_patten))[0]
    max_of_logic_id = struct.unpack('I', storage.Buffer.load(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 16,
                                                             data_size=4, p_num=i, patten=data_patten))[0]
    result_num_file = const.actual_period_physical_block_ids_file[data_patten][i]
    result_physical_ids_file = const.actual_period_physical_block_ids_file[data_patten][i]
    query_list = read_txt_to_list(const.RANGE_QUERY_FILE[data_patten][i])
    # result_block_id = set()
    data_count = 0
    total_physical_block_num = 0
    query_num = 0
    with open(result_num_file, 'w') as f:
        for query in query_list:
            # result_ids, result_of_ids, result_id_count, result_of_id_count, data_num = get_query_result(query, i, data_patten)
            result_ids, result_of_ids, result_id_count, result_of_id_count, data_num = get_query_result(query, i, data_patten)
            data_count += data_num
            total_physical_block_num += result_id_count
            total_physical_block_num += result_of_id_count
            f.write(f'第{query_num}个查询: \n非溢出物理块: {result_ids}\n溢出物理块: {result_of_ids}\n'
                    f'非溢出物理块数量: {result_id_count}  溢出物理块数量: {result_of_id_count}  数据量: {data_num}\n\n')
            query_num += 1
        f.write(f'实际总数据量: {data_count}, 实际总物理块数: {total_physical_block_num}')
