"""SPRIG网格划分方法，用列主序曲线填充单元格"""
import numpy as np


class Grid:
    def __init__(self, n_rows: int, n_cols, data: np.ndarray, id_road_map=None):
        self.n_rows = n_rows  # 行数或者列数
        self.data = data
        self.n_cols = n_cols
        self.data_size = self.data.shape[0]
        self.id_road_map = id_road_map

    def build_grid(self):
        map_x = {}
        map_y = {}
        for x, y in self.data:
            cnt_x = map_x.get(x, 0) + 1
            map_x[x] = cnt_x
            cnt_y = map_y.get(y, 0) + 1
            map_y[y] = cnt_y
        xmin, ymin = np.min(self.data, axis=0)
        xmax, ymax = np.max(self.data, axis=0)
        map_x = dict(sorted(map_x.items()))
        map_y = dict(sorted(map_y.items()))
        avg_x = self.data_size // self.n_cols
        avg_y = self.data_size // self.n_rows
        self.boundary_x = self.get_boundary(xmin, xmax, map_x, avg_x)
        self.boundary_y = self.get_boundary(ymin, ymax, map_y, avg_y)

    def get_boundary(self, min, max, map_v, avg):
        boundary = []
        cnt = 0
        pre = 0
        boundary.append(min)
        for key, single_cnt in map_v.items():
            if single_cnt > avg:
                boundary.append((key + pre) / 2)
                pre = key
                cnt = 0
                continue
            cnt += single_cnt
            if cnt > avg:
                boundary.append((key + pre) / 2)
                cnt = 0
            else:
                pre = key
        if max not in boundary:
            boundary.append(max)
        return boundary


