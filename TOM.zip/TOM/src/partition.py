import numpy as np
import const
from geometry import Rectangle, Polygon
import math


class Partition:
    __slots__ = [
        'sorted_stripes',
        'partition_id',
        'slope',
        'stripe_list',
        'pos_low',
        'pos_high',
        't_low',
        't_high',
        'data_list',
        't_interval',
        'W'
    ]
    """
    每一个划分需要存储：
    3）斜线斜率，
    4）t间隔
    5）底部截距
    """
    def __init__(self, partition_id, pos_low, pos_high, t_low, t_high, data, slope=None, t_interval=None):
        self.sorted_stripes = {}  # 存储形式: 分区内斜条序号:(底部截距，顶部截距)
        self.partition_id = partition_id
        self.slope = slope
        self.stripe_list = []  # 存储属于当前partition的斜条
        self.pos_low = pos_low
        self.pos_high = pos_high
        self.t_low = t_low
        self.t_high = t_high
        self.data_list = []
        self.get_data_in_cell(data)
        # print(f'分区 {partition_id} 数据量: {len(self.data_list)}')
        self.t_interval = t_interval  # 这个代表斜条宽度
        # if len(self.data_list) == 0:
        #     pass
        self.get_stripe_slope()

    def get_stripe_slope(self):
        """计算斜线的斜率，利用PCA的思想，求最大特征值对应的特征向量即是所求方向"""
        X = np.array(self.data_list)
        mean_vector = np.mean(X, axis=0)
        Y = X - mean_vector
        # 计算协方差矩阵
        # print(f'数据量: {len(Y)}')
        C = np.cov(Y, rowvar=False)
        # 计算特征值和特征向量
        eigenvalues, eigenvectors = np.linalg.eig(C)
        # 找到最大特征值对应的特征向量
        max_index = np.argmax(eigenvalues)
        optimal_W = eigenvectors[:, max_index]
        optimal_slope = optimal_W[1] / optimal_W[0]
        self.slope = optimal_slope
        self.W = optimal_W
        # print(f'partition {self.partition_id} best slope: {optimal_slope}')

    def get_stripes(self, min_stripe_data_num) -> dict:
        """
        计算分区斜条数量，利用密度峰值聚类确定聚类数的思想来确定斜条数量
        """
        data_num = len(self.data_list)
        # 确保每个斜条数据不少于
        max_stripe_num = int(data_num // (2 * const.LOGIC_BLOCK_CONTENT_SIZE ))
        # max_stripe_num = data_num // min_stripe_data_num
        if self.slope >= 0:
            high = [self.pos_low, self.t_high]
            low = [self.pos_high, self.t_low]
        else:
            low = [self.pos_low, self.t_low]
            high = [self.pos_high, self.t_high]
        # 单元格底部斜线的截距，利用底部和顶部2条斜线约束和斜线的数量可以确定t_interval
        # 斜线的斜率确定之后，通过 t=slope*pos+intercept 可以得出底部和顶部的截距
        bottom_intercept = low[1] - self.slope * low[0]
        top_intercept = high[1] - self.slope * high[0]
        min_combination = float('inf')

        rectangle = [self.pos_low, self.t_low, self.pos_high, self.t_high]
        # 开始计算最佳的斜条数量，这里先确定斜线的数量，然后斜条的数量=斜线数量+1，斜线最少是0条，最多是最大斜条数-1
        pre_opt_stripes = {}
        optimal_stripes = {}
        for i in range(0, max_stripe_num + 1):

            t_width = (top_intercept - bottom_intercept) / (i + 1)
            # 所有斜线的截距,包括底部和顶部2条
            lines_intercept = np.linspace(bottom_intercept, top_intercept, i+2)
            cur_stripe = {}
            # 根据斜线生成对应的斜条，用上下截距表示
            for i in range(len(lines_intercept) - 1):
                cur_stripe[i] = [lines_intercept[i], lines_intercept[i+1]]
            cur_combination = self.get_density_distance_combination(lines_intercept, t_width)
            if cur_combination < min_combination:
                min_combination = cur_combination
                pre_opt_stripes = cur_stripe
                # 计算当前所有斜条的数据，只要有一个是0则丢弃当前的斜条数选择权
                # 没有0数据斜条则将当前斜条赋给最佳斜条
                less_than_logic_size = False
                for index, stripe in pre_opt_stripes.items():
                    slope = self.slope
                    upper_incpt = stripe[1]
                    lower_incpt = stripe[0]
                    vertices, local_area = self.convex_polygon_area_from_lines(slope, lower_incpt,
                                                                               slope, upper_incpt,
                                                                               rectangle)
                    stripe_data_num = len(self.get_data_in_polygen(vertices))
                    if stripe_data_num < min_stripe_data_num:
                        less_than_logic_size = True
                        break
                if not less_than_logic_size:
                    optimal_stripes = cur_stripe
        self.sorted_stripes = optimal_stripes
        assert len(optimal_stripes) > 0, '最佳斜条数量为0！'
        return optimal_stripes

    def get_density_distance_combination(self, intercepts, t_width):
        # 没有斜线，即只有底部和顶部斜线,计算矩形的面积
        if len(intercepts) == 2:
            density = len(self.data_list) / (Rectangle(x1=self.pos_low, y1=self.t_low, x2=self.pos_high, y2=self.t_high).cal_area())
            distance = t_width
            com = density * distance
            return com
        # 只有一根斜线2个斜条的情况，分别计算上下三角的面积
        if len(intercepts) == 3:
            density = len(self.data_list) / (Rectangle(x1=self.pos_low, y1=self.t_low, x2=self.pos_high, y2=self.t_high).cal_area())
            distance = t_width
            com = density * distance / 2
            return com
        # 所有斜线周围的局部密度，存储形式：上边截距：密度
        local_desities = {}
        # 从底部到顶部依次计算局部密度
        # 计算延伸后的斜线截距
         # 保存形式：原始斜线截距:(延伸之后下截距，延伸之后上截距)
        extended_lines_intercepts = {}
        for i in range(1, len(intercepts) - 2):
            # 默认是从底部向上延伸
            extended_incpt = intercepts[i] + t_width / 2
            # 保存第一根斜线
            if i == 1:
                extended_lines_intercepts[intercepts[i]] = (intercepts[0], extended_incpt)
            else:
                extended_lines_intercepts[intercepts[i]] = (extended_lines_intercepts[intercepts[i-1]][1], extended_incpt)
        # 保存最后一根斜线
        extended_lines_intercepts[intercepts[-2]] = (extended_lines_intercepts[intercepts[-3]][1], intercepts[-1])
        assert len(extended_lines_intercepts)+2 == len(intercepts), 'lines extended error!!!'
        # 计算延伸之后的局部密度
        rectangle = [self.pos_low, self.t_low, self.pos_high,self.t_high]
        for mid_incpt in extended_lines_intercepts.keys():
            slope = self.slope
            upper_incpt = extended_lines_intercepts[mid_incpt][1]
            lower_incpt = extended_lines_intercepts[mid_incpt][0]
            # 局部面积
            vertices, local_area = self.convex_polygon_area_from_lines(slope, lower_incpt, slope, upper_incpt, rectangle)
            # 在区域内的样本数量
            local_data_size = len(self.get_data_in_polygen(vertices))
            local_desities[mid_incpt] = local_data_size / local_area
        # 对局部密度排序
        local_desities = dict(sorted(local_desities.items(), key=lambda item: item[1]))
        distances = {}
        upper_incpts = list(local_desities.keys())
        # 对密度最低的其相对距离设为0
        distances[upper_incpts[0]] = 0
        for index in range(1, len(upper_incpts)):
            distances[upper_incpts[index]] = upper_incpts[index] - upper_incpts[index-1]
        # 计算局部密度和相对距离的组合
        sum = 0
        for incpt in upper_incpts:
            sum += local_desities[incpt] * distances[incpt]
        com = sum / (len(intercepts)-1)
        return com

    def get_data_in_cell(self, data: np.ndarray):
        """获取单元格中的所有数据"""
        left_bottom = np.array([self.pos_low, self.t_low])
        right_top = np.array([self.pos_high, self.t_high])
        in_cell = np.all((data >= left_bottom) & (data <= right_top), axis=1)
        self.data_list = data[in_cell]

    @staticmethod
    def get_data_in_partiton(partiton_range, data):
        data = np.array(data)
        left_bottom = np.array([partiton_range[0], partiton_range[1]])
        right_top = np.array([partiton_range[2], partiton_range[3]])
        in_cell = np.all((data >= left_bottom) & (data <= right_top), axis=1)
        return data[in_cell]

    @staticmethod
    def get_data_in_polygen_by_new_period_data(new_partiton_data, vertices):
        inside_list = []
        for x, y in new_partiton_data:
            xinters = None
            n = len(vertices)
            inside = False
            p1x, p1y = vertices[0]
            for i in range(n + 1):
                p2x, p2y = vertices[i % n]
                if y > min(p1y, p2y):
                    if y <= max(p1y, p2y):
                        if x <= max(p1x, p2x):
                            if p1y != p2y:
                                xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                            if p1x == p2x or x <= xinters:
                                inside = not inside
                p1x, p1y = p2x, p2y
            if inside:
                inside_list.append((x, y))
        return inside_list

    def get_data_in_polygen(self, vertices: list):
        """
        获取在多边形中的数据
        :param vertices: 多边形顶点
        :return:
        """
        inside_list = []
        for x, y in self.data_list:
            xinters = None
            n = len(vertices)
            inside = False
            p1x, p1y = vertices[0]
            for i in range(n + 1):
                p2x, p2y = vertices[i % n]
                if y > min(p1y, p2y):
                    if y <= max(p1y, p2y):
                        if x <= max(p1x, p2x):
                            if p1y != p2y:
                                xinters = (y - p1y) * (p2x - p1x) / (p2y - p1y) + p1x
                            if p1x == p2x or x <= xinters:
                                inside = not inside
                p1x, p1y = p2x, p2y
            if inside:
                inside_list.append((x, y))
        return inside_list

    @staticmethod
    def line_rectangle_intersection(slope, intercept, rect):
        """获取直线（通过斜率，截距表示）和矩形的交点"""
        x1, y1, x2, y2 = rect
        intersections = []
        # 直线与左边相交
        y_left = slope * x1 + intercept
        if y1 <= y_left <= y2:
            intersections.append((x1, y_left))
        # 直线与右边相交
        y_right = slope * x2 + intercept
        if y1 <= y_right <= y2:
            intersections.append((x2, y_right))
        # 直线与上边相交
        if slope != 0:
            x_top = (y2 - intercept) / slope
            if x1 <= x_top <= x2:
                intersections.append((x_top, y2))
        # 直线与下边相交
        if slope != 0:
            x_bottom = (y1 - intercept) / slope
            if x1 <= x_bottom <= x2:
                intersections.append((x_bottom, y1))
        return intersections

    @staticmethod
    def is_line_rec_intersection(slope, intercept, rect):
        """返回直线与矩形框边线相交的布尔数组和交点，无交点用空填充，返回形式[左，右，上，下]"""
        x1, y1, x2, y2 = rect
        is_intersections = []
        inter = []
        # 直线与左边相交
        y_left = slope * x1 + intercept
        if y1 <= y_left <= y2:
            is_intersections.append(True)
            inter.append((x1, y_left))
        else:
            is_intersections.append(False)
            inter.append(tuple())
        # 直线与右边相交
        y_right = slope * x2 + intercept
        if y1 <= y_right <= y2:
            is_intersections.append(True)
            inter.append((x2, y_right))
        else:
            is_intersections.append(False)
            inter.append(tuple())
        # 直线与上边相交
        if slope != 0:
            x_top = (y2 - intercept) / slope
            if x1 <= x_top <= x2:
                is_intersections.append(True)
                inter.append((x_top, y2))
            else:
                is_intersections.append(False)
                inter.append(())
        # 直线与下边相交
        if slope != 0:
            x_bottom = (y1 - intercept) / slope
            if x1 <= x_bottom <= x2:
                is_intersections.append(True)
                inter.append((x_bottom, y1))
            else:
                is_intersections.append(False)
                inter.append(())
        return is_intersections, inter

    def polygon_area(self, vertices):
        """计算多边形面积，顶点应该是按照逆时针排序好的"""
        n = len(vertices)  # 顶点数
        area = 0.0
        for i in range(n):
            x1, y1 = vertices[i]
            x2, y2 = vertices[(i + 1) % n]  # 下一个顶点 (循环回到第一个)
            area += x1 * y2 - x2 * y1
        return abs(area) / 2.0

    def sort_vertices(self, vertices):
        """排序给定的顶点,根据极角逆时针排序"""
        # 计算多边形质心
        centroid_x = sum(x for x, y in vertices) / len(vertices)
        centroid_y = sum(y for x, y in vertices) / len(vertices)
        # 按照极角逆时针排序顶点
        vertices.sort(key=lambda point: math.atan2(point[1] - centroid_y, point[0] - centroid_x))
        return vertices

    def convex_polygon_area_from_lines(self, slope1, intercept1, slope2, intercept2, rectangle):
        """计算斜条和partition的交点"""
        # 计算两条直线的交点
        intersections1 = self.line_rectangle_intersection(slope1, intercept1, rectangle)
        intersections2 = self.line_rectangle_intersection(slope2, intercept2, rectangle)
        # 合并所有交点
        all_points = intersections1 + intersections2
        # 筛选出位于两条直线之间的矩形顶点
        def is_between_lines(x, y, slope1, intercept1, slope2, intercept2):
            return (slope1 * x + intercept1 <= y <= slope2 * x + intercept2) or (
                    slope2 * x + intercept2 <= y <= slope1 * x + intercept1)

        rect_vertices = [(rectangle[0], rectangle[1]), (rectangle[0], rectangle[3]), (rectangle[2], rectangle[1]),
                         (rectangle[2], rectangle[3])]
        for vertex in rect_vertices:
            if is_between_lines(vertex[0], vertex[1], slope1, intercept1, slope2, intercept2):
                all_points.append(vertex)
        # 排序顶点
        vertices_sorted = self.sort_vertices(list(set(all_points)))
        # 计算所包围多边形的面积
        return vertices_sorted, self.polygon_area(vertices_sorted)







