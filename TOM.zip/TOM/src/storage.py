import os
import const
import struct
from collections import defaultdict

"""
分区块、斜条块、region块的模型参数保存在同一个文件中，
然后每一期每个模型的块范围和误差单独保存在一个文件中
"""


class Buffer:
    def __init__(self, max_amount=const.BUFFER_NUM):
        """
        保存形式:
        {
        期数0:
          {块号0: 块0
           块号1: 块1
           ...
          }
        期数1:
          {块号0: 块0
           块号1: 块1
           ...
          }
        }
        添加块时需要指定数据模式和期数以及块号
        """
        self.id_block_map = defaultdict(dict)
        # 字典不能索引，列表用来选择置换的块id
        self.block_id_list = defaultdict(list)  # 为每一期建立缓冲，保存形式: 期数:[期数据块号列表]
        self.max_amount = max_amount
        self.patition_stripe_num_list = []
        pass

    @staticmethod
    def load(pos, data_size, p_num, patten="SIM"):
        """
        斜条数量在运行时确定，起始模型索引块也在运行时确定，所以需要
        在构建索引的时候保存这个起始模型块，约定保存在最后一个分区块的最后,即8192 - 4 = 8188字节处
        这个方法就是获得起始的模型块,另外还有最大的逻辑块号以便约束查询的最大范围

        pos: 相对文件起始的字节偏移量
        data_size: 读取的字节数
        """
        file = const.INDEX_FILE[patten][p_num]
        with open(file, 'rb') as f:
            f.seek(pos)
            data = f.read(data_size)
        return data

    def dump(self, pos, data, p_num, patten="SIM"):
        """修改索引文件中特定位置的数据"""
        file = const.INDEX_FILE[patten][p_num]
        with open(file, 'rb+') as f:
            f.seek(pos)
            f.write(data)

    def set_patition_stripe_num_list(self, psn_list):
        """查询时需要加载这个表"""
        self.patition_stripe_num_list = psn_list

    def is_full(self, p_num, patten="SIM"):
        return len(self.block_id_list[p_num]) >= self.max_amount

    def cal_partition_block_id(self, partition_id):
        """计算分区索引块号"""
        return partition_id // const.PARTITION_BLOCK_ITEM_NUM

    def cal_stripe_block_id(self, partiton_id, stripe_id, cum_stripe_num):
        """
        计算特定分区的斜条所属的索引块,
        通过分区斜条数量列表先累计斜条数量，然后再加上当前斜条号来计算
        """
        cum_stripe_num = cum_stripe_num[partiton_id-1] + stripe_id if partiton_id > 0 else stripe_id
        offset_block_id = cum_stripe_num // const.STRIPE_BLOCK_ITEM_NUM
        real_block_id = const.START_STRIPE_BLOCK_ID + offset_block_id
        return real_block_id

    def cal_region_block_id(self, global_region_number, start_region_block_id):
        """通过模型全局序号计算模型所属的索引块号"""
        rale_region_block_id = global_region_number // const.REGION_BLOCK_ITEM_NUM
        output_id = rale_region_block_id + start_region_block_id
        return output_id

    @staticmethod
    def cal_period_range_block_id(global_region_num):
        """计算特定分布下特定期数的模型范围块号"""
        period_range_block_id = global_region_num // const.PERIOD_RANGE_BLOCK_ITEM_NUM
        return period_range_block_id

    @staticmethod
    def load_block(block_id, file):
        if not os.path.exists(file):
            with open(file, 'wb') as f:
                pass
        if file.endswith('.idx'):  # 索引块
            with open(file, 'rb') as f:
                f.seek(block_id * const.BLOCK_SIZE)
                bin_data = f.read(const.BLOCK_SIZE)
                type = struct.unpack('I', bin_data[4:8])[0]
                if type == const.PARATION:
                    return PartitionBlock.unpack(bin_data)
                elif type == const.STRIPE:
                    return StripeBlock.unpack(bin_data)
                elif type == const.REGION:
                    return RegionBlock.unpack(bin_data)
        elif file.endswith('.dat'):  # 数据块
            with open(file, 'rb') as f:
                f.seek(block_id * const.LOGIC_BLOCK_SIZE)
                bindata = f.read(const.LOGIC_BLOCK_SIZE)
                return DataBlock.unpack(bindata)
        else:
            raise NameError("文件不属于索引文件和数据文件，请选择正确的文件拓展名!")

    @staticmethod
    def load_period_range_block(p_num, b_id, patten='SIM'):
        """加载周期模型的块范围，需要传入分布、期数和块号"""
        with open(const.MODEL_ONE_PERIOD_INDEX_FILE[patten][p_num], 'rb') as f:
            f.seek(b_id * const.BLOCK_SIZE)
            bindata = f.read(const.BLOCK_SIZE)
            return PeriodRangeBlock.unpack(bindata)

    @staticmethod
    def load_physical_block(block_id, max_logic_id, p_num, patten="SIM", is_of=False):
        """ 加载物理块，保存逻辑块列表"""
        if not is_of:
            file = const.DATA_FILE[patten][p_num]
        else:
            file = const.OVERFLOW_DATA_FILE[patten][p_num]
        logic_block_list = []
        const.IO_COUNT += 1
        with open(file, 'rb') as f:
            for i in range(const.LOGIC_PHYSICAL_PROPOTION):
                logic_block_id = block_id * const.LOGIC_PHYSICAL_PROPOTION + i
                # 保存最大逻辑块号，限制查找
                if logic_block_id <= max_logic_id:
                    f.seek(logic_block_id * const.LOGIC_BLOCK_SIZE)
                    bindata = f.read(const.LOGIC_BLOCK_SIZE)
                    data_block = DataBlock.unpack(bindata)
                    logic_block_list.append(data_block)
            physical_block = Block(block_id, logic_blocks=logic_block_list)
            return physical_block


class InsertDataBuffer(Buffer):
    def __init__(self):
        Buffer.__init__(self)

    def add_dblock(self, b, p_num, patten="SIM"):
        if b.block_id not in self.id_block_map[p_num]:
            self.id_block_map[p_num][b.block_id] = b
            self.block_id_list[p_num].append(b.block_id)
        if self.is_full(p_num, patten):
            self.fifo(p_num, patten)

    def insert(self, block, p_num, patten="SIM"):
        """在特点的位置插入一块，需要满足后期的缓冲中块号是连续递增的"""
        self.id_block_map[p_num][block.block_id] = block
        while self.is_full(p_num, patten):
            self.fifo(p_num, patten)

    def get_index_by_block_id(self, block_id, n_p, data_patten="SIM"):
        """通过块号返回这一块在块列表中的索引,并在列表中删除该块"""
        block_id_in_buffer = False
        for b_id in self.block_id_list[n_p]:
            if b_id == block_id:
                block_id_in_buffer = True
                index = self.block_id_list[n_p].index(block_id)
                self.block_id_list[n_p].remove(b_id)
                del self.id_block_map[n_p][b_id]
                return index
        assert block_id_in_buffer, print(f'非溢出块最后一块没在缓存中！')

    def add_block_by_index(self, index, tmp_block, p_num, data_patten="SIM"):
        """通过特定的索引添加临时块"""
        self.block_id_list[p_num].insert(index, tmp_block.block_id)
        self.id_block_map[p_num][tmp_block.block_id] = tmp_block
        if self.is_full(p_num, data_patten):
            self.fifo(p_num, data_patten)

    def write_period_overflow_block(self, period_overflow_blocks, p_num, patten="SIM"):
        """写入region的块范围到磁盘"""
        index_file = const.OVERFLOW_DATA_FILE[patten][p_num]
        if not os.path.exists(index_file):
            with open(index_file, 'wb'):
                pass
        if isinstance(period_overflow_blocks, list):
            with open(index_file, 'rb+') as f:
                for block in period_overflow_blocks:
                    f.seek(block.block_id * const.LOGIC_BLOCK_SIZE)
                    f.write(block.pack())
        else:
            with open(index_file, 'rb+') as f:
                f.seek(period_overflow_blocks.block_id * const.LOGIC_BLOCK_SIZE)
                f.write(period_overflow_blocks.pack())

    def delete(self, id, p_num):
        """由于斜条的数据正好是127的倍数时会有多余的块进来，所以需要舍去这块"""
        self.block_id_list[p_num].remove(id)
        del self.id_block_map[p_num][id]

    def get_dblock(self, block_id, p_num, patten="SIM"):
        for id in self.id_block_map[p_num]:
            if id == block_id:
                return self.id_block_map[p_num][block_id]
        return None

    def write_dblock(self, dblock, p_num, patten="SIM"):
        data_file = const.DATA_FILE[patten][p_num]
        if not os.path.exists(data_file):
            with open(data_file, 'wb') as f:
                pass
        with open(data_file, 'rb+') as f:
            f.seek(dblock.block_id * const.LOGIC_BLOCK_SIZE)
            f.write(dblock.pack())

    def fifo(self, p_num, patten="SIM"):
        """
        先进先出置换策略，只要缓冲一满：
        1   将要置换的块写入文件
        2   将要置换的块从列表中舍去
        3   不考虑脏页问题
        :return:
        """
        id = self.block_id_list[p_num][0]
        # 将数据块写入文件
        self.write_dblock(self.id_block_map[p_num][id], p_num, patten)
        firstid = self.block_id_list[p_num].pop(0)
        del self.id_block_map[p_num][firstid]


    def update_to_disk(self, p_num, patten="SIM"):
        """
        索引建立完成后将缓冲中的内容全部写入磁盘
        :return:
        """
        data_file = const.DATA_FILE[patten][p_num]
        if not os.path.exists(data_file):
            with open(data_file, 'wb') as f:
                pass
        with open(data_file, 'rb+') as fp:
            for block_id in self.block_id_list[p_num]:
                self.write_dblock(self.id_block_map[p_num][block_id], p_num, patten)
        self.id_block_map = defaultdict(dict)
        self.block_id_list = defaultdict(list)


class InsertIndexBuffer(Buffer):
    def __init__(self):
        Buffer.__init__(self)

    def write_block(self, block, p_num, patten='SIM'):
        index_file = const.INDEX_FILE[patten][p_num]
        if not os.path.exists(index_file):
            with open(index_file, 'wb') as f:
                pass
        with open(index_file, 'rb+') as f:
            f.seek(block.block_id * const.BLOCK_SIZE)
            f.write(block.pack())

    def write_period_range_block(self, period_range_block, p_num, patten="SIM"):
        index_file = const.MODEL_ONE_PERIOD_INDEX_FILE[patten][p_num]
        if not os.path.exists(index_file):
            with open(index_file, 'wb'):
                pass
        if isinstance(period_range_block, list):
            with open(index_file, 'rb+') as f:
                for block in period_range_block:
                    f.seek(block.block_id * const.BLOCK_SIZE)
                    f.write(block.pack())
        else:
            with open(index_file, 'rb+') as f:
                f.seek(period_range_block.block_id * const.BLOCK_SIZE)
                f.write(period_range_block.pack())

    def add_block(self, block, p_num, patten="SIM") -> None:
        if block.block_id not in self.id_block_map[p_num]:
            self.id_block_map[p_num][block.block_id] = block
            self.block_id_list[p_num].append(block.block_id)
        if self.is_full(p_num, patten):
            self.fifo(p_num, patten)

    def get_block(self, block_id, p_num, patten="SIM"):
        for block_id1 in self.block_id_list[p_num]:
            if block_id == block_id1:
                return self.id_block_map[p_num][block_id1]
        return None

    def fifo(self, p_num, patten="SIM"):
        assert len(self.block_id_list[p_num]) <= self.max_amount
        id = self.block_id_list[p_num][0]
        self.write_block(self.id_block_map[p_num][id], p_num, patten)
        del self.id_block_map[p_num][id]
        self.block_id_list[p_num].remove(id)

    def update_to_disk(self, p_num, patten="SIM"):
        """
        将缓冲区中的内容写入磁盘
        :return:
        """
        index_file = const.INDEX_FILE[patten][p_num]
        if not os.path.exists(index_file):
            with open(index_file, 'wb'):
                pass
        with open(index_file, 'rb+') as fp:
            for block_id in self.block_id_list[p_num]:
                self.write_block(self.id_block_map[p_num][block_id], p_num, patten)
        self.id_block_map = defaultdict(dict)
        self.block_id_list = defaultdict(list)


class QueryDataBuffer(Buffer):
    def __init__(self):
        Buffer.__init__(self)
        # 后期数据需要保存溢出块，总块数等于非溢出块列表加溢出块列表长度
        self.overflow_block_id_list = defaultdict(list)
        self.overflow_id_block_map = defaultdict(dict)

    def add_overflow_block(self, of_block, p_num, patten='SIM'):
        """后期添加溢出块"""
        if of_block.block_id not in self.overflow_block_id_list[p_num]:
            self.overflow_block_id_list[p_num].append(of_block.block_id)
            self.overflow_id_block_map[p_num][of_block.block_id] = of_block
        if self.is_full(p_num, patten):
            self.fifo(p_num, patten)

    def add_dblock(self, b, p_num, patten="SIM"):
        if b.block_id not in self.id_block_map[p_num]:
            self.id_block_map[p_num][b.block_id] = b
            self.block_id_list[p_num].append(b.block_id)
        if self.is_full(p_num, patten):
            self.fifo(p_num, patten)

    def is_full(self, p_num, patten="SIM"):
        return len(self.block_id_list[p_num]) + len(self.overflow_block_id_list[p_num]) >= self.max_amount

    def get_overflow_block(self, b_id, p_num, patten="SIM"):
        for block_id in self.overflow_id_block_map[p_num]:
            if block_id == b_id:
                return self.overflow_id_block_map[p_num][block_id]
        return None

    def get_dblock(self, block_id, p_num, patten="SIM"):
        for id in self.id_block_map[p_num]:
            if id == block_id:
                return self.id_block_map[p_num][block_id]
        return None

    def fifo(self, p_num, patten="SIM"):
        """
        先进先出页面置换,包括非溢出和溢出块列表，选择较长的那一个列表按照先进先出置换
        :return:
        """
        if len(self.block_id_list[p_num]) >= len(self.overflow_block_id_list[p_num]):
            firstid = self.block_id_list[p_num].pop(0)
            del self.id_block_map[p_num][firstid]
        else:
            firstid = self.overflow_block_id_list[p_num].pop(0)
            del self.overflow_id_block_map[p_num][firstid]


class QueryIndexBuffer(Buffer):
    """索引不设置缓冲，在查询前全都读入内存"""
    def __init__(self):
        Buffer.__init__(self)

    def add_block(self, block, p_num, patten="SIM") -> None:
        if block.block_id not in self.id_block_map[p_num]:
            self.id_block_map[p_num][block.block_id] = block
            self.block_id_list[p_num].append(block.block_id)

    def get_block(self, block_id, p_num, patten="SIM"):
        for block_id1 in self.block_id_list[p_num]:
            if block_id == block_id1:
                return self.id_block_map[p_num][block_id1]
        return None


class Block:
    """物理块"""
    def __init__(self, id, logic_blocks):
        self.logic_block_list = logic_blocks
        self.block_id = id

    @staticmethod
    def get_physical_block(b_id, data_buffer, p_num, patten="SIM", is_of=False):
        if not is_of:
            block = data_buffer.get_dblock(b_id, p_num, patten)
        else:
            block = data_buffer.get_overflow_block(b_id, p_num, patten)
        if block is None:
            if not is_of:
                block = Buffer.load_physical_block(b_id, const.MAX_LOGIC_BLOCK_ID, p_num, patten, is_of)
            else:
                block = Buffer.load_physical_block(b_id, const.MAX_OVERFLOW_LOGIC_BLOCK_ID, p_num, patten, is_of)
            if not is_of:
                data_buffer.add_dblock(block, p_num, patten)
            else:
                data_buffer.add_overflow_block(block, p_num, patten)
        return block


class DataBlockPool:
    def __init__(self, initial_size=5000):
        self._pool = [DataBlock(-1) for _ in range(initial_size)]  # 预初始化对象
        self._ptr = 0  # 当前可用对象的指针

    def get_block(self, block_id):
        """从池中获取一个可复用的 DataBlock 对象"""
        if self._ptr >= len(self._pool):
            # 池不足时动态扩展（按当前大小的 50% 扩展）
            self._pool.extend([DataBlock(-1) for _ in range(len(self._pool) // 2)])
        block = self._pool[self._ptr]
        block.block_id = block_id
        block.data_points.clear()  # 清空旧数据
        block.overflow_block_id = const.DEFAULT_OVERFLOW_BLOCKS[0]  # 重置溢出块号
        block.overflow_block_num = const.DEFAULT_OVERFLOW_BLOCKS[1]  # 重置溢出块数量
        self._ptr += 1
        return block

    def release_all(self):
        """重置池指针以便复用所有对象"""
        self._ptr = 0


class DataBlock:
    __slots__ = ['block_id',
                 'data_points',
                 'overflow_block_id',
                 'overflow_block_num'
                 ]
    """
    逻辑块
    """
    def __init__(self, block_id, overflow_blockid=const.DEFAULT_OVERFLOW_BLOCKS[0]):
        self.block_id = block_id
        self.data_points = []
        self.overflow_block_id = overflow_blockid  # 保存在溢出块中
        self.overflow_block_num = const.DEFAULT_OVERFLOW_BLOCKS[1]

    def create_new_block(self):
        return DataBlock(block_id=self.block_id+1)

    @staticmethod
    def get_logic_block(b_id, data_buffer, p_num, patten="SIM"):
        block = data_buffer.get_dblock(b_id, p_num, patten)
        if block is None:
            block = Buffer.load_block(b_id, file=const.DATA_FILE[patten][p_num])
            data_buffer.add_dblock(block, p_num, patten)
        return block

    def set_overflow_block_id(self, b_id):
        self.overflow_block_id = b_id

    def set_overflow_block_num(self, b_num):
        self.overflow_block_num = b_num

    def is_overflow(self):
        """存满的情况，需要额外加1"""
        return (len(self.data_points) + 1) * 16 + 16 > const.LOGIC_BLOCK_SIZE

    def pack(self):
        """block to bytes"""
        binfo = struct.pack('4I', self.block_id, len(self.data_points), self.overflow_block_id, self.overflow_block_num)
        for x, y in self.data_points:
            binfo = binfo + struct.pack('2d', x, y)
        return binfo

    @staticmethod
    def unpack(bindata):
        """bytes to block"""
        block_id, length, overflow_bid, overlfow_bnum = struct.unpack('4I', bindata[:16])
        dblock = DataBlock(block_id)
        dblock.overflow_block_num = overlfow_bnum
        dblock.overflow_block_id = overflow_bid
        offset = 16
        for i in range(length):
            x = struct.unpack('d', bindata[offset:offset + 8])[0]
            offset += 8
            y = struct.unpack('d', bindata[offset:offset + 8])[0]
            offset += 8
            dblock.data_points.append([x, y])
        return dblock

    def add_point(self, point):
        self.data_points.append(point)

    def add_points_batch(self, points):
        """批量添加数据"""
        self.data_points.extend(points)


class PartitionBlock:
    """保存分区参数的索引块,一般是前面3块,足以保存所有分区参数"""
    def __init__(self, block_id, type=0):
        self.block_id = block_id
        self.type = type  # 索引参数类型，包括3种
        self.partition_param_list = []  # 分区参数列表,具体参数见const模块

    @staticmethod
    def get_partition_block(b_id, index_buffer, p_num, patten="SIM"):
        block = index_buffer.get_block(b_id, p_num, patten)
        if block is None:
            block = Buffer.load_block(b_id, file=const.INDEX_FILE[patten][p_num])
            index_buffer.add_block(block, p_num, patten)
        return block

    def add_partition_param(self, partiton_param):
        """添加顺序：斜率，t间隔，底部截距，最后一个逻辑块号"""
        self.partition_param_list.append(partiton_param)

    def create_new_block(self):
        return PartitionBlock(block_id=self.block_id + 1, type=0)

    def is_overflow(self):
        return (len(self.partition_param_list) + 1) * const.PARTITION_PARAM_SIZE + 12 > const.BLOCK_SIZE

    def pack(self):
        bin_info = struct.pack('3I', self.block_id, self.type, len(self.partition_param_list))
        for W, t_int, low_inpt in self.partition_param_list:
            bin_info += const.PartitionParam(W, t_int, low_inpt).pack()
        return bin_info

    @staticmethod
    def unpack(bin_data):
        block_id, type, par_num = struct.unpack('III', bin_data[:12])
        block = PartitionBlock(block_id=block_id, type=type)
        offset = 12
        for i in range(par_num):
            W = struct.unpack('2d', bin_data[offset: offset + 16])
            offset += 16
            t_int = struct.unpack('d', bin_data[offset: offset + 8])[0]
            offset += 8
            low_inpt = struct.unpack('d', bin_data[offset: offset + 8])[0]
            offset += 8
            block.partition_param_list.append([W, t_int, low_inpt])
        return block


class StripeBlock:
    """保存分区内斜条序号，斜条内的模型数量"""
    def __init__(self, block_id, type=1):
        self.block_id = block_id
        self.type = type
        self.stripe_param_list = []

    @staticmethod
    def get_stripe_block(b_id, index_buffer, p_num, patten="SIM"):
        block = index_buffer.get_block(b_id, p_num, patten)
        if block is None:
            block = Buffer.load_block(b_id, file=const.INDEX_FILE[patten][p_num])
            index_buffer.add_block(block, p_num, patten)
        return block

    def is_overflow(self):
        return (len(self.stripe_param_list) + 1) * const.STRIPE_PARAM_SIZE + 12 > const.BLOCK_SIZE

    def create_new_block(self):
        return StripeBlock(self.block_id + 1)

    def add_stripe_param(self, param):
        """添加顺序：第一个模型的全局序号, 模型数量，斜条数据mbr"""
        self.stripe_param_list.append(param)

    def pack(self):
        bin_info = struct.pack('3I', self.block_id, self.type, len(self.stripe_param_list))
        for region_id, region_num in self.stripe_param_list:
            bin_info += const.StripeParam(region_id, region_num).pack()
        return bin_info

    @staticmethod
    def unpack(bin_data):
        block_id, type, stripe_num = struct.unpack('III', bin_data[:12])
        block = StripeBlock(block_id=block_id, type=type)
        offset = 12
        for i in range(stripe_num):
            region_id = struct.unpack('I', bin_data[offset:offset+4])[0]
            offset += 4
            region_num = struct.unpack('I', bin_data[offset:offset+4])[0]
            offset += 4
            block.stripe_param_list.append([region_id, region_num])
        return block


class RegionBlock:
    def __init__(self, block_id, type=2):
        self.block_id = block_id
        self.type = type
        self.region_param_list = []

    @staticmethod
    def get_region_block(b_id, index_buffer, p_num, patten="SIM"):
        block = index_buffer.get_block(b_id, p_num, patten)
        if block is None:
            block = Buffer.load_block(b_id, file=const.INDEX_FILE[patten][p_num])
            index_buffer.add_block(block, p_num, patten)
        return block

    def is_overflow(self):
        return (len(self.region_param_list) + 1) * const.REGION_PARAM_SIZE + 12 > const.BLOCK_SIZE

    def create_new_block(self):
        return RegionBlock(self.block_id + 1)

    def add_region_param(self, param):
        """添加顺序：start_index, end_index, pos, t, logic_index, m, n, p"""
        """添加顺序：分割pos，基点（pos，t，logic_id），方向向量"""
        self.region_param_list.append(param)

    def pack(self):
        bin_info = struct.pack('3I', self.block_id, self.type, len(self.region_param_list))
        for start_mv, end_mv, pos, t, index, m, n, p in self.region_param_list:
            bin_info += const.RegionParam(start_mv, end_mv, pos, t, int(index), m, n, int(p)).pack()
        return bin_info

    @staticmethod
    def unpack(bin_data):
        block_id, type, region_num = struct.unpack('III', bin_data[:12])
        block = RegionBlock(block_id=block_id, type=type)
        offset = 12
        for i in range(region_num):
            start_mv = struct.unpack('d', bin_data[offset:offset+8])[0]
            offset += 8
            end_mv = struct.unpack('d', bin_data[offset:offset+8])[0]
            offset += 8
            pos = struct.unpack('d', bin_data[offset:offset+8])[0]
            offset += 8
            t = struct.unpack('d', bin_data[offset:offset+8])[0]
            offset += 8
            index = struct.unpack('I', bin_data[offset:offset+4])[0]
            offset += 4
            m = struct.unpack('d', bin_data[offset:offset+8])[0]
            offset += 8
            n = struct.unpack('d', bin_data[offset:offset+8])[0]
            offset += 8
            p = struct.unpack('I', bin_data[offset:offset+4])[0]
            offset += 4
            block.region_param_list.append([start_mv, end_mv, pos, t, index, m, n, int(p)])
        return block


class PeriodRangeBlock:
    """保存各周期所有模型块范围，每一期单独一个文件"""
    def __init__(self, block_id):
        self.block_id = block_id
        self.model_block_range = []

    def add_model_block_range(self, block_range):
        """保存形式：第一个模型block_range, 第二个模型block_range...第n个模型range"""
        self.model_block_range.append(block_range)

    @staticmethod
    def get_period_range_block(b_id, p_num, patten="SIM"):
        block = Buffer.load_period_range_block(p_num, b_id, patten)
        return block

    def is_overflow(self):
        return (len(self.model_block_range) + 1) * const.MODEL_BLOCK_RANGE_PARAM_SIZE_ONE_PERIOD + 8 > const.BLOCK_SIZE

    def create_new_block(self):
        return PeriodRangeBlock(self.block_id + 1)

    def pack(self):
        bin_info = struct.pack('2I', self.block_id, len(self.model_block_range))
        for s_id, e_id, s_of_id, e_of_id in self.model_block_range:
            bin_info += const.PeriodBlockRangeParam(s_id, e_id, s_of_id, e_of_id).pack()
        return bin_info

    @staticmethod
    def unpack(bin_data):
        block_id, model_range_num = struct.unpack('2I', bin_data[:8])
        block = PeriodRangeBlock(block_id=block_id)
        offset = 8
        for i in range(model_range_num):
            model_s_id = struct.unpack('I', bin_data[offset: offset+4])[0]
            offset += 4
            mdel_e_id = struct.unpack("I", bin_data[offset: offset+4])[0]
            offset += 4
            model_s_of_id = struct.unpack("I", bin_data[offset: offset + 4])[0]
            offset += 4
            model_e_of_id = struct.unpack("I", bin_data[offset: offset + 4])[0]
            offset += 4
            block.model_block_range.append((model_s_id, mdel_e_id, model_s_of_id, model_e_of_id))
        return block
