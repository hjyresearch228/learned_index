from src import storage
import struct
from utils.file_utils import *
from collections import defaultdict

patten = 'SIM'
# period_num = 1

def get_block_range():
    for j in range(const.PERIOD_NUM):
        global_region_number = struct.unpack('I', storage.Buffer.load(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 12,
                                               data_size=4, p_num=j, patten=patten))[0]
        period_range_block_total_number = int(np.ceil(global_region_number / const.PERIOD_RANGE_BLOCK_ITEM_NUM))
        region_block_range = defaultdict(list)
        i = 0
        for period_block_index in range(period_range_block_total_number):
            period_range_block = storage.Buffer.load_period_range_block(j, period_block_index, patten)
            for b_r in period_range_block.model_block_range:
                region_block_range[i] = b_r
                i += 1
        if j == 2:
            print(region_block_range)
        if const.TOM2:
            dump_model(region_block_range, os.path.join(rf'E:\Python_Projects\Learned_Index\TOM_update\sim_block_range_tom2', f'region_block_range_p_{j}.pkl'))
        else:
            dump_model(region_block_range, os.path.join(rf'E:\Python_Projects\Learned_Index\TOM_update\sim_block_range_tom1', f'region_block_range_p_{j}.pkl'))


def find_dict_differences():
    for i in range(const.PERIOD_NUM):
        dict1 = load_model(os.path.join(rf'E:\Python_Projects\Learned_Index\TOM_update\sim_block_range_tom1', f'region_block_range_p_{i}.pkl'))
        dict2 = load_model(os.path.join(rf'E:\Python_Projects\Learned_Index\TOM_update\sim_block_range_tom2', f'region_block_range_p_{i}.pkl'))
        only_in_dict1 = {key: dict1[key] for key in dict1 if key not in dict2}
        only_in_dict2 = {key: dict2[key] for key in dict2 if key not in dict1}
        common_keys = set(dict1.keys()) & set(dict2.keys())
        different_values = {key: (dict1[key], dict2[key]) for key in common_keys if dict1[key] != dict2[key]}
        print(f"period_num: {i}, 只在 tom1 中的键: {only_in_dict1}, 总数量: {len(only_in_dict1)}")
        print(f"period_num: {i}, 只在 tom2 中的键: {only_in_dict2}, 总数量: {len(only_in_dict2)}")
        if i == 2:
            print(f"period_num: {i}, 键相同但值不同的项: {different_values}, 总数量: {len(different_values)}")
        # print(f"period_num: {i}, 不同块范围总数量: {len(different_values)}")

# get_block_range()
find_dict_differences()