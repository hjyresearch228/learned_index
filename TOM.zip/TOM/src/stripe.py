import math
import numpy as np
import const


class SlantStripe:
    __slots__ = [
        'stripe_id',
         'stripe_data_list',
         'three_dim_data_list',
         'low_intercept',
         'high_intercept',
         'region_list',
         'region_number_list',
         'parent',
         'break_points'
    ]
    """
    斜条存储：region起始全局序号、region数量，数据的mbr
    """
    def __init__(self, low_intercept, high_intercept, stripe_id, parent=None):
        """每个斜条由底部截距和顶部截距标识"""
        self.stripe_id = stripe_id  # 斜条序号，从0开始
        self.stripe_data_list = []
        self.three_dim_data_list = []  # 存储三维数据点，包括逻辑块号
        self.low_intercept = low_intercept
        self.high_intercept = high_intercept
        self.region_list = []  # 存储斜条对应的模型对象
        self.region_number_list = []  # 存储斜条的模型全局序号,和模型对象列表配合使用
        self.parent = parent  # 斜条所属的分区
        self.break_points = []

    def get_data_in_region(self, max_index, index, data, s_mv, e_mv):
        """从斜条数据获取region数据，对于点在边界的情况，设置为左开右闭"""
        # 原来是按照pos分割，现在按照一维映射值分割
        data = np.array(data)
        # 提取pos和t组成二维数组
        pos_t = data[:, :2]
        # 计算每个点的mv值（点积）
        W = self.parent.W
        mv = np.dot(pos_t, W)
        # 根据index是否max_index确定边界条件
        if index == max_index:
            mask = (mv >= s_mv) & (mv <= e_mv)
        else:
            mask = (mv >= s_mv) & (mv < e_mv)
        filtered_data = data[mask]
        return filtered_data

    def set_parent(self, parent):
        self.parent = parent

    def set_breakpoints(self, bp):
        self.break_points = bp

    def stripe_inner_sort(self):
        """根据坐标和W的乘积排序"""
        W = self.parent.W
        ori_point_proj_map = {}  # 存储原始点和一维值的映射，通过映射值对原数据排序
        for x, y in self.stripe_data_list:
            projected_value = np.dot(np.array([x, y]), np.array(W))
            ori_point_proj_map[(x, y)] = projected_value
        sorted_points = sorted(ori_point_proj_map.keys(), key=lambda point: ori_point_proj_map[point])
        self.stripe_data_list = np.array(list(sorted_points))

        # if isinstance(self.stripe_data_list, list):
        #     self.stripe_data_list.sort(key=lambda x: (x[0], x[1]))
        # else:
        #     sorted_indices = np.lexsort((self.stripe_data_list[:, 1], self.stripe_data_list[:, 0]))
        #     self.stripe_data_list = self.stripe_data_list[sorted_indices]

    @staticmethod
    def fit(features, target):
        """feature：(t, pos), target：逻辑块号，返回模型参数[基点，方向向量]"""
        points = np.column_stack((features, target))
        i = 0
        j = len(points) - 1
        start = points[i]
        end = points[j]
        max_pos = np.max(points[:,0])
        min_pos = np.min(points[:,0])
        max_t = np.max(points[:,1])
        min_t = np.min(points[:,1])
        max_l_id = np.max(points[:,2])
        min_l_id = np.min(points[:,2])
        # 先判断是否有一个维度是否全是一样值,避免方向向量的前2个维度具有0值
        first_dimension = [sublist[0] for sublist in points]
        second_dim = [sub[1] for sub in points]
        # 判断维度的值是否全部相同
        first_all_same = all(value == first_dimension[0] for value in first_dimension)
        second_all_same = all(value == second_dim[0] for value in second_dim)
        # pos全相同
        if first_all_same:
            # 可能会出现递归到只有一个点的时候，这时方向向量的前两个维度会有0值，需要特殊处理
            if min_t == max_t:
                dv = [min_pos, 1, max_l_id - min_l_id]
            else:
                dv = [min_pos, max_t - min_t, max_l_id - min_l_id]
            return [list(start), dv]
        # t全相同
        if second_all_same:
            dv = [max_pos - min_pos, min_t, max_l_id - min_l_id]
            return [list(start), dv]
        dv = [max_pos - min_pos, max_t - min_t, max_l_id - min_l_id]
        while dv[0] == 0 or dv[1] == 0:
            # i += 1
            points = np.delete(points, j, axis=0)
            j -= 1
            start = points[i]
            end = points[j]
            max_pos = np.max(points[:, 0])
            min_pos = np.min(points[:, 0])
            max_t = np.max(points[:, 1])
            min_t = np.min(points[:, 1])
            max_l_id = np.max(points[:, 2])
            min_l_id = np.min(points[:, 2])
            dv = [max_pos - min_pos, max_t - min_t, max_l_id - min_l_id]
        model = [list(start), list(dv)]
        return model

    @staticmethod
    def predict(input, coef_):
        """
        空间直线拟合，分别利用x和y计算z，然后取平均
        input: 输入的查询点
        coef_:模型的参数(基点和方向向量)
        """
        z_x = (coef_[1][2] * (input[0] - coef_[0][0])) / coef_[1][0] + coef_[0][2]
        z_y = (coef_[1][2] * (input[1] - coef_[0][1])) / coef_[1][1] + coef_[0][2]
        pre_z = np.round((z_x + z_y) / 2).astype(int)
        return pre_z

    def douglas_peucker(self, timestamps, edge_positions, indices, epsilon):
        """道格拉斯分段迭代算法，距离定义为z轴距离（即逻辑块的差异）"""
        stack = [(0, len(timestamps) - 1)]
        result_indices = [0, len(timestamps) - 1]
        models = []
        model_error = []
        t_range = []  # 保存改版后需要的t范围
        pos_range = []  # 保存改版后需要的pos范围，在后期更新时计算误差需要用到
        while stack:
            max_distance = 0
            start, end = stack.pop()
            index_of_max = start + 1
            features = np.vstack([edge_positions, timestamps]).T
            coef = SlantStripe.fit(features[start: end + 1], indices[start: end + 1])
            assert coef[1][0] != 0 and coef[1][1] != 0, print(f"方向向量的前2个维度存在0值, coef = {coef}")

            for i in range(start + 1, end):
                predicted_z = SlantStripe.predict([edge_positions[i], timestamps[i]], coef)
                distance = int(abs(predicted_z - indices[i]))
                if distance > max_distance:
                    max_distance = distance
                    index_of_max = i
            if max_distance > epsilon:
                stack.append((start, index_of_max))
                stack.append((index_of_max, end))
                if index_of_max not in result_indices:
                    result_indices.append(index_of_max)
            else:
                start_mv = np.round(np.dot(np.array([edge_positions[start], timestamps[start]]), self.parent.W), 3)
                end_mv = np.round(np.dot(np.array([edge_positions[end], timestamps[end]]), self.parent.W), 3)
                start_pos = np.round(np.min(edge_positions[start: end + 1]), 3)
                end_pos = np.round(np.max(edge_positions[start: end + 1]), 3)
                start_t = np.round(np.min(timestamps[start: end + 1]), 3)
                end_t = np.round(np.max(timestamps[start: end + 1]), 3)
                # 现在是根据一维映射值来排序，但是在后期更新时需要维护每个region的pos和t的范围
                models.append([start_mv, end_mv, coef[0], coef[1]])
                model_error.append(max_distance)
                pos_range.append([start_pos, end_pos])
                t_range.append([start_t, end_t])
        result_indices.sort()
        return result_indices, models, model_error, t_range, pos_range


class StripeRegion:
    __slots__ = [
        'start_pos',
        'end_pos',
        'start_t',
        'end_t',
        'start_mv',
        'end_mv',
        's_b_id',
        'e_b_id',
        'zero_period_data_num',
        'zero_period_block_range',
        'region_overflow_blocks',
        'base_point',
        'dv',
        'global_region_num',
        'region_data_list',
        'new_region_data',
        'par_stripe',
        'period_block_range',
        'period_max_region_error_int',
        'period_ps_int',
        'period_t_int',
        'rd_0',
        'period_psc',
        'period_tc'
    ]
    """一个斜条分为多个region，每个region对应一个模型，保存region的pos范围"""
    def __init__(self, start_mv, end_mv, base_point, dv, s_b_id=None, e_b_id=None):
        self.start_pos = None  # 模型pos范围
        self.end_pos = None
        self.start_t = None  # region的t轴范围，用于改版后的改善模型部分，对应公式38
        self.end_t = None
        self.start_mv = start_mv  # region的一维映射值范围，用于查询时匹配模型
        self.end_mv = end_mv

        self.s_b_id = s_b_id  # 模型的逻辑块范围
        self.e_b_id = e_b_id

        # 保存第0期的数据量和块范围
        self.zero_period_data_num = None
        self.zero_period_block_range = None
        # 后期每一期的溢出块，没溢出则设置默认值，形式为：[起始溢出块，结尾溢出块]
        self.region_overflow_blocks = {}

        self.base_point = base_point  # 这个基点指的是当前期数集成模型的基点，每一期更新时都会改变
        self.dv = dv  # 方向向量在集成模型不超过指定阈值时是固定的

        self.global_region_num = None  # 模型全局序号
        # region中的数据，用于后期数据的调整，当集成模型最大误差超过指定阈值时，重新训练region的所有期数据，这个数据是三维的
        self.region_data_list = []

        # 保存后期的新增数据
        self.new_region_data = []

        self.par_stripe = None  # region所属的斜条，用于后期数据调整
        # 以下为模型更新所需的参数，形式为 期数号: 对应的参数
        self.period_block_range = {}  # 存储每一期的模型的块范围，形式: 期数:(s_b_id, e_b_id)，默认用(0,0)填充
        self.period_max_region_error_int = {}  # 存储每一期的region的最大误差，对应Ak，指的是集成模型的误差
        self.period_ps_int = {}  # 存储每一期的模型基点pos，对应pscj
        self.period_t_int = {}  # 存储每一期的模型基点t， 对应tcj
        self.rd_0 = None  # 初期的z轴系数，更新模型时会用到
        self.period_psc = {}  # 每一期的非集成基点pos
        self.period_tc = {}  # 每一期的非集成基点t

    def set_zero_period_data_num(self, data_num):
        self.zero_period_data_num = data_num

    def set_start_t(self, st):
        self.start_t = st

    def set_end_t(self, et):
        self.end_t = et

    def set_start_pos(self, st):
        self.start_pos = st

    def set_end_pos(self, et):
        self.end_pos = et

    def set_zero_period_block_range(self, b_ra):
        self.zero_period_block_range = b_ra

    def set_stripe(self, stripe):
        self.par_stripe = stripe

    def set_global_region_num(self, region_num):
        self.global_region_num = region_num

    def set_s_b_id(self, sbid):
        self.s_b_id = sbid

    def set_end_b_id(self, endbid):
        self.e_b_id = endbid

    @staticmethod
    def get_model_block_id_range_by_mv_intersection(W, models, model_index, logic_blocks):
        """通过块的一维映射值范围来确定region的块范围"""
        model_block_id_range = []
        model_min_mv = models[model_index][0]
        model_max_mv = models[model_index][1]
        for logic_block in logic_blocks:
            np_points = np.array(logic_block.data_points)
            if len(np_points) == 0:
                continue
            tmp_new_region_data = []
            # 将边界上的数据按照左开右闭存放
            for point in np_points:
                point_mv = np.round(np.dot(np.array(point), W), 3)
                if (model_index == len(models) - 1) or (point_mv != model_max_mv):
                    tmp_new_region_data.append(point)
            np_points = np.array(tmp_new_region_data)
            if len(np_points) == 0:
                continue

            mv_list = []
            for p in np_points:
                mv = np.dot(np.array(p), W)
                mv_list.append(mv)
            block_max_mv = max(mv_list)
            block_min_mv = min(mv_list)
            if model_min_mv <= np.round(block_max_mv, 3) and np.round(block_min_mv, 3) <= model_max_mv:
                model_block_id_range.append(logic_block.block_id)
        model_block_id_ran = list(set(model_block_id_range))
        return model_block_id_ran

