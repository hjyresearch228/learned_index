import math
import os.path
import struct
import time
import bisect
import storage
from utils.file_utils import *
from partition import *
from stripe import SlantStripe
import numpy as np
from geometry import Rectangle, Point, Polygon, MaxPriorityQueue


def get_real_point_query_result(query_list, data_file):
    """返回实际点查询结果"""
    result = []
    data = read_txt_to_list(data_file)
    for query in query_list:
        for p in data:
            if p[0] == query[0] and p[1] == query[1]:
                result.append(p)
                break
    return result


def get_real_range_query_result(query_range, data):
    """
    正确的查询结果，返回实际数据个数
    """
    pos_low, t_low, pos_high, t_high = query_range
    pos_arr = data[:, 0]
    idx_ = np.argwhere((pos_arr <= pos_high) & (pos_arr >= pos_low)).flatten()
    data_ = data[idx_]
    t_arr = data_[:, 1]
    idx_ = np.argwhere((t_arr <= t_high) & (t_arr >= t_low)).flatten()
    data_res = data_[idx_]
    return len(idx_)


def get_real_knn_query_result(k, point_querys, data):
    """暴力返回实际的KNN查询结果"""
    point_querys = np.array(point_querys)
    sq_dist_mat = np.sum((point_querys[:, np.newaxis, :] - data) ** 2, axis=-1)
    # 按行排序取前k个索引，再提取对应距离和坐标
    k_idx = np.argsort(sq_dist_mat, axis=1)[:, :k]
    k_coords = data[k_idx]  # 近邻坐标(m×k×2)
    result = [tuple(pt) for pt in k_coords.reshape(-1, 2)]
    return result


def get_single_real_knn_query_result(k, query_point, data):
    data = np.array(data)
    target = np.array(query_point)
    dists = np.linalg.norm(data - target, axis=1)
    # 筛选掉距离为0的自身点（布尔索引，保留所有非0距离的点）
    non_self_indices = dists != 0
    data = data[non_self_indices]
    dists = dists[non_self_indices]
    return data[np.argsort(dists)[:k]]


class Query:
    def __init__(self, model_error, fp_result, data_buffer, index_buffer, bx, by, cum_stripe_num_list, partiton_range, max_logic_id, start_region_block_id, p_num=0, patten="SIM"):
        self.data_buffer = data_buffer
        self.index_buffer = index_buffer
        self.bx = bx
        self.by = by
        self.cum_stripe_num_list = cum_stripe_num_list  # 累计斜条数量列表，用于计算斜条在当前斜条块中的偏移序号
        self.partition_range = partiton_range  # 分区的边界范围
        self.max_logic_id = max_logic_id  # 最大逻辑块号，用于限制查找
        self.p_num = p_num  # 期数
        self.data_patten = patten
        self.start_region_block_id = start_region_block_id
        self.period_range_block_map = {}  # 保存周期范围块列表，不保存在缓冲对象中
        self.period_range_block_ids = []
        self.overflow_block_ids = []  # 保存溢出块信息
        self.overflow_block_map = {}
        self.query_num = 0
        self.fp_result = fp_result
        self.model_error = model_error

    def get_physical_ids_by_logic_ids(self, logic_ids):
        physical_ids = set()
        for logic_id in logic_ids:
            physical_id = logic_id // const.LOGIC_PHYSICAL_PROPOTION
            physical_ids.add(physical_id)
        return physical_ids

    def get_physical_id_by_start_pre(self, pre_logic_id, start_logic_block_id, global_region_number):
        """通过预测的下界逻辑块块号扩大搜索范围并获得物理号"""
        if const.TOM2:
            error = self.model_error[global_region_number]
        else:
            if self.p_num == 0:
                error = init_error_thre
            else:
                error = follow_error_thre
        extend_logic_id_start = max(start_logic_block_id, pre_logic_id - error)
        start_block_id = extend_logic_id_start // const.LOGIC_PHYSICAL_PROPOTION
        return start_block_id


    def get_physical_id_by_end_pre(self, pre_logic_id, end_logic_block_id, global_region_number):
        """通过预测的上界逻辑块块号获得物理号"""
        if const.TOM2:
            error = self.model_error[global_region_number]
        else:
            if self.p_num == 0:
                error = init_error_thre
            else:
                error = follow_error_thre
        extend_logic_id_end = min(pre_logic_id + error, end_logic_block_id)
        end_block_id = extend_logic_id_end // const.LOGIC_PHYSICAL_PROPOTION
        return end_block_id

    @staticmethod
    def get_positive_slope_stripe_boundary(query_range, stripe_low_inter_bool, stripe_low_inter_res,
                                           stripe_high_inter_bool, stripe_high_inter_res):
        """获取正斜率时的上下边界"""
        if stripe_low_inter_bool[2]:
            max_pos = min(query_range[2], stripe_low_inter_res[2][0])
        else:
            max_pos = query_range[2]
        if stripe_high_inter_bool[1]:
            max_t = min(query_range[3], stripe_high_inter_res[1][1])
        else:
            max_t = query_range[3]

        if stripe_high_inter_bool[3]:
            min_pos = max(query_range[0], stripe_high_inter_res[3][0])
        else:
            min_pos = query_range[0]
        if stripe_low_inter_bool[0]:
            min_t = max(query_range[1], stripe_low_inter_res[0][1])
        else:
            min_t = query_range[1]
        return min_pos, min_t, max_pos, max_t

    @staticmethod
    def get_negative_slope_stripe_boundary(query_range, stripe_low_inter_bool, stripe_low_inter_res,
                                           stripe_high_inter_bool, stripe_high_inter_res):
        """获取负斜率时的上下边界,[左右上下]"""
        if stripe_high_inter_bool[3]:
            max_pos = min(query_range[2], stripe_high_inter_res[3][0])
        else:
            max_pos = query_range[2]
        if stripe_high_inter_bool[0]:
            max_t = min(query_range[3], stripe_high_inter_res[0][1])
        else:
            max_t = query_range[3]

        if stripe_low_inter_bool[2]:
            min_pos = max(query_range[0], stripe_low_inter_res[2][0])
        else:
            min_pos = query_range[0]
        if stripe_low_inter_bool[1]:
            min_t = max(query_range[1], stripe_low_inter_res[1][1])
        else:
            min_t = query_range[1]
        return min_pos, min_t, max_pos, max_t

    def is_point_in_pre_id_non_overflow(self, pre_id, point):
        """扩大范围后没有溢出（即没有到达最后一块）则不需要查询溢出块"""
        pre_physical_block = storage.Block.get_physical_block(pre_id, self.data_buffer, p_num=self.p_num,
                                                              patten=self.data_patten)
        for logic_b in pre_physical_block.logic_block_list:
            for x, y in logic_b.data_points:
                if x == point[0] and y == point[1]:
                    return True
        return False

    def get_query_in_overflow_logic_blocks(self, point, start_of_id, en_of_id, global_region_number):
        """用于点查询，后期非溢出块范围是默认值时直接从溢出块获取数据"""
        if const.TOM2:
            error = self.model_error[global_region_number]
        else:
            error = follow_error_thre
        logic_ids = [id for id in range(start_of_id, min(start_of_id + error, en_of_id))]
        physical_ids = self.get_physical_ids_by_logic_ids(logic_ids)
        for of_id in physical_ids:
            of_block = storage.Block.get_physical_block(of_id, self.data_buffer, self.p_num, self.data_patten,
                                                        is_of=True)
            for of_logic_block in of_block.logic_block_list:
                for x, y in of_logic_block.data_points:
                    if x == point[0] and y == point[1]:
                        return True, of_logic_block
        return False, None

    def is_point_in_pre_id_overflow(self, pre_id, point, start_of_id, end_of_id):
        """扩大误差阈值搜索后到达最后一块，此时需要查找溢出块"""
        point_in_cor_block = False
        of_is_default = True
        pre_physical_block = storage.Block.get_physical_block(pre_id, self.data_buffer, p_num=self.p_num, patten=self.data_patten)
        for logic_b in pre_physical_block.logic_block_list:
            for x, y in logic_b.data_points:
                if x == point[0] and y == point[1]:
                    point_in_cor_block = True
                    return True
        if [start_of_id, end_of_id] != const.DEFAULT_OVERFLOW_BLOCKS:
            of_is_default = False
            logic_ids = [id for id in range(start_of_id, end_of_id + 1)]
            search_physical_of_ids = self.get_physical_ids_by_logic_ids(logic_ids)
        if not of_is_default :
            for of_id in search_physical_of_ids:
                of_block = storage.Block.get_physical_block(of_id, self.data_buffer, self.p_num, self.data_patten, is_of=True)
                for of_logic_block in of_block.logic_block_list:
                    for x, y in of_logic_block.data_points:
                        if x == point[0] and y == point[1]:
                            point_in_cor_block = True
                            return True
        return point_in_cor_block

    def point_querys(self, query_list):
        result = []
        query_num = 0
        for query in query_list:
            # print(query_num, query)
            if query_num == 60 and self.p_num == 0:
                pass
            single_result = self.point_query_single(query, query_num)
            result += single_result
            query_num += 1
            self.query_num += 1
        return result, query_num

    def point_query_single(self, query, query_num):
        """
        单个点查询
        1. 通过两个维度的边界点计算partition id
        2. 计算查询点的t轴截距，通过partition的底部截距计算斜条序号
        3. 根据点的pos匹配region的pos，找到对应的模型
        4. 通过模型预测逻辑块号，在误差阈值内扩大搜索，同时用region保存的块范围来约束结果范围
        5. 后期需要加载溢出块
        """
        result = []
        if self.p_num == 1 and query_num == 95:
            pass
        cor_x = bisect.bisect_left(self.bx, query[0]) - 1
        cor_y = bisect.bisect_left(self.by, query[1]) - 1
        partition_id = cor_x * const.N_ROWS + cor_y
        partition_block_id = self.index_buffer.cal_partition_block_id(partition_id)
        partition_block = storage.PartitionBlock.get_partition_block(partition_block_id, self.index_buffer, p_num=self.p_num, patten=self.data_patten)
        # 通过分区索引块获得斜条斜率
        W = partition_block.partition_param_list[partition_id % const.PARTITION_BLOCK_ITEM_NUM][0]
        slope = W[1] / W[0]
        # 根据斜率计算t的截距
        intercept_t = query[1] - slope * query[0]
        # 底部截距
        bottom_intercept = partition_block.partition_param_list[partition_id % const.PARTITION_BLOCK_ITEM_NUM][2]
        # t_interval
        t_interval = partition_block.partition_param_list[partition_id % const.PARTITION_BLOCK_ITEM_NUM][1]
        # 计算斜条序号
        lower_bound = (intercept_t - bottom_intercept) // t_interval - 1
        stripe_id = int(lower_bound) + 1  # 向上取整
        # 根据分区号和斜条序号计算斜条块号
        stripe_block_id = self.index_buffer.cal_stripe_block_id(partition_id, stripe_id, self.cum_stripe_num_list)
        stripe_block = storage.StripeBlock.get_stripe_block(stripe_block_id, self.index_buffer, p_num=self.p_num, patten=self.data_patten)
        # 找到模型的索引块
        # 通过斜条数量列表找到当前的斜条项在当前索引块的第几个（偏移斜条）
        cum_stripes_num = self.cum_stripe_num_list[partition_id - 1] if partition_id > 0 else 0
        # 计算全局的斜条编号（从0开始）
        global_stripes_num = cum_stripes_num + stripe_id
        offset_stripes_num = global_stripes_num % const.STRIPE_BLOCK_ITEM_NUM
        # 起始全局的模型编号
        global_model_num = stripe_block.stripe_param_list[offset_stripes_num][0]
        # 当前斜条的模型数量
        model_count = stripe_block.stripe_param_list[offset_stripes_num][1]

        # 计算模型索引块
        model_block_id = self.index_buffer.cal_region_block_id(global_model_num, start_region_block_id)
        model_block = storage.RegionBlock.get_region_block(model_block_id, self.index_buffer, self.p_num, self.data_patten)
        # 根据全局模型序号计算当前模型在当前索引块中的序号（偏移模型序号）
        offset_mdoel_number = global_model_num % const.REGION_BLOCK_ITEM_NUM
        # 根据模型数量获取实际模型
        models = model_block.region_param_list[offset_mdoel_number: offset_mdoel_number + model_count]

        # 可能会出现单个模型块无法保存全部的斜条模型，需要在下一块中获取剩余的模型
        while len(models) < model_count:
            block_id = model_block.block_id + 1
            model_block = storage.RegionBlock.get_region_block(block_id, self.index_buffer, self.p_num, self.data_patten)
            models.extend(model_block.region_param_list[: (model_count - len(models))])

        # 临时保存匹配的模型全局序号
        cur_region_num = global_model_num
        pre_logic_id = None
        pre_physical_id = None
        tmp_start_id = None
        tmp_end_id = None
        # 计算查询点的一维映射值
        point_mv = np.round(np.dot(np.array(query), np.array(W)), 3)

        # 根据mv匹配模型，然后预测逻辑块号，通过逻辑块和物理块的关系（4对1）计算物理块号
        for start_mv, end_mv, pos, t, logic_id, m, n, p in models:
            start_id, end_id, start_of_id, end_of_id = self.get_region_block_range(cur_region_num)
            if start_mv <= point_mv < end_mv:
                if [start_id, end_id] == const.DEFAULT_REGION_BLOCK_RANGE:
                    assert [start_of_id, end_of_id] != const.DEFAULT_REGION_BLOCK_RANGE
                    if self.get_query_in_overflow_logic_blocks(query, start_of_id, end_of_id, cur_region_num)[0]:
                        result.append(query)
                        return result

                tmp_start_id = start_id
                tmp_end_id = end_id
                pre_logic_id = SlantStripe.predict(input=query, coef_=[[pos, t, logic_id], [m, n, p]])
                if pre_logic_id < tmp_start_id:
                    pre_logic_id = tmp_start_id
                if pre_logic_id > tmp_end_id:
                    pre_logic_id = tmp_end_id
                pre_physical_id = pre_logic_id // const.LOGIC_PHYSICAL_PROPOTION


                # 初期和后期不同处理
                if self.p_num == 0:
                    if const.TOM2:
                        error = self.model_error[cur_region_num]
                    else:
                        error = init_error_thre
                    # 扩大到达溢出块
                    if pre_logic_id + error >= end_id:
                        is_point_in_pre = self.is_point_in_pre_id_overflow(pre_id=pre_physical_id, point=query, start_of_id=start_of_id, end_of_id=end_of_id)
                        if is_point_in_pre:
                            result.append(query)
                            return result
                    # 扩大没到溢出块
                    else:
                        is_point_in_pre = self.is_point_in_pre_id_non_overflow(pre_physical_id, query)
                        if is_point_in_pre:
                            result.append(query)
                            return result
                else:
                    if const.TOM2:
                        error = self.model_error[cur_region_num]
                    else:
                        error = follow_error_thre
                    # 扩大到达溢出块
                    if pre_logic_id + error >= end_id:
                        is_point_in_pre = self.is_point_in_pre_id_overflow(pre_id=pre_physical_id, point=query,
                                                                           start_of_id=start_of_id, end_of_id=end_of_id)
                        if is_point_in_pre:
                            # print(f'period_num = {self.p_num}, query_num = {query_num}, region_number = {cur_region_num}, max_regin_error = {self.model_error[cur_region_num]}')
                            result.append(query)
                            return result
                    # 扩大没到溢出块
                    else:
                        is_point_in_pre = self.is_point_in_pre_id_non_overflow(pre_physical_id, query)
                        if is_point_in_pre:
                            # print(f'period_num = {self.p_num}, query_num = {query_num}, region_number = {cur_region_num}, max_regin_error = {self.model_error[cur_region_num]}')
                            result.append(query)
                            return result
                break
            cur_region_num += 1
        start_block_id = self.get_physical_id_by_start_pre(pre_logic_id, tmp_start_id, cur_region_num)
        end_block_id = self.get_physical_id_by_end_pre(pre_logic_id, tmp_end_id, cur_region_num)
        # print(f'period_num = {self.p_num}, query_num = {query_num}, region_number = {cur_region_num}, max_regin_error = {self.model_error[cur_region_num]}')
        search_physical_block_ids = np.arange(start_block_id, end_block_id + 1)
        search_physical_blocks = []
        for id in search_physical_block_ids:
            if id != pre_physical_id:
                search_physical_block = storage.Block.get_physical_block(id, self.data_buffer, self.p_num, self.data_patten)
                search_physical_blocks.append(search_physical_block)
        for physical_block in search_physical_blocks:
            # 在逻辑块中查找数据，逻辑块封装到物理块中 ，物理块用来计算IO
            for logic_block in physical_block.logic_block_list:
                for x, y in logic_block.data_points:
                    if x == query[0] and y == query[1]:
                        result.append((x, y))
                        return result
        return None

    def range_querys(self, ranges):
        result = []
        query_num = 0
        for query in ranges:
            if self.p_num == 1 and query_num == 78:
                pass
            result += self.range_query_single(query, query_num)
            query_num += 1
            self.query_num += 1
        return result, query_num

    def get_range_query_pids(self, query_range, query_num):
        """获取单个范围查询的所有partition编号"""
        # 和查询相交的所有分区号
        result_p_ids = set()

        l_x = bisect.bisect_left(self.bx, query_range[0]) - 1
        if l_x < 0:
            l_x = 0
        r_x = bisect.bisect_left(self.bx, query_range[2]) - 1
        if r_x < 0:
            r_x = 0
        l_y = bisect.bisect_left(self.by, query_range[1]) - 1
        if l_y < 0:
            l_y = 0
        r_y = bisect.bisect_left(self.by, query_range[3]) - 1
        if r_y < 0:
            r_y = 0
        # 计算左下角和右上角的分区号
        lb_p_id = l_x * const.N_ROWS + l_y
        lt_p_id = l_x * const.N_ROWS + r_y
        rb_p_id = r_x * const.N_ROWS + l_y
        rt_p_id = r_x * const.N_ROWS + r_y
        # 添加两边的分区
        for id in range(lb_p_id, lt_p_id + 1):
            result_p_ids.add(id)
        for id in range(rb_p_id, rt_p_id + 1):
            result_p_ids.add(id)
        # pos轴的跨度
        x_interval = r_x - l_x
        # 添加中间的分区
        if rt_p_id != rb_p_id or x_interval > 1:
            for i in range(1, x_interval + 1):
                for j in range(0, rt_p_id - rb_p_id + 1):
                    result_p_ids.add(lb_p_id + i * const.N_ROWS + j)
        return result_p_ids

    def get_partition_info_by_id(self, p_id, query_num):
        """获取partition的信息，包括斜率，底部截距，斜条宽度"""
        # 获得分区索引块
        partition_block_id = self.index_buffer.cal_partition_block_id(p_id)
        partition_block = storage.PartitionBlock.get_partition_block(partition_block_id, self.index_buffer, self.p_num, self.data_patten)
        # 通过分区索引块获得斜条斜率
        W = partition_block.partition_param_list[p_id % const.PARTITION_BLOCK_ITEM_NUM][0]
        slope = W[1]  / W[0]
        # 底部截距
        bottom_intercept = partition_block.partition_param_list[p_id % const.PARTITION_BLOCK_ITEM_NUM][2]
        # 斜条宽度
        t_interval = partition_block.partition_param_list[p_id % const.PARTITION_BLOCK_ITEM_NUM][1]
        return W, slope, bottom_intercept, t_interval


    # def get_stripe_low_upp_mv(self):
    #     """计算斜条的上下界一维映射值"""
    #
    #
    # def get_target_stripe_id(self):

    def get_stripe_ids_for_single_partition_query(self, p_id, query_range, slope, bottom_intercept, t_interval):
        """获取单个cell查询的所有斜条编号"""
        if slope > 0:
            # 右下角
            rb_point = [query_range[2], query_range[1]]
            rb_intercept = rb_point[1] - slope * rb_point[0]
            # 计算右下角斜条序号
            lower_bound = (rb_intercept - bottom_intercept) // t_interval - 1
            rb_stripe_id = int(lower_bound) + 1
            # 左上角
            lt_point = [query_range[0], query_range[3]]
            lt_intercept = lt_point[1] - slope * lt_point[0]
            # 注：需要额外处理矩形角落的情况
            n = 0
            while np.round(bottom_intercept + (n + 1) * t_interval, 3) <= np.round(lt_intercept, 3):
                n += 1
            lt_stripe_id = n
            # 需要额外判断，如果查询的左上角正好是分区的左上角则斜条序号会比实际的大1，需要减1
            partiton_rt_point = [self.partition_range[p_id][0], self.partition_range[p_id][3]]
            if lt_point == partiton_rt_point:
                lt_stripe_id -= 1
            return rb_stripe_id, lt_stripe_id
        else:
            # 左下角
            lb_point = [query_range[0], query_range[1]]
            lb_intercept = lb_point[1] - slope * lb_point[0]
            # 计算左下角斜条序号
            lower_bound = (lb_intercept - bottom_intercept) // t_interval - 1
            lb_stripe_id = int(lower_bound) + 1
            # 右上角
            rt_point = [query_range[2], query_range[3]]
            rt_intercept = rt_point[1] - slope * rt_point[0]

            n = 0
            while np.round(bottom_intercept + (n + 1) * t_interval, 3) <= np.round(rt_intercept, 3):
                n += 1
            rt_stripe_id = n
            # 需要额外判断，如果查询的右上角正好是分区的右上角则斜条数量会比实际的大1，需要减1
            partiton_rt_point = [self.partition_range[p_id][2], self.partition_range[p_id][3]]
            if rt_point == partiton_rt_point:
                rt_stripe_id -= 1
            return lb_stripe_id, rt_stripe_id


    def get_stripe_regions(self, p_id, stripe_id):
        """获取单个斜条的所有region"""
        stripe_block_id = self.index_buffer.cal_stripe_block_id(p_id, stripe_id, self.cum_stripe_num_list)
        stripe_block = storage.StripeBlock.get_stripe_block(stripe_block_id, self.index_buffer, self.p_num,
                                                            self.data_patten)
        # 通过斜条数量列表找到当前的斜条项在当前索引块的第几个（偏移斜条序号）
        cum_stripes_num = self.cum_stripe_num_list[p_id - 1] if p_id > 0 else 0
        # 计算全局的斜条编号（从0开始）
        global_stripes_num = cum_stripes_num + stripe_id
        offset_stripes_num = global_stripes_num % const.STRIPE_BLOCK_ITEM_NUM
        # 起始全局的模型编号
        global_model_num = stripe_block.stripe_param_list[offset_stripes_num][0]
        # 当前斜条的模型数量
        model_count = stripe_block.stripe_param_list[offset_stripes_num][1]
        # 计算模型索引块
        model_block_id = self.index_buffer.cal_region_block_id(global_model_num, start_region_block_id)
        model_block = storage.RegionBlock.get_region_block(model_block_id, self.index_buffer, self.p_num,
                                                           self.data_patten)
        # 根据全局模型序号计算当前模型在当前索引块中的序号（偏移模型序号）
        offset_mdoel_number = global_model_num % const.REGION_BLOCK_ITEM_NUM
        # 根据模型数量获取实际模型
        models = model_block.region_param_list[offset_mdoel_number: offset_mdoel_number + model_count]
        # 可能会出现单个模型块无法保存全部的斜条模型，需要在后面的块中获取剩余的模型
        while len(models) < model_count:
            block_id = model_block.block_id + 1
            model_block = storage.RegionBlock.get_region_block(block_id, self.index_buffer, self.p_num,
                                                               self.data_patten)
            models.extend(model_block.region_param_list[: (model_count - len(models))])
        return global_model_num, models


    def get_single_partition_query_range(self, query_range, pid):
        """获取单个cell查询的矩形范围"""
        # 计算查询框和分区的交点
        intersection_range = Rectangle.calculate_overlap(self.partition_range[pid], query_range)
        assert intersection_range != None, print(pid, self.partition_range[pid], query_range)
        return intersection_range

    def range_query_single(self, query_range, query_num):
        result = []
        result_ids = set()
        result_of_ids = set()
        result_p_ids = self.get_range_query_pids(query_range, query_num)
        for pid in result_p_ids:
            intersection_range = self.get_single_partition_query_range(query_range, pid)
            res, result_physical_block_ids, result_physical_of_block_ids = self.get_single_partition_query_result(pid, intersection_range, query_num)
            result += res
            result_ids = result_ids.union(result_physical_block_ids)
            result_of_ids = result_of_ids.union(result_physical_of_block_ids)

        result_id_count = len(result_ids)
        result_of_id_count = len(result_of_ids)
        self.fp_result.write(f'第{query_num}个查询: \n非溢出物理块: {result_ids}\n溢出物理块: {result_of_ids}\n'
                                 f'非溢出物理块数量: {result_id_count}  溢出物理块数量: {result_of_id_count}  数据量: {len(result)}\n\n')
        return result

    def get_stripe_low_upp_mv(self, query_range, W, stripe_id, bottom_intercept, t_interval):
        """获取斜条上下界一维映射值"""
        slope = W[1] / W[0]
        # 斜条上下斜线截距
        low_intercept = bottom_intercept + stripe_id * t_interval
        high_intercept = low_intercept + t_interval
        # 和矩形框相交返回形式[左右上下]
        stripe_low_inter_bool, stripe_low_inter_res = Partition.is_line_rec_intersection(slope=slope,
                                                                                         intercept=low_intercept,
                                                                                         rect=query_range)
        stripe_high_inter_bool, stripe_high_inter_res = Partition.is_line_rec_intersection(slope, high_intercept,
                                                                                           query_range)
        # 根据相交情况获得上下边界
        if slope > 0:
            min_pos, min_t, max_pos, max_t = self.get_positive_slope_stripe_boundary(query_range,
                                                                                 stripe_low_inter_bool,
                                                                                 stripe_low_inter_res,
                                                                                 stripe_high_inter_bool,
                                                                                 stripe_high_inter_res)
        else:
            min_pos, min_t, max_pos, max_t = self.get_negative_slope_stripe_boundary(query_range,
                                                                                     stripe_low_inter_bool,
                                                                                     stripe_low_inter_res,
                                                                                     stripe_high_inter_bool,
                                                                                     stripe_high_inter_res)
        # 精度问题需要格式化
        min_pos = np.round(min_pos, 3)
        min_t = np.round(min_t, 3)
        max_pos = np.round(max_pos, 3)
        max_t = np.round(max_t, 3)

        if slope > 0:
            # 计算每个斜条的上下界一维映射值
            if W[1] > 0 and W[0] > 0:
                low_bound_mv = np.round(np.dot(np.array([min_pos, min_t]), W), 3)
                upp_bound_mv = np.round(np.dot(np.array([max_pos, max_t]), W), 3)
            else:
                low_bound_mv = np.round(np.dot(np.array([max_pos, max_t]), W), 3)
                upp_bound_mv = np.round(np.dot(np.array([min_pos, min_t]), W), 3)
        else:
            # 计算每个斜条的上下界一维映射值
            if W[0] > 0 and W[1] < 0:
                low_bound_mv = np.round(np.dot(np.array([min_pos, max_t]), W), 3)
                upp_bound_mv = np.round(np.dot(np.array([max_pos, min_t]), W), 3)
            else:
                low_bound_mv = np.round(np.dot(np.array([max_pos, min_t]), W), 3)
                upp_bound_mv = np.round(np.dot(np.array([min_pos, max_t]), W), 3)
        return min_pos, min_t, max_pos, max_t, low_bound_mv, upp_bound_mv

    def get_single_stripe_query_physical_ids(self, global_model_num, models, low_bound_mv, upp_bound_mv, min_pos, min_t, max_pos, max_t, query_num):
        """获取单个斜条的物理块范围"""
        result_physical_block_ids = set()  # 两端预测范围可能会重叠，需要用集合保存
        result_physical_of_block_ids = set()
        start_block_id = None
        end_block_id = None
        pre_end_logic_id = None
        pre_start_logic_id = None
        start_id = None
        end_id = None
        upp_start_id = None
        upp_end_id = None
        low_start_id = None
        low_end_id = None
        """
        1   先定位模型，记录上下界对应的模型的全局序号和预测的逻辑块号
        2   判断上下界是否同一模型，如果是则：
            1）  取任意一个模型，获得其非溢出块范围和溢出块范围
            2）  如果非溢出块范围不为默认值，用该范围约束预测，通过误差阈值获得物理块号，加入结果物理块集合
                 如果非溢出块范围是默认值，判断溢出块范围，如果溢出块范围为空，则跳过该斜条
                 如果溢出块范围不是默认值，则获得溢出逻辑块，得到物理块，加入物理块结果集合
        3   如果不是则：
            1）  判断下界的非溢出块范围，如果是默认值则不用约束预测的逻辑块号，直接用误差阈值扩大搜索，
                如果不是则用该范围约束预测，通过误差阈值扩大搜索，获得扩大后的逻辑块范围，然后得到
                物理块范围，加入结果物理块集合，然后判断溢出块范围，获得溢出的物理块，加入结果物理块集合
            2）  判断上界同理
        """
        low_bound_global_region_number = global_model_num
        upp_bound_global_region_number = global_model_num
        for start_mv, end_mv, pos, t, logic_id, m, n, p in models:
            # 预测下界范围
            if start_mv <= low_bound_mv <= end_mv:
                pre_start_logic_id = SlantStripe.predict((min_pos, min_t), [[pos, t, logic_id], [m, n, p]])
                break
            low_bound_global_region_number += 1

        # 预测上界范围
        for start_mv, end_mv, pos, t, logic_id, m, n, p in models:
            if start_mv <= upp_bound_mv <= end_mv:
                pre_end_logic_id = SlantStripe.predict((max_pos, max_t), [[pos, t, logic_id], [m, n, p]])
                break
            upp_bound_global_region_number += 1
        assert pre_start_logic_id != None
        assert pre_end_logic_id != None
        is_same = False
        # 上下界匹配同一个模型
        if upp_bound_global_region_number == low_bound_global_region_number:
            is_same = True
            assert pre_start_logic_id <= pre_end_logic_id
            start_id, end_id, start_of_id, end_of_id = self.get_region_block_range(upp_bound_global_region_number)
            overflow_block_range_is_default = True
            # 溢出块不是默认值,获得溢出块
            if [start_of_id, end_of_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                overflow_block_range_is_default = False
                logic_of_ids = [l_id for l_id in range(start_of_id, end_of_id + 1)]
                physical_of_ids = self.get_physical_ids_by_logic_ids(logic_of_ids)
                result_physical_of_block_ids = result_physical_of_block_ids.union(physical_of_ids)
            # 两个region的非溢出块不是默认值
            if [start_id, end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                if pre_start_logic_id < start_id:
                    pre_start_logic_id = start_id
                if pre_start_logic_id > end_id:
                    pre_start_logic_id = end_id
                if pre_end_logic_id > end_id:
                    pre_end_logic_id = end_id
                if pre_end_logic_id < start_id:
                    pre_end_logic_id = start_id

            # region的非溢出块是默认值，判断溢出块范围
            else:
                # 溢出块范围也是默认值则跳过该斜条，表示没有数据
                if [start_id, end_id] == const.DEFAULT_OVERFLOW_BLOCKS:
                    return result_physical_block_ids, result_physical_of_block_ids
            start_block_id = self.get_physical_id_by_start_pre(pre_start_logic_id, start_id,
                                                               low_bound_global_region_number)
            end_block_id = self.get_physical_id_by_end_pre(pre_end_logic_id, end_id, upp_bound_global_region_number)
        # 上下界匹配不同模型
        else:
            upp_start_id, upp_end_id, upp_start_of_id, upp_end_of_id = self.get_region_block_range(
                upp_bound_global_region_number)
            low_start_id, low_end_id, low_start_of_id, low_end_of_id = self.get_region_block_range(
                low_bound_global_region_number)
            # 出现这种情况：上下界不在同一个region，甚至相差很大，这时中间region的溢出块会被忽略，需要补上
            # 如果两个界的region有一个溢出块和非溢出块全是默认值，则需要找到中间第一个不为默认值的块，用一个列表保存中间不为默认值的region的块范围
            # non_default_region_in_middle_of_block = []
            non_default_region_in_middle_non_of_block = []
            for region_num in range(low_bound_global_region_number + 1, upp_bound_global_region_number):
                s_id, e_id, s_of_id, e_of_id = self.get_region_block_range(region_num)
                if [s_of_id, e_of_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                    # non_default_region_in_middle_of_block.append([s_of_id, e_of_id])
                    logic_of_ids = [l_id for l_id in range(s_of_id, e_of_id + 1)]
                    physical_of_ids = self.get_physical_ids_by_logic_ids(logic_of_ids)
                    result_physical_of_block_ids = result_physical_of_block_ids.union(physical_of_ids)
                if [s_id, e_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                    non_default_region_in_middle_non_of_block.append([s_id, e_id])
                    logic_ids = [l_id for l_id in range(s_id, e_id + 1)]
                    physical_ids = self.get_physical_ids_by_logic_ids(logic_ids)
                    result_physical_block_ids = result_physical_block_ids.union(physical_ids)
            # 获得两个region对应的溢出块
            if [upp_start_of_id, upp_end_of_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                logic_of_ids = [l_id for l_id in range(upp_start_of_id, upp_end_of_id + 1)]
                physical_of_ids = self.get_physical_ids_by_logic_ids(logic_of_ids)
                result_physical_of_block_ids = result_physical_of_block_ids.union(physical_of_ids)
            if [low_start_of_id, low_end_of_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                logic_of_ids = [l_id for l_id in range(low_start_of_id, low_end_of_id + 1)]
                physical_of_ids = self.get_physical_ids_by_logic_ids(logic_of_ids)
                result_physical_of_block_ids = result_physical_of_block_ids.union(physical_of_ids)
            # 如果两个region的非溢出块都是默认值，则直接跳过这一轮斜条
            if [upp_start_id, upp_end_id] == const.DEFAULT_REGION_BLOCK_RANGE and [low_start_id,
                                                                                   low_end_id] == const.DEFAULT_REGION_BLOCK_RANGE:
                return result_physical_block_ids, result_physical_of_block_ids

            if [upp_start_id, upp_end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                if pre_end_logic_id > upp_end_id:
                    pre_end_logic_id = upp_end_id
                if pre_end_logic_id < upp_start_id:
                    pre_end_logic_id = upp_start_id
                end_block_id = self.get_physical_id_by_end_pre(pre_end_logic_id, upp_end_id,
                                                               upp_bound_global_region_number)
            # 上界region的非溢出块是默认值，则下界必不为默认值，这时需要找到中间的最后一个region，其非溢出块范围不为默认值
            else:
                if [low_start_id, low_end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                    if pre_end_logic_id < low_end_id:
                        pre_end_logic_id = low_end_id
                    if len(non_default_region_in_middle_non_of_block) > 0:
                        if pre_end_logic_id > non_default_region_in_middle_non_of_block[-1][-1]:
                            pre_end_logic_id = non_default_region_in_middle_non_of_block[-1][-1]

                end_block_id = pre_end_logic_id // const.LOGIC_PHYSICAL_PROPOTION
            if [low_start_id, low_end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                if pre_start_logic_id < low_start_id:
                    pre_start_logic_id = low_start_id
                if pre_start_logic_id > low_end_id:
                    pre_start_logic_id = low_end_id
                start_block_id = self.get_physical_id_by_start_pre(pre_start_logic_id, low_start_id,
                                                                   low_bound_global_region_number)
            else:
                # 同理，如果下界的region非溢出块是默认值，需要找到中间的非溢出块不为默认值的第一个region
                if [upp_start_id, upp_end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                    if pre_start_logic_id > upp_start_id:
                        pre_start_logic_id = upp_start_id
                    if len(non_default_region_in_middle_non_of_block) > 0:
                        if pre_start_logic_id < non_default_region_in_middle_non_of_block[0][0]:
                            pre_start_logic_id = non_default_region_in_middle_non_of_block[0][0]

                start_block_id = pre_start_logic_id // const.LOGIC_PHYSICAL_PROPOTION
                if start_block_id < 0:
                    start_block_id = end_block_id
        assert start_block_id != None, print(f'{start_block_id}, {end_block_id}, {is_same}, '
                                             f'[low_start_id, low_end_id]={low_start_id}, {low_end_id}, '
                                             f'[upp_start_id, upp_end_id]={upp_start_id}, {upp_end_id},'
                                             f'[start_id, end_id]={start_id}, {end_id}')
        assert end_block_id != None, print(f'{start_block_id}, {end_block_id}, {is_same}, '
                                           f'[low_start_id, low_end_id]={low_start_id}, {low_end_id}, '
                                           f'[upp_start_id, upp_end_id]={upp_start_id}, {upp_end_id},'
                                           f'[start_id, end_id]={start_id}, {end_id}')
        if start_block_id > end_block_id:
            assert [upp_start_id, upp_end_id] == const.DEFAULT_REGION_BLOCK_RANGE or \
                   [low_start_id, low_end_id] == const.DEFAULT_REGION_BLOCK_RANGE, \
                print(
                    f'{start_block_id}, {end_block_id}, {is_same}, '
                    f'[low_start_id, low_end_id]={low_start_id}, {low_end_id}, '
                    f'[upp_start_id, upp_end_id]={upp_start_id}, {upp_end_id},'
                    f'[start_id, end_id]={start_id}, {end_id}')

            if [upp_start_id, upp_end_id] == const.DEFAULT_REGION_BLOCK_RANGE:
                end_block_id = start_block_id
            if [low_start_id, low_end_id] == const.DEFAULT_REGION_BLOCK_RANGE:
                start_block_id = end_block_id
            assert start_block_id <= end_block_id, print(
                f'{start_block_id}, {end_block_id}, {is_same}, '
                f'[low_start_id, low_end_id]={low_start_id}, {low_end_id}, '
                f'[upp_start_id, upp_end_id]={upp_start_id}, {upp_end_id},'
                f'[start_id, end_id]={start_id}, {end_id}')
        for id in range(start_block_id, end_block_id + 1):
            result_physical_block_ids.add(id)
        return result_physical_block_ids, result_physical_of_block_ids


    def get_single_partition_query_result(self, p_id, query_range, query_num):
        """
        获取每个分区的查询结果
        1   斜率大于0：
        每个斜条的上界pos取查询框上线和斜条下线的交点的横坐标比查询框X2的较小者，不相交则直接用X2，t取斜条上线和查询框右线交点的纵坐标比y2的较小者，不相交则直接用y2。
        下界pos取斜条上线和查询下线的交点横坐标比X1的较大者，不相交则直接用X1， t取斜条下线和查询框左线的交点纵坐标比y1的较大者，不相交则直接用y1。
        2   斜率小于0：
        上边界t取斜条上线和查询左线的交点纵坐标比y2的较小者，不相交直接用y2。Pos取斜条下上线和查询下线交点的横坐标比X2的较小者不相交直接用X2。
        下边界t取斜条下线和查询右线的交点y比y1的较大者，不相交直接用y1。Pos取斜条上下线和查询上线的交点的x比X1的较大者，不相交直接用X1。
        """
        result = []
        search_physical_blocks = []
        result_physical_block_ids = set()
        result_physical_of_block_ids = set()
        # 获取cell的斜率，底部截距，斜条宽度
        W, slope, bottom_intercept, t_interval = self.get_partition_info_by_id(p_id, query_num)

        """
        分为两种情况：斜率正和斜率负
        正斜率通过左上和右下计算斜条，负斜率通过左下和右上计算斜条
        """
        if slope > 0:
            rb_stripe_id, lt_stripe_id = self.get_stripe_ids_for_single_partition_query(p_id, query_range, slope, bottom_intercept, t_interval)
            # 根据斜率和斜条斜线截距获取和查询的交点
            for stripe_id in range(rb_stripe_id, lt_stripe_id + 1):
                # 获取斜条region的起始编号和所有的region
                global_model_num, models = self.get_stripe_regions(p_id, stripe_id)
                min_pos, min_t, max_pos, max_t, low_bound_mv, upp_bound_mv = self.get_stripe_low_upp_mv(query_range, W, stripe_id, bottom_intercept, t_interval)
                # result_physical_block_ids, result_physical_of_block_ids = self.get_single_stripe_query_physical_ids(global_model_num, models, low_bound_mv, upp_bound_mv, min_pos, min_t, max_pos, max_t)
                start_block_id = None
                end_block_id = None
                pre_end_logic_id = None
                pre_start_logic_id = None
                start_id = None
                end_id = None
                upp_start_id = None
                upp_end_id = None
                low_start_id = None
                low_end_id = None
                """
                1   先定位模型，记录上下界对应的模型的全局序号和预测的逻辑块号
                2   判断上下界是否同一模型，如果是则：
                    1）  取任意一个模型，获得其非溢出块范围和溢出块范围
                    2）  如果非溢出块范围不为默认值，用该范围约束预测，通过误差阈值获得物理块号，加入结果物理块集合
                         如果非溢出块范围是默认值，判断溢出块范围，如果溢出块范围为空，则跳过该斜条
                         如果溢出块范围不是默认值，则获得溢出逻辑块，得到物理块，加入物理块结果集合
                3   如果不是则：
                    1）  判断下界的非溢出块范围，如果是默认值则不用约束预测的逻辑块号，直接用误差阈值扩大搜索，
                        如果不是则用该范围约束预测，通过误差阈值扩大搜索，获得扩大后的逻辑块范围，然后得到
                        物理块范围，加入结果物理块集合，然后判断溢出块范围，获得溢出的物理块，加入结果物理块集合
                    2）  判断上界同理
                """
                low_bound_global_region_number = global_model_num
                upp_bound_global_region_number = global_model_num
                for start_mv, end_mv, pos, t, logic_id, m, n, p in models:
                    # start_id, end_id, start_of_id, end_of_id = self.get_region_block_range(global_model_num)
                    # 预测下界范围
                    if start_mv <= low_bound_mv <= end_mv:
                        pre_start_logic_id = SlantStripe.predict((min_pos, min_t), [[pos, t, logic_id], [m, n, p]])
                        break
                    low_bound_global_region_number += 1

                # 预测上界范围
                for start_mv, end_mv, pos, t, logic_id, m, n, p in models:
                    if start_mv <= upp_bound_mv <= end_mv:
                        pre_end_logic_id = SlantStripe.predict((max_pos, max_t), [[pos, t, logic_id], [m, n, p]])
                        break
                    upp_bound_global_region_number += 1
                assert pre_start_logic_id != None
                assert pre_end_logic_id != None
                is_same = False
                # 上下界匹配同一个模型
                if upp_bound_global_region_number == low_bound_global_region_number:
                    is_same = True
                    assert pre_start_logic_id <= pre_end_logic_id
                    start_id, end_id, start_of_id, end_of_id = self.get_region_block_range(
                        upp_bound_global_region_number)
                    overflow_block_range_is_default = True
                    # 溢出块不是默认值,获得溢出块
                    if [start_of_id, end_of_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                        overflow_block_range_is_default = False
                        logic_of_ids = [l_id for l_id in range(start_of_id, end_of_id + 1)]
                        physical_of_ids = self.get_physical_ids_by_logic_ids(logic_of_ids)
                        result_physical_of_block_ids = result_physical_of_block_ids.union(physical_of_ids)
                    # 两个region的非溢出块不是默认值
                    if [start_id, end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                        if pre_start_logic_id < start_id:
                            pre_start_logic_id = start_id
                        if pre_start_logic_id > end_id:
                            pre_start_logic_id = end_id
                        if pre_end_logic_id > end_id:
                            pre_end_logic_id = end_id
                        if pre_end_logic_id < start_id:
                            pre_end_logic_id = start_id

                    # region的非溢出块是默认值，判断溢出块范围
                    else:
                        # 溢出块范围也是默认值则跳过该斜条，表示没有数据
                        if [start_id, end_id] == const.DEFAULT_OVERFLOW_BLOCKS:
                            continue
                    start_block_id = self.get_physical_id_by_start_pre(pre_start_logic_id, start_id,
                                                                       low_bound_global_region_number)
                    end_block_id = self.get_physical_id_by_end_pre(pre_end_logic_id, end_id,
                                                                   upp_bound_global_region_number)
                # 上下界匹配不同模型
                else:
                    upp_start_id, upp_end_id, upp_start_of_id, upp_end_of_id = self.get_region_block_range(
                        upp_bound_global_region_number)
                    low_start_id, low_end_id, low_start_of_id, low_end_of_id = self.get_region_block_range(
                        low_bound_global_region_number)
                    # 出现这种情况：上下界不在同一个region，甚至相差很大，这时中间region的溢出块会被忽略，需要补上
                    # 如果两个界的region有一个溢出块和非溢出块全是默认值，则需要找到中间第一个不为默认值的块，用一个列表保存中间不为默认值的region的块范围
                    # non_default_region_in_middle_of_block = []
                    non_default_region_in_middle_non_of_block = []
                    for region_num in range(low_bound_global_region_number + 1, upp_bound_global_region_number):
                        s_id, e_id, s_of_id, e_of_id = self.get_region_block_range(region_num)
                        if [s_of_id, e_of_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                            # non_default_region_in_middle_of_block.append([s_of_id, e_of_id])
                            logic_of_ids = [l_id for l_id in range(s_of_id, e_of_id + 1)]
                            physical_of_ids = self.get_physical_ids_by_logic_ids(logic_of_ids)
                            result_physical_of_block_ids = result_physical_of_block_ids.union(physical_of_ids)
                        if [s_id, e_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                            non_default_region_in_middle_non_of_block.append([s_id, e_id])
                            logic_ids = [l_id for l_id in range(s_id, e_id + 1)]
                            physical_ids = self.get_physical_ids_by_logic_ids(logic_ids)
                            result_physical_block_ids = result_physical_block_ids.union(physical_ids)
                    # 获得两个region对应的溢出块
                    if [upp_start_of_id, upp_end_of_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                        logic_of_ids = [l_id for l_id in range(upp_start_of_id, upp_end_of_id + 1)]
                        physical_of_ids = self.get_physical_ids_by_logic_ids(logic_of_ids)
                        result_physical_of_block_ids = result_physical_of_block_ids.union(physical_of_ids)
                    if [low_start_of_id, low_end_of_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                        logic_of_ids = [l_id for l_id in range(low_start_of_id, low_end_of_id + 1)]
                        physical_of_ids = self.get_physical_ids_by_logic_ids(logic_of_ids)
                        result_physical_of_block_ids = result_physical_of_block_ids.union(physical_of_ids)
                    # 如果两个region的非溢出块都是默认值，则直接跳过这一轮斜条
                    if [upp_start_id, upp_end_id] == const.DEFAULT_REGION_BLOCK_RANGE and [low_start_id,
                                                                                           low_end_id] == const.DEFAULT_REGION_BLOCK_RANGE:
                        continue

                    if [upp_start_id, upp_end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                        if pre_end_logic_id > upp_end_id:
                            pre_end_logic_id = upp_end_id
                        if pre_end_logic_id < upp_start_id:
                            pre_end_logic_id = upp_start_id
                        end_block_id = self.get_physical_id_by_end_pre(pre_end_logic_id, upp_end_id,
                                                                       upp_bound_global_region_number)
                    # 上界region的非溢出块是默认值，则下界必不为默认值，这时需要找到中间的最后一个region，其非溢出块范围不为默认值
                    else:
                        if [low_start_id, low_end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                            if pre_end_logic_id < low_end_id:
                                pre_end_logic_id = low_end_id
                            if len(non_default_region_in_middle_non_of_block) > 0:
                                if pre_end_logic_id > non_default_region_in_middle_non_of_block[-1][-1]:
                                    pre_end_logic_id = non_default_region_in_middle_non_of_block[-1][-1]

                        end_block_id = pre_end_logic_id // const.LOGIC_PHYSICAL_PROPOTION
                    if [low_start_id, low_end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                        if pre_start_logic_id < low_start_id:
                            pre_start_logic_id = low_start_id
                        if pre_start_logic_id > low_end_id:
                            pre_start_logic_id = low_end_id
                        start_block_id = self.get_physical_id_by_start_pre(pre_start_logic_id, low_start_id,
                                                                           low_bound_global_region_number)
                    else:
                        # 同理，如果下界的region非溢出块是默认值，需要找到中间的非溢出块不为默认值的第一个region
                        if [upp_start_id, upp_end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                            if pre_start_logic_id > upp_start_id:
                                pre_start_logic_id = upp_start_id
                            if len(non_default_region_in_middle_non_of_block) > 0:
                                if pre_start_logic_id < non_default_region_in_middle_non_of_block[0][0]:
                                    pre_start_logic_id = non_default_region_in_middle_non_of_block[0][0]

                        start_block_id = pre_start_logic_id // const.LOGIC_PHYSICAL_PROPOTION
                        if start_block_id < 0:
                            start_block_id = end_block_id
                assert start_block_id != None, print(f'{start_block_id}, {end_block_id}, {is_same}, '
                                                     f'[low_start_id, low_end_id]={low_start_id}, {low_end_id}, '
                                                     f'[upp_start_id, upp_end_id]={upp_start_id}, {upp_end_id},'
                                                     f'[start_id, end_id]={start_id}, {end_id}')
                assert end_block_id != None, print(f'{start_block_id}, {end_block_id}, {is_same}, '
                                                   f'[low_start_id, low_end_id]={low_start_id}, {low_end_id}, '
                                                   f'[upp_start_id, upp_end_id]={upp_start_id}, {upp_end_id},'
                                                   f'[start_id, end_id]={start_id}, {end_id}')
                if start_block_id > end_block_id:
                    assert [upp_start_id, upp_end_id] == const.DEFAULT_REGION_BLOCK_RANGE or \
                           [low_start_id, low_end_id] == const.DEFAULT_REGION_BLOCK_RANGE, \
                        print(
                            f'{start_block_id}, {end_block_id}, {is_same}, '
                            f'[low_start_id, low_end_id]={low_start_id}, {low_end_id}, '
                            f'[upp_start_id, upp_end_id]={upp_start_id}, {upp_end_id},'
                            f'[start_id, end_id]={start_id}, {end_id}')

                    if [upp_start_id, upp_end_id] == const.DEFAULT_REGION_BLOCK_RANGE:
                        end_block_id = start_block_id
                    if [low_start_id, low_end_id] == const.DEFAULT_REGION_BLOCK_RANGE:
                        start_block_id = end_block_id
                    assert start_block_id <= end_block_id, print(
                        f'{start_block_id}, {end_block_id}, {is_same}, '
                        f'[low_start_id, low_end_id]={low_start_id}, {low_end_id}, '
                        f'[upp_start_id, upp_end_id]={upp_start_id}, {upp_end_id},'
                        f'[start_id, end_id]={start_id}, {end_id}')
                for id in range(start_block_id, end_block_id + 1):
                    result_physical_block_ids.add(id)

            # 获得非溢出物理块
            for id in result_physical_block_ids:
                search_physical_block = storage.Block.get_physical_block(id, self.data_buffer, self.p_num, self.data_patten)
                search_physical_blocks.append(search_physical_block)
            # 获得溢出物理块
            for id in result_physical_of_block_ids:
                search_physical_block = storage.Block.get_physical_block(id, self.data_buffer, self.p_num, self.data_patten, is_of=True)
                search_physical_blocks.append(search_physical_block)
            for physical_block in search_physical_blocks:
                # 在逻辑块中查找数据，逻辑块封装到物理块中 ，物理块用来计算IO
                for logic_block in physical_block.logic_block_list:
                    for x, y in logic_block.data_points:
                        if Rectangle(query_range[0], query_range[1], query_range[2], query_range[3]).is_contained(Point(x, y)):
                            result.append((x, y))
            return result, result_physical_block_ids, result_physical_of_block_ids
        # 处理负斜率
        else:
            lb_stripe_id, rt_stripe_id = self.get_stripe_ids_for_single_partition_query(p_id, query_range,slope, bottom_intercept, t_interval)
            # 根据斜率和斜条斜线截距获取和查询的交点
            for stripe_id in range(lb_stripe_id, rt_stripe_id + 1):
                global_model_num, models = self.get_stripe_regions(p_id, stripe_id)
                min_pos, min_t, max_pos, max_t, low_bound_mv, upp_bound_mv = self.get_stripe_low_upp_mv(query_range, W, stripe_id, bottom_intercept, t_interval)
                # result_physical_block_ids, result_physical_of_block_ids = self.get_single_stripe_query_physical_ids(global_model_num, models, low_bound_mv, upp_bound_mv, min_pos, min_t, max_pos, max_t)
                start_block_id = None
                end_block_id = None
                pre_end_logic_id = None
                pre_start_logic_id = None
                low_bound_global_region_number = global_model_num
                upp_bound_global_region_number = global_model_num
                for start_mv, end_mv, pos, t, logic_id, m, n, p in models:
                    # 预测下界
                    if start_mv <= low_bound_mv <= end_mv:
                        pre_start_logic_id = SlantStripe.predict((min_pos, min_t), [[pos, t, logic_id], [m, n, p]])
                        break
                    low_bound_global_region_number += 1

                # 预测上界
                for start_mv, end_mv, pos, t, logic_id, m, n, p in models:
                    if start_mv <= upp_bound_mv <= end_mv:
                        pre_end_logic_id = SlantStripe.predict((max_pos, max_t), [[pos, t, logic_id], [m, n, p]])
                        break
                    upp_bound_global_region_number += 1
                assert pre_start_logic_id != None
                assert pre_end_logic_id != None
                is_same = False
                # 上下界匹配同一个模型
                if upp_bound_global_region_number == low_bound_global_region_number:
                    is_same = True
                    assert pre_start_logic_id <= pre_end_logic_id
                    start_id, end_id, start_of_id, end_of_id = self.get_region_block_range(
                        upp_bound_global_region_number)
                    overflow_block_range_is_default = True
                    # 溢出块不是默认值获得溢出块
                    if [start_of_id, end_of_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                        overflow_block_range_is_default = False
                        logic_of_ids = [l_id for l_id in range(start_of_id, end_of_id + 1)]
                        physical_of_ids = self.get_physical_ids_by_logic_ids(logic_of_ids)
                        result_physical_of_block_ids = result_physical_of_block_ids.union(physical_of_ids)
                    # 两个region的非溢出块不是默认值
                    if [start_id, end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                        if pre_start_logic_id < start_id:
                            pre_start_logic_id = start_id
                        if pre_start_logic_id > end_id:
                            pre_start_logic_id = end_id
                        if pre_end_logic_id > end_id:
                            pre_end_logic_id = end_id
                        if pre_end_logic_id < start_id:
                            pre_end_logic_id = start_id
                    # region的非溢出块是默认值，判断溢出块范围
                    else:
                        # 溢出块范围也是默认值则跳过该斜条，表示没有数据
                        if [start_id, end_id] == const.DEFAULT_OVERFLOW_BLOCKS:
                            continue
                    start_block_id = self.get_physical_id_by_start_pre(pre_start_logic_id, start_id,
                                                                       low_bound_global_region_number)
                    end_block_id = self.get_physical_id_by_end_pre(pre_end_logic_id, end_id,
                                                                   upp_bound_global_region_number)
                # 上下界匹配不同模型
                else:
                    upp_start_id, upp_end_id, upp_start_of_id, upp_end_of_id = self.get_region_block_range(
                        upp_bound_global_region_number)
                    low_start_id, low_end_id, low_start_of_id, low_end_of_id = self.get_region_block_range(
                        low_bound_global_region_number)
                    # 出现这种情况：上下界不在同一个region，甚至相差很大，这时中间region的溢出块会被忽略，需要补上
                    non_default_region_in_middle_non_of_block = []
                    for region_num in range(low_bound_global_region_number + 1, upp_bound_global_region_number):
                        s_id, e_id, s_of_id, e_of_id = self.get_region_block_range(region_num)
                        if [s_of_id, e_of_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                            logic_of_ids = [l_id for l_id in range(s_of_id, e_of_id + 1)]
                            physical_of_ids = self.get_physical_ids_by_logic_ids(logic_of_ids)
                            result_physical_of_block_ids = result_physical_of_block_ids.union(physical_of_ids)
                        if [s_id, e_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                            non_default_region_in_middle_non_of_block.append([s_id, e_id])
                            logic_ids = [l_id for l_id in range(s_id, e_id + 1)]
                            physical_ids = self.get_physical_ids_by_logic_ids(logic_ids)
                            result_physical_block_ids = result_physical_block_ids.union(physical_ids)
                    # 获得两个region对应的溢出块
                    if [upp_start_of_id, upp_end_of_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                        logic_of_ids = [l_id for l_id in range(upp_start_of_id, upp_end_of_id + 1)]
                        physical_of_ids = self.get_physical_ids_by_logic_ids(logic_of_ids)
                        result_physical_of_block_ids = result_physical_of_block_ids.union(physical_of_ids)
                    if [low_start_of_id, low_end_of_id] != const.DEFAULT_OVERFLOW_BLOCKS:
                        logic_of_ids = [l_id for l_id in range(low_start_of_id, low_end_of_id + 1)]
                        physical_of_ids = self.get_physical_ids_by_logic_ids(logic_of_ids)
                        result_physical_of_block_ids = result_physical_of_block_ids.union(physical_of_ids)
                    if [upp_start_id, upp_end_id] == const.DEFAULT_REGION_BLOCK_RANGE and [low_start_id,
                                                                                           low_end_id] == const.DEFAULT_REGION_BLOCK_RANGE:
                        continue

                    if [upp_start_id, upp_end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                        if pre_end_logic_id > upp_end_id:
                            pre_end_logic_id = upp_end_id
                        if pre_end_logic_id < upp_start_id:
                            pre_end_logic_id = upp_start_id
                        end_block_id = self.get_physical_id_by_end_pre(pre_end_logic_id, upp_end_id,
                                                                       upp_bound_global_region_number)
                    else:
                        if [low_start_id, low_end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                            if pre_end_logic_id < low_end_id:
                                pre_end_logic_id = low_end_id
                            if len(non_default_region_in_middle_non_of_block) > 0:
                                if pre_end_logic_id > non_default_region_in_middle_non_of_block[-1][-1]:
                                    pre_end_logic_id = non_default_region_in_middle_non_of_block[-1][-1]
                        end_block_id = pre_end_logic_id // const.LOGIC_PHYSICAL_PROPOTION
                    if [low_start_id, low_end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                        if pre_start_logic_id < low_start_id:
                            pre_start_logic_id = low_start_id
                        if pre_start_logic_id > low_end_id:
                            pre_start_logic_id = low_end_id
                        start_block_id = self.get_physical_id_by_start_pre(pre_start_logic_id, low_start_id,
                                                                           low_bound_global_region_number)
                    else:
                        if [upp_start_id, upp_end_id] != const.DEFAULT_REGION_BLOCK_RANGE:
                            if pre_start_logic_id > upp_start_id:
                                pre_start_logic_id = upp_start_id
                            if len(non_default_region_in_middle_non_of_block) > 0:
                                if pre_start_logic_id > non_default_region_in_middle_non_of_block[0][0]:
                                    pre_start_logic_id = non_default_region_in_middle_non_of_block[0][0]
                        start_block_id = pre_start_logic_id // const.LOGIC_PHYSICAL_PROPOTION

                assert start_block_id != None, print(f'{start_block_id}, {end_block_id}, {is_same}, '
                                                     f'[low_start_id, low_end_id]={low_start_id}, {low_end_id}, '
                                                     f'[upp_start_id, upp_end_id]={upp_start_id}, {upp_end_id},'
                                                     f'[start_id, end_id]={start_id}, {end_id}')
                assert end_block_id != None, print(f'{start_block_id}, {end_block_id}, {is_same}, '
                                                   f'[low_start_id, low_end_id]={low_start_id}, {low_end_id}, '
                                                   f'[upp_start_id, upp_end_id]={upp_start_id}, {upp_end_id},'
                                                   f'[start_id, end_id]={start_id}, {end_id}')
                if start_block_id > end_block_id:
                    assert [upp_start_id, upp_end_id] == const.DEFAULT_REGION_BLOCK_RANGE or [low_start_id,
                                                                                              low_end_id] == const.DEFAULT_REGION_BLOCK_RANGE

                    if [upp_start_id, upp_end_id] == const.DEFAULT_REGION_BLOCK_RANGE:
                        end_block_id = start_block_id
                    if [low_start_id, low_end_id] == const.DEFAULT_REGION_BLOCK_RANGE:
                        start_block_id = end_block_id
                    assert start_block_id <= end_block_id, print(
                        f'{start_block_id}, {end_block_id}, {is_same}, '
                        f'[low_start_id, low_end_id]={low_start_id}, {low_end_id}, '
                        f'[upp_start_id, upp_end_id]={upp_start_id}, {upp_end_id},'
                        f'[start_id, end_id]={start_id}, {end_id}')
                for id in range(start_block_id, end_block_id + 1):
                    result_physical_block_ids.add(id)
            for id in result_physical_block_ids:
                search_physical_block = storage.Block.get_physical_block(id, self.data_buffer, self.p_num, self.data_patten)
                search_physical_blocks.append(search_physical_block)
            # 获得溢出物理块
            for id in result_physical_of_block_ids:
                search_physical_block = storage.Block.get_physical_block(id, self.data_buffer, self.p_num, self.data_patten, is_of=True)
                search_physical_blocks.append(search_physical_block)
            for physical_block in search_physical_blocks:
                # 在逻辑块中查找数据，逻辑块封装到物理块中 ，物理块用来计算IO
                for logic_block in physical_block.logic_block_list:
                    for x, y in logic_block.data_points:
                        if Rectangle(query_range[0], query_range[1], query_range[2], query_range[3]).is_contained(Point(x, y)):
                            result.append((x, y))
            return result, result_physical_block_ids, result_physical_of_block_ids

    def get_initial_radiu(self, point_list, query_point, k):
        """初始半径"""
        distance_list = []
        for p in point_list:
            distance = (p[0] - query_point[0])**2 + (p[1] - query_point[1])**2
            distance_list.append(distance)
        distance_list_sorted = sorted(distance_list)
        if len(distance_list_sorted) >= k:
            kth_distance = distance_list_sorted[k - 1]
        else:
            kth_distance = distance_list_sorted[-1]
        return kth_distance

    def get_polygons(self, cell_query_range, stripe_ids, slope, bottom_intercept, t_interval):
        """获取上下界斜条和cell查询组成的凸多边形区域"""
        rl = []
        for stripe_id in stripe_ids:
            low_intercept = bottom_intercept + stripe_id * t_interval
            high_intercept = low_intercept + t_interval
            sorted_vertices, area = Partition.convex_polygon_area_from_lines(slope, low_intercept, slope, high_intercept, cell_query_range)
            rl.append((tuple(sorted_vertices), stripe_id))
        return rl

    def get_knn_min_distance(self, query_point, poly_vertices):
        """
        计算点到凸包的mindistance
        1   点在区域内或者某条边上，返回0
        2   点在区域外面：计算到各条边的最小距离
        """
        px, py = query_point
        n = len(poly_vertices)
        if n < 3:
            raise ValueError("凸多边形至少需要3个顶点")
        EPS = 1e-8
        # 判断点是否在凸多边形内部/边界上
        def is_point_inside():
            cross_sign = None
            for i in range(n):
                v_i = poly_vertices[i]
                v_j = poly_vertices[(i + 1) % n]
                cross = (v_j[0] - v_i[0]) * (py - v_i[1]) - (v_j[1] - v_i[1]) * (px - v_i[0])
                if abs(cross) < EPS:
                    # 点在边上
                    return True
                current_sign = 1 if cross > 0 else -1
                if cross_sign is None:
                    cross_sign = current_sign
                else:
                    if current_sign != cross_sign:
                        # 叉积符号不一致，点在外部
                        return False
            return True
        if is_point_inside():
            return 0.0
        # 点在外部，计算到所有边的距离（点到线段的距离）
        min_dist = float('inf')
        def point_to_segment_distance(A, B, P):
            Ax, Ay = A
            Bx, By = B
            Px, Py = P

            ABx = Bx - Ax
            ABy = By - Ay
            APx = Px - Ax
            APy = Py - Ay

            ab_sq = ABx ** 2 + ABy ** 2
            if ab_sq < EPS:
                # 线段AB长度为0（两点重合）
                return APx**2 + APy**2

            t = (APx * ABx + APy * ABy) / ab_sq
            t = max(0.0, min(1.0, t))  # 限制t在[0,1]范围内

            proj_x = Ax + t * ABx
            proj_y = Ay + t * ABy

            dx = Px - proj_x
            dy = Py - proj_y
            return dx**2 + dy**2
        for i in range(n):
            A = poly_vertices[i]
            B = poly_vertices[(i + 1) % n]
            dist = point_to_segment_distance(A, B, (px, py))
            if dist < min_dist:
                min_dist = dist
        return min_dist

    def get_knn_min_max_distance(self, query_point, poly_vertices):
        """计算minmaxdistance"""
        # px, py = query_point
        # n = len(poly_vertices)
        # if n < 3:
        #     raise ValueError("凸多边形至少需要3个顶点")
        # minmax_dist_sq = float('inf')
        # for i in range(n):
        #     v_i = poly_vertices[i]
        #     v_j = poly_vertices[(i + 1) % n]
        #     # 计算两个端点到查询点的平方距离
        #     d_i = (v_i[0] - px) ** 2 + (v_i[1] - py) ** 2
        #     d_j = (v_j[0] - px) ** 2 + (v_j[1] - py) ** 2
        #     # 取较远的端点作为该边的最远顶点
        #     if d_i >= d_j:
        #         h_dist_sq = d_i
        #     else:
        #         h_dist_sq = d_j
        #     # 更新最小距离（平方）
        #     if h_dist_sq < minmax_dist_sq:
        #         minmax_dist_sq = h_dist_sq
        # return minmax_dist_sq
        px, py = query_point
        max_dist_sq = float('-inf')
        for v in poly_vertices:
            dist_sq = (v[0] - px) ** 2 + (v[1] - py) ** 2
            # 更新最大距离（平方）
            if dist_sq > max_dist_sq:
                max_dist_sq = dist_sq
        return max_dist_sq

    def fill_priority_queue(self, query_point, k, distance_heap, p_id, stripe_id, query_range, W, bottom_intercept, t_interval, result_physical_ids, result_of_physical_ids, query_num):
        min_pos, min_t, max_pos, max_t, low_bound_mv, upp_bound_mv = self.get_stripe_low_upp_mv(query_range, W,
                                                                                                stripe_id,
                                                                                                bottom_intercept,
                                                                                                t_interval)
        global_model_num, models = self.get_stripe_regions(p_id, stripe_id)
        # 获得单个斜条查询的物理块
        single_stripe_result_physical_ids, single_stripe_result_of_physical_ids = self.get_single_stripe_query_physical_ids(
            global_model_num, models, low_bound_mv, upp_bound_mv, min_pos, min_t, max_pos, max_t, query_num)
        for physical_id in single_stripe_result_physical_ids:
            if physical_id not in result_physical_ids:
                physical_block = storage.Block.get_physical_block(physical_id, self.data_buffer, self.p_num,
                                                                  self.data_patten)
                for logic_block in physical_block.logic_block_list:
                    for point in logic_block.data_points:
                        if query_num == 96 and ((point[0] == 7204333.346 and point[1]==62496) or (point[0]==7205874.383 and point[1]==55864)):
                            pass
                        dt = self.get_distance(point, query_point)
                        if dt == 0:
                            continue
                        if len(distance_heap) < k or dt < distance_heap.get_kth_distance():
                            distance_heap.add(point, self.get_distance(point, query_point))
                result_physical_ids.add(physical_id)
        for physical_of_id in single_stripe_result_of_physical_ids:
            if physical_of_id not in result_of_physical_ids:
                physical_of_block = storage.Block.get_physical_block(physical_of_id, self.data_buffer, self.p_num,
                                                                     self.data_patten, is_of=True)
                for logic_block in physical_of_block.logic_block_list:
                    for point in logic_block.data_points:
                        dt = self.get_distance(point, query_point)
                        if dt == 0:
                            continue
                        if len(distance_heap) < k or dt < distance_heap.get_kth_distance():
                            distance_heap.add(point, self.get_distance(point, query_point))
                result_of_physical_ids.add(physical_of_id)

    def get_distance(self, p1, p2):
        return (p1[0] - p2[0])**2 + (p1[1] - p2[1])**2

    def knn_querys(self, query_points, k, data):
        """
        KNN查询
        1 初始化半径、优先队列、逻辑块列表
        2 对每个半径执行一次范围查询，分解为每个单元格的斜条查询，然后得到每个斜条的凸多边形
        3 找最近的多边形执行模型预测逻辑块号，放入列表
        """
        query_num = 0
        result = []

        pos_length = const.MAX_POS_SIM - const.MIN_POS_SIM if data_patten == "SIM" else const.MAX_POS_REAL - const.MIN_POS_REAL
        t_length = const.MAX_T_SIM - const.MIN_T_SIM if data_patten == "SIM" else const.MAX_T_REAL - const.MIN_T_REAL
        max_position = const.MAX_POS_SIM if data_patten == 'SIM' else const.MAX_POS_REAL
        max_time = const.MAX_T_SIM if data_patten == 'SIM' else const.MAX_T_REAL
        min_position = const.MIN_POS_SIM if data_patten == 'SIM' else const.MIN_POS_REAL
        min_time = const.MIN_T_SIM if data_patten == 'SIM' else const.MIN_T_REAL
        for query_point in query_points:
            result_physical_ids = set()
            result_of_physical_ids = set()
            query_num += 1
            initial_r = math.sqrt(k / const.DATA_NUM) * min(pos_length, t_length)
            # initial_r = (math.sqrt(k / const.DATA_NUM) * min(pos_length, t_length)) / 8

            # query_point_logic_block = self.get_point_query_logic_block(query_point, result_physical_ids, result_of_physical_ids)
            # initial_r = self.get_initial_radiu(point_list=query_point_logic_block.data_points, query_point=query_point, k=k)

            print(f'query_num = {query_num}, initial_r = {initial_r}, query_point = {query_point}')
            while True:
                distance_heap = MaxPriorityQueue(k)
                # 需要用实际的POS和T的范围约束查询框
                query_range = [max(query_point[0]-initial_r, min_position), max(query_point[1]-initial_r, min_time), min(query_point[0]+initial_r, max_position), min(query_point[1]+initial_r, max_time)]
                pids = self.get_range_query_pids(query_range, query_num)
                for p_id in pids:
                    cell_query_range = self.get_single_partition_query_range(query_range, p_id)



                    # result, result_physical_block_ids, result_physical_of_block_ids = self.get_single_partition_query_result(p_id, cell_query_range, query_num)
                    # for point in result:
                    #     dt = self.get_distance(point, query_point)
                    #     if dt <= initial_r**2 and dt != 0:
                    #         distance_heap.add(point, dt)




                    W, slope, bottom_intercept, t_interval = self.get_partition_info_by_id(p_id, query_num)
                    low_stripe_id, upp_stripe_id = self.get_stripe_ids_for_single_partition_query(p_id, cell_query_range,
                                                                                                slope, bottom_intercept,
                                                                                                 t_interval)
                    stripe_ids = list(range(low_stripe_id, upp_stripe_id + 1))
                    rl = self.get_polygons(cell_query_range, stripe_ids, slope, bottom_intercept, t_interval)
                    assert len(rl) == len(stripe_ids), print(f'凸多边形数量和斜条数量不一致！')
                    # 保存凸多边形（用顶点表示）和mindt以及minmaxdt的映射，保存形式(多边形顶点序列）:(mindt,minmaxdt)
                    polygon_distance_map = {}
                    for pg, stripe_id in rl:
                        polygon_distance_map[pg] = (self.get_knn_min_distance(query_point, pg), self.get_knn_min_max_distance(query_point, pg))
                    # sorted_polygon_distance_map = dict(sorted(polygon_distance_map.items(), key=lambda x: x[1][0]))
                    sorted_polygons = sorted(rl, key=lambda x: polygon_distance_map[x[0]][0])
                    for pg, stripe_id in sorted_polygons:
                        if len(distance_heap) < k:
                            self.fill_priority_queue(query_point=query_point,
                                                     k=k,
                                                     distance_heap=distance_heap,
                                                     p_id=p_id,
                                                     stripe_id=stripe_id,
                                                     query_range=cell_query_range,
                                                     W=W,
                                                     bottom_intercept=bottom_intercept,
                                                     t_interval=t_interval,
                                                     result_physical_ids=result_physical_ids,
                                                     result_of_physical_ids=result_of_physical_ids,
                                                     query_num=query_num)
                        else:
                            """
                            当优先队列满时需要剪枝：只有当前多边形的mindt小于第k个距离 且 没有其他的minmaxdt小于当前多边形的mindt才需要处理
                            """
                            if polygon_distance_map[pg][0] <= distance_heap.get_kth_distance():
                                door = True
                                for poly, s_id in sorted_polygons:
                                    if poly is pg:
                                        continue
                                    if polygon_distance_map[poly][1] <= polygon_distance_map[pg][0]:
                                        door = False
                                        break
                                if door:
                                    self.fill_priority_queue(query_point=query_point,
                                                             k=k,
                                                             distance_heap=distance_heap,
                                                             p_id=p_id,
                                                             stripe_id=stripe_id,
                                                             query_range=cell_query_range,
                                                             W=W,
                                                             bottom_intercept=bottom_intercept,
                                                             t_interval=t_interval,
                                                             result_physical_ids=result_physical_ids,
                                                             result_of_physical_ids=result_of_physical_ids,
                                                             query_num=query_num)

                if len(distance_heap) < k:
                    initial_r = 2 * initial_r
                else:
                    break
            tmp_result = [tuple(item[1]) for item in distance_heap.heap]
            result += [tmp_result]
            # real_result = list(get_single_real_knn_query_result(k, query_point, data=data))
            # assert is_same_list(real_result, tmp_result), print(f'query_point: {query_point}, real_result: {real_result}, query_result: {tmp_result}, query_num: {query_num}')

        # print(f'final radiu: {initial_r}')
        return result, query_num

    def get_region_block_range(self, global_model_num):
        """获得region的块范围"""
        period_range_block_id = self.index_buffer.cal_period_range_block_id(global_model_num)
        assert period_range_block_id in self.period_range_block_ids, print(f'查询时范围块没有全部读取到内存中')
        period_range_block = self.period_range_block_map[period_range_block_id]
        # 计算region在块中的偏移序号
        offset_number_in_period_range_block = global_model_num % const.PERIOD_RANGE_BLOCK_ITEM_NUM
        # 获得region的块范围
        start_id, end_id, start_of_id, end_of_id = period_range_block.model_block_range[offset_number_in_period_range_block]
        return start_id, end_id, start_of_id, end_of_id


if __name__ == '__main__':
    """
    后期查询时，首先匹配region，获得region的块范围，在通过模型预测后，通过et扩大搜索范围，获得对应的物理块，获取每个物理块的逻辑块列表：
    region的非溢出块范围和溢出块范围都只有2种：
    1   非溢出块范围非默认值，代表region在那一期有数据，溢出块非默认值代表region在那一期溢出
    2   非溢出块范围默认值，代表region在该期无数据，溢出块范围默认值代表region在该期无溢出
    """
    init_error_thre = const.FOLLOW_ERROR // const.SCALE_FACTOR  # 初始周期误差
    follow_error_thre = const.FOLLOW_ERROR  # 后期数据误差
    data_patten = const.PATTEN

    query_index_buffer = storage.QueryIndexBuffer()
    query_data_buffer = storage.QueryDataBuffer()
    # init_range_query_file = const.RANGE_QUERY_FILE[data_patten][0]
    # init_point_query_file = const.POINT_QUERY_FILE[data_patten][0]

    # 加载边界值
    bx = load_model(const.x_boundary_file)
    by = load_model(const.y_boundary_file)
    # 加载分区范围
    partiton_range = load_model(const.partition_range_file)
    # 加载分区的累计斜条数量列表
    cum_stripes_num_list = load_model(const.cum_stripes_num_list)

    all_result_file_list = []
    # 若没有查询文件则生成
    for i in range(const.PERIOD_NUM):
        model_error = load_model(const.PERIOD_MODEL_ERROR_FILE[data_patten][i])
        check_dir(rf'../result/{data_patten}/EP{i}')
        all_result_file_list.append(const.PERIOD_QUERY_RESULT_FILE[data_patten][i])

        # clean_file(const.RANGE_QUERY_FILE[data_patten][i])
        if not os.path.exists(const.POINT_QUERY_FILE[data_patten][i]):
            generate_point_query_data(data_file=const.ORI_FILE[data_patten][i], query_file=const.POINT_QUERY_FILE[data_patten][i], patten=data_patten)
        if not os.path.exists(const.RANGE_QUERY_FILE[data_patten][i]):
            generate_range_query_data(data_file=const.ORI_FILE[data_patten][i], query_file=const.RANGE_QUERY_FILE[data_patten][i], patten=data_patten)
        if not os.path.exists(const.KNN_QUERY_FILE[data_patten][i]):
            generate_knn_query_data(data_file=const.ORI_FILE[data_patten][i], query_file=const.KNN_QUERY_FILE[data_patten][i], patten=data_patten)

        point_query_file = const.POINT_QUERY_FILE[data_patten][i]
        # range_query_file = const.RANGE_QUERY_FILE[data_patten][i]
        range_query_file = const.high_se_query_file[data_patten][i]
        point_query_list = read_txt_to_list(point_query_file)
        range_query_list = read_txt_to_list(range_query_file)
        knn_query_list = point_query_list

        if i == 1:
            pass

        max_logic_id = struct.unpack('I', storage.Buffer.load(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 8,
                                     data_size=4, p_num=i, patten=data_patten))[0]
        start_region_block_id = struct.unpack('I', storage.Buffer.load(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 4,
                                              data_size=4, p_num=i, patten=data_patten))[0]
        global_region_number = struct.unpack('I', storage.Buffer.load(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 12,
                                             data_size=4, p_num=i, patten=data_patten))[0]
        if i != 0:
            max_of_logic_id = struct.unpack('I', storage.Buffer.load(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 16,
                                             data_size=4, p_num=i, patten=data_patten))[0]
            const.MAX_OVERFLOW_LOGIC_BLOCK_ID = max_of_logic_id
        const.MAX_LOGIC_BLOCK_ID = max_logic_id  # 最大的逻辑块号
        const.START_REGION_BLOCK_ID = start_region_block_id  # 起始的region索引块号
        fp_result = open(const.query_period_result_num_file[data_patten][i], 'w', encoding='utf-8')  # 结果写入文件指针
        query_obj = Query(model_error, fp_result, query_data_buffer, query_index_buffer, bx, by, cum_stripes_num_list, partiton_range, max_logic_id, start_region_block_id, p_num=i, patten=data_patten)

        # 将索引全读入内存，包括索引块和region块范围
        region_block_number = int(np.ceil(global_region_number / const.REGION_BLOCK_ITEM_NUM))
        index_block_total_number = start_region_block_id + region_block_number
        for block_index in range(index_block_total_number):
            index_block = storage.Buffer.load_block(block_index, const.INDEX_FILE[data_patten][i])
            query_index_buffer.add_block(index_block, i, data_patten)
        period_range_block_total_number = int(np.ceil(global_region_number / const.PERIOD_RANGE_BLOCK_ITEM_NUM))
        for period_block_index in range(period_range_block_total_number):
            period_range_block = storage.Buffer.load_period_range_block(i, period_block_index, data_patten)
            query_obj.period_range_block_map[period_block_index] = period_range_block
            query_obj.period_range_block_ids.append(period_block_index)


        fp = open(const.PERIOD_QUERY_RESULT_FILE[data_patten][i], 'w')

        print(f'---------------point query------------------')
        fp.write(f'---------------point query------------------\n')
        start = time.time()
        result, query_num = query_obj.point_querys(point_query_list)
        end = time.time()
        real_res = get_real_point_query_result(point_query_list, data_file=const.ORI_FILE[data_patten][i])
        real_num = len(real_res)

        fp.write(f'average point query time in period {i}: {(end - start) / query_num} s\n'
                 f'average point query io cost in period {i}: {const.IO_COUNT / query_num}\n'
                 f'point query result number: {len(result)}, real result number: {real_num}\n'
                 f'point query recall in period {i}: {len(result) / real_num}\n\n\n')
        print(f'average point query time in period {i}: {(end - start) / query_num} s')
        print(f'average point query io cost in period {i}: {const.IO_COUNT / query_num}')
        print(f'point query result number: {len(result)}, real result number: {real_num}')
        print(f'point query recall in period {i}: {len(result) / real_num}')
        print('\n')


        print(f'---------------range query------------------')
        fp.write(f'---------------range query------------------\n')
        const.IO_COUNT = 0
        # query_obj.query_num = 0
        start = time.time()
        result, query_num = query_obj.range_querys(range_query_list)
        end = time.time()

        real_num = 0
        data = read_txt_to_np(const.ORI_FILE[data_patten][i])
        for qu in range_query_list:
            real_num += get_real_range_query_result(qu, data)
        fp.write(f'average range query time in period {i}: {(end - start) / query_num} s\n'
                 f'average range query io cost in period {i}: {const.IO_COUNT / query_num}\n'
                 f'range query result number: {len(result)}, real result number: {real_num}\n'
                 f'range query recall in period {i}: {len(result) / real_num}\n\n\n')
        fp_result.write(f'查询总数据量: {len(result)}')

        print(f'average range query time in period {i}: {(end - start) / query_num} s')
        print(f'average range query io cost in period {i}: {const.IO_COUNT / query_num}')
        print(f'range query result number: {len(result)}, real result number: {real_num}')
        print(f'range query recall in period {i}: {len(result) / real_num}')
        print('\n')


        # query_obj.query_num = 0
        k_list = [i for i in range(2, 19, 4)]
        for k in k_list:
            print(f'---------------knn query (k={k})------------------')
            fp.write(f'---------------knn query (k={k})------------------\n')
            const.IO_COUNT = 0
            query_obj.data_buffer.reset()
            start = time.time()
            result, query_num = query_obj.knn_querys(knn_query_list, k, data)
            end = time.time()
            # data = read_txt_to_list(const.ORI_FILE[data_patten][i])
            # real_knn_result = get_real_knn_query_result(k, point_query_list, data=data)
            fp.write(f'average knn(k = {k}) query time in period {i}: {(end - start) / query_num} s\n'
                     f'average knn(k = {k}) query io cost in period {i}: {const.IO_COUNT / query_num}\n\n')
                     # f'knn(k = {k}) query recall in period {i}: {len(result) / real_num}\n')
            print(f'average knn(k = {k}) query time in period {i}: {(end - start) / query_num} s')
            print(f'average knn(k = {k}) query io cost in period {i}: {const.IO_COUNT / query_num}')
            # print(f'knn(k = {k}) query recall in period {i}: {get_knn_recall(real_result=real_knn_result, query_result=result)}')
            print('\n')
        fp.close()
        fp_result.close()

    with open(const.common_query_result_file, 'w') as outfile:
        # 遍历每个文件并将其内容写入输出文件
        for file in all_result_file_list:
            with open(file, 'r') as infile:
                outfile.write(infile.read())
                outfile.write("\n")
    print(f"{const.PERIOD_NUM} periods  query result has been into {const.common_query_result_file}")