import sys

from src.storage import *
import struct




buff = QueryDataBuffer()
p_num = 1
max_logic_id = struct.unpack('I', Buffer.load(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 8,
                                                      data_size=4, p_num=p_num, patten=const.PATTEN))[0]

for b_id in range(max_logic_id+1):
    logic_block = DataBlock.get_logic_block(b_id, buff, p_num, const.PATTEN)
    for point in logic_block.data_points:
        if (point[0] == 2089458.419 and point[1]==2372) or (point[0]==2089458.419 and point[1]==2384):
            print(f'{point}在物理块号: {b_id // const.LOGIC_PHYSICAL_PROPOTION}')