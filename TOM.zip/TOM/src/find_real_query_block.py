
import src.storage as s
import struct
from utils.file_utils import *
from collections import defaultdict


class DataBlock:
    """
    逻辑块
    """
    def __init__(self, block_id, overflow_blockid=const.DEFAULT_OVERFLOW_BLOCKS[0]):
        self.block_id = block_id
        self.data_points = []
        self.overflow_block_id = overflow_blockid  # 保存在溢出块中
        self.overflow_block_num = const.DEFAULT_OVERFLOW_BLOCKS[1]

    def create_new_block(self):
        return DataBlock(block_id=self.block_id+1)

    @staticmethod
    def get_logic_block(b_id, data_buffer, p_num, patten="SIM"):
        block = data_buffer.get_dblock(b_id, p_num, patten)
        if block is None:
            block = s.Buffer.load_block(b_id, file=const.DATA_FILE[patten][p_num])
            data_buffer.add_dblock(block, p_num, patten)
        return block

    def set_overflow_block_id(self, b_id):
        self.overflow_block_id = b_id

    def set_overflow_block_num(self, b_num):
        self.overflow_block_num = b_num

    def is_overflow(self):
        """存满的情况，需要额外加1"""
        return (len(self.data_points) + 1) * 16 + 16 > const.LOGIC_BLOCK_SIZE

    def pack(self):
        """block to bytes"""
        binfo = struct.pack('4I', self.block_id, len(self.data_points), self.overflow_block_id, self.overflow_block_num)
        for x, y in self.data_points:
            binfo = binfo + struct.pack('2d', x, y)
        return binfo

    @staticmethod
    def unpack(bindata):
        """bytes to block"""
        block_id, length, overflow_bid, overlfow_bnum = struct.unpack('4I', bindata[:16])
        dblock = DataBlock(block_id)
        dblock.overflow_block_num = overlfow_bnum
        dblock.overflow_block_id = overflow_bid
        offset = 16
        for i in range(length):
            x = struct.unpack('d', bindata[offset:offset + 8])[0]
            offset += 8
            y = struct.unpack('d', bindata[offset:offset + 8])[0]
            offset += 8
            dblock.data_points.append([x, y])
        return dblock

    def add_point(self, point):
        self.data_points.append(point)

    def add_points_batch(self, points):
        """批量添加数据"""
        self.data_points.extend(points)


query = (9662900.879, 22028.0)
data_count = 0
patten = 'SIM'
period_num = 1
with open(const.DATA_FILE[patten][period_num], 'rb') as f:
    for i in range(4715):
        f.seek(i * const.LOGIC_BLOCK_SIZE)
        bin_data = f.read(const.LOGIC_BLOCK_SIZE)
        block = DataBlock.unpack(bin_data)
        data_count += len(block.data_points)
        for x, y in block.data_points:
            if x == query[0] and y == query[1]:
                print(f'逻辑块: {i}')
print(f'总数据量: {data_count}')
# print(load_model(const.MODEL_ONE_PERIOD_INDEX_FILE[patten][period_num]))
