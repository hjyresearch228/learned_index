import math
import os
import struct
import time
from itertools import accumulate
from utils.file_utils import *
from utils.build_utils import *
from grid import Grid
from partition import Partition
from stripe import SlantStripe, StripeRegion
from storage import *
import numpy as np
import copy
from geometry import *
import bisect


"""
数据块使用逻辑块存储，逻辑块大小是物理块的因子例如物理块8KB，则逻辑块可以是1KB，2KB，4KB，8KB等。
分区模型预测的是逻辑块，查询时按照物理块来算IO，物理块号 = 逻辑块号 // const.LOGIC_PHYSICAL_PROPOTION
"""


"""
在region边界值改为一维映射值之后，需要变化的地方有：
1. 原来保存的是斜率，现在需要改为partition的W
2. 原来道格拉斯分段时保存的边界是pos，现在需要改为一维映射值
3. 原来获得region的块范围是根据region的pos范围和逻辑块pos范围相交，现在需要根据一维映射值的相交来获得
4. 添加对应的region块时pos参数需要换为mv，partition的slope参数需要换为W
5. 在查询时需要用到W，查询时每个斜条的上下界pos和t和原来一样
"""


def build_initial_period(data_block_pool, init_data, insert_index_buffer, insert_data_buffer, fp, data_patten='SIM', n_p=0):
    """
    先按照SPRIG的方法构建网格，然后用曲线填充，然后对每个cell/partition进行斜条划分，
    利用PCA的思想确定斜线的斜率，利用密度峰值聚类的思想确定斜线的最佳数量，
    然后每个斜条内部再进行道格拉斯分段，每个分段对应一个region，保存pos的边界值和模型参数、逻辑块范围

    给定查询点，在查询时先通过两个维度的分割点来确定每个维度的序号，然后通过这个序号计算出cell编号值，也就是
    partition_id，然后再通过斜线的斜率确定查询点所在的截距，通过截距定位所属的斜条，然后再通过
    pos来定位对应的模型，通过模型预测出点所在的位置，然后通过误差来扩大搜索范围
    """
    init_error_threshold = const.FOLLOW_ERROR // const.SCALE_FACTOR
    index_exist = True
    # 斜条中最少数据量要求
    min_stripe_data_num = 32
    if data_patten == 'SIM':
        print(f'======================SIM DATA=========================')
    elif data_patten == 'REAL':
        print(f'======================REAL DATA=========================')
    print('==========================================================')
    if const.TOM2:
        print('=================== TOM2 ====================')
    else:
        print('=================== TOM1 ====================')
    print('===================initial period building=================')
    print('==========================================================')
    # id_road_length_map = load_model(const.ID_ROAD_LENGTH_FILE)
    region_num = 0  # region全局数量计数
    partition_list = []  # 保存所有partition对象

    model_error = {}  # 存储每个模型的误差
    partition_range_dict = {}
    # 存储每个partition的斜条数量，通过这个定位斜条所属的索引块
    data = read_txt_to_np(init_data)
    print(f'-------------------total data number: {len(data)}--------------------')
    start = time.time()

    clean_file(const.x_boundary_file)
    clean_file(const.y_boundary_file)
    clean_file(const.cum_stripes_num_list)
    clean_file(const.partition_range_file)

    clean_file(const.partition_file[data_patten][n_p])
    clean_file(const.stripe_file[data_patten][n_p])
    clean_file(const.INDEX_FILE[data_patten][n_p])
    clean_file(const.DATA_FILE[data_patten][n_p])
    clean_file(const.OVERFLOW_DATA_FILE[data_patten][n_p])
    clean_file(const.MODEL_ONE_PERIOD_INDEX_FILE[data_patten][n_p])
    clean_file(const.PERIOD_MODEL_ERROR_FILE[data_patten][n_p])
    clean_file(const.partition_pkl[data_patten][n_p])
    # 先通过SPRIG的方法划分网格，然后根据道路的长度调整边界，需要保证同一道路落入同一cell
    grid = Grid(const.N_ROWS, const.N_COLS, data)
    # 构建网格
    print(f'---------------------start grid building-------------------------')
    grid.build_grid()
    bx = grid.boundary_x
    by = grid.boundary_y
    # 设置边界0
    if data_patten == 'SIM':
        bx[0] = const.MIN_POS_SIM
        by[0] = const.MIN_T_SIM
    else:
        bx[0] = const.MIN_POS_REAL
        by[0] = const.MIN_T_REAL
    if data_patten == 'SIM':
        bx[-1] = const.MAX_POS_SIM
        by[-1] = const.MAX_T_SIM
    else:
        bx[-1] = const.MAX_POS_REAL
        by[-1] = const.MAX_T_REAL
    # 保存网格分割点
    if not os.path.exists(const.x_boundary_file) and not os.path.exists(const.y_boundary_file):
        print(f'----------------------save splitting points in each dimension----------------------')
        dump_model(by, const.y_boundary_file)
        dump_model(bx, const.x_boundary_file)
    print(f'bx:{bx}')
    print(f'by:{by}')
    print(f'------------------grid is built, grid resolution: {const.N_ROWS} * {const.N_COLS}-------------------')
    print(f'------------------partition number: {const.N_ROWS * const.N_COLS}---------------------------------')
    print(f'------------------logic block size: {const.LOGIC_BLOCK_SIZE} Bytes--------------------------------')
    print(f'------------------error threshold: {init_error_threshold}----------------------------------------')
    print(f'------------------min data number required in stripe slant: {min_stripe_data_num}-----------------------------------')
    # 分割网格，然后用列曲线填充
    logic_block_count = 0
    if not os.path.exists(const.partition_pkl[data_patten][n_p]):
        index_exist = False
        for x in range(len(bx) - 1):
            for y in range(len(by) - 1):
                partition_id = x * const.N_ROWS + y
                partiiton_region_num = 0
                new_partition = Partition(partition_id=partition_id,
                                          pos_low=bx[x], pos_high=bx[x + 1], t_low=by[y], t_high=by[y + 1], data=data)
                partition_range_dict[partition_id] = (new_partition.pos_low, new_partition.t_low,
                                                      new_partition.pos_high, new_partition.t_high)
                # print(f'分区号:{new_partition.partition_id}')
                partition_list.append(new_partition)
                stripes = new_partition.get_stripes(min_stripe_data_num)
                # 斜条宽度
                new_partition.t_interval = stripes[0][1] - stripes[0][0]

                point_count = 0
                # 分配斜条并确定斜条参数
                for id, inpt in stripes.items():
                    logic_blocks = []
                    new_stripe = SlantStripe(stripe_id=id, low_intercept=inpt[0], high_intercept=inpt[1])
                    new_partition.stripe_list.append(new_stripe)
                    # 设置斜条对应的分区
                    new_stripe.set_parent(new_partition)
                    slope = new_partition.slope
                    low_incpt = new_stripe.low_intercept
                    high_inpt = new_stripe.high_intercept
                    # cell的四个角
                    rec = [new_partition.pos_low, new_partition.t_low, new_partition.pos_high, new_partition.t_high]
                    # 获得斜条与矩形相交的多边形的顶点
                    stripe_vertices, area = new_partition.convex_polygon_area_from_lines(slope, low_incpt, slope,
                                                                                         high_inpt, rec)

                    # 在斜条的边界模型中需要调整边界值，不调整的话可能查询的时候匹配不到模型
                    # 调整策略是左边取多边形的点的横坐标最小值，右边取横坐标最大值
                    # 获得多边形的横坐标最值
                    first_dimension_values = [item[0] for item in stripe_vertices]
                    #另外一种异常，因为精度问题匹配不到模型，保留3位小数
                    min_stripe_pos = np.round(min(first_dimension_values), 3)
                    max_stripe_pos = np.round(max(first_dimension_values), 3)

                    # 获得纵坐标最值
                    second_dim_values = [item[1] for item in stripe_vertices]
                    min_stripe_t = np.round(min(second_dim_values), 3)
                    max_stripe_t = np.round(max(second_dim_values), 3)

                    # 获得对应斜条中的数据
                    new_stripe.stripe_data_list = new_partition.get_data_in_polygen(stripe_vertices)
                    assert len(new_stripe.stripe_data_list) > 0, print(f'斜条数据量不足！')
                    # 排序斜条数据
                    new_stripe.stripe_inner_sort()
                    # dump_model(new_stripe.stripe_data_list, const.stripe_data_dir + str(new_partition.partition_id) + '.' + str(new_stripe.stripe_id) + '.pkl')
                    # 准备斜条数据，根据斜条训练分段模型

                    if logic_block_count != 0 or id != 0:
                        logic_block_count += 1
                    new_points = []
                    points = new_stripe.stripe_data_list
                    # mbr = Rectangle.get_mbr(data=points)
                    # new_stripe.set_stripe_mbr(mbr)
                    # new_logic_block = DataBlock(block_id=logic_block_count)
                    new_logic_block = data_block_pool.get_block(logic_block_count)
                    logic_blocks.append(new_logic_block)
                    insert_data_buffer.add_dblock(new_logic_block, n_p, data_patten)

                    for point in points:
                        # 新的point3个维度：pos,t,logic_id(index)
                        new_logic_block.add_point(point)

                        new_points.append(np.append(point, logic_block_count))
                        point_count += 1

                        # 一个逻辑块满：逻辑块数量加1，重置数据计数
                        if point_count == const.LOGIC_BLOCK_CONTENT_SIZE:
                            logic_block_count += 1
                            point_count = 0
                            # new_logic_block = DataBlock(block_id=logic_block_count)
                            new_logic_block = data_block_pool.get_block(logic_block_count)
                            logic_blocks.append(new_logic_block)
                            insert_data_buffer.add_dblock(new_logic_block, n_p, data_patten)

                    # 有可能出现一种情况就是斜条数据量正好是127的倍数，这种情况需要单独处理，即让逻辑块减一
                    # 然后还需要舍去缓冲中刚刚加入的那块
                    # 并修改斜条的结束块
                    if point_count == 0:
                        insert_data_buffer.delete(logic_block_count, p_num=n_p)
                        logic_blocks.pop(-1)
                        logic_block_count -= 1

                    new_points = np.array(new_points)
                    time_stamps = new_points[:, 1]
                    edge_pos = new_points[:, 0]
                    # 逻辑块号
                    index = new_points[:, 2]

                    new_stripe.three_dim_data_list = new_points
                    # 获取分割点
                    break_points, models, errors, t_range, pos_range = new_stripe.douglas_peucker(time_stamps, edge_pos, index, init_error_threshold)
                    # 反转模型使其按照mv升序排序
                    models.reverse()
                    errors.reverse()
                    t_range.reverse()
                    pos_range.reverse()

                    W = new_partition.W

                    """
                    如果按照一维映射值分割数据的话，需要分情况讨论
                    1 如果斜条斜率大于0:
                        1）如果分量大于0，则最小映射值在左下角（即pos最小且t最小的位置），最大映射值在右上角
                        2）如果分量小于0，则最小映射值在右上角（即pos最大且t最大的位置），最大映射值在左下角
                    2 如果斜条斜率小于0：
                        1）如果W[0]>0 且W[1]<0, 则最小值在左上（即pos最小且t最大），最大值在右下
                        2）如果W[0]<0 且W[1]>0, 则最小值在右下（即pos最大且t最小），最大值在左上
                    """
                    # 更正两端region的边界映射值
                    if new_partition.slope > 0:
                        if new_partition.W[0] > 0 and new_partition.W[1] > 0:
                            tmp_mv = np.round(np.dot(np.array([min_stripe_pos, min_stripe_t]), W), 3)
                            if tmp_mv < models[0][0]:
                                models[0][0] = tmp_mv
                            tmp_mv = np.round(np.dot(np.array([max_stripe_pos, max_stripe_t]), W), 3)
                            if tmp_mv > models[-1][1]:
                                models[-1][1] = tmp_mv
                        else:
                            tmp_mv = np.round(np.dot(np.array([max_stripe_pos, max_stripe_t]), W), 3)
                            if tmp_mv < models[0][0]:
                                models[0][0] = tmp_mv
                            tmp_mv = np.round(np.dot(np.array([min_stripe_pos, min_stripe_t]), W), 3)
                            if tmp_mv > models[-1][1]:
                                models[-1][1] = tmp_mv
                    else:
                        if new_partition.W[0] > 0 and new_partition.W[1] < 0:
                            tmp_mv = np.round(np.dot(np.array([min_stripe_pos, max_stripe_t]), W), 3)
                            if tmp_mv < models[0][0]:
                                models[0][0] = tmp_mv
                            tmp_mv = np.round(np.dot(np.array([max_stripe_pos, min_stripe_t]), W), 3)
                            if tmp_mv > models[-1][1]:
                                models[-1][1] = tmp_mv
                        else:
                            tmp_mv = np.round(np.dot(np.array([max_stripe_pos, min_stripe_t]), W), 3)
                            if tmp_mv < models[0][0]:
                                models[0][0] = tmp_mv
                            tmp_mv = np.round(np.dot(np.array([min_stripe_pos, max_stripe_t]), W), 3)
                            if tmp_mv > models[-1][1]:
                                models[-1][1] = tmp_mv
                    # 更正两端region的pos范围
                    """
                    处理pos和t的边界情况，由于现在换成一维映射值之后，pos的最值不一定和原来一样，即：
                    左端pos的最小值赋值给最左端的region，右端pos的最大值赋值给最右端的region。
                    现在需要根据W的情况分类讨论，和前面的对mv的讨论一样，只不过现在考虑的是pos：
                    1. W[0] > 0 且 W[1] > 0: 最小pos赋值给左端region，最大pos赋值给右端region。最小t赋给左端，最大t赋给右端。
                    2. W[0] < 0 且 W[1] < 0: 最小pos赋值给右端region，最大pos赋给左端region，最小t赋给右端，最大t赋给左端。
                    3. W[0] > 0 且 W[1] < 0: 最小pos赋给左端region，最大赋给右端region，最小t赋给右端，最大t赋给左端。
                    4. W[0] < 0 且 W[1] > 0: 最小pos赋给右端region，最大赋给左端region，最小t赋给左端，最大t赋给右端
                    """
                    if W[0] > 0 and W[1] > 0:
                        if pos_range[0][0] > min_stripe_pos:
                            pos_range[0][0] = min_stripe_pos
                        if pos_range[-1][1] < max_stripe_pos:
                            pos_range[-1][1] = max_stripe_pos
                        if t_range[0][0] > min_stripe_t:
                            t_range[0][0] = min_stripe_t
                        if t_range[-1][1] < max_stripe_t:
                            t_range[-1][1] = max_stripe_t
                    elif W[0] < 0 and W[1] < 0:
                        if pos_range[-1][0] > min_stripe_pos:
                            pos_range[-1][0] = min_stripe_pos
                        if pos_range[0][1] < max_stripe_pos:
                            pos_range[0][1] = max_stripe_pos
                        if t_range[-1][0] > min_stripe_t:
                            t_range[-1][0] = min_stripe_t
                        if t_range[0][1] < max_stripe_t:
                            t_range[0][1] = max_stripe_t
                    elif W[0] > 0 and W[1] < 0:
                        if pos_range[0][0] > min_stripe_pos:
                            pos_range[0][0] = min_stripe_pos
                        if pos_range[-1][1] < max_stripe_pos:
                            pos_range[-1][1] = max_stripe_pos
                        if t_range[-1][0] > min_stripe_t:
                            t_range[-1][0] = min_stripe_t
                        if t_range[0][1] < max_stripe_t:
                            t_range[0][1] = max_stripe_t
                    else:
                        if pos_range[-1][0] > min_stripe_pos:
                            pos_range[-1][0] = min_stripe_pos
                        if pos_range[0][1] < max_stripe_pos:
                            pos_range[0][1] = max_stripe_pos
                        if t_range[0][0] > min_stripe_t:
                            t_range[0][0] = min_stripe_t
                        if t_range[-1][1] < max_stripe_t:
                            t_range[-1][1] = max_stripe_t
                    """
                    会出现一种情况就是由于数据量很少，导致两个region的映射值范围是一样的，这时需要合并这两个region
                    """
                    tmp_models = []
                    tmp_errors = []
                    tmp_t_ranges = []
                    tmp_pos_ranges = []
                    assert 0 in break_points, print(break_points)
                    tmp_breakpoints = [0]
                    for ix in range(len(models)):
                        if models[ix][0] != models[ix][1] or ix == (len(models) - 1):
                            tmp_models.append(models[ix])
                            tmp_errors.append(errors[ix])
                            tmp_breakpoints.append(break_points[ix + 1])
                            tmp_t_ranges.append(t_range[ix])
                            tmp_pos_ranges.append(pos_range[ix])
                    models = tmp_models
                    errors = tmp_errors
                    break_points = tmp_breakpoints
                    t_range = tmp_t_ranges
                    pos_range = tmp_pos_ranges
                    new_stripe.set_breakpoints(break_points)
                    for ix in range(len(models) - 1):
                        assert models[ix][1] == models[ix+1][0], print(models)
                    assert len(errors) == len(models), print(len(models), len(errors))
                    assert len(break_points) == len(models) + 1, print(len(break_points), len(models))
                    # 根据分割点创建模型
                    for i in range(len(models)):
                        # print(f'模型起始块: {start_model_logic_block_id}, 结尾块: {end_model_logic_block_id}')
                        new_region = StripeRegion(start_mv=models[i][0],
                                                  end_mv=models[i][1],
                                                  base_point=models[i][2],
                                                  dv=models[i][3])
                        assert new_region.start_mv <= new_region.end_mv, print(new_region.start_mv, new_region.end_mv)
                        new_region.set_stripe(new_stripe)
                        model_block_id_range = new_region.get_model_block_id_range_by_mv_intersection(new_partition.W, models, i, logic_blocks)
                        # assert is_consecutive_incrementing(model_block_id_range), print("模型的块范围不连续", model_block_id_range)
                        if len(model_block_id_range) == 0:
                            start_model_logic_block_id = const.DEFAULT_REGION_BLOCK_RANGE[0]
                            end_model_logic_block_id = const.DEFAULT_REGION_BLOCK_RANGE[1]
                        else:
                            start_model_logic_block_id = min(model_block_id_range)
                            end_model_logic_block_id = max(model_block_id_range)
                        # 设置region的块范围、pos和t的范围
                        new_region.set_s_b_id(start_model_logic_block_id)
                        new_region.set_end_b_id(end_model_logic_block_id)
                        new_region.set_start_t(t_range[i][0])
                        new_region.set_end_t(t_range[i][1])
                        new_region.set_start_pos(pos_range[i][0])
                        new_region.set_end_pos(pos_range[i][1])
                        assert new_region.start_pos <= new_region.end_pos, print(new_region.start_pos, new_region.end_pos, region_num)
                        assert new_region.start_t <= new_region.end_t, print(new_region.start_t, new_region.end_t, region_num)

                        # 保存斜条内模型的全局序号,通过这个序号可以计算出模型的偏移量，进而计算出对应的块号
                        assert all(i >= 0 for i in new_region.dv), print(f'方向向量的分量存在负值')

                        # new_region.dv = [new_region.dv[0], new_region.dv[1], new_region.e_b_id - new_region.s_b_id]
                        # 设置模型初期的块范围和默认溢出块范围
                        new_region.period_block_range[0] = [start_model_logic_block_id, end_model_logic_block_id]
                        new_region.region_overflow_blocks[0] = const.DEFAULT_OVERFLOW_BLOCKS
                        # 获取region中的数据，用于后期数据的调整
                        new_stripe.region_list.append(new_region)
                        new_stripe.region_number_list.append(region_num)

                        new_region.set_global_region_num(region_num)
                        new_region.region_data_list = new_stripe.get_data_in_region(len(models) - 1, i, new_points, new_region.start_mv, new_region.end_mv)
                        new_region.set_zero_period_data_num(len(new_region.region_data_list))
                        new_region.set_zero_period_block_range(new_region.period_block_range[0])
                        new_region.period_ps_int[0] = new_region.base_point[0]
                        new_region.period_t_int[0] = new_region.base_point[1]
                        new_region.period_psc[0] = new_region.period_ps_int[0]
                        new_region.period_tc[0] = new_region.period_t_int[0]
                        new_region.rd_0 = models[i][2][2]
                        new_region.period_max_region_error_int[0] = errors[i]
                        model_error[new_region.global_region_num] = errors[i]
                        if region_num == 7620:
                            pass
                        print(f'period num = {n_p}, region_num = {region_num}, max_error = {new_region.period_max_region_error_int[0]}')
                        region_num += 1
                        partiiton_region_num += 1
    else:
        partition_list = load_model(const.partition_pkl[data_patten][n_p])

    """以下为IO操作，存储索引参数"""

    """计算第一个region块号"""
    if index_exist is False:
        # 保存每个分区的斜条数量
        for par in partition_list:
            insert_index_buffer.patition_stripe_num_list.append(len(par.stripe_list))
        cumulative_list = list(accumulate(insert_index_buffer.patition_stripe_num_list))
        # 计算总斜条数量
        total_stripe_num = sum(insert_index_buffer.patition_stripe_num_list)
        # with open(const.partition_file[data_patten][n_p], 'a') as f:
        #     f.write(f'总斜条数: {total_stripe_num}\n')
        print(f'总斜条数: {total_stripe_num}, 模型总数: {region_num}')
        # 计算斜条需要的块数
        total_stripe_block_num = math.ceil(total_stripe_num / const.STRIPE_BLOCK_ITEM_NUM)
        # 计算第一个模型块，由于需要知道斜条总数，所以只能在运行时确定这个值
        const.START_REGION_BLOCK_ID = const.START_STRIPE_BLOCK_ID + total_stripe_block_num

        max_period_range_block_id = 0
        max_partition_block_id = const.START_PARTITION_BLOCK_ID
        max_stripe_block_id = const.START_STRIPE_BLOCK_ID
        max_region_block_id = const.START_REGION_BLOCK_ID
        period_range_block_list = []
        for new_partition in partition_list:
            """每个分区的数据从新的一块开始，每个斜条的数据也从新的一块开始"""
            stripes = new_partition.sorted_stripes
            # 建立初始块存储分区参数
            if max_partition_block_id == const.START_PARTITION_BLOCK_ID:
                first_block = PartitionBlock(block_id=const.START_PARTITION_BLOCK_ID)
                max_partition_block_id += 1
                insert_index_buffer.add_block(first_block, n_p, data_patten)

            # 获得分区所属的索引块，每个索引块存满分区参数
            partion_block_id = insert_index_buffer.cal_partition_block_id(new_partition.partition_id)
            partion_block = PartitionBlock.get_partition_block(partion_block_id, insert_index_buffer, p_num=n_p, patten=data_patten)
            # 添加分区参数，包括：斜条斜率，t间隔（斜条宽度），底部斜线的截距
            partion_block.add_partition_param([new_partition.W,
                                               new_partition.t_interval,
                                               stripes[0][0]])
            if partion_block.is_overflow():
                max_partition_block_id += 1
                new_partition_block = partion_block.create_new_block()
                insert_index_buffer.add_block(new_partition_block, n_p, data_patten)


            # 保存斜条块和模型块，模型块的全局序号通过斜条的region_number_list获得
            # 起始模型序号即模型序号列表的第一个元素
            for stripe_numer, stripe in enumerate(new_partition.stripe_list):
                if const.START_STRIPE_BLOCK_ID == max_stripe_block_id:
                    first_stripe_block = StripeBlock(block_id=const.START_STRIPE_BLOCK_ID)
                    max_stripe_block_id += 1
                    insert_index_buffer.add_block(first_stripe_block, n_p, data_patten)

                # 获得斜条所属的索引块,每个斜条块也存满斜条参数
                stripe_block_id = insert_index_buffer.cal_stripe_block_id(new_partition.partition_id, stripe_numer, cumulative_list)
                stripe_block = StripeBlock.get_stripe_block(stripe_block_id, insert_index_buffer, n_p, data_patten)

                # 添加斜条参数，包括：模型起始全局序号，模型数量
                stripe_block.add_stripe_param([stripe.region_number_list[0], len(stripe.region_list)])
                # stripe_block.add_stripe_param([stripe.region_number_list[0], len(stripe.region_list)])
                if stripe_block.is_overflow():
                    max_stripe_block_id += 1
                    new_stripe_block = stripe_block.create_new_block()
                    insert_index_buffer.add_block(new_stripe_block, n_p, data_patten)

                # 保存模型参数，现在模型的块范围单独保存
                for global_region_number, region in zip(stripe.region_number_list, stripe.region_list):
                    # with open(const.model_info_file[data_patten][n_p], 'a') as f:
                    #     f.write(f'region {global_region_number} 数据量: {len(region.region_data_list)}\n')
                    if const.START_REGION_BLOCK_ID == max_region_block_id:
                        first_region_block = RegionBlock(const.START_REGION_BLOCK_ID)
                        max_region_block_id += 1
                        insert_index_buffer.add_block(first_region_block, n_p, data_patten)
                    # 通过模型的全局序号获得对应的索引块
                    region_block_id = insert_index_buffer.cal_region_block_id(global_region_number, const.START_REGION_BLOCK_ID)
                    region_block = RegionBlock.get_region_block(region_block_id, insert_index_buffer, n_p, data_patten)
                    # 添加模型参数，包括：起始pos，结束pos，直线上一点，方向向量
                    region_param = [region.start_mv, region.end_mv, region.base_point[0],
                                    region.base_point[1], region.base_point[2],
                                    region.dv[0], region.dv[1], int(region.dv[2])]
                    region_block.add_region_param(region_param)

                    # 判断region块是否溢出，直接新分配一块，然后加入索引缓冲
                    if region_block.is_overflow():
                        max_region_block_id += 1
                        new_region_block = region_block.create_new_block()
                        insert_index_buffer.add_block(new_region_block, n_p, data_patten)

                    # 保存第一期的模型块范围，对于周期范围块来说, 不设置缓冲
                    if max_period_range_block_id == 0:
                        first_period_range_block = PeriodRangeBlock(block_id=0)
                        period_range_block_list.append(first_period_range_block)
                        max_period_range_block_id += 1
                    period_range_block_id = Buffer.cal_period_range_block_id(global_region_number)
                    period_range_block = period_range_block_list[period_range_block_id]
                    period_range_block.add_model_block_range([region.period_block_range[n_p][0],
                                                             region.period_block_range[n_p][1],
                                                             region.region_overflow_blocks[n_p][0],
                                                             region.region_overflow_blocks[n_p][1]])
                    if period_range_block.is_overflow():
                        new_period_range_block = period_range_block.create_new_block()
                        period_range_block_list.append(new_period_range_block)
                        max_period_range_block_id += 1

        # 索引构建完成，将缓冲中的内容全部写入磁盘
        insert_index_buffer.update_to_disk(n_p, data_patten)
        insert_data_buffer.update_to_disk(n_p, data_patten)
        # 将初期的模型块范围写入文件
        insert_index_buffer.write_period_range_block(period_range_block_list, n_p, data_patten)
        # 写入起始模型块号和最大逻辑块号以便查询时查找
        start_r_b_id = struct.pack('I', const.START_REGION_BLOCK_ID)
        # 最大的逻辑块号是logic_block_count,而不是块数
        max_logic_block_id = struct.pack("I", logic_block_count)
        global_region_num = struct.pack('I', region_num)
        insert_index_buffer.dump(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 8, data=max_logic_block_id, p_num=n_p, patten=data_patten)
        insert_index_buffer.dump(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 4, data=start_r_b_id, p_num=n_p, patten=data_patten)
        # 保存最大的全局region编号, 8kb能保存(8192-12)/24 = 340个分区，340*24=8160，
        # 也就是还有8180-8160=20字节空空余，可以额外保存5个整数，目前保存了3个，后期保存4个，另外一个是最大的溢出块号
        insert_index_buffer.dump(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 12, data=global_region_num, p_num=n_p, patten=data_patten)
        # 将斜条数量累计列表持久化以便查询时使用
        dump_model(cumulative_list, const.cum_stripes_num_list)
        dump_model(partition_range_dict, const.partition_range_file)
        # 保存模型误差
        dump_model(model_error, const.PERIOD_MODEL_ERROR_FILE[data_patten][0])
        # dump_model(partition_list, const.partition_pkl[data_patten][n_p])
        end = time.time()
        time_use = end - start
        # 最大的全局region编号
        print(f'region_num in initial period: {region_num}')
        print(f'logic_block_count in initial period: {logic_block_count}')
        print(f'initial period building time: {end - start} s')
        fp.write(f'region_num in initial period: {region_num}\n'
                f'logic_block_count in initial period: {logic_block_count}\n'
                f'initial period building time: {end - start} s\n'
                 f'minimal error in period {n_p}: {min(model_error.values())}\n'
                 f'maximal error in period {n_p}: {max(model_error.values())}\n'
                 f'average error in period {n_p}: {round(sum(model_error.values()) / region_num, 3)}\n')
    else:
        time_use = time.time() - start
    return partition_list, time_use, region_num


def bulk_insert(initial_region_num, data_block_pool, fp, t_use, insert_points, n_p, bx, by, cum_stripe_num_list, max_logic_block_id, index_buffer, data_buffer, partiton_range, partition_list, region_num, start_region_block_id, data_patten="SIM"):
    """
    后期数据的插入，按照region插入，计算每个region的集成模型，当集成模型在各期数据中的误差大于指定值时需要重新分段
    """
    """
    原来是固定初期误差，后期阈值根据比例因子调整
    现在是固定后期误差，通过比例因子调整初期误差阈值
    """
    error_threshold = const.FOLLOW_ERROR
    index_exist = True
    if data_patten == 'SIM':
        print(f'===========================================================')
        print(f'=========================SIM DATA==========================')
    elif data_patten == 'REAL':
        print(f'======================== REAL DATA==========================')
    print(f'=============================================================')
    if const.TOM2:
        print('=================== TOM2 ====================')
    else:
        print('=================== TOM1 ====================')
    print(f'----------------period number: {n_p}--------------------------------')
    print(f'----------------total data number: {len(insert_points)}-------------------------')
    print(f'----------------logic block size: {const.LOGIC_BLOCK_SIZE} Bytes---------------')
    print(f'----------------error threshold: {error_threshold}------------------------')
    global_region_number_list = []
    model_error = {}  # 保存每个模型的实际误差，如果有新的region，则按照新的region的误差来
    model_error_decimal_list = []  # 保存error_bound，即使有新的region，也按照原来的region误差来
    visited_points = set()
    new_period_total_data_num = 0
    # 设置全局的最大溢出块号
    global_overflow_block_id = 0
    # 保存溢出文件中的逻辑块
    global_overflow_block_list = []
    first_new_model = False  # 记录第一次创建新模型
    logic_block_count = 0  # 逻辑块计数
    # 这个是后期数据的模型全局序号，如果没有新模型的创建，则这个值和初期时一样
    new_period_model_num = 0

    clean_file(const.INDEX_FILE[data_patten][n_p])
    clean_file(const.DATA_FILE[data_patten][n_p])
    clean_file(const.MODEL_ONE_PERIOD_INDEX_FILE[data_patten][n_p])
    clean_file(const.OVERFLOW_DATA_FILE[data_patten][n_p])
    clean_file(const.partition_pkl[data_patten][n_p])
    clean_file(const.PERIOD_MODEL_ERROR_FILE[data_patten][n_p])
    start = time.time()
    if not os.path.exists(const.partition_pkl[data_patten][n_p]):
        index_exist = False
        first_logic_block = data_block_pool.get_block(logic_block_count)
        data_buffer.add_dblock(first_logic_block, n_p, data_patten)
        logic_block_count += 1

        """
        插入步骤：
        1 通过bx，by定位partition，
        2 通过截距定位stripe
        3 通过mv定位region
        4 暂时保存region的数据，先不作处理
        5 在遍历完数据之后，再分配块以及更新stripe的region
        """
        for point in insert_points:
            cor_x = bisect.bisect_left(bx, point[0]) - 1
            cor_y = bisect.bisect_left(by, point[1]) - 1
            partition_id = cor_x * const.N_ROWS + cor_y
            partition = partition_list[partition_id]
            W = partition.W
            slope = partition.slope
            # 根据斜率计算t的截距
            intercept_t = point[1] - slope * point[0]
            # 底部截距
            bottom_intercept = partition.sorted_stripes[0][0]
            t_interval = partition.t_interval
            # 计算斜条序号
            lower_bound = (intercept_t - bottom_intercept) // t_interval - 1
            stripe_id = int(lower_bound) + 1  # 向上取整
            # 获取斜条
            stripe = partition.stripe_list[stripe_id]
            mv = np.round(np.dot(np.array(point), W), 3)
            # 通过mv匹配region
            for region in stripe.region_list:
                if region.start_mv <= mv <= region.end_mv:
                    region.new_region_data.append(point)
        # 分配region的新一期数据逻辑块
        for p_id, p_range in partiton_range.items():
            partiton = partition_list[p_id]
            for stripe in partiton.stripe_list:
                logic_blocks = set()
                overflow_logic_blocks = set()
                # 溢出块也要斜条另起一块
                new_overflow_logic_block = data_block_pool.get_block(global_overflow_block_id)
                stripe_first_of_block_id = new_overflow_logic_block.block_id
                global_overflow_block_list.append(new_overflow_logic_block)
                global_overflow_block_id += 1

                # 这两个是临时保存新建立的模型和模型编号，
                # 因为需要从斜条中取region时取的是原来的region,不设置临时列表会导致取到新建立的模型，
                # 这是不合理的
                tmp_stripe_new_region_list = []
                tmp_stripe_new_region_number_list = []

                # 当前斜条的模型数量
                stripe_model_num = len(stripe.region_list)
                cal_stripe_data_num = 0
                for idx, region in enumerate(stripe.region_list):
                    if (n_p == 1 or n_p == 2 or n_p == 3 or n_p == 4 or n_p == 5 or n_p == 6) and region.global_region_num == 5:
                        pass
                    # 指示当前region的结尾块是否和下一region的起始块相同, 会出现另外一种情况，就是region的
                    cur_region_end_id_equal_next_region_start_id = False
                    # 指示前期块范围是否默认值
                    pre_region_block_range_is_default = False
                    zero_period_block_range = region.zero_period_block_range  # 上一期模型的块范围
                    if zero_period_block_range == const.DEFAULT_REGION_BLOCK_RANGE:
                        pre_region_block_range_is_default = True
                    if idx != (stripe_model_num - 1):
                        next_region_block_range = stripe.region_list[idx + 1].zero_period_block_range
                        if zero_period_block_range[-1] == next_region_block_range[0]:
                            cur_region_end_id_equal_next_region_start_id = True
                    # 初始化默认块范围，表示没有溢出
                    region.period_block_range[n_p] = const.DEFAULT_REGION_BLOCK_RANGE
                    region.region_overflow_blocks[n_p] = const.DEFAULT_OVERFLOW_BLOCKS
                    """
                    第2期的块范围是在第1期的基础之上，如果第1期某个region的块范围是空的(默认值,也就是说这个模型是新模型)，则：
                    第2期的这个region块范围也设置成默认值，且如果第2期这个region的数据量不为0，则直接分配溢出块。
                    """
                    if not pre_region_block_range_is_default:
                        for b_id in range(zero_period_block_range[0], zero_period_block_range[1] + 1):
                            if b_id not in data_buffer.block_id_list[n_p]:
                                new_logic_block = data_block_pool.get_block(b_id)
                                logic_block_count += 1
                                data_buffer.add_dblock(new_logic_block, n_p, data_patten)
                        while data_buffer.is_full(n_p, data_patten):
                            data_buffer.fifo(n_p, data_patten)
                        is_con = is_consecutive_incrementing(data_buffer.block_id_list[n_p])
                        if not is_con:
                            full_list, to_add_block_ids = make_consecutive_incrementing(data_buffer.block_id_list[n_p])
                            for b_id in to_add_block_ids:
                                # new_logic_block = DataBlock(block_id=b_id)
                                new_logic_block = data_block_pool.get_block(b_id)
                                logic_block_count += 1
                                data_buffer.insert(new_logic_block, n_p, data_patten)
                            data_buffer.block_id_list[n_p] = full_list
                    new_region_data = region.new_region_data
                    # 由于有的点可能处于region边界，会获得重复点，需要唯一点
                    if len(new_region_data) != 0:
                        tmp_new_region_data = []
                        for point in new_region_data:
                            row_tuple = tuple(point)
                            if row_tuple in visited_points:
                                continue
                            else:
                                visited_points.add(row_tuple)
                                tmp_new_region_data.append(point)
                        new_region_data = np.array(tmp_new_region_data)
                    cal_stripe_data_num += len(new_region_data)
                    # 处理后期region无数据的情况
                    if len(new_region_data) == 0:
                        region.period_ps_int[n_p] = region.base_point[0]
                        region.period_t_int[n_p] = region.base_point[1]
                        region.period_psc[n_p] = region.base_point[0]
                        region.period_tc[n_p] = region.base_point[1]
                        region.period_max_region_error_int[n_p] = 0
                        if new_period_model_num == region_num and not first_new_model:
                            new_period_model_num = 0
                        tmp_stripe_new_region_number_list.append(new_period_model_num)
                        tmp_stripe_new_region_list.append(region)
                        global_region_number_list.append(new_period_model_num)
                        # model_error[region.global_region_num] = 0
                        model_error[new_period_model_num] = 0
                        model_error_decimal_list.append(max(region.period_max_region_error_int.values()))
                        region.global_region_num = new_period_model_num
                        new_period_model_num += 1
                        continue
                    """
                    插入新一期的数据：
                    插入数据按照模型（region）来，对后期中每一期每个模型中的数据：初始化模型当前期序号的块范围，默认是（0，0）
                    1   首先查找前期各期模型的块范围，如果有空则直接插入，否则转2
                    2   前期没有空判断当前期数模型的块范围：
                        1）如果(0, 0)则新分配一块，加入缓冲，最大块序号+1，模型的当前期数起始块设置为最大块序号
                        2）如果(x(x!=0), 0)则判断x是否满，没满直接插入，否则新分配一块，加入缓冲，最大块序号+1，模型的结尾块设置为最大块号
                        3) 如果(x,x)说明模型当前期的起始和结尾都已经溢出，则在这些块中查找，没满直接插入，否则新分配一块，加入缓冲，
                           最大块序号+1，模型的当前期结尾块设置为最大块号
            
                    """
                    # 指示后期region的数据量是否多余0期数据量
                    new_data_num_great_than_cur_data_num = False
                    zero_period_data_num = region.zero_period_data_num
                    new_region_data_num = len(new_region_data)
                    new_period_total_data_num += new_region_data_num
                    if new_region_data_num > zero_period_data_num:
                        new_data_num_great_than_cur_data_num = True
                    # 排序region数据
                    assert new_region_data.shape[1] == 2
                    mv = np.dot(new_region_data, partiton.W)
                    # 按mv值升序排序
                    sorted_indices = np.argsort(mv)
                    new_region_data = new_region_data[sorted_indices]
                    # 当前期数三个维度数据
                    rd_cur = np.empty(new_region_data.shape[0], dtype=np.int32)
                    ps_arr_cur = new_region_data[:, 0]
                    t_arr_cur = new_region_data[:, 1]
                    # 设置新一期的region起始块为第0期起始块
                    region.period_block_range[n_p] = zero_period_block_range
                    start_region_b_id = region.period_block_range[n_p][0]

                    region_logic_block_is_of = False  # 是否溢出的标志

                    """
                    如果前期的块范围是默认值，则代表当前期数直接溢出，需要选择溢出块，否则选择非溢出块
                    这种情况下就不用设置临时块，因为前期根本没有块，更不用谈最后一块非溢出块
                    """
                    # 指示是否创建新的溢出块
                    new_of_logic_block = False
                    if not pre_region_block_range_is_default:
                        logic_block = DataBlock.get_logic_block(start_region_b_id, data_buffer, n_p, data_patten)
                        logic_blocks.add(logic_block)
                    else:
                        if len(global_overflow_block_list) != 0:
                            if not global_overflow_block_list[-1].is_overflow():
                                logic_block = global_overflow_block_list[-1]
                            else:
                                logic_block = data_block_pool.get_block(logic_block_count)
                                new_of_logic_block = True
                        else:
                            logic_block = data_block_pool.get_block(0)
                            new_of_logic_block = True
                        if new_of_logic_block:
                            global_overflow_block_list.append(logic_block)
                            global_overflow_block_id += 1
                        overflow_logic_blocks.add(logic_block)
                        region_logic_block_is_of = True
                        overflow_start_block_id = logic_block.block_id
                    # 设置临时的最后一块，因为在迭代时logic_block这个变量一直在变，需要在溢出时将最后一个非溢出块赋给这个临时块
                    tmp_last_block = None
                    """分配新一期region的数据块"""
                    for i, dt in enumerate(new_region_data):
                        # 会出现一种情况就是拿到的块正好满了，而如果之间添加数据会溢出，需要先判断是否满
                        if logic_block.is_overflow():
                            # 还没溢出
                            if logic_block.block_id < region.period_block_range[n_p][1] and not region_logic_block_is_of:
                                logic_block = DataBlock.get_logic_block(logic_block.block_id + 1, data_buffer, n_p, data_patten)
                                logic_blocks.add(logic_block)
                                data_buffer.add_dblock(logic_block, n_p, data_patten)
                            # 刚刚溢出
                            elif logic_block.block_id == region.period_block_range[n_p][1] and not region_logic_block_is_of:
                                # 保存最后一块非溢出块副本，然后设置起始溢出块号
                                tmp_last_block = copy.deepcopy(logic_block)
                                if len(global_overflow_block_list) != 0:
                                    if not global_overflow_block_list[-1].is_overflow():
                                        logic_block = global_overflow_block_list[-1]
                                    else:
                                        # logic_block = DataBlock(block_id=global_overflow_block_id)
                                        logic_block = data_block_pool.get_block(global_overflow_block_id)
                                        new_of_logic_block = True
                                else:
                                    # logic_block = DataBlock(block_id=0)
                                    logic_block = data_block_pool.get_block(0)
                                    new_of_logic_block = True
                                if new_of_logic_block:
                                    global_overflow_block_list.append(logic_block)
                                    global_overflow_block_id += 1
                                overflow_logic_blocks.add(logic_block)
                                region_logic_block_is_of = True
                                tmp_last_block.set_overflow_block_id(logic_block.block_id)
                                # 在溢出时将原来放入缓冲的最后一块非溢出块替换为临时块
                                block_index = data_buffer.get_index_by_block_id(tmp_last_block.block_id, n_p, data_patten)
                                data_buffer.add_block_by_index(block_index, tmp_last_block, n_p, data_patten)
                                # logic_blocks中的逻辑块也需要更新，不更新的话可能有多个块号相同但是溢出块范围不同的逻辑块
                                for b in logic_blocks:
                                    if b.block_id == tmp_last_block.block_id:
                                        logic_blocks.remove(b)
                                        logic_blocks.add(tmp_last_block)
                            # 溢出多块
                            elif region_logic_block_is_of:
                                # logic_block = DataBlock(block_id=global_overflow_block_id)
                                logic_block = data_block_pool.get_block(global_overflow_block_id)
                                overflow_logic_blocks.add(logic_block)
                                global_overflow_block_list.append(logic_block)
                                global_overflow_block_id += 1

                        logic_block.add_point(dt)
                        # 设置数据的第三个维度，在没溢出时就是那个逻辑块号，如果溢出则设置为最后一个非溢出块号
                        if not region_logic_block_is_of:
                            rd_cur[i] = logic_block.block_id
                        else:
                            if not pre_region_block_range_is_default:
                                rd_cur[i] = region.period_block_range[n_p][1]
                            else:
                                # rd_cur[i] = logic_block.block_id
                                # 如果前期非溢出块范围是默认值则找到第一个不为默认值的那个region的结尾块
                                first_non_default = find_left_non_default(stripe.region_list, idx)
                                if first_non_default is None:
                                    first_non_default = find_right_non_default(stripe.region_list, idx)
                                assert first_non_default is not None
                                rd_cur[i] = first_non_default


                        """
                        在溢出时为最后一个非溢出块预留一半空间，前提是:
                        1   后期数据量多于前期数据量
                        2   前期后一个region的起始块不等于当前region的结尾块
                        3   当前处于未溢出的状态
                        """
                        if logic_block.block_id == region.period_block_range[n_p][1] and new_data_num_great_than_cur_data_num:
                            if cur_region_end_id_equal_next_region_start_id and not region_logic_block_is_of:
                                # 为最后一块非溢出块预留一半空间，以便后面的region存储
                                if len(logic_block.data_points) >= (const.LOGIC_BLOCK_CONTENT_SIZE // 2):
                                    # 保存最后一块非溢出块副本，然后设置起始溢出块号
                                    tmp_last_block = copy.deepcopy(logic_block)
                                    if len(global_overflow_block_list) != 0:
                                        if not global_overflow_block_list[-1].is_overflow():
                                            logic_block = global_overflow_block_list[-1]
                                        else:
                                            # logic_block = DataBlock(block_id=global_overflow_block_id)
                                            logic_block = data_block_pool.get_block(global_overflow_block_id)
                                            new_of_logic_block = True
                                    else:
                                        # logic_block = DataBlock(block_id=0)
                                        logic_block = data_block_pool.get_block(0)
                                        new_of_logic_block = True
                                    if new_of_logic_block:
                                        # overflow_logic_blocks.add(logic_block)
                                        global_overflow_block_list.append(logic_block)
                                        global_overflow_block_id += 1
                                    overflow_logic_blocks.add(logic_block)
                                    region_logic_block_is_of = True
                                    tmp_last_block.set_overflow_block_id(logic_block.block_id)
                                    # 在溢出时将原来放入缓冲的最后一块非溢出块替换为临时块
                                    block_index = data_buffer.get_index_by_block_id(tmp_last_block.block_id, n_p, data_patten)
                                    data_buffer.add_block_by_index(block_index, tmp_last_block, n_p, data_patten)
                                    # logic_blocks中的逻辑块也需要更新，不更新的话可能有多个块号相同但是溢出块范围不同的逻辑块
                                    for b in logic_blocks:
                                        if b.block_id == tmp_last_block.block_id:
                                            logic_blocks.remove(b)
                                            logic_blocks.add(tmp_last_block)
                                    continue
                        """
                        块满时分3种情况:
                        1   逻辑块小于最后一块且没溢出，则分配新的非溢出块
                        2   逻辑块等于最后一块且没溢出，设置溢出标志位true，设置起始溢出块号为当前最大溢出块号，分配第一块溢出块，加入溢出块列表，最大溢出块号加1
                        3   已经溢出，则分配一块新的溢出块，加入溢出块列表，最大溢出块号+1
                        """
                        if logic_block.is_overflow():
                            # 还没溢出
                            if logic_block.block_id < region.period_block_range[n_p][1] and not region_logic_block_is_of:
                                logic_block = DataBlock.get_logic_block(logic_block.block_id + 1, data_buffer, n_p, data_patten)
                                logic_blocks.add(logic_block)
                                data_buffer.add_dblock(logic_block, n_p, data_patten)
                                continue
                            # 刚刚溢出
                            if logic_block.block_id == region.period_block_range[n_p][1] and not region_logic_block_is_of:
                                # 保存最后一块非溢出块副本，然后设置起始溢出块号
                                tmp_last_block = copy.deepcopy(logic_block)
                                if len(global_overflow_block_list) != 0:
                                    if not global_overflow_block_list[-1].is_overflow():
                                        logic_block = global_overflow_block_list[-1]
                                    else:
                                        # logic_block = DataBlock(block_id=global_overflow_block_id)
                                        logic_block = data_block_pool.get_block(global_overflow_block_id)
                                        new_of_logic_block = True
                                else:
                                    # logic_block = DataBlock(block_id=0)
                                    logic_block = data_block_pool.get_block(0)
                                    new_of_logic_block = True
                                if new_of_logic_block:
                                    # overflow_logic_blocks.add(logic_block)
                                    global_overflow_block_list.append(logic_block)
                                    global_overflow_block_id += 1
                                region_logic_block_is_of = True
                                overflow_logic_blocks.add(logic_block)
                                tmp_last_block.set_overflow_block_id(logic_block.block_id)
                                # 在溢出时将原来放入缓冲的最后一块非溢出块替换为临时块
                                block_index = data_buffer.get_index_by_block_id(tmp_last_block.block_id, n_p, data_patten)
                                data_buffer.add_block_by_index(block_index, tmp_last_block, n_p, data_patten)
                                # logic_blocks中的逻辑块也需要更新，不更新的话可能有多个块号相同但是溢出块范围不同的逻辑块
                                for b in logic_blocks:
                                    if b.block_id == tmp_last_block.block_id:
                                        logic_blocks.remove(b)
                                        logic_blocks.add(tmp_last_block)
                                continue
                            # 溢出多块
                            if region_logic_block_is_of:
                                # logic_block = DataBlock(block_id=global_overflow_block_id)
                                logic_block = data_block_pool.get_block(global_overflow_block_id)
                                overflow_logic_blocks.add(logic_block)
                                global_overflow_block_list.append(logic_block)
                                global_overflow_block_id += 1
                                continue

                    # 会出现一种情况，最新的那一块的数据量为0，则需要舍去那一块
                    if len(logic_block.data_points) == 0:
                        if region_logic_block_is_of and logic_block.block_id > stripe_first_of_block_id and (idx == len(stripe.region_list) - 1):
                            global_overflow_block_id -= 1
                            global_overflow_block_list.pop(-1)
                            tmp_overflow_logic_blocks = {block for block in overflow_logic_blocks if block.block_id != logic_block.block_id}
                            overflow_logic_blocks = tmp_overflow_logic_blocks
                        else:
                            tmp_logic_blocks = {block for block in logic_blocks if block.block_id != logic_block.block_id}
                            logic_blocks = tmp_logic_blocks

                    # 会出现这种情况：新的region数据量没有第0期多，则其结尾块需要修改一下
                    if not region_logic_block_is_of and logic_block.block_id < region.period_block_range[n_p][1]:
                        region.period_block_range[n_p] = [region.period_block_range[n_p][0], logic_block.block_id]
                    # 设置溢出块数量
                    if region_logic_block_is_of:
                        # 只有临时块不为空时才赋值，否则代表前期块范围是默认值
                        if tmp_last_block is not None and not pre_region_block_range_is_default:
                            # 会出现当到达region最后一个点时正好溢出，此时溢出块是空的，也就是实际上这个region并没有溢出
                            # 但是tmp_last_block是存在的，而且设置了起始溢出块号
                            # 这时需要将tmp_last_block的起始溢出块号和溢出块数量设置成默认,同时将region的溢出也设置成默认
                            if global_overflow_block_id > tmp_last_block.overflow_block_id:
                                tmp_last_block.set_overflow_block_num(global_overflow_block_id - tmp_last_block.overflow_block_id)
                                region.region_overflow_blocks[n_p] = [tmp_last_block.overflow_block_id, tmp_last_block.overflow_block_id + tmp_last_block.overflow_block_num - 1]
                            else:
                                tmp_last_block.set_overflow_block_id(const.DEFAULT_OVERFLOW_BLOCKS[0])
                                tmp_last_block.set_overflow_block_num(const.DEFAULT_OVERFLOW_BLOCKS[1])
                                region.region_overflow_blocks[n_p] = const.DEFAULT_OVERFLOW_BLOCKS
                        # 前期块范围为空时将region的当前块范围设置为[默认值+起始溢出块号, 默认值+global_overflow_block_id]
                        else:
                            # region.period_block_range[n_p] = [const.DEFAULT_REGION_BLOCK_RANGE[0]+overflow_start_block_id, const.DEFAULT_REGION_BLOCK_RANGE[1] + global_overflow_block_id - 1]
                            region.region_overflow_blocks[n_p] = [overflow_start_block_id, global_overflow_block_id - 1]


                    """
                    以上为数据的更新，下面是索引的更新，包括模型参数（方向向量和基点）以及误差的更新
                    """
                    """ 
                    得到前期模型的参数，由于每期都需要用到rd0，所以这个需要专门保存
                    """
                    # 获得region的三维数据
                    rd_cur = rd_cur.reshape(new_region_data.shape[0], 1)
                    cur_region_three_dim_data = np.concatenate((new_region_data, rd_cur), axis=1)
                    cur_region_three_dim_data = np.atleast_2d(cur_region_three_dim_data)
                    region.region_data_list = np.concatenate((region.region_data_list, cur_region_three_dim_data), axis=0)
                    # 所有期共用方向向量，不同期数只有基点的前两个维度不同，集成模型基点的前2个维度取当前和前一期的平均值
                    pre_dv = region.dv  # (m, n, p)，这个方向向量在集成模型不超过阈值时是固定的
                    pre_base_pos = region.period_ps_int[n_p - 1]
                    pre_base_t = region.period_t_int[n_p - 1]
                    rd_0 = region.rd_0
                    # pre_base_point = region.base_point  # (xi, yi, zi)
                    pre_base_point_int = [pre_base_pos, pre_base_t, rd_0]
                    # 计算当前期数模型的2个参数，z轴使用初期的z0
                    tmp_pre_dv = copy.deepcopy(pre_dv)
                    # 约束分母不为0
                    if pre_dv[2] == 0:
                        tmp_pre_dv[2] = 1
                    # psc和tc
                    base_ps_cur, base_t_cur = cal_cur_model_base_pos_t(ps_arr_cur, t_arr_cur, rd_0, tmp_pre_dv, rd_cur)
                    # 计算集成模型，即取当前 和 前期集成 的平均
                    ps_int = (pre_base_point_int[0] + base_ps_cur) / 2
                    t_int = (pre_base_point_int[1] + base_t_cur) / 2
                    region.period_ps_int[n_p] = ps_int  # 保存每一期的集成模型的基点pos和t
                    region.period_t_int[n_p] = t_int
                    region.period_psc[n_p] = base_ps_cur
                    region.period_tc[n_p] = base_t_cur

                    # 利用集成模型计算当前期数数据的最大误差，即文中的Ai
                    cur_max_error = 0
                    for i, (ps, t) in enumerate(zip(ps_arr_cur, t_arr_cur)):
                        pre_z = SlantStripe.predict(input=[ps, t], coef_=[[ps_int, t_int, rd_0], region.dv])
                        cur_error = abs(pre_z - rd_cur[i])[0]
                        # 计算集成模型在当前期数的最大误差
                        if cur_error > cur_max_error:
                            cur_max_error = cur_error
                    # 保存当前期数的集成模型最大误差
                    # region.period_max_region_error_int[n_p] = cur_max_error

                    """
                    计算集成模型在目前为止所有期数据的最大误差：
                    1   计算err(D_k,M_i)，其中k取值为0-(i-1)，i=n_p
                    2   由于region保存有Ak信息，所以只需要比较err(D_k,M_i)和Ak的最大值即可
                    3   如果这个误差超过设定阈值，则需要在目前为止所有期数据上重新训练模型，
                    """

                    # 获得初始的3个系数
                    p_0 = region.dv[2]
                    m_0 = region.dv[0]
                    n_0 = region.dv[1]


                    # -------------------------改版后的误差计算(basic model error determination)----------------------------
                    """
                    1   计算集成模型在前期各期中的最大误差，由于改版后只需要计算递推的误差即可，即前一期的集成模型在所有期的误差最大值(对应E^i-1)
                    与当前集成模型的误差扩张(对应公式38的后半部分)的和。
                    2   improved error determination：
                        当集成模型的分量在当前region的对应分量范围内时，这个分量不会引起太大误差
                    
                    """
                    # 获得region的两个分量的范围
                    min_region_pos = region.start_pos
                    max_region_pos = region.end_pos
                    min_region_t = region.start_t
                    max_region_t = region.end_t
                    # 上一期的集成模型在前面所有期中的最大误差
                    # max_error_of_pre_int_model_on_all_period = region.period_max_region_error_int[n_p - 1]
                    max_error_of_pre_int_model_on_all_period = max(region.period_max_region_error_int.values())
                    # 初始化两个分量引起的误差为公式34的后半部分
                    pos_error = abs(p_0 * (base_ps_cur - region.period_ps_int[n_p - 1]) / (4 * m_0))
                    t_error = abs(p_0 * (base_t_cur - region.period_t_int[n_p - 1]) / (4 * n_0))
                    # --------------------------改版后的误差(improved error determination)-------------------------
                    if const.TOM2:
                        if min_region_pos <= ps_int <= max_region_pos:
                            pos_error = 0
                        if min_region_t <= t_int <= max_region_t:
                            t_error = 0
                    # 当前集成模型在前期所有期中的最大误差
                    max_error_of_cur_int_model_on_pre_all_period = int(max_error_of_pre_int_model_on_all_period + pos_error + t_error)
                    error_bound_in_pre_all_period = round(max_error_of_pre_int_model_on_all_period + pos_error + t_error, 3)
                    # 当前集成模型在当前期数的误差
                    A_i = cur_max_error
                    # 当前集成模型在所有期的最大误差
                    max_error_of_cur_int_model_on_all_period = max(max_error_of_cur_int_model_on_pre_all_period, A_i)
                    error_bound_in_all_period = max(A_i, error_bound_in_pre_all_period)
                    if error_bound_in_all_period == 0:
                        pass
                    # print(f'period number: {n_p}, region number: {region.global_region_num}, 计算集成模型误差的时间开销: {time.time() - s_time}')

                    # --------------------------下面是改版前的误差计算-------------------------
                    # 集成模型在前期各期数据中的误差上界，即err(D_k,M_i)数组，列表长度为n_p
                    # int_model_over_pre_data_error_list = []
                    # for period_n in range(n_p):
                    #     upp_error_bound = cal_model_max_error_over_pre(Ak=region.period_max_region_error_int[period_n],
                    #                                                    P0=region.dv[2],
                    #                                                    m0=region.dv[0],
                    #                                                    n0=region.dv[1],
                    #                                                    i=n_p, k=period_n,
                    #                                                    pscj=[region.period_psc[j] for j in range(period_n + 1, n_p+1)],
                    #                                                    psk=region.period_ps_int[period_n],
                    #                                                    tcj=[region.period_tc[j] for j in range(period_n + 1, n_p+1)],
                    #                                                    tk=region.period_t_int[period_n])
                    #     int_model_over_pre_data_error_list.append(int(upp_error_bound))
                    # # 集成模型在当前期数的最大误差
                    # A_i = region.period_max_region_error_int[n_p]
                    # # 取当前集成模型在所有期数据中的误差最大值
                    # max_error_over_all_period = int(max([A_i] + int_model_over_pre_data_error_list))

                    """
                    如果这个集成误差大于指定阈值阈值则需要重新训练所有期数据:
                    1   需要在斜条的原region列表中删除这个region
                    2   重新训练时的误差阈值和原来一样，以索引大小为代价提升查询效率
                    3   region计数从第一次创建新模型那里的region_num开始，新创建的模型会使region_num递增，其后的模型全局计数也要往后移
                    4   对于新模型的块范围，利用旧模型的各期块范围来计算新模型的范围
                    5   一旦创建新模型（即误差超过指定阈值）则region计数按照new_period_model_num来
                    """
                    # print(f'period number: {n_p}, region number: {region.global_region_num}, 集成模型最大误差: {max_error_over_all_period}')
                    print(f'period number: {n_p}, region number: {region.global_region_num}, max error of integrated model: {error_bound_in_all_period}')

                    # if max_error_over_all_period > error_threshold:
                    # model_error_decimal_list.append(error_bound_in_all_period)
                    # if max_error_of_cur_int_model_on_all_period > error_threshold:
                    if error_bound_in_all_period > error_threshold:
                        # 按照第一次误差超过2et创建新模型开始计算new_period_model_num
                        if first_new_model is False:
                            first_new_model = True
                            # new_period_model_num = cur_region_number

                        # 获得各期数据，并获得3个维度的数据
                        all_period_data = region.region_data_list
                        mv = np.dot(all_period_data[:, :2], partiton.W)
                        # 按mv值升序排序
                        sorted_indices = np.argsort(mv)
                        all_period_data = all_period_data[sorted_indices]
                        region.region_data_list = all_period_data

                        timestamps = all_period_data[:, 1]
                        edge_positions = all_period_data[:, 0]
                        logic_block_num = all_period_data[:, 2]

                        """
                        重新训练所有期的数据，模型数量有2种情况：
                        1）大于1，这个几率更大 
                        2）还是1个模型，这是由于重新训练时的模型不再是集成模型，而是一个最优的模型
                        """
                        break_points, models, errors, t_ranges, pos_range = stripe.douglas_peucker(timestamps=timestamps, edge_positions=edge_positions, indices=logic_block_num, epsilon=error_threshold)
                        models.reverse()
                        errors.reverse()
                        t_ranges.reverse()
                        pos_range.reverse()

                        W = partiton.W
                        # 更正边界上的mv
                        # if region.start_mv < models[0][0]:
                        models[0][0] = region.start_mv
                        # if region.end_mv > models[-1][1]:
                        models[-1][1] = region.end_mv
                        # if partiton.slope > 0:
                        #     if partiton.W[0] > 0 and partiton.W[1] > 0:
                        #         tmp_mv = np.round(np.dot(np.array([start_pos, start_t]), W), 3)
                        #         if tmp_mv < models[0][0]:
                        #             models[0][0] = tmp_mv
                        #         tmp_mv = np.round(np.dot(np.array([end_pos, end_t]), W), 3)
                        #         if tmp_mv > models[-1][1]:
                        #             models[-1][1] = tmp_mv
                        #     else:
                        #         tmp_mv = np.round(np.dot(np.array([end_pos, end_t]), W), 3)
                        #         if tmp_mv < models[0][0]:
                        #             models[0][0] = tmp_mv
                        #         tmp_mv = np.round(np.dot(np.array([start_pos, start_t]), W), 3)
                        #         if tmp_mv > models[-1][1]:
                        #             models[-1][1] = tmp_mv
                        # else:
                        #     if partiton.W[0] > 0 and partiton.W[1] < 0:
                        #         tmp_mv = np.round(np.dot(np.array([start_pos, end_t]), W), 3)
                        #         if tmp_mv < models[0][0]:
                        #             models[0][0] = tmp_mv
                        #         tmp_mv = np.round(np.dot(np.array([end_pos, start_t]), W), 3)
                        #         if tmp_mv > models[-1][1]:
                        #             models[-1][1] = tmp_mv
                        #     else:
                        #         tmp_mv = np.round(np.dot(np.array([end_pos, start_t]), W), 3)
                        #         if tmp_mv < models[0][0]:
                        #             models[0][0] = tmp_mv
                        #         tmp_mv = np.round(np.dot(np.array([start_pos, end_t]), W), 3)
                        #         if tmp_mv > models[-1][1]:
                        #             models[-1][1] = tmp_mv

                        # 更正边界上region的pos和t
                        if W[0] > 0 and W[1] > 0:
                            if pos_range[0][0] > min_region_pos:
                                pos_range[0][0] = min_region_pos
                            if pos_range[-1][1] < max_region_pos:
                                pos_range[-1][1] = max_region_pos
                            if t_ranges[0][0] > min_region_t:
                                t_ranges[0][0] = min_region_t
                            if t_ranges[-1][1] < max_region_t:
                                t_ranges[-1][1] = max_region_t
                        elif W[0] < 0 and W[1] < 0:
                            if pos_range[-1][0] > min_region_pos:
                                pos_range[-1][0] = min_region_pos
                            if pos_range[0][1] < max_region_pos:
                                pos_range[0][1] = max_region_pos
                            if t_ranges[-1][0] > min_region_t:
                                t_ranges[-1][0] = min_region_t
                            if t_ranges[0][1] < max_region_t:
                                t_ranges[0][1] = max_region_t
                        elif W[0] > 0 and W[1] < 0:
                            if pos_range[0][0] > min_region_pos:
                                pos_range[0][0] = min_region_pos
                            if pos_range[-1][1] < max_region_pos:
                                pos_range[-1][1] = max_region_pos
                            if t_ranges[-1][0] > min_region_t:
                                t_ranges[-1][0] = min_region_t
                            if t_ranges[0][1] < max_region_t:
                                t_ranges[0][1] = max_region_t
                        else:
                            if pos_range[-1][0] > min_region_pos:
                                pos_range[-1][0] = min_region_pos
                            if pos_range[0][1] < max_region_pos:
                                pos_range[0][1] = max_region_pos
                            if t_ranges[0][0] > min_region_t:
                                t_ranges[0][0] = min_region_t
                            if t_ranges[-1][1] < max_region_t:
                                t_ranges[-1][1] = max_region_t
                        tmp_models = []
                        tmp_errors = []
                        tmp_t_ranges = []
                        tmp_pos_ranges = []
                        for ix in range(len(models)):
                            if models[ix][0] != models[ix][1] or ix == (len(models) - 1):
                                tmp_models.append(models[ix])
                                tmp_errors.append(errors[ix])
                                tmp_t_ranges.append(t_ranges[ix])
                                tmp_pos_ranges.append(pos_range[ix])
                        models = tmp_models
                        errors = tmp_errors
                        t_ranges = tmp_t_ranges
                        pos_range = tmp_pos_ranges
                        for ix in range(len(models) - 1):
                            assert models[ix][1] == models[ix + 1][0]
                        assert len(errors) == len(models), print(f'误差数组长度和模型数量不一致！')
                        # print(f'partition_id={p_id}, stripe_id={stripe.stripe_id}, 各期总数据量: {len(all_period_data)}, 当前期数数据量: {len(new_region_data)}, 新模型数量: {len(models)}')
                        for m in range(len(models)):
                            # 指示是否有溢出块范围，如果有则需要设置新模型的溢出块范围
                            region_of_blocks = False
                            start_model_of_logic_block_id = None
                            end_model_of_logic_block_id = None
                            model_block_id_range = StripeRegion.get_model_block_id_range_by_mv_intersection(partiton.W, models, m, logic_blocks)
                            # 可能出现为空的情况，主要是新一期的数据的pos范围没有涵盖models的全部的pos范围，
                            # 或者说models有的模型的pos范围只在旧期的数据上，例如新一期的数据pos全是52743.319，
                            # 而models的有个模型pos范围在52745.959到52747.582，这时这个模型在新一期的块就是空的
                            # 然后设置成默认的块范围，在查询时如果是默认的块范围则直接跳过该region
                            if len(model_block_id_range) == 0:
                                start_model_logic_block_id = const.DEFAULT_REGION_BLOCK_RANGE[0]
                                end_model_logic_block_id = const.DEFAULT_REGION_BLOCK_RANGE[1]
                            else:
                                start_model_logic_block_id = min(model_block_id_range)
                                end_model_logic_block_id = max(model_block_id_range)
                            # 设置溢出块范围，前提是已经溢出而且溢出块列表不为空
                            model_overflow_id_range = []
                            if len(overflow_logic_blocks) != 0 and region_logic_block_is_of:
                                region_of_blocks = True
                                model_overflow_id_range = StripeRegion.get_model_block_id_range_by_mv_intersection(partiton.W, models, m, overflow_logic_blocks)
                                # is_con_incre = is_consecutive_incrementing(model_overflow_id_range)
                                # assert is_con_incre, print(f'模型的溢出块范围不连续, {model_overflow_id_range}')
                                if len(model_overflow_id_range) == 0:
                                    start_model_of_logic_block_id = const.DEFAULT_REGION_BLOCK_RANGE[0]
                                    end_model_of_logic_block_id = const.DEFAULT_REGION_BLOCK_RANGE[1]
                                else:
                                    start_model_of_logic_block_id = min(model_overflow_id_range)
                                    end_model_of_logic_block_id = max(model_overflow_id_range)

                            new_region = StripeRegion(start_mv=models[m][0],
                                                      end_mv=models[m][1],
                                                      base_point=models[m][2],
                                                      dv=models[m][3],
                                                      s_b_id=start_model_logic_block_id,
                                                      e_b_id=end_model_logic_block_id)
                            assert new_region.start_mv <= new_region.end_mv, print(new_region.start_mv, new_region.end_mv)
                            new_region.set_stripe(stripe)
                            # 设置新region的pos和t范围
                            new_region.set_start_t(t_ranges[m][0])
                            new_region.set_end_t(t_ranges[m][1])
                            new_region.set_start_pos(pos_range[m][0])
                            new_region.set_end_pos(pos_range[m][1])

                            new_region.period_block_range[n_p] = [start_model_logic_block_id, end_model_logic_block_id]
                            new_region.region_data_list = stripe.get_data_in_region(len(models)-1, m,
                                                                                    region.region_data_list,
                                                                                    new_region.start_mv,
                                                                                    new_region.end_mv)

                            new_region.set_zero_period_data_num(len(new_region.region_data_list))
                            new_region.set_zero_period_block_range(new_region.period_block_range[n_p])
                            if region_of_blocks:
                                new_region.region_overflow_blocks[n_p] = [start_model_of_logic_block_id, end_model_of_logic_block_id]
                            else:
                                new_region.region_overflow_blocks[n_p] = const.DEFAULT_OVERFLOW_BLOCKS
                            # 设置新模型的前期参数都为默认值
                            new_region.rd_0 = models[m][2][2]  # 新模型的rd_0设置为当前期数的rd
                            # 设置新模型的当前基点和集成基点
                            new_region.period_ps_int[n_p] = new_region.base_point[0]
                            new_region.period_t_int[n_p] = new_region.base_point[1]
                            new_region.period_psc[n_p] = new_region.base_point[0]
                            new_region.period_tc[n_p] = new_region.base_point[1]
                            new_region.period_max_region_error_int[n_p] = errors[m]
                            new_region.set_global_region_num(new_period_model_num)

                            model_error[new_period_model_num] = errors[m]
                            model_error_decimal_list.append(errors[m])
                            tmp_stripe_new_region_list.append(new_region)
                            tmp_stripe_new_region_number_list.append(new_period_model_num)
                            global_region_number_list.append(new_period_model_num)
                            new_period_model_num += 1
                    else:
                        region.base_point = [ps_int, t_int, rd_0]  # 更新基点
                        region.period_max_region_error_int[n_p] = error_bound_in_all_period  # 更新集成模型最大误差
                        # 更新region的两个维度范围和映射值范围
                        region.start_pos = min(np.min(ps_arr_cur), region.start_pos)
                        region.end_pos = max(np.max(ps_arr_cur), region.end_pos)
                        region.start_t = min(np.min(t_arr_cur), region.start_t)
                        region.end_t = max(np.max(t_arr_cur), region.end_t)
                        region.start_mv = min(region.start_mv, np.min(mv))
                        region.end_mv = max(region.end_mv, np.max(mv))

                        tmp_stripe_new_region_list.append(region)
                        # 这个是防止第一个全局模型的误差没有超过指定阈值导致初始的全局模型序号等于传过来的region_num，将其设为0
                        if new_period_model_num == region_num and not first_new_model:
                            new_period_model_num = 0
                        tmp_stripe_new_region_number_list.append(new_period_model_num)
                        global_region_number_list.append(new_period_model_num)

                        # 如果集成模型误差没超过阈值，则保存这个误差
                        # model_error[new_period_model_num] = max_error_over_all_period
                        model_error[new_period_model_num] = max_error_of_cur_int_model_on_all_period
                        model_error_decimal_list.append(error_bound_in_all_period)
                        region.global_region_num = new_period_model_num
                        new_period_model_num += 1
                # assert cal_stripe_data_num == real_stripe_data_num, print(f'real_stripe_data_num = {real_stripe_data_num}, cal_stripe_data_num = {cal_stripe_data_num}, stripe_region_num = {stripe_model_num}')
                stripe.region_list = tmp_stripe_new_region_list
                stripe.region_number_list = tmp_stripe_new_region_number_list

    else:
        partition_list = load_model(const.partition_pkl[data_patten][n_p])

    if index_exist is False:
        # assert len(model_error_decimal_list) == new_period_model_num
        # model_error_decimal_np_arr = np.array(model_error_decimal_list)
        assert new_period_total_data_num == len(insert_points), print(f'new_period_total_data_num={new_period_total_data_num}, len(insert_points)={len(insert_points)}')
        assert len(visited_points) == len(insert_points), print(f'len(visited_points)={len(visited_points)}, len(insert_points)={len(insert_points)}')
        """
        保存模型和块范围，基本和第0期一致，只是在保存块范围时包括多种情况，第0期所有的region的非溢出块范围都不为空，
        但是后期因为数据量的不一致可能导致其region的非溢出块范围为空。
        """
        max_partition_block_id = const.START_PARTITION_BLOCK_ID
        max_stripe_block_id = const.START_STRIPE_BLOCK_ID
        max_region_block_id = start_region_block_id
        max_period_range_block_id = 0
        period_range_block_list = []
        for new_partition in partition_list:
            stripes = new_partition.sorted_stripes
            # 建立初始块存储分区参数
            if max_partition_block_id == const.START_PARTITION_BLOCK_ID:
                first_block = PartitionBlock(block_id=const.START_PARTITION_BLOCK_ID)
                max_partition_block_id += 1
                index_buffer.add_block(first_block, n_p, data_patten)
            # 获得分区所属的索引块，每个索引块存满分区参数
            partion_block_id = index_buffer.cal_partition_block_id(new_partition.partition_id)
            partion_block = PartitionBlock.get_partition_block(partion_block_id, index_buffer, p_num=n_p,
                                                               patten=data_patten)
            # 添加分区参数，包括：斜条斜率，t间隔（斜条宽度），底部斜线的截距
            partion_block.add_partition_param([new_partition.W,
                                               new_partition.t_interval,
                                               stripes[0][0]])
            if partion_block.is_overflow():
                new_partition_block = partion_block.create_new_block()
                max_partition_block_id += 1
                index_buffer.add_block(new_partition_block, n_p, data_patten)

            # 保存斜条块和模型块，模型块的全局序号通过斜条的region_number_list获得
            # 起始模型序号即模型序号列表的第一个元素
            for stripe_numer, stripe in enumerate(new_partition.stripe_list):
                if max_stripe_block_id == const.START_STRIPE_BLOCK_ID:
                    first_stripe_block = StripeBlock(block_id=const.START_STRIPE_BLOCK_ID)
                    max_stripe_block_id += 1
                    insert_index_buffer.add_block(first_stripe_block, n_p, data_patten)
                # 获得斜条所属的索引块,每个斜条块也存满斜条参数
                stripe_block_id = insert_index_buffer.cal_stripe_block_id(new_partition.partition_id, stripe_numer,
                                                                          cum_stripe_num_list)
                stripe_block = StripeBlock.get_stripe_block(stripe_block_id, insert_index_buffer, n_p, data_patten)
                # 添加斜条参数，包括：模型起始全局序号，模型数量
                stripe_block.add_stripe_param([stripe.region_number_list[0], len(stripe.region_list)])
                # stripe_block.add_stripe_param([stripe.region_number_list[0], len(stripe.region_list)])
                if stripe_block.is_overflow():
                    new_stripe_block = stripe_block.create_new_block()
                    max_stripe_block_id += 1
                    insert_index_buffer.add_block(new_stripe_block, n_p, data_patten)

                # 保存模型参数，现在模型的块范围单独保存
                for global_region_number, region in zip(stripe.region_number_list, stripe.region_list):
                    # 更新完一期数据后，重置region的新一期数据
                    region.new_region_data = []
                    # 每一期的斜条数量相同，所以起始region块号是相同的
                    if max_region_block_id == start_region_block_id:
                        first_region_block = RegionBlock(start_region_block_id)
                        max_region_block_id += 1
                        insert_index_buffer.add_block(first_region_block, n_p, data_patten)
                    # 通过模型的全局序号获得对应的索引块
                    region_block_id = insert_index_buffer.cal_region_block_id(global_region_number,
                                                                              start_region_block_id)
                    region_block = RegionBlock.get_region_block(region_block_id, insert_index_buffer, n_p, data_patten)
                    # 添加模型参数，包括：起始pos，结束pos，直线上一点，方向向量
                    region_param = [region.start_mv, region.end_mv, region.base_point[0],
                                    region.base_point[1], region.base_point[2],
                                    region.dv[0], region.dv[1], int(region.dv[2])]
                    region_block.add_region_param(region_param)

                    # 判断region块是否溢出，直接新分配一块，然后加入索引缓冲
                    if region_block.is_overflow():
                        max_region_block_id += 1
                        new_region_block = region_block.create_new_block()
                        insert_index_buffer.add_block(new_region_block, n_p, data_patten)

                    # 保存后期的模型块范围，对于周期范围块来说, 不设置缓冲
                    if max_period_range_block_id == 0:
                        first_period_range_block = PeriodRangeBlock(block_id=0)
                        period_range_block_list.append(first_period_range_block)
                        max_period_range_block_id += 1
                    period_range_block_id = Buffer.cal_period_range_block_id(global_region_number)
                    period_range_block = period_range_block_list[period_range_block_id]
                    """
                    添加后期region块范围时包括3种情况：
                    1   非溢出块范围不是默认值且溢出块范围为空(即是原始的空字典{}或者默认值)，则直接保存非溢出块范围
                    2   非溢出块范围不是默认值且溢出块范围不为空，也是直接保存非溢出块范围
                    3   非溢出块范围是默认值且溢出块范围为空，则保存默认值
                    4   非溢出块范围是默认值且溢出块范围不是默认值，则保存[默认值+起始溢出块号, 默认值+结尾溢出块号]
                    非溢出块范围是默认值代表该期数据在该region内无数据，溢出块范围是默认值代表没有溢出。
                    """
                    period_range_block.add_model_block_range([region.period_block_range[n_p][0],
                                                              region.period_block_range[n_p][1],
                                                              region.region_overflow_blocks[n_p][0],
                                                              region.region_overflow_blocks[n_p][1]])

                    if period_range_block.is_overflow():
                        new_period_range_block = period_range_block.create_new_block()
                        period_range_block_list.append(new_period_range_block)
                        max_period_range_block_id += 1

        index_buffer.update_to_disk(n_p, data_patten)
        data_buffer.update_to_disk(n_p, data_patten)
        # 保存溢出块和region范围块
        print(f'max overflow block id in period {n_p}: {global_overflow_block_id - 1}')
        f.write(f'max overflow block id in period {n_p}: {global_overflow_block_id - 1}\n')
        data_buffer.write_period_overflow_block(global_overflow_block_list, n_p, data_patten)
        insert_index_buffer.write_period_range_block(period_range_block_list, n_p, data_patten)
        end = time.time()
        time_use = end - start
        total_time = time_use + t_use
        # 写入四个常量: 起始region的块号，最大逻辑块号，最大全局region序号, 最大溢出块号
        max_logic_b_id = struct.pack("I", logic_block_count - 1)
        global_region_num = struct.pack('I', new_period_model_num)
        start_r_b_id = struct.pack('I', start_region_block_id)
        max_of_b_id = struct.pack('I', global_overflow_block_id - 1)
        insert_index_buffer.dump(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 4, data=start_r_b_id, p_num=n_p, patten=data_patten)
        insert_index_buffer.dump(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 8, data=max_logic_b_id, p_num=n_p, patten=data_patten)
        insert_index_buffer.dump(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 12, data=global_region_num, p_num=n_p, patten=data_patten)
        insert_index_buffer.dump(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 16, data=max_of_b_id, p_num=n_p, patten=data_patten)
        # dump_model(partition_list, const.partition_pkl[data_patten][n_p])
        dump_model(model_error, const.PERIOD_MODEL_ERROR_FILE[data_patten][n_p])
        dump_model(model_error_decimal_list, const.PERIOD_MODEL_ERROR_BOUND_FILE[data_patten][n_p])
        print(f'max_logic_block_id in period {n_p}: {logic_block_count - 1}')
        print(f'max_global_region_num in period {n_p}: {new_period_model_num - 1}')
        print(f'pre period region_num: {region_num}')
        print(f'new region number in period {n_p}: {(new_period_model_num - region_num)}')
        print(f'period {n_p} building time: {end - start} s')
        fp.write(f'max_logic_block_id in period {n_p}: {logic_block_count - 1}\n'
                 f'max_global_region_num in period {n_p}: {new_period_model_num}\n'
                 f'pre period region_num: {region_num}\n'
                 f'new region number in period {n_p}: {(new_period_model_num - region_num)}\n'
                 f'{n_p + 1} period building time: {total_time} s\n'
                 f'minimal error in period {n_p}: {min(model_error_decimal_list)}\n'
                 f'maximal error in period {n_p}: {max(model_error_decimal_list)}\n'
                 f'average error in period {n_p}: {round(sum(model_error_decimal_list) / initial_region_num, 3)}\n')
    else:
        end = time.time()
        time_use = end - start
        total_time = time_use + t_use
    return partition_list, total_time, new_period_model_num


def get_index_size(fp, p_num, data_patten, region_num):
    total_size = 0
    # 辅助结构
    total_size += os.path.getsize(const.x_boundary_file)
    total_size += os.path.getsize(const.y_boundary_file)
    total_size += os.path.getsize(const.cum_stripes_num_list)
    # 模型大小
    common_index_file = const.INDEX_FILE[data_patten][p_num]
    total_size += os.path.getsize(common_index_file)
    # region块范围
    cur_period_block_range_file = const.MODEL_ONE_PERIOD_INDEX_FILE[data_patten][p_num]
    total_size += os.path.getsize(cur_period_block_range_file)
    # 模型误差
    model_errors = load_model(const.PERIOD_MODEL_ERROR_FILE[data_patten][p_num])
    total_size += len(model_errors) * 4  # 每个误差使用4字节的int类型
    # TOM2需要增加region的边界（4个值，double）
    if const.TOM2:
        total_size += region_num * 32
    print(f'{p_num + 1} periods total index size: {total_size / 1024} KB')
    if p_num == 0:
        fp.write(f'{p_num + 1} period total index size: {total_size / 1024} KB\n')
    else:
        fp.write(f'{p_num + 1} periods total index size: {total_size / 1024} KB\n')


if __name__ == '__main__':
    """
    注：本索引基于浮点数构建，在构建之前请先将数据处理为保留小于等于3位小数，并修改const模块中的
    MAX_POS_SIM、MAX_T_SIM、MAX_POS_REAL、MAX_T_REAL为您的两个维度的最大值+1(稍微比最大值大即可),
    MIN_POS_SIM、MIN_T_SIM、MIN_POS_REAL、MIN_T_REAL为您的两个维度的最小值-1(稍微比最小值小即可)。
    """
    # 数据分布
    data_patten = const.PATTEN
    insert_index_buffer = InsertIndexBuffer()
    insert_data_buffer = InsertDataBuffer()
    init_data_file = const.ORI_FILE[data_patten][0]
    # 初始化逻辑块对象池
    data_block_pool = DataBlockPool(initial_size=5000)
    # 初期构建
    check_dir(path=const.MODEL_ONE_PERIOD_INDEX_DIR[data_patten][0])
    f = open(const.PERIOD_BUILDING_RESULT_FILE[data_patten][0], 'w')
    partition_list, time_use, region_num = build_initial_period(data_block_pool, init_data_file, insert_index_buffer, insert_data_buffer, f, data_patten=data_patten)
    data_block_pool.release_all()
    get_index_size(f, 0, data_patten, region_num)
    f.close()
    # 加载边界值
    bx = load_model(const.x_boundary_file)
    by = load_model(const.y_boundary_file)
    # 加载分区的范围
    partiton_range = load_model(const.partition_range_file)
    # 加载分区的累计斜条数量列表，这两个列表是不变的
    cum_stripes_num_list = load_model(const.cum_stripes_num_list)
    all_result_file_list = [const.PERIOD_BUILDING_RESULT_FILE[data_patten][0]]
    initial_region_num = struct.unpack('I', Buffer.load(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 12,
                                                       data_size=4, p_num=0, patten=data_patten))[0]
    # 构建后期
    for i in range(1, const.PERIOD_NUM):
        check_dir(path=const.MODEL_ONE_PERIOD_INDEX_DIR[data_patten][i])
        all_result_file_list.append(const.PERIOD_BUILDING_RESULT_FILE[data_patten][i])
        start_region_block_id = struct.unpack("I", Buffer.load(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 4,
                                                               data_size=4, p_num=i-1, patten=data_patten))[0]
        max_logic_id = struct.unpack('I', Buffer.load(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 8,
                                                      data_size=4, p_num=i-1, patten=data_patten))[0]
        global_region_num = struct.unpack('I', Buffer.load(pos=const.START_STRIPE_BLOCK_ID * const.BLOCK_SIZE - 12,
                                                           data_size=4, p_num=i-1, patten=data_patten))[0]
        data = read_txt_to_list(const.ORI_FILE[data_patten][i])
        f = open(const.PERIOD_BUILDING_RESULT_FILE[data_patten][i], 'w')
        partition_list, time_use, region_num = bulk_insert(initial_region_num, data_block_pool, f, time_use, data, i, bx, by, cum_stripes_num_list, max_logic_id, insert_index_buffer, insert_data_buffer, partiton_range, partition_list, global_region_num, start_region_block_id, data_patten=data_patten)
        data_block_pool.release_all()
        get_index_size(f, p_num=i, data_patten=data_patten, region_num=region_num)
        f.close()
    with open(const.common_building_result_file, 'w') as outfile:
        # 遍历每个文件并将其内容写入输出文件
        for file in all_result_file_list:
            with open(file, 'r') as infile:
                outfile.write(infile.read())
                outfile.write("\n")
    print(f"{const.PERIOD_NUM} period index building result has been into {const.common_building_result_file}")
    data_block_pool.release_all()
