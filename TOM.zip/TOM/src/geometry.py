import math
import heapq
from typing import List, Tuple, Optional, Any
import numpy as np
"""几何库"""


class Rectangle:
    def __init__(self, x1=float('inf'), y1=float('inf'), x2=float('-inf'), y2=float('-inf')):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2

    @staticmethod
    def calculate_overlap(rect1, rect2):
        """
        计算两个矩形的重叠区域坐标。
        """
        x1, y1, x2, y2 = rect1
        x3, y3, x4, y4 = rect2
        # 计算重叠区域的左下角
        overlap_left = max(x1, x3)
        overlap_bottom = max(y1, y3)
        # 计算重叠区域的右上角
        overlap_right = min(x2, x4)
        overlap_top = min(y2, y4)
        # 判断是否有重叠
        if overlap_left < overlap_right and overlap_bottom < overlap_top:
            return [overlap_left, overlap_bottom, overlap_right, overlap_top]
        else:
            return None

    def is_intersect(self, mbr):
        return self.x1 <= mbr.x2 and self.x2 >= mbr.x1 \
            and self.y1 <= mbr.y2 and self.y2 >= mbr.y1

    def __eq__(self, other):
        return self.x1 == other.x1 and self.y1==other.y1 \
            and self.x2==other.x2 and self.y2==other.y2

    def is_contained(self, point):
        return self.x1 <= point.x <= self.x2 and self.y1 <= point.y <= self.y2

    @property
    def mbr(self):
        return [self.x1, self.y1, self.x2, self.y2]

    @staticmethod
    def get_mbr(data=None):
        if data is None:
            return Rectangle().mbr
        data = np.array(data)
        minx, miny = np.min(data, axis=0)
        maxx, maxy = np.max(data, axis=0)
        return Rectangle(minx, miny, maxx, maxy).mbr

    def cal_area(self):
        """计算面积"""
        return abs(self.x2 - self.x1) * abs(self.y2 - self.y1)

    def cal_dis_to_center(self, point):
        """计算点到mbr中心的距离"""
        center = Point((self.x1+self.x2)/2, (self.y1 + self.y2)/2)
        return center.cal_distance(point)


class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __eq__(self, other):
        return self.x == other.x and self.y == other.y

    def cal_distance(self, point):
        return np.sqrt((self.x - point.x)**2 + (self.y - point.y)**2)
        # return math.hypot(point[0], dy)


class Polygon:
    def __init__(self, vertices):
        """用顶点代表多边形"""
        self.vertices = vertices
        self.n = len(self.vertices)
        self.edges = self.get_edges()

    def cal_polygon_area(self):
        """计算凸多边形的面积"""
        n = len(self.vertices)
        area = 0
        for i in range(n):
            x1, y1 = self.vertices[i]
            x2, y2 = self.vertices[(i + 1) % n]  # 使用模运算确保循环
            area += x1 * y2 - y1 * x2
        return abs(area) / 2

    def get_edges(self):
        """获取多边形的边"""
        edges = []
        for i in range(self.n):
            start = self.vertices[i]
            end = self.vertices[(i + 1) % self.n]
            edges.append((start, end))
        return edges



    def get_min_max_distance(self, point):
        pass


class MaxPriorityQueue:
    def __init__(self, k: int):
        self.k = k
        self.heap = []

    def add(self, point: Any, distance: float) -> bool:
        # 使用负距离实现最大堆
        item = (-distance, point)
        if len(self.heap) < self.k:
            heapq.heappush(self.heap, item)
            return True
        elif distance < self.get_kth_distance():
            # 新点比当前第k个最近邻近
            heapq.heapreplace(self.heap, item)
            return True
        return False

    def get_kth_distance(self) -> float:
        """
        获取当前第k个最近邻的距离
        如果不足k个点，返回无穷大
        """
        if len(self.heap) < self.k:
            return float('inf')
        # 堆顶是距离最大的（第k个最近邻）
        return -self.heap[0][0]

    def get_all(self) -> List[Tuple[Any, float]]:
        """获取所有最近邻（点，距离）"""
        return [(point, -dist) for dist, point in self.heap]

    def get_sorted(self) -> List[Tuple[Any, float]]:
        """获取按距离升序排列的最近邻"""
        items = [(point, -dist) for dist, point in self.heap]
        return sorted(items, key=lambda x: x[1])  # 按距离升序

    def __len__(self) -> int:
        return len(self.heap)

    def is_full(self) -> bool:
        """队列是否已满"""
        return len(self.heap) >= self.k

    def clear(self):
        """清空队列"""
        self.heap.clear()

    def batch_add(self, points: List[Any], distances: List[float]) -> int:
        """
        批量添加点
        """
        count = 0
        for point, distance in zip(points, distances):
            if self.add(point, distance):
                count += 1
        return count