import numpy as np
"""几何库"""


class Rectangle:
    def __init__(self, x1=float('inf'), y1=float('inf'), x2=float('-inf'), y2=float('-inf')):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2

    @staticmethod
    def calculate_overlap(rect1, rect2):
        """
        计算两个矩形的重叠区域坐标。
        """
        x1, y1, x2, y2 = rect1
        x3, y3, x4, y4 = rect2
        # 计算重叠区域的左下角
        overlap_left = max(x1, x3)
        overlap_bottom = max(y1, y3)
        # 计算重叠区域的右上角
        overlap_right = min(x2, x4)
        overlap_top = min(y2, y4)
        # 判断是否有重叠
        if overlap_left < overlap_right and overlap_bottom < overlap_top:
            return [overlap_left, overlap_bottom, overlap_right, overlap_top]
        else:
            return None

    def is_intersect(self, mbr):
        return self.x1 <= mbr.x2 and self.x2 >= mbr.x1 \
            and self.y1 <= mbr.y2 and self.y2 >= mbr.y1

    def __eq__(self, other):
        return self.x1 == other.x1 and self.y1==other.y1 \
            and self.x2==other.x2 and self.y2==other.y2

    def is_contained(self, point):
        return self.x1 <= point.x <= self.x2 and self.y1 <= point.y <= self.y2

    @property
    def mbr(self):
        return [self.x1, self.y1, self.x2, self.y2]

    @staticmethod
    def get_mbr(data=None):
        if data is None:
            return Rectangle().mbr
        data = np.array(data)
        minx, miny = np.min(data, axis=0)
        maxx, maxy = np.max(data, axis=0)
        return Rectangle(minx, miny, maxx, maxy).mbr

    def cal_area(self):
        """计算面积"""
        return abs(self.x2 - self.x1) * abs(self.y2 - self.y1)

    def cal_dis_to_center(self, point):
        """计算点到mbr中心的距离"""
        center = Point((self.x1+self.x2)/2, (self.y1 + self.y2)/2)
        return center.cal_distance(point)


class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __eq__(self, other):
        return self.x == other.x and self.y == other.y

    def cal_distance(self, point):
        return np.sqrt((self.x - point.x)**2 + (self.y - point.y)**2)


class Polygon:
    def __init__(self, vertices):
        """用顶点代表多边形"""
        self.vertices = vertices

    def cal_polygon_area(self):
        """计算凸多边形的面积"""
        n = len(self.vertices)
        area = 0
        for i in range(n):
            x1, y1 = self.vertices[i]
            x2, y2 = self.vertices[(i + 1) % n]  # 使用模运算确保循环
            area += x1 * y2 - y1 * x2
        return abs(area) / 2