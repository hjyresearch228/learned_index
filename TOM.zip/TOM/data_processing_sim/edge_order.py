"""道路排序"""

import xml.etree.ElementTree as ET
import pandas as pd
import os
from utils.file_utils import *
import sys

dt_num = '2000w'
data_num = 20000000

connections_info_file = r'C:\Users\yanxi\Desktop\读研\移动数据管理\SUMO-仿真轨迹数据-2023-12-王彦之\路网\Beijing_join_addLanes1-1.net.xml'  # 请根据实际路径修改
csv_path = 'E:\\模拟数据\\simulation4-1\\'
output_file = f'E:\\Python_Projects\\Learned_Index\\TOM\data\\{dt_num}_test.csv'
ordered_edges_file = r'E:\Python_Projects\Learned_Index\TOM\net_processing\ordered_edges.pkl'
pos_t_file = rf'E:\Python_Projects\Learned_Index\TOM\data\{dt_num}_sim.txt'


def get_csv_edge(csv_file):
    """获取样本文件中的所有道路ID"""
    df = pd.read_csv(csv_file)
    # 分离出道路ID，现在舍去路段了
    df['edge'] = df['edgeID'].str.split('#').str[0]
    return set(df['edge'])


def get_data(dir):
    """取样200w数据"""
    data_size = 0
    data = pd.DataFrame()
    file_list = os.listdir(dir)
    file_suffix= file_list[0].split('_')[1]
    file_digit_list = [int(file.split('_')[0]) for file in file_list]
    file_digit_list.sort()
    file_list = [csv_path+str(digit)+'_'+file_suffix for digit in file_digit_list]
    print(len(file_list))
    for i in range(0, len(file_list), 6):
        if data_size >= data_num:
            break
        df = pd.read_csv(file_list[i])
        data_size += df.shape[0]
        print(f'当前总数据量: {data_size}')
        if not df.empty:
            data = pd.concat([data, df], ignore_index=True)
    return data


def parse_connections(file_path, edges):
    # 解析XML文件，获取所有道路的连通信息
    tree = ET.parse(file_path)
    root = tree.getroot()
    # 创建一个字典来存储连接信息
    connections_dict = {}
    # 查找所有的连接元素
    for connection in root.findall('.//connection'):
        from_id = connection.get('from').split('#')[0]
        to_id = connection.get('to').split('#')[0]
        if int(from_id) not in connections_dict:
            connections_dict[int(from_id)] = set()
        connections_dict[int(from_id)].add(int(to_id))
    return connections_dict


def edge_order(connections, data, edges):
    '''dfs排序道路'''
    ordered_edges = []  # 排序之后的道路
    visited = set()  # 标记已访问数组
    # 随机选择一条道路
    first_edge = int(data['edgeID'].str.split('#').str[0][0])
    ordered_edges.append(first_edge)
    visited.add(first_edge)
    ordered_edges += dfs(first_edge, connections, edges, visited)
    for edge in connections.keys():
        if edge in edges and edge not in visited:
            ordered_edges.append(edge)
            visited.add(edge)
            ordered_edges += dfs(edge, connections, edges, visited)
    return ordered_edges


def dfs(edge, connections, edges, visited):
    ordered_edges = []
    if -edge in connections[edge] and -edge not in visited and -edge in edges:
        ordered_edges.append(-edge)
        visited.add(-edge)
        connections[edge].remove(-edge)
    stack = list(set(edges) & set(connections[edge]))
    while stack:
        next_edge = stack.pop()
        if next_edge not in visited:
            visited.add(next_edge)
            ordered_edges.append(next_edge)
            if next_edge in connections.keys():
                if -next_edge in connections[next_edge] and -next_edge not in visited and -next_edge in edges and next_edge in connections:
                    ordered_edges.append(-next_edge)
                    visited.add(-next_edge)
                    connections[next_edge].remove(-next_edge)
                for con in connections[next_edge]:
                    if con not in visited and con in edges:
                        stack.append(con)
    return ordered_edges


def sort_data_by_edges(data_csv_path, sorted_edges):
    # 读取CSV文件
    df = pd.read_csv(data_csv_path)
    # 新增一列，提取纯道路ID（去掉#及后面的路段ID部分）
    df['pure_edgeID'] = df['edgeID'].apply(lambda x: x.split('#')[0])
    # 新增一列，提取路段ID
    df['segmentID'] = df['edgeID'].apply(lambda x: int(x.split('#')[1]) if '#' in x else 0)
    # 按照sorted_edges顺序排序
    sorted_df = pd.DataFrame()
    for edge in sorted_edges:
        edge_str = str(edge)
        # 找出匹配的子数据框
        temp_df = df[df['pure_edgeID'] == edge_str]
        # 按照segmentID进一步排序
        temp_df = temp_df.sort_values(by=['segmentID'])
        # 追加到结果数据框
        sorted_df = pd.concat([sorted_df, temp_df], ignore_index=True)
    # 删除临时列
    sorted_df.drop(columns=['segmentID'], inplace=True)
    return sorted_df


def main():
    clean_file(ordered_edges_file)
    clean_file(output_file)
    if not os.path.exists(output_file):
        data = get_data(csv_path)
        data.to_csv(output_file, index=False)
    data = pd.read_csv(output_file)
    print('---------处理道路----------')
    if not os.path.exists(ordered_edges_file):
        # 获得所有道路ID
        edges = get_csv_edge(output_file)
        edges = list(map(int, edges))
        connection_info = parse_connections(connections_info_file, edges)
        ordered_edge = edge_order(connection_info, data, edges)
        dump_model(ordered_edge, ordered_edges_file)
    else:
        ordered_edge = load_model(ordered_edges_file)
    sorted_df = sort_data_by_edges(output_file, ordered_edge)
    sorted_data = sorted_df[['timestep', 'edgeID', 'edgePos', 'length']]
    sorted_data.to_csv(pos_t_file, header=False, index=False, sep=',')
    print(f'道路已排序至文件{ordered_edges_file}')
    # print(ordered_edge, len(ordered_edge))
    print(f'{dt_num}数据已经抽取到文件 {pos_t_file}')


if __name__ == '__main__':
    main()


