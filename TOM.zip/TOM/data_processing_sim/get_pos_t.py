"""从abs_dis的输出文件中获得pos,t2个维度"""
from edge_order import dt_num
from src.const import *
ori_file = f'..\\data\\{dt_num}_ori.txt'
# ori_file = '..\\data\\60W.txt'


import pandas as pd
new_file = fr'../data/{dt_num}_new.txt'
data = pd.read_csv(new_file, header=None, names=['timestamp', 'road_segment', 'pos', 'len'])
# data = pd.read_csv(new_file, header=None, names=['timestamp', 'pos'])
data = data[['pos', 'timestamp']]
data.to_csv(ori_file, index=False, header=False, columns=['pos', 'timestamp'])
print(f'已经抽取pos,t 2个维度到文件 {ori_file}')