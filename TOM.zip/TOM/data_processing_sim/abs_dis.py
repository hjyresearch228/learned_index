"""相对距离转绝对距离"""

import pandas as pd
from utils.file_utils import *
from edge_order import data_num, dt_num
import os

id_road_map_file = r'/id_road_length_map.pkl'

pos_t_file = rf'../data/{dt_num}_sim.txt'
new_file = fr'../data/{dt_num}_new.txt'
# 读取数据文件
data = pd.read_csv(pos_t_file, header=None, names=['timestamp', 'road_segment', 'pos', 'len'])

# 分割道路ID和路段ID
data[['road_id', 'segment_id']] = data['road_segment'].str.split('#', expand=True, n=1)
data['segment_id'].fillna(-2, inplace=True)  # 将空的路段ID填充为-2
data['road_id'] = data['road_id'].astype(int)
data['segment_id'] = data['segment_id'].astype(int)

# 计算累计距离
cumulative_distance = {}

current_length = 0

cur_segment_length = 0

cum_road_total_length = []  # 累计长度
current_road_id = -1
cur_segment_id = -1
pre_road_length = 0
pre_segment_length = 0
road_number = 0  # 记录到当前为止的道路总数量
id_road_length_map = {} # 记录道路ID和道路长度的映射

# 同一道路内的累计路段长度，道路变化时需要重置
cum_segment_total_length = 0


"""将道路包含一条路段和包含多条路段统一处理"""


# 当前轨迹的绝对长度
cur_tra_abs_length = 0

for idx, row in data.iterrows():
    road_id = row['road_id']
    segment_id = row['segment_id']
    """
    出现一条新道路,需要
    1   重置路段和，
    2   道路数量加1，
    3   更新当前道路ID
    4   判断是否是只包含一条路段的道路：如果是则：
            将当前道路的长度添加到累计道路长度列表，
        如果当前道路包含多条路段，则：
            将当前路段的长度添加到累计路段长度
    5   将以前的累计路段长度（其实就是一条道路的长度）和道路ID添加到映射表，统一处理2种道路
            
    """
    if road_id != current_road_id:
        if idx > 0:
            id_road_length_map[data.at[idx-1, 'road_id']] = cum_segment_total_length
        cum_road_total_length.append(cum_segment_total_length)
        # 重置路段长度和
        cum_segment_total_length = 0
        road_number += 1
        data.at[idx, 'pos'] = data.at[idx,'pos'] + cum_segment_total_length + sum(cum_road_total_length[:road_number])
        current_road_id = road_id
        # 两种道路统一处理
        cum_segment_total_length += row['len']
        # 道路不同时需要重置路段ID
        cur_segment_id = segment_id
        continue

    # 以下这种情况只可能发生在同一道路内，即道路包括多条路段的情况下
    """
    如果的同一道路的不同路段：
    1   将当前路段长度加入到累计路段长度（因为这种只可能出现在道路包含多条路段的情况）
    2   更新当前路段
    """
    if road_id == current_road_id and segment_id != cur_segment_id:
        data.at[idx, 'pos'] += (sum(cum_road_total_length[:road_number]) + cum_segment_total_length)
        cur_segment_id = segment_id
        cum_segment_total_length += row['len']
        continue
    # 同一道路同一路段直接加上以前的累计道路距离
    if road_id == current_road_id and segment_id == cur_segment_id:
        data.at[idx, 'pos'] += sum(cum_road_total_length[:road_number])
        continue


# 保存结果到新的文件
data.to_csv(new_file, index=False, header=False, columns=['timestamp', 'road_segment', 'pos', 'len'])
dump_model(id_road_length_map, id_road_map_file)
print(id_road_length_map, len(id_road_length_map))
print(f"更新的轨迹数据绝对距离已保存至 {new_file}")
