"""
路网道路排序, 然后pos使用绝对距离
执行顺序
1   edge_order.py
2   abs_dis.py
3   get_pos_t.py
"""