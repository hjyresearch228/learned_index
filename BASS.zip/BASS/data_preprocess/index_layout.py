"""等频区域划分与单元编号
"""

import json
from pathlib import Path
import sys
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from config import LayoutConfig

def read_table(path, widths=(2,), header=False, delimiter=None):
    path = Path(path)
    if header:
        with path.open(encoding="utf-8-sig") as stream:
            names = stream.readline().strip().split()
        if names not in (["pos", "t"], ["lc", "tm"]):
            raise ValueError(f"{path}：表头应为pos,t或lc,tm")
        with path.open(encoding="utf-8-sig") as stream:
            next(stream)
            if not any(line.strip() for line in stream):
                return np.empty((0, 2), dtype=np.float64)
    values = np.loadtxt(path, delimiter=delimiter, skiprows=int(header),
                        dtype=np.float64, ndmin=2, encoding="utf-8-sig")
    if values.shape[1] not in widths or not np.isfinite(values).all():
        raise ValueError(f"{path}：列数或有限数值检查失败")
    return values


def read_queries(cfg, kind, period):
    if kind != "range":
        raise ValueError("网格划分只使用范围查询")
    values = read_table(cfg.query_dir / cfg.range_file.format(period=period),
                        widths=(4,), delimiter=",")[:, cfg.range_columns]
    if np.any(values[:, :2] > values[:, 2:]):
        raise ValueError("范围查询下界大于上界，请检查range_columns")
    return values


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


class IndexLayout:
    def __init__(self, cfg):
        self.cfg = cfg
        self.pos = self.time = None
        self.clusters, self.grids = {}, {}

    @property
    def region_count(self):
        return (len(self.pos) - 1) * (len(self.time) - 1)

    @staticmethod
    def equal_frequency(values, parts, lower, upper, method="linear"):
        """论文第 III 节的近似等量行/列；分位数是本实现的具体划分办法。"""
        if len(values) == 0 or not np.isfinite(values).all():
            raise ValueError("第一期数据为空或含非有限值")
        if values.min() < lower or values.max() > upper:
            raise ValueError("第一期数据超出全局范围")
        # 分位点给出内部边界，首尾仍固定为数据集全局范围。
        cuts = np.quantile(values, np.arange(1, parts) / parts, method=method)
        boundaries = np.r_[lower, cuts, upper]
        if np.any(np.diff(boundaries) <= 0):
            raise ValueError("等频边界重合，请减少分区数量")
        return boundaries

    def partition(self, period):
        """论文第 III 节：首期确定 gls/gts，后期沿用边界。

        逻辑区域键仅是 gm；EP_n/n_gm.txt 中的 n 是数据期数，不属于区域编号。
        """
        root = self.cfg.data_dir
        root.mkdir(parents=True, exist_ok=True)
        boundary_file = root / "partition_boundaries.json"
        ranges = self.cfg.data_bounds
        if boundary_file.exists():
            # 后续期复用同一组边界，区域编号才会跨期对应相同位置。
            record = load_json(boundary_file)
            self.pos = np.asarray(record["pos_boundaries"])
            self.time = np.asarray(record["t_boundaries"])
            if (len(self.pos) - 1, len(self.time) - 1) != (self.cfg.pos_parts, self.cfg.time_parts):
                raise ValueError("已有分区数与配置不一致，请使用新的DATA目录")
            if not (np.array_equal(self.pos[[0, -1]], ranges["pos"])
                    and np.array_equal(self.time[[0, -1]], ranges["t"])):
                raise ValueError("已保存分区与data_bounds.json范围不一致")
        elif period != 1:
            raise FileNotFoundError("后期必须先有第一期分区边界")
        values = read_table(self.cfg.source_dir / f"period_{period}.txt", header=True)
        if not len(values):
            raise ValueError("整期数据为空")
        if self.pos is None:
            self.pos = self.equal_frequency(values[:, 0], self.cfg.pos_parts,
                                             *ranges["pos"], self.cfg.quantile_method)
            self.time = self.equal_frequency(values[:, 1], self.cfg.time_parts,
                                              *ranges["t"], self.cfg.quantile_method)
            save_json(boundary_file, {"pos_boundaries": self.pos.tolist(),
                                      "t_boundaries": self.time.tolist(),
                                      "region_id_base": 1,
                                      "interval_rule": "[lower,upper); final includes upper"})
        destination = root / f"EP_{period}"
        ids = self.region_ids(values)
        if destination.exists():
            # 已有分区逐区域核对，防止静默沿用不匹配的数据。
            for region in range(1, self.region_count + 1):
                saved = read_table(destination / f"{period}_{region}.txt", header=True)
                if not np.array_equal(saved, values[ids == region]):
                    raise ValueError(f"已有分区与输入不一致：EP_{period}/{period}_{region}.txt")
            return len(values)
        temporary = root / f"EP_{period}.tmp"
        temporary.mkdir()
        for region in range(1, self.region_count + 1):
            np.savetxt(temporary / f"{period}_{region}.txt", values[ids == region],
                       delimiter=self.cfg.delimiter, fmt=self.cfg.txt_format,
                       header="pos\tt", comments="")
        temporary.rename(destination)
        return len(values)

    def region_ids(self, points):
        """论文第 V-A 节 gm 的行主序编号；本实现从 1 起算。"""
        ids = []
        for axis, bounds in enumerate((self.pos, self.time)):
            v = np.asarray(points)[:, axis]
            if not np.isfinite(v).all() or np.any(v < bounds[0]) or np.any(v > bounds[-1]):
                raise ValueError("坐标超出已保存的分区边界")
            ids.append(np.clip(np.searchsorted(bounds, v, side="right") - 1, 0, len(bounds) - 2))
        # 位置轴为外层、时间轴为内层；区域编号从 1 开始。
        return ids[0] * (len(self.time) - 1) + ids[1] + 1

    def bounds(self, region):
        if not 1 <= region <= self.region_count:
            raise ValueError("区域编号越界")
        p, t = divmod(region - 1, len(self.time) - 1)
        return np.array([[self.pos[p], self.time[t]], [self.pos[p + 1], self.time[t + 1]]])

    def region_queries(self, rectangle):
        rectangle = np.asarray(rectangle, dtype=float).reshape(2, 2)
        if not np.isfinite(rectangle).all() or np.any(rectangle[0] > rectangle[1]):
            raise ValueError("无效查询范围")
        ranges = []
        for axis, bounds in enumerate((self.pos, self.time)):
            lo, hi = max(rectangle[0, axis], bounds[0]), min(rectangle[1, axis], bounds[-1])
            if lo > hi:
                return []
            a, b = np.clip(np.searchsorted(bounds, [lo, hi], side="right") - 1, 0, len(bounds) - 2)
            ranges.append(range(int(a), int(b) + 1))
        result = []
        # 返回每个相交区域及查询框与该区域的交集。
        for p in ranges[0]:
            for t in ranges[1]:
                region = p * (len(self.time) - 1) + t + 1
                bounds = self.bounds(region)
                clipped = np.array([np.maximum(rectangle[0], bounds[0]), np.minimum(rectangle[1], bounds[1])])
                result.append((region, clipped))
        return result

    def cell_ids(self, region, points, shape=None):
        """论文第 V-A 节：区域内等宽单元行主序编号，供 ordmap 映射到谱序。"""
        if shape is None:
            grid = self.grids[self.clusters[region]]
            shape = (grid["lnm"], grid["tnm"])
        lnm, tnm = shape
        bounds = self.bounds(region)
        coordinates = np.floor((np.asarray(points) - bounds[0]) / (bounds[1] - bounds[0])
                               * [lnm, tnm]).astype(np.int64)
        coordinates = np.clip(coordinates, [0, 0], [lnm - 1, tnm - 1])
        return coordinates[:, 0] * tnm + coordinates[:, 1]


if __name__ == "__main__":
    from config import BSplineIndexConfig as BIC
    layout = IndexLayout(LayoutConfig(source_dir=Path(BIC.SOURCE_DIR),
                                      query_dir=Path(BIC.QUERY_DIR),
                                      data_dir=Path(BIC.DATA_ROOT)))
    for period in range(1, 8):
        print(f"EP_{period} 区域划分完成或校验：{layout.partition(period)} 个点")
