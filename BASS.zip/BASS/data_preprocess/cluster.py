"""论文两阶段区域聚类的实现。"""

from collections import Counter
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import fcluster, linkage
from scipy.spatial.distance import pdist
from sklearn.cluster import KMeans
from sklearn.metrics import (
    calinski_harabasz_score,
    davies_bouldin_score,
    silhouette_score,
)
from sklearn.preprocessing import normalize


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from config import TwoStageClusteringConfig as CFG


# ------------------------- 第一阶段：路段与时间嵌入 -------------------------

def load_segments(path):
    """读取路段起点、终点和编号，并按位置排序。"""
    frame = pd.read_csv(path, encoding="utf-8-sig", dtype={"路段id": str})
    frame = frame.sort_values("start_pos").reset_index(drop=True)
    starts = frame["start_pos"].to_numpy(dtype=np.float64)
    ends = starts + frame["长度"].to_numpy(dtype=np.float64)
    return frame, starts, ends, frame["路段id"].tolist()


def load_period_data(period_dir):
    """读取首期全部区域文件，返回 {1_gm: [(pos, t), ...]}。"""
    result = {}
    for path in Path(period_dir).glob("*.txt"):
        with path.open(encoding="utf-8-sig") as stream:
            next(stream, None)
            points = [tuple(map(float, line.split())) for line in stream if line.strip()]
        result[path.stem] = points
    return result


def normalize_adjacency(adjacency):
    """计算 D^(-1/2)(A+I)D^(-1/2)。"""
    adjacency = adjacency + np.eye(adjacency.shape[0])
    # 自环保留本路段特征；对称度归一化控制不同度数节点的影响。
    degree = adjacency.sum(axis=1)
    inverse = 1.0 / np.sqrt(degree + 1e-8)
    return inverse[:, None] * adjacency * inverse[None, :]


def load_connections(xml_path):
    """从路网读取路段连接关系。"""
    root = ET.parse(xml_path).getroot()
    return {
        (node.attrib["from"], node.attrib["to"])
        for node in root.findall("connection")
        if node.attrib.get("from") and node.attrib.get("to")
    }


def build_adjacency(edge_ids, connections):
    """把当前数据覆盖的路段构造成无向邻接矩阵。"""
    indexes = {edge_id: index for index, edge_id in enumerate(edge_ids)}
    adjacency = np.zeros((len(edge_ids), len(edge_ids)), dtype=np.float64)
    for source, target in connections:
        if source in indexes and target in indexes:
            i, j = indexes[source], indexes[target]
            adjacency[i, j] = adjacency[j, i] = 1.0
    return adjacency


def propagate_edges(adjacency, values, eps, max_iter):
    """传播路段特征，直至均方 Frobenius 变化小于 eps。"""
    normalized = normalize_adjacency(adjacency)
    current = values.copy()
    for iteration in range(1, max_iter + 1):
        updated = normalized @ current
        change = np.linalg.norm(updated - current, "fro") / np.sqrt(updated.size)
        print(f"路段传播轮次={iteration}, 变化={change:.6f}")
        current = updated
        if change < eps:
            break
    return current


def find_segment_id(position, starts, ends, edge_ids):
    """定位位置所属的路段。"""
    index = np.searchsorted(starts, position, side="right") - 1
    if index >= 0 and position <= ends[index]:
        return edge_ids[index]
    return None


def time_layer(timestamp):
    """将一天划分为高峰、白天和夜间三种时间类别。"""
    hour = (timestamp % 86400) / 3600.0
    if 7 <= hour < 9 or 17 <= hour < 19:
        return 0
    if 9 <= hour < 17:
        return 1
    return 2


def encode_cell(points, encoding, lengths, starts, ends, edge_ids):
    """生成一个单元格的三维路段嵌入和三维时间嵌入。"""
    segment_ids = {
        segment
        for position, _ in points
        if (segment := find_segment_id(position, starts, ends, edge_ids)) in encoding.index
    }
    segment_lengths = {segment: lengths.get(segment, 0.0) for segment in segment_ids}
    total_length = sum(length for length in segment_lengths.values() if length > 0)
    road_vector = np.zeros(3, dtype=np.float64)
    if total_length > 0:
        # 同一单元格内先去重路段，再按路段长度加权汇总道路特征。
        for segment, length in segment_lengths.items():
            if length > 0:
                road_vector += length / total_length * encoding.loc[
                    segment, ["长度", "车道数", "曲率"]
                ].to_numpy(dtype=np.float64)

    time_vector = np.zeros(3, dtype=np.float64)
    for _, timestamp in points:
        time_vector[time_layer(timestamp)] += 1.0
    if points:
        # 时间向量表示三类时段的点数占比。
        time_vector /= len(points)
    return np.r_[road_vector, time_vector]


def build_region_feature(points, encoding, lengths, bounds, starts, ends, edge_ids, shape):
    """将一个区域的单元格嵌入按行主序拼接为高维向量。"""
    rows, columns = shape
    lower, upper = bounds
    buckets = [[] for _ in range(rows * columns)]
    for position, timestamp in points:
        coordinate = np.floor(
            (np.array([position, timestamp]) - lower) / (upper - lower) * [rows, columns]
        ).astype(np.int64)
        coordinate = np.clip(coordinate, [0, 0], [rows - 1, columns - 1])
        buckets[coordinate[0] * columns + coordinate[1]].append((position, timestamp))

    cells = np.zeros((rows * columns, 6), dtype=np.float64)
    for cell, cell_points in enumerate(buckets):
        if cell_points:
            cells[cell] = encode_cell(cell_points, encoding, lengths, starts, ends, edge_ids)
    return cells.reshape(-1)


def discretize_cells(features, n_cells, dimension, vocabulary_size, random_state):
    """空单元格编码为0，非空单元格由 KMeans 离散成词。"""
    cells = features.reshape(len(features) * n_cells, dimension)
    empty = np.all(cells == 0, axis=1)
    words = np.zeros(len(cells), dtype=np.int64)
    nonempty = cells[~empty]
    if len(nonempty):
        if len(nonempty) < vocabulary_size:
            raise ValueError("非空单元格数量小于第一阶段词表大小")
        labels = KMeans(
            n_clusters=vocabulary_size,
            n_init=10,
            random_state=random_state,
        ).fit_predict(nonempty)
        # 0 留给空格；非空格的 KMeans 标签整体加 1。
        words[~empty] = labels + 1
    return words.reshape(len(features), n_cells)


def build_ngram_features(word_sequences, n, vocabulary_size):
    """根据行主序单元格词序列构造 n-gram 频率向量。"""
    result = np.zeros((len(word_sequences), vocabulary_size ** n), dtype=np.float64)
    for region, sequence in enumerate(word_sequences):
        counts = Counter(tuple(sequence[i:i + n]) for i in range(len(sequence) - n + 1))
        total = sum(counts.values())
        # 每种 n-gram 编码到固定维度，再用出现频率表示该区域。
        for gram, count in counts.items():
            index = 0
            for word in gram:
                index = index * vocabulary_size + word
            result[region, index] = count / total
    return result


def first_stage_kmeans(features, cfg):
    """路段/时间嵌入经 n-gram 表示后，用 KMeans 得到初始模型簇。"""
    n_cells = cfg.STAGE1_GRID_ROWS * cfg.STAGE1_GRID_COLS
    words = discretize_cells(
        features,
        n_cells=n_cells,
        dimension=cfg.STAGE1_CELL_DIM,
        vocabulary_size=cfg.STAGE1_VOCAB_SIZE,
        random_state=cfg.RANDOM_STATE,
    )
    vocabulary_size = int(words.max()) + 1
    ngram = normalize(
        build_ngram_features(words, cfg.STAGE1_NGRAM_N, vocabulary_size),
        norm="l1",
    )
    labels = KMeans(
        n_clusters=cfg.STAGE1_CLUSTER_COUNT,
        n_init=10,
        random_state=cfg.RANDOM_STATE,
    ).fit_predict(ngram)
    return np.asarray(labels, dtype=np.int64), ngram


def report_first_stage(features, labels):
    """输出第一阶段聚类质量指标。"""
    cluster_count = len(np.unique(labels))
    if cluster_count < 2:
        return
    print(f"第一阶段簇数={cluster_count}")
    print(f"轮廓系数={silhouette_score(features, labels):.6f}")
    print(f"CH指数={calinski_harabasz_score(features, labels):.6f}")
    print(f"DB指数={davies_bouldin_score(features, labels):.6f}")


class TwoStageRegionClusterer:
    """先生成初始模型簇，再在各初始簇内部按累积点数细分。"""

    def __init__(self, cfg=CFG):
        self.cfg = cfg
        boundary_data = json.loads(Path(cfg.REGION_BOUNDARIES_PATH).read_text(encoding="utf-8"))
        self.pos_boundaries = np.asarray(boundary_data["pos_boundaries"], dtype=np.float64)
        self.time_boundaries = np.asarray(boundary_data["t_boundaries"], dtype=np.float64)
        self.period_data = None

    @property
    def region_count(self):
        return (len(self.pos_boundaries) - 1) * (len(self.time_boundaries) - 1)

    @staticmethod
    def region_id(region_key):
        return int(region_key.split("_", 1)[1])

    def region_bounds(self, region):
        pos_index, time_index = divmod(region - 1, len(self.time_boundaries) - 1)
        return np.array([
            [self.pos_boundaries[pos_index], self.time_boundaries[time_index]],
            [self.pos_boundaries[pos_index + 1], self.time_boundaries[time_index + 1]],
        ])

    def cell_ids(self, region, points, shape):
        if not len(points):
            return np.empty(0, dtype=np.int64)
        lower, upper = self.region_bounds(region)
        coordinates = np.floor((points - lower) / (upper - lower) * shape).astype(np.int64)
        coordinates = np.clip(coordinates, [0, 0], np.asarray(shape) - 1)
        return coordinates[:, 0] * shape[1] + coordinates[:, 1]

    def load_segment_encoding(self, segment_frame, edge_ids):
        """读取已有路段编码，或按原第一阶段方法计算并保存。"""
        if self.cfg.REUSE_SEGMENT_ENCODING:
            return pd.read_csv(
                self.cfg.ENCODING_CSV,
                encoding="utf-8-sig",
                dtype={"路段id": str},
            ).set_index("路段id")

        columns = ["长度", "车道数", "曲率"]
        adjacency = build_adjacency(edge_ids, load_connections(self.cfg.XML_PATH))
        propagated = propagate_edges(
            adjacency,
            segment_frame[columns].to_numpy(dtype=np.float64),
            self.cfg.EPS,
            self.cfg.MAX_ITER,
        )
        encoded = segment_frame.copy()
        encoded[columns] = np.round(propagated, 6)
        output = Path(self.cfg.ENCODING_CSV)
        output.parent.mkdir(parents=True, exist_ok=True)
        encoded.to_csv(output, index=False, encoding="utf-8-sig", float_format="%.6f")
        return encoded.set_index("路段id")

    def stage1_features(self):
        """构造第一阶段使用的全部区域嵌入。"""
        segment_frame, starts, ends, edge_ids = load_segments(self.cfg.SEGMENTS_CSV)
        self.period_data = load_period_data(self.cfg.PERIOD1_DIR)
        region_keys = sorted(self.period_data, key=self.region_id)
        region_ids = np.asarray([self.region_id(key) for key in region_keys], dtype=np.int64)
        if not np.array_equal(region_ids, np.arange(1, self.region_count + 1)):
            raise ValueError("首期区域文件必须完整覆盖连续区域编号1..N")

        encoding = self.load_segment_encoding(segment_frame, edge_ids)
        lengths = dict(zip(segment_frame["路段id"], segment_frame["长度"]))
        shape = (self.cfg.STAGE1_GRID_ROWS, self.cfg.STAGE1_GRID_COLS)
        features = np.empty(
            (len(region_ids), shape[0] * shape[1] * self.cfg.STAGE1_CELL_DIM),
            dtype=np.float64,
        )
        for index, (key, region) in enumerate(zip(region_keys, region_ids)):
            features[index] = build_region_feature(
                self.period_data[key], encoding, lengths,
                self.region_bounds(int(region)), starts, ends, edge_ids, shape,
            )
        return region_ids, features

    def cumulative_features(self, region_ids):
        """第二阶段：生成每个区域行、列两个方向的累积点数序列。"""
        shape = (self.cfg.STAGE2_GRID_ROWS, self.cfg.STAGE2_GRID_COLS)
        n_cells = shape[0] * shape[1]
        cumulative = np.empty((len(region_ids), 2 * n_cells), dtype=np.float64)
        for index, region in enumerate(region_ids):
            points = np.asarray(self.period_data[f"1_{region}"], dtype=np.float64).reshape(-1, 2)
            counts = np.bincount(
                self.cell_ids(int(region), points, shape), minlength=n_cells
            ).reshape(shape)
            # 前半段按行主序累计，后半段对转置矩阵累计，分别描述两个方向。
            cumulative[index, :n_cells] = np.cumsum(counts)
            cumulative[index, n_cells:] = np.cumsum(counts.T)
        return cumulative

    def second_stage(self, region_ids, stage1_labels, cumulative):
        """在每个第一阶段簇内，以完整连接聚类继续细分。"""
        final_labels = np.empty(len(region_ids), dtype=np.int64)
        next_label = 0
        for stage1_label in sorted(np.unique(stage1_labels)):
            members = np.flatnonzero(stage1_labels == stage1_label)
            if len(members) == 1:
                groups = np.ones(1, dtype=np.int64)
            else:
                # Chebyshev 距离取所有行列累计位置中的最大差。
                distances = pdist(cumulative[members], metric="chebyshev")
                groups = fcluster(
                    linkage(distances, method="complete"),
                    t=self.cfg.STAGE2_CUMULATIVE_THRESHOLD,
                    criterion="distance",
                )

            ordered = sorted(
                np.unique(groups),
                key=lambda group: region_ids[members[groups == group]].min(),
            )
            for group in ordered:
                selected = members[groups == group]
                final_labels[selected] = next_label
                curves = cumulative[selected]
                spread = float(np.ptp(curves, axis=0).max())
                ce = float(np.abs(curves - curves.mean(axis=0)).max())
                print(
                    f"最终簇={next_label}, 第一阶段簇={stage1_label}, 区域数={len(selected)}, "
                    f"最大累积差={spread:.0f}, 参考ce={ce:.3f}"
                )
                next_label += 1
        return final_labels

    def run(self):
        region_ids, features = self.stage1_features()
        stage1_labels, ngram = first_stage_kmeans(features, self.cfg)
        report_first_stage(ngram, stage1_labels)
        final_labels = self.second_stage(
            region_ids, stage1_labels, self.cumulative_features(region_ids)
        )

        if any(
            len(np.unique(stage1_labels[final_labels == label])) != 1
            for label in np.unique(final_labels)
        ):
            raise RuntimeError("第二阶段结果跨越了第一阶段簇")

        output = Path(self.cfg.OUTPUT_CSV)
        output.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame({"region_key": region_ids, "cluster": final_labels}).to_csv(
            output, index=False, encoding="utf-8-sig"
        )
        print(
            f"两阶段聚类完成：第一阶段={len(np.unique(stage1_labels))}簇，"
            f"最终={len(np.unique(final_labels))}簇，结果={output}"
        )
        return output


if __name__ == "__main__":
    TwoStageRegionClusterer().run()
