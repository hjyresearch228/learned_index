"""划分簇内单元格。"""

import argparse
import csv
from dataclasses import replace
from fractions import Fraction
import itertools
import json
import math
from pathlib import Path
import sys

import networkx as nx
import numpy as np
from scipy.linalg import eigh

if __package__:
    from .index_layout import IndexLayout, read_queries
else:
    from index_layout import IndexLayout, read_queries


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from config import BSplineIndexConfig as BIC, GridLayoutConfig as LayoutConfig


class SpectralLPM:
    """规则网格的谱序及行主序到谱序的 ordmap。"""

    def __init__(self, connectivity=4):
        if connectivity not in (4, 8):
            raise ValueError("connectivity must be 4 or 8")
        self.connectivity = connectivity
        self.rank_ = None

    def fit(self, points):
        points = np.rint(np.asarray(points)).astype(np.int64, copy=False)
        n, dimensions = points.shape
        graph = nx.Graph()
        graph.add_nodes_from(range(n))
        coord_to_ids = {}
        for node_id, point in enumerate(points):
            coord_to_ids.setdefault(tuple(point), []).append(node_id)
        if self.connectivity == 4:
            # 四邻接只连接上下左右；八邻接还包含对角方向。
            offsets = []
            for axis in range(dimensions):
                for direction in (-1, 1):
                    offset = [0] * dimensions
                    offset[axis] = direction
                    offsets.append(tuple(offset))
        else:
            offsets = [
                offset for offset in itertools.product((-1, 0, 1), repeat=dimensions)
                if any(value != 0 for value in offset)
            ]
        for node_id, point in enumerate(points):
            for offset in offsets:
                neighbor = tuple(point[d] + offset[d] for d in range(dimensions))
                for other_id in coord_to_ids.get(neighbor, ()):
                    if node_id < other_id:
                        graph.add_edge(node_id, other_id)
        if not nx.is_connected(graph):
            raise ValueError("The graph is disconnected; the Fiedler vector is not unique.")
        laplacian = nx.laplacian_matrix(graph, nodelist=list(range(n))).toarray()
        # 第二小特征值对应的特征向量给出每个网格点的谱序位置。
        _, eigvecs = eigh(laplacian)
        self.rank_ = np.argsort(eigvecs[:, 1])
        return self.rank_

    def get_rank_map(self):
        if self.rank_ is None:
            raise ValueError("Call fit(points) before requesting the rank map.")
        rank_map = np.zeros(len(self.rank_), dtype=int)
        # rank_ 按谱序列出点编号，此处转换为“点编号 -> 谱序编号”。
        for rank, node_id in enumerate(self.rank_):
            rank_map[node_id] = rank
        return rank_map


def generate_grid_points(m, n):
    return np.array([(i, j) for i in range(m) for j in range(n)])


class GridIndexLayout(IndexLayout):
    """簇内统一网格；聚类映射由当前项目的 CSV 注入。"""

    def spectral_order(self, lnm, tnm):
        size = lnm * tnm
        if size == 1:
            return np.array([0])
        if size > self.cfg.spectral_max_cells:
            raise ValueError("超过LSS稠密谱分解上限，请先检查网格或调整spectral_max_cells")
        model = SpectralLPM(connectivity=self.cfg.spectral_connectivity)
        model.fit(generate_grid_points(lnm, tnm))
        return model.get_rank_map()

    def build_grid(self, range_queries):
        """论文第 IV-B 节：依据查询形状确定簇内区域共享的网格。

        式 (4)-(9) 定义区域与查询的维度比、形状比；式 (17) 给出 c，
        sr=1/c 决定初始 lnm:tnm；式 (18) 给出查询次轴平均宽度 chi。
        """
        RQ = {gm: [] for gm in self.clusters}
        for rq in range_queries:
            for gm, grq in self.region_queries(rq.reshape(2, 2)):
                if np.all(grq[1] > grq[0]):
                    RQ[gm].append(grq)
        global_queries = [rq for queries in RQ.values() for rq in queries]
        for MC_id in sorted(set(self.clusters.values())):
            MC = [gm for gm, c in self.clusters.items() if c == MC_id]
            observed = [gm for gm in MC if RQ[gm]]
            fallback = not observed
            if fallback and not global_queries:
                raise ValueError("第一期没有有效范围查询，无法确定网格形状")
            shape_regions = MC if fallback else observed
            # 无查询覆盖的簇沿用首期全局查询的形状统计量。
            dr_ratio = []
            for gm in shape_regions:
                RG = self.bounds(gm)
                width = RG[1] - RG[0]
                dr_RG = width[0] / width[1]
                queries = global_queries if fallback else RQ[gm]
                dr_RQ = np.mean([(rq[1, 0] - rq[0, 0]) / (rq[1, 1] - rq[0, 1]) for rq in queries])
                dr_ratio.append(dr_RG / dr_RQ)
            dr_ratio = np.asarray(dr_ratio)
            # 论文式 (17)：dr_ratio_i = dr(RG_i) / dr(Q_i)。
            c = math.sqrt(dr_ratio.sum() / np.square(dr_ratio).sum())
            sr_raw = 1 / c
            if not math.isfinite(sr_raw) or sr_raw <= 0:
                raise ValueError("网格形状比必须大于0")
            sr = round(sr_raw, self.cfg.shape_decimals)
            if sr == 0:
                # 极小正形状比可能因保留小数位而变为 0，
                # 使用当前精度能表示的最小正数，保留原始轴向。
                sr = 10 ** (-self.cfg.shape_decimals)
            fraction = Fraction(str(sr))
            lnm, tnm = fraction.numerator, fraction.denominator
            nonlocal_axis = 0 if lnm >= tnm else 1
            la, ln = min(lnm, tnm), max(lnm, tnm)
            minor_widths = []
            # 次轴指每条查询在“查询宽度/单元宽度”比例更小的方向。
            for gm in shape_regions:
                RG = self.bounds(gm)
                widths = RG[1] - RG[0]
                cell_widths = widths / [lnm, tnm]
                for rq in (global_queries if fallback else RQ[gm]):
                    qw = rq[1] - rq[0]
                    minor = int(np.argmin(qw / cell_widths))
                    minor_widths.append(qw[minor])
            chi = float(np.mean(minor_widths))
            # 论文算法 2：使非局部轴槽宽接近查询次轴平均宽度。
            la, ln = self.buildGridLayout(MC, la, ln, chi, nonlocal_axis)
            lnm, tnm = (ln, la) if nonlocal_axis == 0 else (la, ln)
            self.grids[MC_id] = {"lnm": lnm, "tnm": tnm,
                                "ordmap": self.spectral_order(lnm, tnm).tolist()}
            if fallback:
                print(f"簇 {MC_id} 无有效范围查询：使用全局查询形状和次轴宽度")

    def buildGridLayout(self, MC, la, ln, chi, nonlocal_axis):
        """论文算法 2：非局部轴平均槽宽大于 chi 时，将该轴槽数翻倍。"""
        if la * ln > self.cfg.max_grid_cells:
            raise ValueError("初始网格超出资源上限")
        interval_widths = []
        for gm in MC:
            RG = self.bounds(gm)
            tmp = (RG[1, nonlocal_axis] - RG[0, nonlocal_axis]) / ln
            interval_widths.append(tmp)
        lna = float(np.mean(interval_widths))
        # 按二倍增加非局部轴格数，直到平均槽宽不大于查询次轴宽度。
        while lna > chi:
            ln *= 2
            lna /= 2
            if la * ln > self.cfg.max_grid_cells:
                raise ValueError("网格超出max_grid_cells")
        return la, ln

def read_cluster_mapping(path, region_count):
    """读取当前聚类结果的逻辑区域编号。"""
    mapping = {}
    with Path(path).open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream)
        if not {"region_key", "cluster"}.issubset(reader.fieldnames or ()):
            raise ValueError("聚类 CSV 缺少 region_key 或 cluster 列")
        for row in reader:
            key = row["region_key"].strip()
            if key.startswith("1_"):
                key = key[2:]  
            if not key.isdigit() or int(key) < 1:
                raise ValueError(f"非法区域编号: {key}")
            region = int(key)
            cluster = int(row["cluster"])
            if region in mapping or cluster < 0:
                raise ValueError(f"重复区域或非法簇编号: {key}")
            mapping[region] = cluster
    expected = set(range(1, region_count + 1))
        # 聚类文件必须为每个逻辑区域提供且只提供一个簇编号。
    if set(mapping) != expected:
        raise ValueError(f"聚类 CSV 与当前 {region_count} 个区域不匹配："
                         f"{path} 包含 {len(mapping)} 个区域，"
                         f"缺少 {len(expected - mapping.keys())} 个，"
                         f"多出 {len(mapping.keys() - expected)} 个")
    return mapping


class GridLayoutBuilder:
    def __init__(self, cfg=None, cluster_csv=None, output_dir=None):
        self.cfg = cfg or LayoutConfig(source_dir=Path(BIC.SOURCE_DIR),
                                       query_dir=Path(BIC.QUERY_DIR),
                                       data_dir=Path(BIC.DATA_ROOT))
        self.cluster_csv = Path(cluster_csv) if cluster_csv else Path(BIC.CLUSTER_CSV)
        self.output_dir = Path(output_dir) if output_dir else Path(BIC.GRID_LAYOUT_DIR)
        self.layout = GridIndexLayout(self.cfg)

    def build_grid(self):
        self.layout.partition(1)
        self.layout.clusters = read_cluster_mapping(self.cluster_csv, self.layout.region_count)
        self.layout.build_grid(read_queries(self.cfg, "range", 1))
        return self.layout.grids

    def save_cluster_layouts(self):
        """单元边界由区域边界计算，仅保存索引必需的网格形状及谱序。"""
        if not self.layout.grids:
            raise RuntimeError("请先调用 build_grid")
        payloads = {}
        for cluster_id, grid in self.layout.grids.items():
            lnm, tnm = int(grid["lnm"]), int(grid["tnm"])
            ordmap = [int(rank) for rank in grid["ordmap"]]
            n_cells = lnm * tnm
            if sorted(ordmap) != list(range(n_cells)):
                raise ValueError(f"簇 {cluster_id} 的谱序映射不是排列")
            regions = sorted(
                region for region, cluster in self.layout.clusters.items()
                if cluster == cluster_id
            )
            payloads[cluster_id] = {
                "cluster_id": int(cluster_id),
                "num_regions": len(regions),
                "num_cells": n_cells,
                "lnm": lnm,
                "tnm": tnm,
                "ordmap": ordmap,
                "region_keys": [str(region) for region in regions],
            }
        self.output_dir.mkdir(parents=True, exist_ok=True)
        paths = []
        for cluster_id, payload in payloads.items():
            path = self.output_dir / f"cluster_{cluster_id}_grid.json"
            temporary = path.with_suffix(path.suffix + ".tmp")
            temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                                 encoding="utf-8")
            temporary.replace(path)
            paths.append(path)
        return paths


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="按已有聚类结果构建查询驱动网格")
    parser.add_argument("--data-dir", type=Path, default=None)
    parser.add_argument("--query-dir", type=Path, default=None)
    parser.add_argument("--cluster-csv", type=Path, default=Path(BIC.CLUSTER_CSV))
    parser.add_argument("--output-dir", type=Path, default=Path(BIC.GRID_LAYOUT_DIR))
    args = parser.parse_args()
    cfg = LayoutConfig(source_dir=Path(BIC.SOURCE_DIR),
                       query_dir=Path(BIC.QUERY_DIR),
                       data_dir=Path(BIC.DATA_ROOT))
    cfg = replace(cfg, data_dir=args.data_dir or cfg.data_dir,
                  query_dir=args.query_dir or cfg.query_dir)
    builder = GridLayoutBuilder(cfg, args.cluster_csv, args.output_dir)
    for cluster_id, grid in builder.build_grid().items():
        print(f"簇 {cluster_id}: {grid['lnm']} x {grid['tnm']} = "
              f"{grid['lnm'] * grid['tnm']} 个单元")
    for path in builder.save_cluster_layouts():
        print(f"已保存 {path}")
