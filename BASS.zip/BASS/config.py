# config.py
# 路径、划分参数与模型参数。

import os
from dataclasses import dataclass
import json
from pathlib import Path

import numpy as np


# ============================================================
# 项目根目录与通用路径
# ============================================================

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
DATASET_NAME = os.environ.get("BSPLINE_DATASET", "chd").lower()
DATASET_ROOT = os.path.join(PROJECT_ROOT, DATASET_NAME)
PREPROCESS_ROOT = os.path.join(DATASET_ROOT, "data_preprocess")

DATASETS = {
    "nrmd": {
        "data_root": os.path.normpath(os.path.join(PROJECT_ROOT, "..", "BASS", "nrmd", "partitioned_data")),
        "source_dir": r"E:\暑期工作代码\DATA\nrmd",
        "query_dir": r"E:\暑期工作代码\DATA\nrmd\query",
        "net_xml": os.path.join(PROJECT_ROOT, "data_preprocess", "Beijing_join_addLanes1-1.net.xml"),
        "segment_features": os.path.join(PROJECT_ROOT, "data_preprocess", "Beijing_road_features_extracted.csv"),
        "periods": tuple(range(1, 15)),
        "partition": (34, 30),
    },
    "vard": {
        "data_root": os.path.join(PROJECT_ROOT,"..", "BASS", "vard", "partitioned_data"),
        "source_dir": r"E:\暑期工作代码\DATA\vard",
        "query_dir": r"E:\暑期工作代码\DATA\vard\query",
        "net_xml": os.path.join(PROJECT_ROOT, "data_preprocess", "Beijing_join_addLanes1-1.net.xml"),
        "segment_features": os.path.join(PROJECT_ROOT, "data_preprocess", "Beijing_road_features_extracted.csv"),
        "periods": tuple(range(1, 15)),
        "partition": (34, 30),
    },
    "chd": {
        "data_root": os.path.join(PROJECT_ROOT, "..", "BASS","chd", "partitioned_data"),
        "source_dir": r"E:\暑期工作代码\DATA\chd",
        "query_dir":  r"E:\暑期工作代码\DATA\chd\query",
        "net_xml": os.path.join(PROJECT_ROOT, "data_preprocess", "chengdu.net.xml"),
        "segment_features": os.path.join(PROJECT_ROOT, "data_preprocess", "chengdu_road_features_extracted.csv"),
        "periods": tuple(range(1, 8)),
        "partition": (42, 38),
    }
}
INPUTS = DATASETS[DATASET_NAME]
DATA_ROOT = INPUTS["data_root"]
SOURCE_DIR = INPUTS["source_dir"]
QUERY_DIR = INPUTS["query_dir"]
NET_XML = INPUTS["net_xml"]

PARTITION_BOUNDARIES_JSON = os.path.join(
    DATA_ROOT, "partition_boundaries.json"
)


# ============================================================
# index_layout.py / grid_layout.py：区域与单元格划分
# ============================================================

@dataclass(frozen=True)
class LayoutConfig:
    # 首期区域边界及后续时期复用
    pos_parts: int = INPUTS["partition"][0]
    time_parts: int = INPUTS["partition"][1]
    bounds_filename: str = "data_bounds.json"
    quantile_method: str = "linear"
    source_dir: Path = Path(SOURCE_DIR)
    query_dir: Path = Path(QUERY_DIR)
    data_dir: Path = Path(DATA_ROOT)
    range_file: str = "range_query.txt"
    range_columns: tuple = (0, 1, 2, 3)
    delimiter: str = "\t"
    txt_format: str = "%.17g"

    @property
    def data_bounds(self):
        path = self.query_dir / self.bounds_filename
        bounds = json.loads(path.read_text(encoding="utf-8-sig"))
        for key in ("pos", "t"):
            values = np.asarray(bounds[key], dtype=float)
            if values.shape != (2,) or not np.isfinite(values).all() or values[0] >= values[1]:
                raise ValueError(f"{path}：{key}必须是有限的[最小值,最大值]")
        return bounds


@dataclass(frozen=True)
class GridLayoutConfig(LayoutConfig):
    # 簇内网格与谱排序参数
    shape_decimals: int = 1
    max_grid_cells: int = 200000
    spectral_connectivity: int = 4
    spectral_max_cells: int = 8192



# cluster.py：两阶段区域聚类
# ============================================================

class TwoStageClusteringConfig:
    # 输入与路段编码
    SEGMENTS_CSV = INPUTS.get(
        "segment_features",
        os.path.join(PREPROCESS_ROOT, "road_features_extracted.csv"),
    )
    PERIOD1_DIR = os.path.join(DATA_ROOT, "EP_1")
    XML_PATH = NET_XML
    REGION_BOUNDARIES_PATH = PARTITION_BOUNDARIES_JSON
    ENCODING_CSV = INPUTS.get(
        "segment_encoding",
        os.path.join(PREPROCESS_ROOT, "segments_200w_propagated_all_region.csv"),
    )
    REUSE_SEGMENT_ENCODING = "segment_encoding" in INPUTS
    EPS = 11.00
    MAX_ITER = 100

    # 第一阶段：路段嵌入 + 时间嵌入的 n-gram 聚类
    STAGE1_GRID_ROWS = 100
    STAGE1_GRID_COLS = 100
    STAGE1_CELL_DIM = 6
    STAGE1_CLUSTER_COUNT = 3
    STAGE1_NGRAM_N = 2
    STAGE1_VOCAB_SIZE = 20
    RANDOM_STATE = 42

    # 第二阶段：仅在第一阶段簇内，按双轴累积点数差继续细分
    STAGE2_GRID_ROWS = 100
    STAGE2_GRID_COLS = 100
    STAGE2_CUMULATIVE_THRESHOLD = 1000.0

    # 聚类结果
    OUTPUT_CSV = os.path.join(PREPROCESS_ROOT, "region_clusters_two_stage.csv")


# ============================================================
# B-Spline 索引
# ============================================================

class BSplineIndexConfig:
    # 数据路径
    DATA_ROOT = DATA_ROOT
    SOURCE_DIR = SOURCE_DIR
    QUERY_DIR = QUERY_DIR
    DATASET_NAME = DATASET_NAME
    DATASET_ROOT = DATASET_ROOT
    CLUSTER_CSV = TwoStageClusteringConfig.OUTPUT_CSV
    GRID_LAYOUT_DIR = os.path.join(PREPROCESS_ROOT, "cluster_layouts")
    SAVE_DIR = os.path.join(DATASET_ROOT, "saved_index")
    DATA_DISK_ROOT = os.path.join(DATASET_ROOT, "saved_data")
    LOG_DIR = os.path.join(DATASET_ROOT, "logs")
    # 要更新的期数
    UPDATE_PERIODS = list(INPUTS.get("periods", (1, 2, 3, 4))[1:])

    # 查询验证期数
    QUERY_PERIODS = list(INPUTS.get("periods", (1, 2, 3, 4)))

    # 独立分析目标簇
    TARGET_CLUSTER = 0

    # 分裂阶段的 k 分析参数
    SPLIT_K = 2
    SPLIT_TARGET_CE = None  # 绝对 ce；为 None 时用 ratio
    SPLIT_TARGET_CE_RATIO = 0.1  # baseline 的比例
    SPLIT_KLIST = [2, 3, 5, 8]
    SPLIT_N_POINTS = 3
    SPLIT_N_INIT = 5

    # B-Spline 超参数
    GAMMA = 4
    DEGREE = 2
    PHI = 5

