"""预测页优先的查询实现。"""

import bisect
from collections import OrderedDict
import heapq
import math
import os

from disk_io import BLOCK_SIZE, RECORD, read_data_page, buffer, CACHE_SIZE_BYTES, PAGE_SIZE


PAGE_FENCE_LIMIT = 2048  # 每条缓存页首、尾单元格谱序，各占 4 B。
KNN_EXPANSION_FACTOR = 2
# 4 MiB 逻辑缓存同时容纳数据页和页边界：2048 × 8 B = 2 个 8 KiB 页。
buffer.max_pages = (CACHE_SIZE_BYTES - PAGE_FENCE_LIMIT * 8) // PAGE_SIZE
_page_fences = OrderedDict()
_file_signatures = {}


def clear_page_fences():
    """与数据页缓存一起，在每类查询开始时清空页边界"""
    _page_fences.clear()
    _file_signatures.clear()


def _fence_key(MCgm, gm, page):
    # QueryModelCluster 初始化时已规范化路径，热路径中不重复调用 abspath。
    path = MCgm.data_path
    if path not in _file_signatures:
        stamp = os.stat(path)
        _file_signatures[path] = (stamp.st_mtime_ns, stamp.st_size)
    mtime_ns, size = _file_signatures[path]
    return (path, int(gm), int(page), mtime_ns, size)


def _cached_fence(key):
    if key in _page_fences:
        _page_fences.move_to_end(key)
        return True, _page_fences[key]
    return False, None


def _remember_fence(key, records, MCgm, RG):
    if records:
        # 页内记录连续按谱序写入，页首尾记录可界定该页涉及的单元格序号。
        def rank(record):
            pos, t = record
            i = _slot(t, *RG[0], MCgm.tnm)
            j = _slot(pos, *RG[1], MCgm.lnm)
            return int(MCgm.ordmap[j * MCgm.tnm + i])

        first, last = rank(records[0]), rank(records[-1])
        fence = (first, last) if first <= last else None
    else:
        fence = None
    _page_fences[key] = fence
    _page_fences.move_to_end(key)
    if len(_page_fences) > PAGE_FENCE_LIMIT:
        _page_fences.popitem(last=False)
    return fence


def _read_page(MCgm, gm, RG, page):
    records, io = read_data_page(MCgm.data_path, gm, page)
    key = _fence_key(MCgm, gm, page)
    if key not in _page_fences:
        _remember_fence(key, records, MCgm, RG)
    return records, io


class QueryModelCluster:
    """目标期、目标区域的模型查询视图。"""

    def __init__(self, model, period, region_id, data_path, error_bound):
        self.model, self.period, self.region_id = model, period, region_id
        self.data_path = os.path.abspath(os.fspath(data_path))
        self.tnm, self.lnm = int(model.tnm), int(model.lnm)
        self.ordmap = model.ordmap
        self.error_bound = float(error_bound)
        if self.error_bound < 0 or not math.isfinite(self.error_bound):
            raise ValueError("error_bound 必须是有限的非负累计点数误差界")
        size = os.path.getsize(self.data_path)
        if size % RECORD.size:
            raise ValueError("数据文件长度不是完整记录的整数倍")
        self.point_count = size // RECORD.size
        self._cumulative_cache = {-1: 0.0}

    def _cumulative(self, cell):
        if cell not in self._cumulative_cache:
            C = self.model.get_coeffs(cell + 1, self.region_id, self.period)
            self._cumulative_cache[cell] = float(self.model.AM[0].N_matrix[cell] @ C)
        return self._cumulative_cache[cell]

    def P_M(self, cell):
        """按该期累计点数误差界给出谱序单元格的候选记录闭区间。"""
        start = self._cumulative(cell - 1)
        end = self._cumulative(cell)
        lower = max(0, math.floor(start - self.error_bound))
        # end 是右开边界，转成记录下标后要减 1。
        upper = min(self.point_count - 1, math.ceil(end + self.error_bound) - 1)
        return lower, upper


def binarySearch(scale, value):
    """返回固定线性尺度上包含 value 的区间与 0-based 区间号。"""
    if len(scale) < 2 or value < scale[0] or value > scale[-1]:
        raise ValueError("坐标超出全局分区范围")
    i = min(len(scale) - 2, bisect.bisect_right(scale, value) - 1)
    return (scale[i], scale[i + 1]), i


def targetRegion(pq, gls, gts):
    """论文算法 7：确定点查询的区域范围和区域编号。"""
    (ta, tb), ti = binarySearch(gts, pq[0])
    (la, lb), lj = binarySearch(gls, pq[1])
    gm = lj * (len(gts) - 1) + ti + 1
    return ((ta, tb), (la, lb)), gm


def regionQueries(rq, gts, gls):
    """论文算法 9：将范围查询裁成相交区域内的查询。"""
    (tx, tz), (lx, lz) = rq
    if tx > tz or lx > lz:
        raise ValueError("范围查询下界不能大于上界")
    tx, tz = max(tx, gts[0]), min(tz, gts[-1])
    lx, lz = max(lx, gls[0]), min(lz, gls[-1])
    if tx > tz or lx > lz:
        return []
    (_, _), ia = binarySearch(gts, tx)
    (_, _), ib = binarySearch(gts, tz)
    (_, _), ja = binarySearch(gls, lx)
    (_, _), jb = binarySearch(gls, lz)
    rt = []
    for i in range(ia, ib + 1):
        qtx, qtz = max(tx, gts[i]), min(tz, gts[i + 1])
        for j in range(ja, jb + 1):
            qlx, qlz = max(lx, gls[j]), min(lz, gls[j + 1])
            gm = j * (len(gts) - 1) + i + 1
            rt.append((gm, ((qtx, qtz), (qlx, qlz)),
                       ((gts[i], gts[i + 1]), (gls[j], gls[j + 1]))))
    return rt


def _slot(value, lower, upper, slots):
    return min(slots - 1, max(0, math.floor((value - lower) / (upper - lower) * slots)))


def cellNumberSeq(gm, grq, RG, MC):
    """每个位置行返回一个行主序单元编号闭区间。"""
    (tx, tz), (lx, lz) = grq
    (ta, tb), (la, lb) = RG
    m, n = MC.tnm, MC.lnm
    ia, ib = _slot(tx, ta, tb, m), _slot(tz, ta, tb, m)
    ja, jb = _slot(lx, la, lb, n), _slot(lz, la, lb, n)
    return [(j * m + ia, j * m + ib) for j in range(ja, jb + 1)]


def _runs(numbers):
    rt = []
    for number in numbers:
        if rt and number == rt[-1][1] + 1:
            rt[-1] = (rt[-1][0], number)
        else:
            rt.append((number, number))
    return rt


def _page_ranks(MCgm, gm, RG, page):
    """落盘单元格按谱序排列，页首/页尾记录给出页内谱序范围。"""
    key = _fence_key(MCgm, gm, page)
    hit, fence = _cached_fence(key)
    if hit:
        return fence
    _read_page(MCgm, gm, RG, page)
    return _page_fences[key]


def _locate_run(MCgm, gm, RG, first_rank, last_rank, middle_first=False):
    """单格从预测中间页定位，连续段从预测边界定位。"""
    if not MCgm.point_count:
        return []
    lower, _ = MCgm.P_M(first_rank)
    _, upper = MCgm.P_M(last_rank)
    if lower > upper:
        return []
    lo, hi = lower // BLOCK_SIZE, upper // BLOCK_SIZE
    clamp = lambda page: min(hi, max(lo, page))
    seen = {}

    def bounds(page):
        if page not in seen:
            seen[page] = _page_ranks(MCgm, gm, RG, page)
        if seen[page] is None:
            raise ValueError("无法从数据页确定单元格谱序")
        return seen[page]

    try:
        if middle_first:
            # 单格查询从预测区间中点所在页开始，再用页首尾谱序校正。
            predicted = (MCgm._cumulative(first_rank - 1) +
                         MCgm._cumulative(last_rank)) / 2
            page = clamp(math.floor(predicted / BLOCK_SIZE))
            while page < hi and bounds(page)[1] < first_rank:
                page += 1
            while page > lo and bounds(page)[0] > last_rank:
                page -= 1
            if bounds(page)[1] < first_rank or bounds(page)[0] > last_rank:
                return []
            left = right = page
        else:
            # 连续段先分别定位预测起止页，并向内移动到可能相交的页。
            left = clamp(math.floor(MCgm._cumulative(first_rank - 1) / BLOCK_SIZE))
            right = clamp((math.ceil(MCgm._cumulative(last_rank)) - 1) // BLOCK_SIZE)
            while left < hi and bounds(left)[1] < first_rank:
                left += 1
            while right > lo and bounds(right)[0] > last_rank:
                right -= 1
        # 页首或页尾仍可能落在目标谱序范围时，向该侧扩一页。
        while left > lo and bounds(left)[0] >= first_rank and bounds(left - 1)[1] >= first_rank:
            left -= 1
        while right < hi and bounds(right)[1] <= last_rank and bounds(right + 1)[0] <= last_rank:
            right += 1
        if bounds(left)[1] < first_rank or bounds(right)[0] > last_rank or left > right:
            return []
        return range(left, right + 1)
    except ValueError:
        # 页首尾信息不可用时，读取误差界覆盖的全部候选页。
        return range(lo, hi + 1)


def blockNumberSeq(MCgm, lcs, gm=None, RG=None, middle_first=False):
    """给出区域范围时优先定位预测边界页。"""
    olst = sorted({int(MCgm.ordmap[e])
                   for first, last in lcs for e in range(first, last + 1)})
    pages = set()
    for lower, upper in _runs(olst):
        if gm is not None and RG is not None:
            pages.update(_locate_run(MCgm, gm, RG, lower, upper, middle_first))
        else:
            left, _ = MCgm.P_M(lower)
            _, right = MCgm.P_M(upper)
            if left <= right:
                pages.update(range(left // BLOCK_SIZE, right // BLOCK_SIZE + 1))
    return _runs(sorted(pages))


def pointQuery(pq, gts, gls, MC):
    """预测页先读，按页首尾谱序只扩展可能含目标单元格的方向。"""
    RG, gm = targetRegion(pq, gls, gts)
    MCgm = MC[gm]
    grq = ((pq[0], pq[0]), (pq[1], pq[1]))
    LC = cellNumberSeq(gm, grq, RG, MCgm)
    rank = int(MCgm.ordmap[LC[0][0]])
    lower, upper = MCgm.P_M(rank)
    if lower > upper:
        return []
    lo, hi = lower // BLOCK_SIZE, upper // BLOCK_SIZE
    predicted = (MCgm._cumulative(rank - 1) + MCgm._cumulative(rank)) / 2
    middle_page = min(hi, max(lo, math.floor(predicted / BLOCK_SIZE)))
    # 小顶堆按离预测页的页数排序，减少不必要的远端页读取。
    pages, visited = [(0, middle_page)], set()
    while pages:
        _, page = heapq.heappop(pages)
        if page in visited:
            continue
        visited.add(page)
        found = [(pos, t) for pos, t in _read_page(MCgm, gm, RG, page)[0]
                 if t == pq[0] and pos == pq[1]]
        if found:
            return found
        fence = _page_ranks(MCgm, gm, RG, page)
        if fence is None:
            for candidate in range(lo, hi + 1):
                if candidate not in visited:
                    heapq.heappush(pages, (abs(candidate - middle_page), candidate))
            continue
        first, last = fence
        # 目标谱序小于页内范围时只查左邻页，大于时只查右邻页。
        if rank <= first and page > lo:
            heapq.heappush(pages, (abs(page - 1 - middle_page), page - 1))
        if rank >= last and page < hi:
            heapq.heappush(pages, (abs(page + 1 - middle_page), page + 1))
    return []


def rangeQuery(rq, gts, gls, MC):
    """区域裁剪、单元序列、预测边界定位、逐点验证。"""
    rt = []
    for gm, grq, RG in regionQueries(rq, gts, gls):
        MCgm = MC[gm]
        LC = cellNumberSeq(gm, grq, RG, MCgm)
        LB = blockNumberSeq(MCgm, LC, gm, RG)
        for first, last in LB:
            for bk in range(first, last + 1):
                for pos, t in _read_page(MCgm, gm, RG, bk)[0]:
                    # 页中可能含查询框外的记录，按裁剪后的坐标范围精确过滤。
                    if grq[0][0] <= t <= grq[0][1] and grq[1][0] <= pos <= grq[1][1]:
                        rt.append((pos, t))
    return rt


def mindist(pq, grq, eta):
    """点到区域查询矩形的加权距离下界。"""
    dt = max(grq[0][0] - pq[0], 0, pq[0] - grq[0][1])
    dl = max(grq[1][0] - pq[1], 0, pq[1] - grq[1][1])
    return math.hypot(dt, eta * dl)


def _cell_mindist(pq, cell, RG, MCgm, eta):
    """点到网格单元矩形的加权距离下界，用于安全剪枝。"""
    (ta, tb), (la, lb) = RG
    row, col = divmod(cell, MCgm.tnm)
    cell_t = (ta + col * (tb - ta) / MCgm.tnm,
              ta + (col + 1) * (tb - ta) / MCgm.tnm)
    cell_l = (la + row * (lb - la) / MCgm.lnm,
              la + (row + 1) * (lb - la) / MCgm.lnm)
    return mindist(pq, (cell_t, cell_l), eta)


class ResultQueue(list):
    """按距离升序维护前 K 个样本。"""

    def __init__(self, K, eta):
        super().__init__()
        self.K, self.eta = K, eta

    def put(self, distance, pos, t):
        bisect.insort(self, (distance, pos, t))
        if len(self) > self.K:
            self.pop()


def _cell_candidates(pq, grq, RG, MCgm, eta):
    cls = cellNumberSeq(0, grq, RG, MCgm)
    return sorted(
        ((_cell_mindist(pq, cell, RG, MCgm, eta), cell)
         for first, last in cls for cell in range(first, last + 1)),
        key=lambda item: item[0],
    )


def _filter_cell(pq, gm, RG, VB, RQ, MCgm, cell):
    """读取单个候选单元格对应的页；每次 kNN 查询中每页只扫描一次。"""
    for first, last in blockNumberSeq(MCgm, [(cell, cell)], gm, RG, middle_first=True):
        for page in range(first, last + 1):
            key = (MCgm.data_path, page)
            if key in VB:
                continue
            for pos, t in _read_page(MCgm, gm, RG, page)[0]:
                distance = math.hypot(t - pq[0], RQ.eta * (pos - pq[1]))
                if len(RQ) < RQ.K or distance < RQ[-1][0]:
                    RQ.put(distance, pos, t)
            VB.add(key)


def filterSample(pq, gm, grq, RG, VB, RQ, MCgm):
    """按单元格距离下界优先检查，并定位逻辑块、复用已读页。"""
    for lower, cell in _cell_candidates(pq, grq, RG, MCgm, RQ.eta):
        # 当前单元下界已超过第 K 近距离，后续单元也可安全跳过。
        if len(RQ) >= RQ.K and lower > RQ[-1][0]:
            break
        _filter_cell(pq, gm, RG, VB, RQ, MCgm, cell)
    return VB, RQ


def kNNQuery(kq, beta, gts, gls, eta, MC):
    """窗口逐轮扩张，区域内有序单元格通过小顶堆全局归并。"""
    pq, K = kq
    if K < 1 or beta <= 0 or eta <= 0:
        raise ValueError("K、beta、eta 必须是正数")
    RQ, VB = ResultQueue(K, eta), set()
    sigma = math.sqrt(K / beta) * min(len(gts), len(gls)) / 4

    while True:
        # 以当前 sigma 构造查询窗；未找到足够近的 K 点时按固定倍数扩窗。
        tl, ll = 2 * sigma, 2 * sigma / eta
        W = ((pq[0] - tl / 2, pq[0] + tl / 2),
             (pq[1] - ll / 2, pq[1] + ll / 2))
        region_cells = []
        queue = []
        for gm, grq, RG in regionQueries(W, gts, gls):
            MCgm = MC[gm]
            cells = _cell_candidates(pq, grq, RG, MCgm, eta)
            if cells:
                region_cells.append((gm, RG, MCgm, cells))
                sequence = len(region_cells) - 1
                heapq.heappush(queue, (cells[0][0], sequence, 0))

        while queue:
            lower, sequence, cell_index = heapq.heappop(queue)
            # 全局最小下界已超过当前第 K 名距离，剩余单元均无需访问。
            if len(RQ) >= K and lower > RQ[K - 1][0]:
                break
            gm, RG, MCgm, cells = region_cells[sequence]
            _filter_cell(pq, gm, RG, VB, RQ, MCgm, cells[cell_index][1])
            cell_index += 1
            if cell_index < len(cells):
                heapq.heappush(queue, (cells[cell_index][0], sequence, cell_index))

        full_coverage = (W[0][0] <= gts[0] and W[0][1] >= gts[-1]
                         and W[1][0] <= gls[0] and W[1][1] >= gls[-1])
        if len(RQ) >= K and RQ[K - 1][0] <= sigma:
            break
        if full_coverage:
            break
        sigma *= KNN_EXPANSION_FACTOR

    return [(pos, t) for _, pos, t in RQ]
