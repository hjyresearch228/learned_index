import glob
import json
import os
import random
import pickle
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import json
from scipy.linalg import lstsq
from config import BSplineIndexConfig as BIC

DATA_PREPROCESS_DIR = Path(__file__).resolve().parents[1] / "data_preprocess"
if str(DATA_PREPROCESS_DIR) not in sys.path:
    sys.path.insert(0, str(DATA_PREPROCESS_DIR))
from data_preprocess.index_layout import IndexLayout, LayoutConfig

'''
B-Spline model for every model cluster
'''
class BSplineModel:
    """B-Spline:节点、基函数、系数、预测、局部更新"""
    def __init__(self,  n_cells, degree, n_ctrl):
        self.n_cells = n_cells
        self.n_ctrl = n_ctrl        # 控制点数量
        self.degree = degree
        self.U = self._create_knots(n_ctrl)
        self.ce = None
        self.er = None

        self.C = None
        self.Y = None

        self.N = []                 # 抽象
        self.N_matrix = None        # 代入cell_id后的具体基函数矩阵对应的数值

        # 1. 创建基函数集合--N=[ N1(u),N2(u),..N_「n/gamma(u) ],每个元素是一个基函数 N_i(u)返回第 i 个基函数在参数 u 处的值
        from functools import partial
        for i in range(n_ctrl):
            N_i = partial(basis_function, i, degree, U=self.U)
            self.N.append(N_i)



    def _create_knots(self, n_ctrl):
        p = self.degree
        # 内部节点数 = n_ctrl - p -1
        if n_ctrl <= p:
            raise ValueError(f"n_ctrl={n_ctrl} must be > degree={p}")
        print("create knots ...")
        n_internal = n_ctrl - p - 1
        internal = (np.linspace(0, 1, n_internal + 2)[1:-1]
                    if n_internal > 0 else [])
        print('internal:', internal)
        U = np.concatenate([np.zeros(p + 1), internal, np.ones(p + 1)])
        print('U:', U)
        assert len(U) == n_ctrl + p + 1
        return U



    def compute_N_matrix(self, n_cells):
        """根据抽象基函数，代入 cell_id 生成具体的基函数矩阵(n_cells x n_ctrl)"""
        x_indices = np.arange(1, n_cells + 1)
        u_params = (x_indices - 1) / (n_cells - 1) if n_cells > 1 else np.zeros(n_cells)
        N_matrix = np.zeros((n_cells, self.n_ctrl))
        # 直接调用抽象基函数
        for i, basis_func in enumerate(self.N):
            N_matrix[:, i] = [basis_func(u) for u in u_params]
        self.N_matrix = N_matrix
        return N_matrix



    def fit(self, Y):  # 拟合目标Y 由外部传入
        '''求出控制点系数C，模型预测误差re'''
        self.N_matrix = self.compute_N_matrix(self.n_cells)
        self.C, *_ = lstsq(self.N_matrix, Y)
        self.re = np.max(np.abs(self.N_matrix @ self.C - Y))
        self.Y = np.asarray(Y, dtype=float).copy()




    def updateCoefficients(self, ra, rb, rl, current_SC, gamma,MC=None, t=0, pd=None):
        """
        局部更新 受影响的控制点系数（无分裂）。
        params：
            ra，rb：需要更新的cell起始和终止id
            rl：区域数
        return:
            {
            "ctrl_range": ctrl_cols,------新的控制点索引
            "old_C": old_C,
            "new_C": new_C,
            "delta": delta
            }
        """
        cell_rows = np.arange(ra - 1, rb)  # cell 索引
        N_full = self.compute_N_matrix(self.n_cells)
        # 由目标单元格的非零基函数确定实际参与预测的控制点
        ctrl_cols = np.flatnonzero(np.any(N_full[cell_rows] != 0, axis=0))
        N_sub = N_full[np.ix_(cell_rows, ctrl_cols)]

        # 4. 目标值 X：所选区域在 格子范围为 [ra, rb] 上的真实的平均累积样本数
        region_indices = [r - 1 for r in rl]        # 转为 0-based
        sub_matrix = current_SC[np.ix_(region_indices, cell_rows)]
        X = sub_matrix.mean(axis=0)                 #每个cell的平均累积样本数

        # 5. 最小二乘求解
        new_C, _, _, _ = lstsq(N_sub, X)

        # 6. 不改变原始系数
        initial_C  = self.C[ctrl_cols].copy()       # 复制

        # 被更新的系数的增量
        delta = new_C - initial_C

        return {
        "ctrl_range": ctrl_cols,
        "old_C": initial_C ,
        "abs_C": new_C,
        "delta": delta
        }






# ============================ 模型簇 ===========================
class ModelCluster:
    '''
    多区域管理：聚合、误差、触发更新、分裂
    '''
    def __init__(self, cluster_id,tnm,lnm,ordmap,SC, gamma, degree,phi):
        # MC = (tnm, lnm, ordmap, AM,  ccmin, DS)
        # AM = (M^0,M^1,..)
        # M = (N, C, re, ce, er)
        self.cluster_id = cluster_id
        self.tnm = tnm
        self.lnm = lnm
        self.ordmap = ordmap

        self.SC = np.asarray(SC, dtype=float)       # 多区域累积样本数，形状 (m, n)
                                                    # SC=[ s1,s2,..sm ]，sm=[s1m,s2m,..snm]每个区域的每个cell的累积样本数
        self.n = self.SC.shape[1]                   # cell格子数
        self.m = self.SC.shape[0]                   # 区域数

        self.gamma = gamma                          #每gamma个cell有一个控制点
        self.degree = degree

        self.Y = self.SC.mean(axis=0)               # mean对每个cell求所选区域的平均累积样本数（索引预测输出）
                                                    # 预测目标：平均累积样本序列
        # self.rd = degree                          # 控制点影响范围（等于阶数）
        # 控制点至少为 3；同时保证数量大于样条次数，避免节点向量无效。
        n_ctrl = max(3, degree + 1, int(np.ceil(self.n / gamma)))

        # 直接创建 BSplineModel 实例，完成初始化
        self.M = BSplineModel(self.n, degree, n_ctrl)
        self.M.fit(self.Y)                              #C，re(预测误差)，Y
        self.M.ce = np.max(np.abs(SC - self.Y))         #区域偏离
        self.M.er = self.M.re + self.M.ce

        self.DS = {}                                    # {pd: {ctrl_idx: new_value, ...}}
        self.current_period = 0                         # period=0 :初始模型，1:第一期

        # 直接把 初始的M 作为 AM 的第一个元素
        self.AM = [self.M]                              # 锚模型集合，初始只含初始模型 M
        self.c_min = float('inf')                       # 最小相关阈值（初始为 +∞）
        self.phi = phi                                  # 锚模型数量上限



    def get_coeffs(self, cell_id, region_id, period):
        """
        从DS中获取指定期、指定 cell、指定 region 的完整控制点系数。
          - 从 AM[0].C 出发；
          - 每期先切换到所选锚模型，再应用本期更新记录：
              * {"anchor": k}                      → 切换到 AM[k].C
              * {"tag": 1, "cell_range", "abs_C"}  → 覆盖对应控制点
              * {"tag": 2, "cell_range", "groups"} → 按 region 所属分组覆盖
        """
        # 1. 从初始锚模型 AM[0] 的系数出发
        C = self.AM[0].C.copy()
        matched = False

        # 2. 按期顺序叠加 DS
        for pd in sorted(self.DS.keys()):
            if pd > period:
                break

            for record in self.DS[pd]:
                # ---------- 锚模型切换记录 ----------
                if "anchor" in record:
                    anchor_id = int(record["anchor"])
                    C = self.AM[anchor_id].C.copy()
                    continue

                # ---------- cell 级更新记录 ----------
                ra, rb = record["cr"]
                if not (ra <= cell_id <= rb):
                    continue
                # 此 cell 在此次更新记录内
                st = int(record["st"])      #控制点起始索引
                if record["t"] == 1:
                    for offset, v in enumerate(record["C"]):
                        C[st + offset] = float(v)

                elif record["t"] == 2:
                    matched = False
                    for group in record["g"]:
                        if region_id not in group["r"]:
                            continue
                        for offset, v in enumerate(group["C"]):
                            C[st + offset] = float(v)
                        matched = True
                        break
                    if not matched:
                        raise RuntimeError(
                            f"DS[pd={pd}] tag=2 记录中，region_id={region_id} "
                            f"不属于任何组 {[g['r'] for g in record['g']]}"
                        )
        return C



    def predict_avg(self, cell_ids, period):
        """
        预测指定期、每个 cell 上『所有区域平均』的累积样本数。
        说明：
          - 分裂时不同 region 走不同曲线；
          - "所有区域平均" = 对所有 region 逐一带入其所属组的系数、
        params:
            cell_ids : list[int] 或 np.ndarray，1-based 格子编号
            period   : 第几期
        return:
            np.ndarray，与 cell_ids 等长
        """
        cell_ids = np.asarray(cell_ids)
        all_regions = list(range(1, self.m + 1))   # self.m = 区域数
        N_matrix = self.AM[0].N_matrix             # 所有锚模型共享同一套基函数矩阵

        result = np.zeros(len(cell_ids), dtype=float)
        for k, cid in enumerate(cell_ids):
            y_sum = 0.0
            for region_id in all_regions:
                C_r = self.get_coeffs(int(cid), int(region_id), int(period))
                y_sum += float(N_matrix[cid - 1] @ C_r)
            result[k] = y_sum / len(all_regions)

        return result





def basis_function(i, p, u, U):
    """
    计算 N_{i,p}(u) : 第 i 个 p 次 B-spline 基函数在参数 u 处的值。
    参数:
        i : int, 基函数索引 (0 <= i <= len(U)-p-2)--- 控制点数-1
        p : int, 基函数次数
        u : float, 参数值
        U : array_like, 节点向量
    """
    # 处理 u 等于最大节点值的情况（右端点）
    if abs(u - U[-1]) < 1e-12:
        # 最后一个基函数在 u=U[-1] 处取值为 1，其余为 0
        if i == len(U) - p - 2:
            return 1.0
        else:
            return 0.0

    # 0 次基函数
    if p == 0:
        return 1.0 if (U[i] <= u < U[i + 1]) else 0.0

    # 递推计算
    left = 0.0
    right = 0.0
    denom1 = U[i + p] - U[i]
    if denom1 != 0.0:
        left = (u - U[i]) / denom1 * basis_function(i, p - 1, u, U)
    denom2 = U[i + p + 1] - U[i + 1]
    if denom2 != 0.0:
        right = (U[i + p + 1] - u) / denom2 * basis_function(i + 1, p - 1, u, U)

    return left + right






# ==================================== 更新 ====================================

'''
传入需要更新的cell_id,模型簇，进行曲线段的更新 -> 每次更新后的系数保存到DS[pd]当中
'''
# 1.为新一期数据根据 KL 散度选择最相似锚模型 t
def select_anchor_model(MC, Y_current):
    '''
    根据 KL 散度选择最相似锚模型
    return:
        best_t
    '''
    # 第pd期平均累积样本数Y的分布
    P_pd = Y_current / Y_current[-1]
    best_t, best_kd = 0, float('inf')
    for i, M_anchor in enumerate(MC.AM):
        # 根据基函数矩阵N和锚模型的系数C，获得锚模型预测的平均累积样本数（预测准度）
        Y_anchor = M_anchor.N_matrix @ M_anchor.C
        # 锚模型的平均累积样本数Y_的分布
        P_i = Y_anchor / Y_anchor[-1]
        eps = 1e-12
        P_pd_s, P_i_s = np.clip(P_pd, eps, 1), np.clip(P_i, eps, 1)
        # 计算KL散度值
        kd = np.sum(P_pd_s * np.log(P_pd_s / P_i_s))
        if kd < best_kd:
            best_kd, best_t = kd, i
    return best_t



# 2.在此锚模型基础上更新参数
def updateCurveSegments(avg_deviation,max_region_deviation,as_dict, ds_dict, MC, current_SC, t=0, pd=None):
    """
    在此之前已判断KL散度相似性，传入最符合此期数据分布的锚模型索引t。
    在此基础上，逐个单元格判断误差是否过大，即是否需要更新（细粒度筛选），
    params:
        as_dict：某单元格上当前期真实的累积样本数和锚模型的真实的累积样本数的差超过锚模型预测误差
        ds_dict: 某单元格，某个区域的真实累积样本数和平均累积样本数之差大于锚模型的ce
        current_SC：当前真实的各区域在每个格子上的累积样本数
        t：与当前期数据分布最相似的锚模型索引
    return：
        更新后的模型簇 MC
    """
    # 初始化
    rt = {}                                     #记录每个 cell 的处理标签{cell_id:1/2,..}
    cntr = 0                                    #记录更新的cell的数量
    reused = True                               #默认重用，此时已知最相似分布的重用模型t
    anchored = True
    # 合并 as 和 ds 的元素并排序
    n = MC.n                                    # 区域的总 cell 数
    M_anchor = MC.AM[t]                         # 以当前锚模型为对比基础
    all_cells = sorted(set(as_dict) | set(ds_dict))

    # 遍历所有需要处理的 cell，标记
    for el in all_cells:
        # 获取该 cell 的两个偏差值
        a = avg_deviation[el - 1]  # 用真实值
        d = max_region_deviation[el - 1]  # 用真实值
        # a = as_dict.get(el, 0.0)
        # d = ds_dict.get(el, 0.0)
        # 误差变化太大 -> 需要更新
        if a + d > M_anchor.er:                        #er=re+ce
            #通过判断ds与ce的大小，决定分裂后更新还是仅更新
            # 仅仅是as>re--每个格子的平均累积样本数比原来大
            if d <= M_anchor.ce:
                rt[el] = 1
                cntr +=1                        #大范围局部更新的cell数+1
            # d > M.ce：某区域的某格子的累积数和平均的某格子累积数差太多--此区域的此格子发生巨大变化--可能变大也可能变小--原始参数C无法拟合两种变化趋势--根据变化趋势进行分裂
            elif d > M_anchor.ce:
                rt[el] = 2
                anchored = False                #局部更新与分裂的混合情况，不加入锚模型，只记录于DS[pd]
            #发生更新了，不重用模型
            reused = False

    # 1. 误差没有达到阈值-->直接重用最相似的模型t
    if reused:
        pd = _resolve_period(MC, pd)
        # 标记此期DS为已有的重用的模型索引t
        MC.DS[pd] = [{"anchor":t}]
        return MC

    # 2. 不可以重用，分布发生了变化，需要更新模型
    # 将rt合并为具有相同tag的连续范围
    print('需要更新的cell_id的范围以及标签（合并前）', rt)
    ranges = merge_ranges(rt)  # 返回 [(start, end, tag), ...]
    print('需要更新的cell_id的范围以及标签（合并后）',ranges)

    #开启新 period，准备累积本次更新的系数
    pd = _resolve_period(MC, pd)
    MC.DS[pd] = [{"anchor": int(t)}]
    #DS={
    #   pd1:[
    #       {
    #           "type":update,
    #           "tag":1,
    #           ...
    #        }
    #   ],
    #   pd2:[
    #           {record}
    #   ]
    # }

    # 对每个范围执行相应的更新操作，并将结果记录于DS[pd]中
    for rgn in ranges:
        ra, rb, tag = rgn                               #（ra，rb）连续区间
        if tag == 1:
            print(f"更新模型范围: cells {ra} ~ {rb}")
            all_regions = list(range(1, MC.SC.shape[0] + 1))
            result = M_anchor.updateCoefficients(ra, rb, all_regions, current_SC, MC.gamma)

            ctrl_range = result["ctrl_range"]
            st = int(ctrl_range[0])
            abs_C = result["abs_C"]

            record = {
                "t": 1,
                "cr": (int(ra), int(rb)),                # 格子号范围 cell_range
                "st": st,                               # 控制点索引范围 压缩为控制点起始索引
                "C": [float(v) for v in abs_C],     # 系数序列：abs[k] ↔ 控制点 st+k
            }
            MC.DS[pd].append(record)

        elif tag == 2:
            print(f"分裂并更新范围: cells {ra} ~ {rb}")
            # 目前只知道平均累积数下，超过ce的cell_id，并不知道是哪些区域的cell
            # 根据累积样本数序列 SC 将范围分裂为两个子范围
            k_target = _choose_split_k(MC, ra, rb, current_SC)
            clusters = split(ra, rb, current_SC, k=k_target)
            print(f"分裂结果: {len(clusters)} 个簇 -> {clusters}")

            # 对 k 个簇逐一求解控制点系数；所有簇共享同一 ra/rb/gamma，
            # 因此 ctrl_range 必然一致，取第一组作为 st。
            ctrl_cols = None
            st = None
            groups = []
            for regions in clusters:
                res = M_anchor.updateCoefficients(
                    ra, rb, regions, current_SC, MC.gamma
                )
                if ctrl_cols is None:
                    ctrl_cols = res["ctrl_range"]
                    st = int(ctrl_cols[0])
                # 所有簇用同一 ra/rb/gamma，ctrl_range 必须一致
                assert np.array_equal(ctrl_cols, res["ctrl_range"]), \
                    "不同簇的 ctrl_range 不一致，检查 updateCoefficients"
                groups.append({
                    "r": [int(x) for x in regions],
                    "C": [float(v) for v in res["abs_C"]],
                })

            record = {
                "t": 2,
                "cr": (int(ra), int(rb)),
                "st": st,
                "g": groups,  # k 个 group，get_coeffs 已能遍历匹配
            }
            MC.DS[pd].append(record)
            print(f"》〉》分裂为 {len(groups)} 个簇，控制点起始索引 st={st}，"
                  f"各组：{[g['r'] for g in groups]}")


    # 2.2 如果需要局部更新的单元个数太多了，说明分布发生重大变化
    # 就直接在AM中加入新的模型M，并且将此次更新DS[pd]标记为新模型M
    if cntr > n * (1.0 - 1.0 / MC.gamma) and len(MC.AM) < MC.phi and anchored == True:
        addAnchorModel(MC, t, pd, current_SC)

    return MC




def _resolve_period(MC, pd):
    """若 pd 未指定，则取 MC.current_period + 1；否则同步 MC.current_period。"""
    if pd is None:
        pd = MC.current_period + 1
        MC.current_period = pd
    else:
        MC.current_period = max(MC.current_period, pd)
    return pd


def _shape_correlation(current, anchor):
    """计算归一化累积序列的形状相似度，并处理 Pearson 相关系数无定义的边界情况。"""
    current = np.asarray(current, dtype=float)
    anchor = np.asarray(anchor, dtype=float)
    constant = (current.size < 2 or anchor.size < 2
                or np.isclose(np.std(current), 0.0)
                or np.isclose(np.std(anchor), 0.0))
    if constant:
        return 1.0 if np.allclose(current, anchor) else 0.0
    return abs(float(np.corrcoef(current, anchor)[0, 1]))


def addAnchorModel(MC, t, pd, SC):
    """
    数据分布变化剧烈，需要向AM中新增一个锚模型new_M，将其参数设置为此期更新后的MC.DS[pd]，并用其标识符覆盖 MC.DS[pd]
    params：
        MC：本期已经大范围更新完的模型M
        t:与此次数据分布最相似的模型索引
        pd：当前期数
        n：单元格数
    """
    # 以第 t 个锚模型的控制点系数为起点，用当前周期的更新记录覆盖系数，加入新模型
    # 直接使用本期真实数据 SC，重新训练一个完整的 B 样条模型 new_M。
    new_M = _train_new_model(MC,SC)

    # 计算当前周期分布与 AM 中各锚模型的最大相关系数
    Y_cur = np.mean(SC, axis=0)
    y_norm = Y_cur / Y_cur[-1] if Y_cur[-1] != 0 else Y_cur         #归一化稳定数值
    max_cc = 0.0
    for M_anchor in MC.AM:
        Y_anchor = M_anchor.N_matrix @ M_anchor.C
        anchor_norm = Y_anchor / Y_anchor[-1] if Y_anchor[-1] != 0 else Y_anchor
        # cc(Y, Y) = |pcc(Y, Y)|；单值或常量序列按形状是否一致处理。
        cc = _shape_correlation(y_norm, anchor_norm)
        max_cc = max(max_cc, cc)            #当前周期的分布形状与所有已有锚模型中最相似的那个的相似度

    # 精滤：通过判断各个锚模型的预测结果与真实Y的相似程度，获取最大相似值，
    # 与MC中保存的AM的最小相关阈值，再次确定当前分布无法用锚模型表示，进而加入新的锚模型
    if max_cc < MC.c_min:
        MC.AM.append(new_M)
        print("已加入新锚模型索引",t+1)
        MC.c_min = max_cc
        MC.DS[pd] = [{"anchor": len(MC.AM) - 1}]
    print("未加入新锚模型索引")

    return MC



def _train_new_model(MC,SC):
    """
    构造新锚模型的方法：重新训练此期数据（防止系数变化导致不变格子的预测误差）
    """

    # 当前期每个 cell 的平均累积样本数
    Y_cur = np.mean(SC, axis=0)
    # 沿用现有锚模型的控制点数量，确保模型结构一致
    base = MC.AM[0]
    new_M = BSplineModel(
        n_cells=MC.n,
        degree=base.degree,
        n_ctrl=base.n_ctrl
    )
    # 直接根据本期数据训练，求出控制点系数和模型预测误差re
    new_M.fit(Y_cur)
    # 重新计算新模型的误差指标
    new_M.ce = float(np.max(np.abs(SC - Y_cur)))
    new_M.er = float(new_M.re + new_M.ce)

    print(f"本期新模型训练完成：re={new_M.re:.6f}, "
          f"ce={new_M.ce:.6f}, er={new_M.er:.6f}")
    return new_M


def _construct_updated_model(MC, t, pd, SC):
    """
    基于 MC.AM[t] 和 MC.DS[pd] 构造新锚模型M。
    return:
        new_M
    """
    base = MC.AM[t]                     # 基底是 AM[t]=（N，C,er,re,ce）
    C_new = base.C.copy()

    for record in MC.DS.get(pd, []):
        # 跳过非更新记录
        if "t" not in record:
            continue

        # 控制点起始索引
        st = int(record["st"])

        # 只有tag=1：所有区域共享同一组系数
        if record["t"] == 1:
            for offset, v in enumerate(record["C"]):
                C_new[st + offset] = float(v)

        elif record["t"] == 2:
            raise NotImplementedError(
                f"有误：[_construct_updated_model] 遇到 tag=2 (split) 记录，"
                f"pd={pd}, cell_range={record.get('cr')}, "
                f"groups={[g.get('r') for g in record.get('g', [])]}"
            )

    # 装配于M=（N，C，er，ce，re）
    new_M = BSplineModel.__new__(BSplineModel)
    new_M.n_cells = MC.n
    new_M.n_ctrl = base.n_ctrl
    new_M.degree = base.degree
    new_M.U = base.U
    new_M.N = base.N
    new_M.N_matrix = base.N_matrix
    new_M.C = C_new

    # 误差重算
    Y_cur = np.mean(SC, axis=0)
    new_M.re = float(np.max(np.abs(new_M.N_matrix @ C_new - Y_cur)))
    new_M.ce = float(np.max(np.abs(SC - Y_cur)))
    new_M.er = new_M.re + new_M.ce
    new_M.Y = Y_cur.copy()

    return new_M



def merge_ranges(tag_dict):
    """
    将 tag_dict = {cell_id: tag} 合并成连续的相同 tag 范围。
    return：list of tuples [(start, end, tag),..]
    """
    if not tag_dict:
        return []
    cells = sorted(tag_dict.keys()) #id
    ranges = []
    start = prev = cells[0]
    prev_tag = tag_dict[start]
    for c in cells[1:]:
        if c == prev + 1 and tag_dict[c] == prev_tag:
            prev = c
        else:
            ranges.append((start, prev, prev_tag))
            start = prev = c
            prev_tag = tag_dict[c]
    ranges.append((start, prev, prev_tag))
    return ranges


def split_orig(ra, rb, SC,k=2):
    """
    对模型簇中所有区域在 [ra, rb] 范围内的累积样本数子序列进行 2-means 聚类。
    k-means：更新中心 → 计算误差 → 判断是否继续迭代
    params：
        ra, rb : int, 受影响 cell 的起始和结束序号
        SC     : m*n:(s1,s2,..sm) ,形状 (m, n)，m 个区域，s1=(s11,s12,..,s1n), 每个区域有 n 个累积样本数
    return：
        C1, C2 : list, 两种簇，每个簇C内记录簇内区域的索引（0-based）
    """
    m = len(SC)
    if m < 2:
        # 如果区域数小于2，无法聚类，直接返回所有区域为一个簇，另一个为空
        return list(range(1, m + 1)), []

    # 提取每个区域在 [ra, rb] 范围内的子序列作为特征向量
    # 索引获取所有区域内 符合此范围的 cell累积样本数
    features = [ region_seq[ra - 1:rb] for region_seq in SC ]   #[ [ra_num,,,rb_num],[],. ]

    # 1. 随机选择两个不同的区域作为初始中心
    indices = list(range(m))    #0,1,..m-1
    i, j = random.sample(indices, 2)  # 随机选两个不同索引作为中心
    center1 = features[i]  # 对应区域 i+1
    center2 = features[j]  # 对应区域 j+1

    # 初始化簇分配
    C1 = []
    C2 = []
    prev_err = float('inf') #无穷大∞
    epsilon = 1e-9
    max_iter = 100

    for _ in range(max_iter):
        # 2. 分配步骤：将每个区域分配给距离最近的中心
        new_C1 = []
        new_C2 = []
        for k in range(m):
            feat = features[k]
            # 使用无穷范数距离：计算两个向量在每个 cell 位置上的差异，取其中最大的差异作为距离
            dist1 = max(abs(a - b) for a, b in zip(feat, center1))
            dist2 = max(abs(a - b) for a, b in zip(feat, center2))
            if dist1 <= dist2:
                new_C1.append(k + 1)  # 区域编号为索引+1
            else:
                new_C2.append(k + 1)

        # 处理空簇情况：如果某个簇为空，则随机将一个区域移到该簇
        if not new_C1:
            # 从 new_C2 中移一个到 new_C1
            moved = new_C2.pop()
            new_C1.append(moved)
        if not new_C2:
            moved = new_C1.pop()
            new_C2.append(moved)

        # 3. 更新中心：计算每个簇的平均向量
        # 将区域编号转回索引以获取特征
        idx1 = [x - 1 for x in new_C1]
        idx2 = [x - 1 for x in new_C2]
        #求均值：新簇里的每个区域在各n个cell上的均值
        new_center1 = [ sum(features[i][d] for i in idx1) / len(idx1)
                       for d in range(len(features[0])) ]
        new_center2 = [sum(features[i][d] for i in idx2) / len(idx2)
                       for d in range(len(features[0]))]

        # 4. 计算误差 err(C1, C2)
        err = 0.0
        for idx_list, center in [(idx1, new_center1), (idx2, new_center2)]:
            for i in idx_list:
                #求和-簇内每个区域与新中心的距离
                feat = features[i]
                err += max(abs(a - b) for a, b in zip(feat, center))

        # 检查收敛：误差不再变化（或变化极小）
        if abs(prev_err - err) < epsilon:
            C1 = new_C1
            C2 = new_C2
            break

        # 更新中心和簇分配
        center1, center2 = new_center1, new_center2
        C1, C2 = new_C1, new_C2
        prev_err = err

    return C1, C2


def split(ra, rb, SC, k=2, n_init=10):
    """
    在 [ra, rb] 上把 m 个区域按累积样本数子序列分成 k 簇。
    - 聚类后去除空簇，返回有效区域分组。
    """
    features = np.array([region_seq[ra - 1:rb] for region_seq in SC], dtype=float)
    m = features.shape[0]
    if m < 2:
        return [[i + 1] for i in range(m)]     # 保持"list of lists"契约

    k = max(2, min(int(k), m))
    result = get_final_clustering(features, k, n_init=n_init)
    return [cl["region_ids"] for cl in result["clusters"]]





def calculate_deviation_sets(Y_anchor,Y_current,SC_current,re,ce):
    '''
    计算as={sl:详细数值},ds={sl:详细数值}。
    as：衡量更新后的平均累积样本数的某个格子的值 与 此格子的最初的平均累积样本数 差值 > 最初模型的预测误差
        模型预测的误差
    ds：更新后模型的某个区域某个格子的具体累积样本数 与 此格子的更新后的平均累积样本数的差值大于 初始模型的格子的最大偏离程度
        具体格子的偏离程度
    return:
        avg_deviation, max_region_deviation, as_dict, ds_dict
    '''
    avg_deviation = np.abs(Y_current - Y_anchor)
    as_dict = {
        i + 1: float(avg_deviation[i])
        for i in range(len(avg_deviation))
        if avg_deviation[i] >= re
    }

    region_deviation = np.abs(SC_current - Y_current)       # m * n，每一行是此区域的每个格子的偏离程度
    # 对于每个 cell sl，找出所有区域中偏离平均值最大的那个值
    max_region_deviation = np.max(region_deviation,axis=0)  #求出[m1,...mn]，每个具体的格子的最大偏离数是多少，但是不知道是哪个区域的格子
    # ds只需记录{符合条件的格子id：最大偏离数}
    ds_dict = {
        i + 1: float(max_region_deviation[i])
        for i in range(len(max_region_deviation))
        if max_region_deviation[i] >= ce
    }

    return avg_deviation, max_region_deviation, as_dict, ds_dict






# ============================ 簇数与方差关系分析 ============================
def _kmeans_numpy(features, k, max_iter=100, seed=0):
    """
    k-means（k-means++ 初始化，欧氏距离）
    """
    # features[i]	第 i 个区域在 [ra, rb] 上的累积样本数子序列
    features = np.asarray(features, dtype=float)
    # 区域数
    n = features.shape[0]
    rng = np.random.default_rng(seed)

    # k-means++ 初始化
    centers = [features[rng.integers(n)]]
    for _ in range(1, k):
        # 每个数据点到簇中心的距离--L2范数
        d2 = np.min(
            np.linalg.norm(features[:, None, :] - np.array(centers)[None, :, :], axis=2) ** 2,
            axis=1,
        )
        if d2.sum() <= 0:
            centers.append(features[rng.integers(n)])
        else:
            # 从索引 {0, 1, n-1} 中，按给定概率 p 抽 1 个索引，返回这个整数，作为新的簇中心
            centers.append(features[rng.choice(n, p=d2 / d2.sum())])

    # 已初始化每个簇中心
    centers = np.array(centers)

    labels = np.full(n, -1, dtype=int)
    for _ in range(max_iter):
        dists = np.linalg.norm(features[:, None, :] - centers[None, :, :], axis=2)
        new_labels = np.argmin(dists, axis=1)
        if np.array_equal(new_labels, labels):
            break
        labels = new_labels
        for c in range(k):
            members = features[labels == c]
            if len(members) == 0:
                centers[c] = features[rng.integers(n)]
            else:
                # 计算分配点后的簇中心（簇内点均值）
                centers[c] = members.mean(axis=0)


    # 为每个簇分配好稳定的簇中心后，计算每个簇内的 簇内平方和（点到中心的距离-欧几里得）
    inertia = 0.0
    for c in range(k):
        members = features[labels == c]
        # idx = np.where(labels == c)[0]  # 0-based
        # region_ids = [int(i + 1) for i in idx]  # 1-based 区域编号
        # members_ = features[idx]
        # ce_c = float(np.max(np.abs(members_ - members_.mean(axis=0))))
        # print(f"簇{c}: 区域 {region_ids}, ce={ce_c:.4f}")
        if len(members) > 0:
            inertia += float(np.sum((members - members.mean(axis=0)) ** 2))

    return labels, inertia



def analyze_k_vs_variance(SC, ra, rb, k_range=None, n_init=10, metric="ce",
                          region_keys=None,
                          verbose=True):
    """
    在 [ra, rb] 区间上，把 m 个区域分成 k 簇，计算 每个簇内的 ce，获取簇数和ce的关系。

    params:
        SC      : (m, n) 累积样本数
        ra, rb  : 分析区间（1-based，闭区间 [ra, rb]）
        k_range : 候选簇数；缺省 range(2, m)
        n_init  : k-means 重启次数（取 inertia 最小的解）
        metric  : "ce"   → 簇内最大绝对偏差
    return:
        dict{ k : avg_dispersion }
    """
    # m * [ra - 1:rb]
    features = np.array([region_seq[ra - 1:rb] for region_seq in SC], dtype=float)
    m = features.shape[0]
    if k_range is None:
        k_range = range(2, m)

    results = {}
    for k in k_range:
        if k < 2 or k > m:
            continue
        best_labels, best_inertia = None, np.inf
        for s in range(n_init):
            # 迭代n_init次，选出最好的（interia最小的）簇中心
            # 传入种子s来随机初始化
            labels, inertia = _kmeans_numpy(features, k, seed=s)
            if inertia < best_inertia:
                best_inertia, best_labels = inertia, labels

        print("",)
        # 记录分为k簇时，每个簇的ce
        disps = []
        clusters = []
        for c in range(k):
            idx = np.where(best_labels == c)[0]
            # 获取属于此簇的区域特征
            members = features[best_labels == c]
            if len(members) == 0:
                continue
            # 这个簇的平均累积样本数
            center = members.mean(axis=0)
            if  metric == "ce":
                # 获取此簇内区域的最大背离程度
                ce_c = float(np.max(np.abs(members - center)))
                disps.append(ce_c)
                region_ids = [int(i + 1) for i in idx]
                clusters.append({
                    "cluster_id": int(c),
                    "region_ids": region_ids,
                    "region_keys": ([region_keys[i - 1] for i in region_ids]
                                    if region_keys is not None else None),
                    "ce": ce_c,
                    "size": len(region_ids),
                })
            else:
                raise ValueError(metric)
        # 记录 簇数和对应的均值ce
        results[k] = float(np.mean(disps)) if disps else 0.0

        # ---- 打印本次最终划分（每个 k 一次）----
        if verbose:
            print(f"\n[k={k}] , "
                  f"avg_ce={results[k]:.4f}")
            # print(f"  best_labels = {best_labels.tolist()}")
            for cl in clusters:
                ids = cl["region_keys"] if cl["region_keys"] else cl["region_ids"]
                print(f"  簇{cl['cluster_id']} (n={cl['size']}): "
                      f"区域 {ids}  ce={cl['ce']:.4f}")

    return results



def get_final_clustering(features, k, n_init=10, region_keys=None):
    """
    给定 features 和 k，跑 n_init 次 k-means，返回 inertia 最小的「最终划分」。

    return:
        dict{
            "best_labels":  (n,) int ndarray,      # 0..k-1 组号
            "best_inertia": float,
            "clusters": [
                {
                    "cluster_id":  c,               # 簇编号（0-based 组号）
                    "region_ids":  [1,2,...],       # 区域编号（1-based）
                    "region_keys": ['1_38', ...],   # 可选，若传了 region_keys
                    "ce":          float,           # 该簇的 ce
                    "size":        int,             # 该簇区域数
                }, ...
            ],
            "avg_ce": float,
        }
    """
    n = features.shape[0]
    if k < 2 or k > n:
        raise ValueError(f"k={k} 不在 [2, {n}] 范围内")

    best_labels, best_inertia = None, np.inf
    for s in range(n_init):
        labels, inertia = _kmeans_numpy(features, k, seed=s)
        if inertia < best_inertia:
            best_inertia, best_labels = inertia, labels

    clusters = []
    disps = []
    for c in range(k):
        idx = np.where(best_labels == c)[0]          # 0-based
        if len(idx) == 0:
            continue
        members = features[idx]
        center = members.mean(axis=0)
        ce_c = float(np.max(np.abs(members - center)))
        disps.append(ce_c)

        region_ids = [int(i + 1) for i in idx]       # 1-based
        info = {
            "cluster_id": int(c),
            "region_ids": region_ids,
            "ce": ce_c,
            "size": len(region_ids),
        }
        if region_keys is not None:
            info["region_keys"] = [region_keys[i - 1] for i in region_ids]
        clusters.append(info)

    return {
        "best_labels":  best_labels,
        "best_inertia": float(best_inertia),
        "clusters":     clusters,
        "avg_ce":       float(np.mean(disps)) if disps else 0.0,
    }


def print_final_clustering(features, k, n_init=10, region_keys=None):
    """一行调用：跑 n_init 次，择优，然后打印每个簇的区域 + ce。"""
    result = get_final_clustering(features, k, n_init=n_init,
                                  region_keys=region_keys)
    print(f"\n=== 最终聚类结果: k={k} ===")
    print(f"  best_inertia = {result['best_inertia']:.4f}")
    print(f"  avg_ce       = {result['avg_ce']:.4f}")
    print(f"  best_labels  = {result['best_labels'].tolist()}")
    for cl in result["clusters"]:
        if region_keys is not None:
            ids = cl["region_keys"]
        else:
            ids = cl["region_ids"]
        print(f"  簇{cl['cluster_id']} (n={cl['size']}): "
              f"区域 {ids}  ce={cl['ce']:.4f}")
    return result


# ============================ k 与平均 ce 曲线及 k 反求 ============================
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import json


def _choose_k_points(m_regions, n_points,k_list=None):
    """
    确定每个插值点的簇数--决定了"用几个点、哪几个点"来构建 k → avg_ce 曲线--确定k值以及k的数量。
    return：
        插值点为n_point个的情况下，选择的每个插值点的簇数
    """
    k_min, k_max = 2, m_regions - 1
    if k_max < k_min:
        return []

    # 读取传入的 ks，并筛除越界值。
    if k_list is not None:
        ks = [int(k) for k in k_list if k_min <= int(k) <= k_max]
        ks = sorted(set(ks))  # 纯 Python list
        return ks if len(ks) >= 2 else []

    # 默认：linspace 等距采样
    available = list(range(k_min, k_max + 1))
    if len(available) <= n_points:
        return available

    ks = np.linspace(k_min, k_max, n_points).round().astype(int).tolist()
    result = sorted(set(ks))  # 纯 Python list
    return result if len(result) >= 2 else []



def _compute_target_ce_for_range(SC, ra, rb, ratio):
    """
    该期该区间上"不分簇时的最大偏离"作为尺度基线，
    取 ratio 倍作为 target_ce。

    baseline 分裂区间上，未聚类前的ce
    return: (target_ce, baseline)
    """
    sub = SC[:, ra - 1:rb]
    mean = sub.mean(axis=0)
    # 分裂区间上，未聚类前的ce
    baseline = float(np.max(np.abs(sub - mean)))
    return ratio * baseline, baseline


def build_k_vs_ce_curve(SC, ra, rb, n_points=5, n_init=10,region_keys=None, verbose=False, k_list=None):
    """
    用 n_points 个 k 值构建「k → avg_ce」曲线（只跑 n_points 次 k-means）。
    params:
        SC     : (m, n) 累积样本数
        ra, rb : 分析区间（1-based，闭区间）
        n_points: 曲线采样点数（3/5/...），决定要评估几个 k
        n_init : 每个 k 的 k-means 重启次数
    return: dict{k: avg_ce}
    """
    m_regions = SC.shape[0]
    # 不同插值点对应的簇数
    k_candidates = _choose_k_points(m_regions, n_points, k_list=k_list)
    print("k_candidates:",k_candidates)
    if not k_candidates:
        print(f"[k-analysis] range=[{ra},{rb}]: 区域数 {m_regions} 不足以分析 "
              f"k 曲线（需要 ≥ 4 个区域才能得到 ≥ 2 个 k 值）")
        return {}
    return analyze_k_vs_variance(
        SC, ra, rb,
        k_range=k_candidates,
        n_init=n_init,
        metric="ce",
        region_keys=region_keys,
        verbose=verbose,
    )


def interpolate_k_from_ce(curve, target_ce):
    """
    在「k → avg_ce」曲线上线性插值，反求 avg_ce = target_ce 对应的 k。
    params:

    return: (k_float | None, msg: str)
    """
    if not curve or len(curve) < 2:
        return None, "曲线点数不足（<2）"
    ks = np.array(sorted(curve.keys()), dtype=float)
    ces = np.array([curve[int(k)] for k in ks], dtype=float)
    if not np.all(np.diff(ces) <= 1e-9):
        return None, "曲线非单调（avg_ce 未随 k 单调不增）"
    if target_ce < ces.min() or target_ce > ces.max():
        return None, (f"target_ce={target_ce} 不在值域 "
                      f"[{ces.min():.4f}, {ces.max():.4f}]")
    # ce 随 k 递减；np.interp 要求第一参数单调增，故翻转
    # 返回在 target_ce 处的线性插值结果 y
    k_at = np.interp(target_ce, ces[::-1], ks[::-1])
    return float(k_at), "ok"


def plot_k_vs_ce_all_periods(SC_by_period, split_ranges_by_period,
                             n_cells, n_points=5, target_ce=None,target_ce_ratio=0.2,
                             n_init=10, save_dir="logs_0",region_keys=None, verbose=False
                             , k_list=None):
    """
    对每期数据：构建 k → avg_ce 曲线，画图，并用 target_ce 反求 k。

    params:
        SC_by_period           : dict {period: SC}
        split_ranges_by_period : dict {period: [(ra, rb), ...]}
        n_cells                : 全区间 cell 数（作为无分裂时的回退）
        n_points               : 曲线采样点数（3/5/...）
        target_ce              : 目标 ce
        n_init                 : 每个 k 的 k-means 重启次数
        save_dir               : 图 & summary 保存目录
        target_ce        : 若给定，则所有期数和区间使用同一目标值；
                       若为 None，则每期每区间按
                       target_ce_ratio × "不分簇时的最大偏离" 自动计算
        target_ce_ratio  : 自动模式的缩放系数（0.2 = 降到不分簇时的 20%）
    return:
        summary: dict{period: {(ra,rb): {k_points, ce_values, k_at, msg}}}
    """
    os.makedirs(save_dir, exist_ok=True)
    summary = {}

    for pd in sorted(SC_by_period.keys()):
        # 获取某期的SC
        SC = SC_by_period[pd]
        # 此期需要分裂的cell范围
        ranges = split_ranges_by_period.get(pd)
        # None → 该期根本没被收集到（异常，通常是 build 没跑到）
        if ranges is None:
            print(f"[warn] period={pd} 缺少 split_ranges 记录，跳过")
            summary[pd] = {}
            continue

        # [] → 明确无分裂 → 按要求跳过画图
        if len(ranges) == 0:
            print(f"[skip] period={pd} 无分裂区间，跳过画图")
            summary[pd] = {}
            continue

        summary[pd] = {}

        fig, ax = plt.subplots(figsize=(7, 4.5))
        drew_any = False

        for (ra, rb) in ranges:
            # 获取插值点对应的簇数，以及簇数对应的平均ce
            # dict{ k : avg_dispersion }
            curve = build_k_vs_ce_curve(SC, ra, rb,
                                         n_points=n_points, n_init=n_init
                                        ,region_keys=region_keys, verbose=verbose, k_list=k_list)
            if not curve:
                print(f"[warn] period={pd}, range=[{ra},{rb}]: "
                      f"曲线为空（该区间区域数不足以分 ≥2 簇）")
                continue
            # ks簇数，ces对应的平均ce
            ks = np.array(sorted(curve.keys()))
            ces = np.array([curve[int(k)] for k in ks])

            # 计算当前区间的 target_ce。
            if target_ce is None:
                tce, baseline = _compute_target_ce_for_range(
                    SC, ra, rb, target_ce_ratio
                )
            else:
                tce, baseline = float(target_ce), None


            line, = ax.plot(ks, ces, marker="o", linewidth=1.5,
                            label=f"[{ra},{rb}]  ({len(ks)} points)")
            color = line.get_color()

            # 获取target_ce对应的结果
            k_at, msg = interpolate_k_from_ce(curve, tce)
            summary[pd][(ra, rb)] = {
                "k_points": ks.tolist(),
                "ce_values": ces.tolist(),
                "target_ce": tce,
                "baseline": baseline,
                "k_at_target_ce": k_at,
                "msg": msg,
            }
            # 绘制当前区间的 target 水平线。
            ax.axhline(tce, color=color, linestyle="--",
                       alpha=0.4, linewidth=1.0)

            if k_at is not None:
                ax.axvline(k_at, linestyle=":", alpha=0.7, color=color)
                ax.plot(k_at, tce, marker="*", markersize=14,
                        color=color, zorder=5)
                print(f">>> period={pd}, range=[{ra},{rb}]: "
                      f"target_ce={tce} → k ≈ {k_at:.2f} "
                      f"(向上取整 = {int(np.ceil(k_at))})")
            else:
                print(f">>> period={pd}, range=[{ra},{rb}]: 无法插值 — {msg}")

            drew_any = True

        if not drew_any:
            print(f"[skip] period={pd} 没有可分析区间，跳过")
            plt.close(fig)
            continue


        ax.set_xlabel("k (number of clusters)")
        ax.set_ylabel("avg_ce (mean of per-cluster max abs deviation)")
        ax.set_title(f"Period {pd}  —  k vs avg_ce")
        ax.grid(True, alpha=0.3)
        ax.legend(fontsize=8)

        # out = os.path.join(save_dir, f"k_vs_ce_period{pd}.png")
        # fig.savefig(out, dpi=150, bbox_inches="tight")
        plt.close(fig)
        # print(f">>> 已保存: {out}\n")

    # 保存 summary（tuple key 转 str）
    json_summary = {
        f"period_{pd}": {
            f"range_{ra}_{rb}": v
            for (ra, rb), v in per_pd.items()
        }
        for pd, per_pd in summary.items()
    }
    with open(os.path.join(save_dir, "k_vs_ce_summary.json"),
              "w", encoding="utf-8") as f:
        json.dump(json_summary, f, indent=2, ensure_ascii=False)

    return summary



def _choose_split_k(MC, ra, rb, current_SC):
    """
    根据 MC 上配置的 target_ce / target_ce_ratio，
    在 [ra, rb] 上构建 k → avg_ce 曲线，插值反求最佳簇数。
    失败（区域数不足 / 曲线不单调 / target_ce 越界）时回退 MC.split_k。
    """
    fallback_k = int(getattr(MC, "split_k", 2))
    m = current_SC.shape[0]

    # 区域数 < 4：曲线最多 2 个点，插值误差大，直接回退
    if m < 4:
        print(f"[split-k] range=[{ra},{rb}]: 区域数 {m} < 4，回退 split_k={fallback_k}")
        return fallback_k

    # 读配置（优先读 SPLIT_* 专用配置，否则共享分析阶段配置）
    target_ce       = getattr(MC, "split_target_ce",
                              getattr(MC, "target_ce", None))
    target_ce_ratio = float(getattr(MC, "split_target_ce_ratio",
                                    getattr(MC, "target_ce_ratio", 0.2)))
    k_list          = getattr(MC, "split_k_list",
                              getattr(MC, "k_list", None))
    n_points        = int(getattr(MC, "split_k_analysis_n_points",
                                  getattr(MC, "k_analysis_n_points", 5)))
    n_init          = int(getattr(MC, "split_k_analysis_n_init",
                                  getattr(MC, "k_analysis_n_init", 10)))

    # 1. 构建曲线
    try:
        curve = build_k_vs_ce_curve(
            current_SC, ra, rb,
            n_points=n_points, n_init=n_init, k_list=k_list,
        )
    except Exception as e:
        print(f"[split-k] range=[{ra},{rb}]: build 异常({e})，回退 split_k={fallback_k}")
        return fallback_k

    if not curve or len(curve) < 2:
        print(f"[split-k] range=[{ra},{rb}]: 曲线不足 2 点，回退 split_k={fallback_k}")
        return fallback_k

    # 2. 确定 target_ce
    if target_ce is None:
        ces_sorted = np.array([curve[k] for k in sorted(curve.keys())])
        lo, hi = ces_sorted.min(), ces_sorted.max()  # lo=ce(kmax), hi=ce(k=2)
        # 将 tce 限制在 [lo, hi] 范围内。
        tce = lo + target_ce_ratio * (hi - lo)
        baseline = None
        print(f"[split-k] relative tce = {lo:.4f} + {target_ce_ratio}*"
              f"({hi:.4f}-{lo:.4f}) = {tce:.4f}", file=sys.stderr)
    else:
        tce, baseline = float(target_ce), None

    # 3. 插值反求 k
    k_at, msg = interpolate_k_from_ce(curve, tce)
    if k_at is None:
        print(f"[split-k] range=[{ra},{rb}]: 插值失败 ({msg})，回退 split_k={fallback_k}")
        return fallback_k

    # 4. 取整 + 夹到 [2, m-1]（避免 k=m 时每区一簇、ce=0 的无意义解）
    k_best = int(np.ceil(k_at))
    k_best = max(2, min(k_best, m - 1))

    print(f"[split-k] range=[{ra},{rb}]: "
          f"target_ce={tce:.2f}"
          f"{f'（baseline={baseline:.2f}）' if baseline is not None else ''} "
          f"→ k*≈{k_at:.2f} → 采用 k={k_best}")
    return k_best


#=======================================================================================================
#                                               读取数据，构建索引
#=======================================================================================================

def load_region_points(period_dir, region_key):
    """读取 EP_X/{region_key}.txt，返回 DataFrame(pos, t)。"""
    path = os.path.join(period_dir, f"{region_key}.txt")
    if not os.path.exists(path):
        raise FileNotFoundError(f"找不到：{path}")

    # 与区域划分时的 float64 文本读取保持同一精度，避免边界点被解析到区外。
    df = pd.read_csv(path, sep=r"\s+", float_precision="round_trip")
    df = df[["pos", "t"]].copy()
    df["pos"] = pd.to_numeric(df["pos"], errors="raise")
    df["t"]   = pd.to_numeric(df["t"],   errors="raise")
   # print(f"已读取到{region_key}.txt：\n",df[:1])
    return df



def load_region_cluster_mapping(csv_file):
    '''
    获得区域和簇的映射。论文第 V-A 节的区域编号 gm 跨期不变。
    return:
        mapping =
            {
                region_key: cluster_id
            }
    '''
    df = pd.read_csv(csv_file)
    required_columns = ["region_key","cluster"]

    for col in required_columns:
        if col not in df.columns:
            raise ValueError(f"CSV 缺少必要字段：{col}")

    mapping = {}
    for _, row in df.iterrows():
        region_key = str(row["region_key"]).strip()
        if region_key.startswith("1_"):
            region_key = region_key[2:]  # 解析带 1_ 前缀的区域编号。
        if not region_key.isdigit() or int(region_key) < 1:
            raise ValueError(f"非法区域编号：{row['region_key']}")
        region_key = str(int(region_key))
        cluster_id = int( row["cluster"] )
        if region_key in mapping:
            raise ValueError(f"重复区域编号：{region_key}")
        mapping[region_key] = cluster_id

    print("获得区域和簇的映射:\n",mapping)
    return mapping




def load_cluster_cells(csv_file):
    """
    读取一个 Cluster 内各个 region 的相关信息, Cell内的点数,边界等。（读取边界为了加入点进行更新）
    返回：
        cluster_cells=
        {
            region_key: {
                cell_id: point_count
            }
        }
    """
    df = pd.read_csv(csv_file)
    required_columns = [
        "region_key",
        "cell_id",
        "point_count"
    ]
    for col in required_columns:
        if col not in df.columns:
            raise ValueError( f"CSV 缺少必要字段：{col}" )

    cluster_cells = {}
    for _, row in df.iterrows():
        region_key = str( row["region_key"] )
        cell_id = int( row["cell_id"] )
        point_count = int( row["point_count"] )
        cluster_cells.setdefault(region_key, {})[cell_id] = {
            "point_count": int(row["point_count"]),
            "pos_min": float(row["pos_min"]),
            "pos_max": float(row["pos_max"]),
            "t_min": float(row["t_min"]),
            "t_max": float(row["t_max"]),
        }
    print("已读取cluster内各个region的相关信息：\n",cluster_cells)
    return cluster_cells










def load_cluster_grid(json_file):
    """论文第 V-A 节：读取簇网格、谱序 ordmap 和跨期不变的区域编号。"""
    with open(json_file, "r", encoding="utf-8") as f:
        grid = json.load(f)
    n_cells = int(grid["num_cells"])
    if (int(grid["lnm"]) * int(grid["tnm"]) != n_cells or
            sorted(grid["ordmap"]) != list(range(n_cells)) or
            len(grid["region_keys"]) != int(grid["num_regions"])):
        raise ValueError(f"簇网格文件不一致: {json_file}")
    keys = grid["region_keys"]
    if (any(not isinstance(key, str) or not key.isdigit() or int(key) < 1
            for key in keys) or len(set(keys)) != len(keys)):
        raise ValueError(f"簇网格区域键必须是无期数前缀的唯一正整数编号: {json_file}")
    return grid



def build_SC_for_period(period_dir, region_keys_sorted,
                        layout, n_cells, lnm, tnm, ordmap):
    """
    params:
        period_dir:          e.g. ".../EP_2"
        region_keys_sorted:  论文第 V-A 节的 gm 编号列表，不含期数
        layout:              IndexLayout，提供固定的区域边界与单元编号
        n_cells:             网格单元总数
    return:
        SC: shape (m, n_cells) 每个区域，每个cell的累积样本数
    """
    # 从目录名推断期数
    period = int(os.path.basename(period_dir).split("_")[1])

    m = len(region_keys_sorted)
    SC = np.zeros((m, n_cells), dtype=float)
    ranks = np.asarray(ordmap, dtype=np.int64)
    for i, rk in enumerate(region_keys_sorted):
        # 论文第 III 节固定区域边界；只有数据文件名需要当前期数前缀。
        file_key = f"{period}_{rk}"
        #加载此区域的数据点
        df = load_region_points(period_dir, file_key)
        region_id = int(rk)
        flat_ids = layout.cell_ids(region_id, df[["pos", "t"]].to_numpy(), (lnm, tnm))
        # ordmap[行主序] 为 0-based 谱序；按谱序统计后取累积数。
        cell_counts = np.bincount(ranks[flat_ids], minlength=n_cells).astype(float)
        SC[i] = np.cumsum(cell_counts)
        if i == 0:
            print(f"区域 {rk} 的各单元点数: {cell_counts}")
            print(f"区域 {rk} 的累积样本数: {SC[i]}")
    print(f"此簇内共{m}个区域，每个区域内有{n_cells}个单元格\n")
    return SC




'''
把一个簇内的个区域的各cell的详细信息：点数，边界点 用一个簇的类表示，便于获取簇内区域的cell的信息
'''
class ClusterIndex:
    '''
    各个簇的：整合簇模型和簇内cell的详细信息
    '''
    def __init__(self, cluster_id, model_cluster, region_cells):
        self.cluster_id = cluster_id
        self.model_cluster = model_cluster
        self.region_cells = region_cells

    def get_region_cells(self,region_key):
        return self.region_cells.get(region_key)

    def get_cell(self,region_key, cell_id):
        cells = self.get_region_cells(region_key)
        if cells is None:
            return None
        for cell in cells:
            if int( cell["cell_id"] ) == int(cell_id):
                return cell
        return None




# ================================================== 保存索引 ==================================================

def save_base_index(mc, period, save_dir):
    """
    第 1 期：保存完整基础索引
    MC = (tnm, lnm, ordmap, AM, ccmin, DS)
    M  = (N, C, re, ce, er)
    """
    period_dir = os.path.join(save_dir, f"ep{period}")
    os.makedirs(period_dir, exist_ok=True)

    def serialize_model_with_N(model):
        return {
            "N":  model.N,                                     # 抽象基函数只在这里存一次
            "C":  np.asarray(model.C, dtype=float).tolist(),
            "re": float(model.re),
            "ce": float(model.ce),
            "er": float(model.er),
        }

    snapshot = {
        "cluster_id": int(mc.cluster_id),
        "tnm":        int(mc.tnm),
        "lnm":        int(mc.lnm),
        "ordmap":     mc.ordmap,
        "num_regions": int(mc.m),
        "AM":         [serialize_model_with_N(a) for a in mc.AM],
        "ccmin":      float(mc.c_min),
        "DS":         {pd: recs
                       for pd, recs in mc.DS.items()
                       if int(pd) <= period},
    }

    path = os.path.join(period_dir, f"cluster_{mc.cluster_id}_base.pkl")
    with open(path, "wb") as f:
        pickle.dump(snapshot, f, protocol=pickle.HIGHEST_PROTOCOL)

    print(f"[save-base] {path}  |AM|={len(snapshot['AM'])}")
    return path





def save_pd_index(mc, period, save_dir, prev_am_size, period_er=None):
    """
    第 pd 期（pd>1）：只保存本期增量
      - new_anchors：本期写入的锚模型（AM[prev_am_size:]）
      - DS[period]：本期更新记录
      - er：本期实际生效模型的查询误差界（由构建入口提供）
    prev_am_size：进入本期之前 AM 的大小
    """
    period_dir = os.path.join(save_dir, f"ep{period}")
    os.makedirs(period_dir, exist_ok=True)

    def serialize_model_no_N(model):
        """
        AM 的增量里不存 N，N 从 base 里共享
        AM = ( M_base=(N,C,er,re,ce), M=(C,er,re,ce) )
        """
        return {
            "C":  np.asarray(model.C, dtype=float).tolist(),
            "re": float(model.re),
            "ce": float(model.ce),
            "er": float(model.er),
        }

    new_anchors = [serialize_model_no_N(a)
                   for a in mc.AM[prev_am_size:]]

    # ---- 与基础文件同构的 snapshot ----
    snapshot = {
        # 只存本期增量
        "AM": new_anchors,  # 仅包含本期锚模型
        "DS": {period: mc.DS.get(period, [])},  # 本期 DS 记录
    }
    if period_er is not None:
        if not np.isfinite(period_er) or period_er < 0:
            raise ValueError("本期 er 必须是有限的非负数")
        snapshot["er"] = float(period_er)  # 查询时直接使用本期 er=re+ce

    path = os.path.join(period_dir, f"cluster_{mc.cluster_id}_p{period}.pkl")
    with open(path, "wb") as f:
        pickle.dump(snapshot, f, protocol=pickle.HIGHEST_PROTOCOL)

    print(f"[save-delta] {path}  |new_anchors|={len(new_anchors)}, "
          f"|DS[{period}]|={len(snapshot['DS'][period])}")      #该周期有多少条修改记录
    return path





def load_base_index(path, n_cells, gamma=None, phi=5):
    '''
    加载基础索引
    '''
    with open(path, "rb") as f:
        data = pickle.load(f)

    # num_regions 用于运行时恢复平均预测所需的区域数。
    expected = {"cluster_id", "tnm", "lnm", "ordmap", "AM", "ccmin", "DS"}
    if set(data.keys()) not in (expected, expected | {"num_regions"}):
        raise ValueError(f"基础索引字段异常：{set(data.keys())}")

    # 用第一个锚模型恢复 N / U / degree
    first = data["AM"][0]
    N = first["N"]      #抽象
    first_N = N[0]
    degree  = first_N.args[1]
    U       = np.asarray(first_N.keywords["U"], dtype=float)
    n_ctrl  = len(N)

    # 带入具体的格子数来计算基函数矩阵 N_matrix（AM 中所有锚模型共享这一个矩阵）
    tmp = BSplineModel.__new__(BSplineModel)
    tmp.n_cells = int(n_cells)
    tmp.n_ctrl = n_ctrl
    tmp.degree = degree
    tmp.U = U
    tmp.N = N
    tmp.compute_N_matrix(int(n_cells))
    N_matrix = tmp.N_matrix

    # 5. 装配初始模型 M
    M = BSplineModel.__new__(BSplineModel)
    M.n_cells = int(n_cells)
    M.n_ctrl = n_ctrl
    M.degree = degree
    M.U = U
    M.N = N
    M.N_matrix = N_matrix
    M.C = np.asarray(first["C"], dtype=float)
    M.re = float(first["re"])
    M.ce = float(first["ce"])
    M.er = float(first["er"])
    M.Y = None
    M.splits = []

    # 6. 组装 MC = (tnm, lnm, ordmap, AM, ccmin, DS)
    mc = ModelCluster.__new__(ModelCluster)
    mc.cluster_id = int(data["cluster_id"])
    mc.tnm = data["tnm"]
    mc.lnm = data["lnm"]
    mc.ordmap = data["ordmap"]
    mc.AM = [M]  # base 里 AM 只有一个初始模型
    mc.c_min = float(data["ccmin"])
    mc.DS = {int(pd): recs for pd, recs in data["DS"].items()}

    # 7. 运行时辅助字段（不属于索引文件）
    mc.M = M
    mc.n = int(n_cells)
    mc.m = int(data.get("num_regions", len(mc.ordmap)))
    mc.gamma = gamma
    mc.degree = degree
    mc.phi = phi
    mc.SC = None
    mc.Y = None
    mc.current_period = max(mc.DS.keys()) if mc.DS else 0
    mc.query_er = M.er

    print(f"[load-base] {path}  |AM|=1")
    return mc



# 用于增量：不含 N，复用 base 的 N/N_matrix/U/degree
def _deserialize_model_reuse_N(M_dict, n_cells,
                               N, N_matrix, U, degree):
    """delta 里的锚模型：只有 C/re/ce/er，N 从 base 共享"""
    M = BSplineModel.__new__(BSplineModel)
    M.n_cells  = int(n_cells)
    M.n_ctrl   = len(N)
    M.degree   = degree
    M.U        = U
    M.N        = N
    M.N_matrix = N_matrix
    M.C  = np.asarray(M_dict["C"], dtype=float)
    M.re = float(M_dict["re"])
    M.ce = float(M_dict["ce"])
    M.er = float(M_dict["er"])
    M.Y  = None
    return M



def apply_delta_index(mc, delta_path, n_cells):
    """
    把一期增量叠加到 mc 上：
      - 追加 new_anchors 到 AM（复用 base 的 N_matrix）
      - 合并 DS[period]
    """
    with open(delta_path, "rb") as f:
        delta = pickle.load(f)

    base = mc.AM[0]

    # 追加新锚模型
    for entry in delta.get("AM", []):
        m = _deserialize_model_reuse_N(
            entry, n_cells,
            N=base.N, N_matrix=base.N_matrix,
            U=base.U, degree=base.degree,
        )
        mc.AM.append(m)

    # 合并 DS
    for pd, recs in delta.get("DS", {}).items():
        mc.DS[int(pd)] = recs

    mc.current_period = max(mc.DS.keys()) if mc.DS else 0
    mc.query_er = float(delta["er"]) if "er" in delta else None

    print(f"[apply-delta] {delta_path}  "
          f"|new_anchors|={len(delta.get('AM', []))}, "
          f"DS period={list(delta.get('DS', {}).keys())}")
    return mc



def load_index_up_to_period(cluster_id, save_dir, upto_period,
                            n_cells, gamma=None, phi=5):
    """
    加载到指定期的索引文件：
        先读基础文件，再从 p2 到 upto_period 依次叠加增量。
    return：
        mc
    """
    base_path = os.path.join(save_dir, "ep1", f"cluster_{cluster_id}_base.pkl")
    mc = load_base_index(base_path, n_cells, gamma=gamma, phi=phi)

    for pd in range(2, upto_period + 1):
        delta_path = os.path.join(
            save_dir, f"ep{pd}", f"cluster_{cluster_id}_p{pd}.pkl"
        )
        if os.path.exists(delta_path):
            mc = apply_delta_index(mc, delta_path, n_cells)
        else:
            print(f"[warn] 缺少增量文件：{delta_path}（跳过）")

    return mc







# ================================================== 预测函数 ==================================================
def predict_cell(period, region_id, cell_id,
                 cluster_id, save_dir,
                 n_cells, gamma=None, phi=5):
    """
    预测指定期、指定区域、某个格子的『平均累积样本数』。

    params:
        period      : 第几期（pd）
        region_id   : 区域编号（1-based，对应 SC 的行）
        cell_id     : 格子编号（1-based）
        cluster_id  : 该区域所属模型簇的 id（外部已判断好）
        save_dir    : 索引保存目录
        n_cells     : 格子总数
        gamma, phi  : 索引维护的超参数（继续维护用，预测本身不依赖）

    return:
        y_pred : float，该期该区域该格子的平均累积样本数

    说明：
        1. load_index_up_to_period：先读 base，再依次叠加 p2..period 的增量
           → 得到截至 period 的完整 MC（含 AM 和 DS）
        2. get_coeffs_from_DS：从 AM[0].C 出发，按期叠加所有 cell_range
           覆盖 cell_id 的更新，得到该期该区域的完整控制点系数
        3. N_matrix[cell_id-1] @ C_r：B-Spline 求值
    """

    # ============ 步骤 1：依次读取索引文件，加载截至该期的模型簇 ============
    mc = load_index_up_to_period(
        cluster_id=cluster_id,
        save_dir=save_dir,
        upto_period=period,
        n_cells=n_cells,
        gamma=gamma,
        phi=phi,
    )
    # 2. 取该期该 cell 该 region 的完整控制点系数
    C_r = mc.get_coeffs(int(cell_id), int(region_id), int(period))

    # 3. B-Spline 求值
    y_pred = float(mc.AM[0].N_matrix[cell_id - 1] @ C_r)

    return y_pred


def predict_cells(period, cell_ids, region_id,
                  cluster_id, save_dir,
                  n_cells, gamma=None, phi=5):
    """
    高效批量预测：同一期、同一区域、多个 cell 的累积样本数。

    只加载一次索引，然后循环求值。

    params:
        cell_ids : list[int] / np.ndarray，1-based 格子编号
    return:
        np.ndarray，与 cell_ids 等长
    """
    # ---- 只加载一次 ----
    mc = load_index_up_to_period(
        cluster_id=cluster_id, save_dir=save_dir,
        upto_period=period, n_cells=n_cells,
        gamma=gamma, phi=phi,
    )
    N = mc.AM[0].N_matrix           # 所有锚模型共享同一套基函数矩阵
    cell_ids = np.asarray(cell_ids)
    result = np.zeros(len(cell_ids), dtype=float)

    # ---- 循环求值，不再读盘 ----
    for k, cid in enumerate(cell_ids):
        C_r = mc.get_coeffs(int(cid), int(region_id), int(period))
        result[k] = float(N[cid - 1] @ C_r)

    return result





def predict_cells_multi(period, queries,
                        cluster_id, save_dir,
                        n_cells, gamma=None, phi=5):
    """
    批量预测：同一期，多个 (region_id, cell_ids) 组合。

    params:
        queries : list[(region_id, cell_ids)]
                  region_id  : int
                  cell_ids   : list[int] / np.ndarray
    return:
        list[np.ndarray]，与 queries 等长
    """
    mc = load_index_up_to_period(
        cluster_id=cluster_id, save_dir=save_dir,
        upto_period=period, n_cells=n_cells,
        gamma=gamma, phi=phi,
    )
    N = mc.AM[0].N_matrix

    results = []
    for region_id, cell_ids in queries:
        cell_ids = np.asarray(cell_ids)
        r = np.zeros(len(cell_ids), dtype=float)
        for k, cid in enumerate(cell_ids):
            C_r = mc.get_coeffs(int(cid), int(region_id), int(period))
            r[k] = float(N[cid - 1] @ C_r)
        results.append(r)
    return results



def _stat(pred, true):
    """返回 MAE、最大绝对误差、相对误差(%)"""
    pred = np.asarray(pred, dtype=float)
    true = np.asarray(true, dtype=float)
    ae = np.abs(pred - true)
    mae = float(np.mean(ae))
    maxe = float(np.max(ae))
    denom = np.where(np.abs(true) < 1e-12, 1e-12, np.abs(true))
    rel = float(np.mean(ae / denom) * 100)
    return mae, maxe, rel

