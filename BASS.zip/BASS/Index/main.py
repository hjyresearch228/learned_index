"""分别运行索引构建和查询评估。"""

from collections import Counter
from contextlib import redirect_stdout
import json
import os
from pathlib import Path
import sys
import tempfile
from time import perf_counter

import numpy as np
from scipy.spatial import cKDTree


if not hasattr(np, "_core"):
    sys.modules.setdefault("numpy._core", np.core)
    sys.modules.setdefault("numpy._core.numeric", np.core.numeric)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from config import BSplineIndexConfig as CFG
from data_preprocess.index_layout import IndexLayout, LayoutConfig, read_table
from BSpline_Index import (ModelCluster, basis_function, build_SC_for_period, calculate_deviation_sets,
                           load_cluster_grid, load_index_up_to_period,
                           load_region_cluster_mapping, save_base_index, save_pd_index,
                           select_anchor_model, updateCurveSegments,plot_k_vs_ce_all_periods)
import disk_io
from disk_io import write_cluster_period
from query import QueryModelCluster, clear_page_fences, kNNQuery, pointQuery, rangeQuery

PERIODS = tuple(CFG.QUERY_PERIODS)
DATA_DISK_ROOT = Path(CFG.DATA_DISK_ROOT)


def period_error(model, sc, period):
    """分裂格子以组均值为目标；后续期逐区域、逐格相加计算查询误差界。"""
    basis = model.AM[0].N_matrix
    predictions = np.empty_like(sc, dtype=float)
    for region in range(sc.shape[0]):
        for cell in range(sc.shape[1]):
            predictions[region, cell] = basis[cell] @ model.get_coeffs(cell + 1, region + 1, period)

    target = np.broadcast_to(sc.mean(axis=0), sc.shape).copy()
    signatures = [[] for _ in range(sc.shape[0])]
    for index, record in enumerate(model.DS.get(period, [])):
        if record.get("t") != 2:
            continue
        ra, rb = record["cr"]
        for group_id, group in enumerate(record["g"]):
            rows = np.asarray(group["r"], dtype=int) - 1
            if not len(rows):
                continue
            target[rows, ra - 1:rb] = sc[rows, ra - 1:rb].mean(axis=0)
            for row in rows:
                signatures[row].append((index, group_id))

    # 多个分裂范围的分组可不同；同一组别组合共享一条分段目标曲线。
    groups = {}
    for region, signature in enumerate(signatures):
        groups.setdefault(tuple(signature), []).append(region)
    result = (0.0, 0.0, 0.0)
    for group in groups.values():
        rows = np.asarray(group, dtype=int)
        prediction_error = np.abs(predictions[rows] - target[rows])
        region_error = np.abs(sc[rows] - target[rows])
        re = float(np.max(prediction_error))
        ce = float(np.max(region_error))
        er = re + ce if period == 1 else float(np.max(prediction_error + region_error))
        if er > result[2]:
            result = (re, ce, er)
    return result


def recall(found, actual):
    expected = Counter(map(tuple, actual))
    return sum((Counter(map(tuple, found)) & expected).values()) / len(actual) if len(actual) else float(not found)


def evaluate(period, layout, mc_by_region):
    # 用原始数据计算查询真值；I/O 只统计数据页读取。
    points = read_table(Path(CFG.SOURCE_DIR) / f"period_{period}.txt", header=True)
    gls, gts = layout.pos, layout.time
    eta = (gts[-1] - gts[0]) / (gls[-1] - gls[0])
    query_dir = Path(CFG.QUERY_DIR)
    point_queries = read_table(query_dir / f"period_{period}" / "point_query.txt",
                               widths=(2,), delimiter=",")
    range_queries = read_table(query_dir / "range_query.txt", widths=(4,), delimiter=",")
    knn_queries = read_table(query_dir / f"period_{period}" / "knn_query.txt",
                             widths=(3,), delimiter=",")
    tree = cKDTree(np.column_stack((points[:, 1], eta * points[:, 0])))
    metrics = []

    for kind, queries in (("point", point_queries), ("range", range_queries),
                          ("knn", knn_queries)):
        ios, recalls = [], []
        # 每类查询开始时清空缓存；同类查询之间保留缓存。
        disk_io.buffer.clear()  # 每类查询开始前清空一次 4 MiB FIFO 缓存。
        clear_page_fences()
        for query in queries:
            disk_io.reset_io()  # 仅重置本条查询的 I/O，同类查询共享缓存。
            if kind == "point":
                pos, t = query
                found = pointQuery((t, pos), gts, gls, mc_by_region)
                actual = points[(points[:, 0] == pos) & (points[:, 1] == t)]
                recalls.append(recall(found, actual))
            elif kind == "range":
                lo_pos, lo_t, hi_pos, hi_t = query
                found = rangeQuery(((lo_t, hi_t), (lo_pos, hi_pos)), gts, gls, mc_by_region)
                actual = points[(points[:, 0] >= lo_pos) & (points[:, 0] <= hi_pos) &
                                (points[:, 1] >= lo_t) & (points[:, 1] <= hi_t)]
                recalls.append(recall(found, actual))
            else:
                pos, t, k = query
                if k < 1 or not float(k).is_integer():
                    raise ValueError("kNN 查询文件中的 K 必须是正整数")
                k = int(k)
                found = kNNQuery(((t, pos), k), len(points), gts, gls, eta, mc_by_region)
                # 第 K 名可能并列，按真实第 K 近距离判断，不固定选择某 K 条记录。
                kth = float(np.max(tree.query((t, eta * pos), k=k)[0]))
                tol = max(1e-9, kth * 1e-12)
                recalls.append(sum(np.hypot(ft - t, eta * (fp - pos)) <= kth + tol
                                   for fp, ft in found) / k)
            ios.append(disk_io.IO)
        metrics.append(np.mean(ios))
        metrics.append(np.mean(recalls))
    return metrics


def load_context():
    with open(os.devnull, "w") as quiet:
        with redirect_stdout(quiet):
            cluster_map = load_region_cluster_mapping(CFG.CLUSTER_CSV)
    clusters = {}
    for cid in sorted(set(cluster_map.values())):
        grid = load_cluster_grid(Path(CFG.GRID_LAYOUT_DIR) / f"cluster_{cid}_grid.json")
        regions = sorted((int(gm) for gm, group in cluster_map.items() if group == cid))
        if regions != sorted(map(int, grid["region_keys"])):
            raise ValueError(f"簇 {cid} 的网格与聚类结果不一致")
        clusters[cid] = (grid, regions)
    layout = IndexLayout(LayoutConfig(source_dir=Path(CFG.SOURCE_DIR),
                                      query_dir=Path(CFG.QUERY_DIR),
                                      data_dir=Path(CFG.DATA_ROOT)))
    bounds = json.loads((Path(CFG.DATA_ROOT) / "partition_boundaries.json").read_text(encoding="utf-8"))
    layout.pos = np.asarray(bounds["pos_boundaries"], dtype=float)
    layout.time = np.asarray(bounds["t_boundaries"], dtype=float)
    return clusters, layout


def artifacts_exist(clusters):
    save_dir = Path(CFG.SAVE_DIR)
    for period in PERIODS:
        for cid, (_, regions) in clusters.items():
            name = f"cluster_{cid}_base.pkl" if period == 1 else f"cluster_{cid}_p{period}.pkl"
            if not (save_dir / f"ep{period}" / name).is_file():
                return False
            if not all((DATA_DISK_ROOT / f"EP_{period}" / f"{period}_{gm}.dat").is_file()
                       for gm in regions):
                return False
    return True


def _attach_k_analysis_config(mc):
    """给 mc 挂上"分裂阶段 k 分析"所需配置。SPLIT_* 优先，其次共享分析阶段配置，最后兜底。"""
    mc.split_k = int(getattr(CFG, "SPLIT_K", 2))   # 兜底

    mc.split_target_ce = getattr(CFG, "SPLIT_TARGET_CE",getattr(CFG, "TARGET_CE", None))
    mc.split_target_ce_ratio= float(getattr(CFG, "SPLIT_TARGET_CE_RATIO",getattr(CFG, "TARGET_CE_RATIO", 0.2)))
    mc.split_k_list = getattr(CFG, "SPLIT_KLIST",getattr(CFG, "KLIST", None))
    mc.split_k_analysis_n_points = int(getattr(CFG, "SPLIT_N_POINTS",getattr(CFG, "N_POINTS", 5)))
    mc.split_k_analysis_n_init   = int(getattr(CFG, "SPLIT_N_INIT",getattr(CFG, "N_INIT", 10)))
    return mc

def build(clusters, layout):
    save_dir = Path(CFG.SAVE_DIR)
    log_dir = Path(CFG.LOG_DIR)
    log_dir.mkdir(exist_ok=True)
    log_path = log_dir / "构建结果.log"
    models, rows = {}, []
    
    # 按簇记录每期的 SC 和分裂区间
    sc_by_period_by_cid = {cid: {} for cid in clusters}
    split_ranges_by_cid = {cid: {} for cid in clusters}

    if not PERIODS or PERIODS[0] < 1 or any(
            current != previous + 1 for previous, current in zip(PERIODS, PERIODS[1:])):
        raise ValueError("构建期数必须是连续的正整数，不能跳期")
    for cid in clusters:
        for pd in range(1, PERIODS[0]):
            name = f"cluster_{cid}_base.pkl" if pd == 1 else f"cluster_{cid}_p{pd}.pkl"
            path = save_dir / f"ep{pd}" / name
            if not path.is_file():
                raise FileNotFoundError(
                    f"不能从第 {PERIODS[0]} 期开始：前期索引未完整构建，缺少 {path}")

    with tempfile.TemporaryDirectory(prefix="cluster_logs_", dir=log_dir) as temp_dir, \
            log_path.open("a", encoding="utf-8") as log, open(os.devnull, "w") as quiet:
        def report(line):
            print(line, flush=True)
            print(line, file=log, flush=True)
        
        if log.tell():
            print(file=log, flush=True)
        report(f"构建结果 期={PERIODS[0]}-{PERIODS[-1]}")
        report(f"区域分区 pos_parts={layout.cfg.pos_parts} time_parts={layout.cfg.time_parts} "
               f"区域总数={layout.cfg.pos_parts * layout.cfg.time_parts} GAMMA={CFG.GAMMA}"
               f"类型={CFG.CLUSTER_CSV}"
               )
        if PERIODS and PERIODS[0] > 1:
            previous_period = PERIODS[0] - 1
        # 增量构建从磁盘恢复紧邻的前一期模型，并核对网格和区域映射。
            for cid, (grid, regions) in clusters.items():
                with redirect_stdout(quiet):
                    model = load_index_up_to_period(cid, save_dir, previous_period,
                                                    grid["num_cells"], CFG.GAMMA, CFG.PHI)
                    _attach_k_analysis_config(model)
                if (model.current_period != previous_period or
                        (model.tnm, model.lnm, model.m) !=
                        (grid["tnm"], grid["lnm"], len(regions)) or
                        not np.array_equal(model.ordmap, grid["ordmap"])):
                    raise ValueError(f"簇 {cid} 的前期索引与当前网格或数据不一致")
                models[cid] = model
            report(f"已从磁盘加载至第 {previous_period} 期，继续构建第 {PERIODS[0]} 期")
            
        for period in PERIODS:
            build_seconds = 0.0
            for cid, (grid, regions) in clusters.items():
                print(f"进度: 期={period} 簇={cid} 开始处理 ({grid['num_cells']} 格)", flush=True)
                started = perf_counter()
                previous_anchors = len(models[cid].AM) if period > 1 else 0
                name = (f"cluster_{cid}_base.pkl" if period == 1
                        else f"cluster_{cid}_p{period}.pkl")
                path = save_dir / f"ep{period}" / name
                data_paths = [DATA_DISK_ROOT / f"EP_{period}" / f"{period}_{gm}.dat"
                              for gm in regions]
                # 数据页文件齐全时复用；缺少任一区域文件时补写本期数据。
                data_ready = all(data_path.exists() for data_path in data_paths)
                with redirect_stdout(quiet):
                    sc = build_SC_for_period(str(Path(CFG.DATA_ROOT) / f"EP_{period}"),
                                             list(map(str, regions)), layout, grid["num_cells"],
                                             grid["lnm"], grid["tnm"], grid["ordmap"])
                    before_re = None
                    if period > 1:
                        # 更新前误差以本期簇平均曲线和所选锚模型预测比较。
                        average = sc.mean(axis=0)
                        previous_model = models[cid]
                        anchor_id = select_anchor_model(previous_model, average)
                        anchor = previous_model.AM[anchor_id]
                        anchor_prediction = anchor.N_matrix @ anchor.C
                        before_re = float(np.max(np.abs(anchor_prediction - average)))
                    if path.exists():
                        model = load_index_up_to_period(cid, save_dir, period,
                                                        grid["num_cells"], CFG.GAMMA, CFG.PHI)
                        _attach_k_analysis_config(model)
                        if period == 1:
                            re, ce, er = float(model.M.re), float(model.M.ce), float(model.M.er)
                            model.current_period = 1
                        else:
                            re, ce, er = period_error(model, sc, period)
                        action, elapsed = "复用", 0.0
                    elif period == 1:
                        model = ModelCluster(cid, grid["tnm"], grid["lnm"], grid["ordmap"],
                                             sc, CFG.GAMMA, CFG.DEGREE, CFG.PHI)
                        _attach_k_analysis_config(model)
                        path = Path(save_base_index(model, period, save_dir))
                        model.current_period = 1
                        re, ce, er = float(model.M.re), float(model.M.ce), float(model.M.er)
                        action = "构建"
                    else:
                        model = previous_model
                        _attach_k_analysis_config(model)
                        model.SC, model.Y = sc, average
                        deviation = calculate_deviation_sets(anchor_prediction,
                                                             average, sc, anchor.re, anchor.ce)
                        updateCurveSegments(*deviation, model, sc, t=anchor_id, pd=period)
                        re, ce, er = period_error(model, sc, period)
                        path = Path(save_pd_index(model, period, save_dir, previous_anchors,
                                                  period_er=er))
                        action = "构建"
                if not data_ready:
                    with redirect_stdout(quiet):
                        write_cluster_period(period, CFG.DATA_ROOT, DATA_DISK_ROOT, layout, grid)
                if action == "构建":
                    elapsed = perf_counter() - started
                build_seconds += elapsed
                if period == 1:
                    model_type = "锚模型(初始)"
                else:
                    records = model.DS[period]
                    if len(records) == 1 and "anchor" in records[0]:
                        model_type = ("锚模型(新增)" if len(model.AM) > previous_anchors
                                      else "锚模型(复用)")
                    else:
                        model_type = ("增量模型(分裂)" if any(record.get("t") == 2 for record in records)
                                      else "增量模型(未分裂)")


                # 保存本簇本期的 SC 和分裂区间。
                sc_by_period_by_cid[cid][period] = sc
                if period == 1:
                    split_ranges_by_cid[cid][period] = [(1, grid["num_cells"])]
                else:
                    pd_ranges = [tuple(rec["cr"]) for rec in model.DS.get(period, [])
                                 if rec.get("t") == 2]
                    split_ranges_by_cid[cid][period] = pd_ranges


                before_re_text = "NA" if before_re is None else f"{before_re:.6f}"
                with (Path(temp_dir) / f"cluster_{cid}.log").open("a", encoding="utf-8") as file:
                    print(f"{action} 期={period} 簇={cid} 时间={elapsed:.3f}s "
                          f"索引文件={path.stat().st_size / 1024:.3f}KB "
                          f"模型={model_type} 更新前re={before_re_text} "
                          f"re={re:.6f} ce={ce:.6f} er={er:.6f}", file=file)
                models[cid] = model
            rows.append((period, build_seconds))

        # 每簇日志逐个合并，避免把所有期、所有簇的明细留在内存。
        for cid in clusters:
            with (Path(temp_dir) / f"cluster_{cid}.log").open("r", encoding="utf-8") as file:
                for line in file:
                    report(line.rstrip("\n"))
            report("")

        report("期 | 本次构建秒")
        for row in rows:
            report(" | ".join((str(row[0]), *(f"{value:.3f}" for value in row[1:]))))

    # 在临时日志合并后执行 k 与平均 ce 分析。
    _run_k_analysis(clusters, sc_by_period_by_cid, split_ranges_by_cid)

    return log_path





def _run_k_analysis(clusters, sc_by_period_by_cid, split_ranges_by_cid):
    """对每个簇跑 k vs avg_ce 分析，图和 summary 存到 log/k_analysis/cluster_{cid}/。"""
    k_root = Path(CFG.LOG_DIR) / "k_analysis"
    k_root.mkdir(parents=True, exist_ok=True)

    n_points         = int(getattr(CFG, "N_POINTS", 5))
    n_init           = int(getattr(CFG, "K_ANALYSIS_N_INIT", 10))
    target_ce_ratio  = float(getattr(CFG, "TARGET_CE_RATIO", 0.2))
    k_list           = getattr(CFG, "KLIST", None)

    print("\n" + "=" * 78)
    print(f"k vs avg_ce 分析  (n_points={n_points}, target_ce_ratio={target_ce_ratio}, "
          f"k_list={k_list})")
    print("=" * 78)

    for cid, (grid, regions) in clusters.items():
        sc_by_period = sc_by_period_by_cid.get(cid, {})
        split_ranges = split_ranges_by_cid.get(cid, {})
        if not sc_by_period:
            print(f"[k-analysis] 簇 {cid}: 无 SC 数据，跳过")
            continue

        cluster_dir = k_root / f"cluster_{cid}"
        cluster_dir.mkdir(parents=True, exist_ok=True)

        try:
            plot_k_vs_ce_all_periods(
                SC_by_period=sc_by_period,
                split_ranges_by_period=split_ranges,
                n_cells=grid["num_cells"],
                n_points=n_points,
                target_ce=None,
                target_ce_ratio=target_ce_ratio,
                n_init=n_init,
                save_dir=str(cluster_dir),
                region_keys=[int(r) for r in regions],   # 和 main.py 风格一致
                verbose=True,
                k_list=k_list,
            )
            print(f"[k-analysis] 簇 {cid} 完成，结果保存在 {cluster_dir}")
        except Exception as e:
            print(f"[k-analysis] 簇 {cid} 失败: {e}")




def query(clusters, layout):
    save_dir = Path(CFG.SAVE_DIR)
    log_dir = Path(CFG.LOG_DIR)
    log_dir.mkdir(exist_ok=True)
    log_path = log_dir / "查询结果.log"
    rows = []
    cluster_csv_bytes = Path(CFG.CLUSTER_CSV).stat().st_size
    grid_files = [Path(CFG.GRID_LAYOUT_DIR) / f"cluster_{cid}_grid.json" for cid in clusters]
    grid_layout_bytes = sum(path.stat().st_size for path in grid_files)
    metadata_bytes = cluster_csv_bytes + grid_layout_bytes

    with log_path.open("a", encoding="utf-8") as log, open(os.devnull, "w") as quiet:
        def report(line):
            print(line, flush=True)
            print(line, file=log, flush=True)

        if log.tell():
            print(file=log, flush=True)
        report(f"查询结果 期={PERIODS[0]}-{PERIODS[-1]}")
        report(f"区域分区 pos_parts={layout.cfg.pos_parts} time_parts={layout.cfg.time_parts} "
               f"区域总数={layout.cfg.pos_parts * layout.cfg.time_parts} GAMMA={CFG.GAMMA}"
               f"类型={CFG.CLUSTER_CSV}"
               )
        report(f"首期聚类映射={cluster_csv_bytes / 1024:.3f}KB "
               f"网格布局({len(grid_files)}个文件)={grid_layout_bytes / 1024:.3f}KB")
        report("累计索引大小=.pkl 文件+首期聚类映射+首期网格布局；不计数据页")

        for period in PERIODS:
            region_models = {}
            for cid, (grid, regions) in clusters.items():
                with redirect_stdout(quiet):
                    model = load_index_up_to_period(
                        cid, save_dir, period, grid["num_cells"], CFG.GAMMA, CFG.PHI)
                for row, gm in enumerate(regions, 1):
                    data_path = DATA_DISK_ROOT / f"EP_{period}" / f"{period}_{gm}.dat"
                    region_models[gm] = QueryModelCluster(
                        model, period, row, data_path, model.query_er)

            print(f"进度: 第 {period} 期开始查询", flush=True)
            index_files = [
                save_dir / f"ep{pd}" /
                (f"cluster_{cid}_base.pkl" if pd == 1 else f"cluster_{cid}_p{pd}.pkl")
                for pd in range(1, period + 1) for cid in clusters
            ]
            index_kb = (metadata_bytes + sum(path.stat().st_size for path in index_files)) / 1024
            rows.append((period, index_kb, *evaluate(period, layout, region_models)))
            print(f"进度: 第 {period} 期查询完成", flush=True)

        report("期 | 累计索引KB | 点均IO | 点召回 | 范围均IO | 范围召回 | KNN均IO | KNN召回")
        for row in rows:
            report(" | ".join((str(row[0]), *(f"{value:.3f}" for value in row[1:]))))
    return log_path


def main():
    clusters, layout = load_context()
    if not artifacts_exist(clusters):
        build(clusters, layout)
    return query(clusters, layout)

if __name__ == "__main__":
    main()
