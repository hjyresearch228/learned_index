"""B 样条索引的数据页存取。

磁盘顺序：区域内按 ordmap 所给谱序依次存放单元格；同一单元格内
保持输入文件中的记录顺序。数据文件仅包含 (pos, t) 的 float64 记录，
不保存单元格点数、起止偏移或其他布局元数据。

512 条记录为一个 8 KiB 逻辑页，
缓存命中记 0 次 I/O，实际读取一个数据页记 1 次 I/O。模型文件、
"""

import math
import os
from pathlib import Path
import struct
import tempfile

import numpy as np


BLOCK_SIZE = 512
RECORD = struct.Struct("<dd")  # pos、t 各为一个小端 float64，共 16 字节
PAGE_SIZE = BLOCK_SIZE * RECORD.size
CACHE_SIZE_BYTES = 4 * 1024 * 1024  # 4 MiB，按磁盘数据页的原始字节数计
IO = 0


class buffer:
    """按数据页缓存；满 4 MiB（512 页）时先进先出淘汰。"""

    max_pages = CACHE_SIZE_BYTES // PAGE_SIZE
    memory_page_ids = []
    memory_page_data = {}

    @classmethod
    def clear(cls):
        cls.memory_page_ids.clear()
        cls.memory_page_data.clear()

    @classmethod
    def invalidate_path(cls, path):
        """路径数据变化后，移除对应的缓存页。"""
        absolute = os.path.abspath(os.fspath(path))
        keys = [key for key in cls.memory_page_ids if key[0] == absolute]
        for key in keys:
            cls.memory_page_ids.remove(key)
            cls.memory_page_data.pop(key, None)


def reset_io(clear_cache=False):
    """新一轮查询计数从零开始；是否同时清缓存由实验口径决定。"""
    global IO
    IO = 0
    if clear_cache:
        buffer.clear()


def _validate_layout(points, flat_cell_ids, ordmap):
    points = np.asarray(points, dtype=np.float64)
    if points.ndim != 2 or points.shape[1] != 2 or not np.isfinite(points).all():
        raise ValueError("points 必须是有限的 N×2 (pos, t) 数组")
    ids = np.asarray(flat_cell_ids)
    ranks = np.asarray(ordmap)
    if ids.shape != (len(points),) or not np.issubdtype(ids.dtype, np.integer):
        raise ValueError("flat_cell_ids 必须与每个数据点一一对应")
    if ranks.ndim != 1 or len(ranks) == 0 or not np.issubdtype(ranks.dtype, np.integer):
        raise ValueError("ordmap 必须是一维整数谱序映射")
    if sorted(ranks.tolist()) != list(range(len(ranks))):
        raise ValueError("ordmap 必须是 0 到单元格数减 1 的排列")
    if np.any(ids < 0) or np.any(ids >= len(ranks)):
        raise ValueError("存在越界的行主序单元格编号")
    return points, ids, ranks


def write_region_data(file_name, points, flat_cell_ids, ordmap, overwrite=False):
    """按谱序连续写入一个区域的数据，不对单元格内的数据排序。

    flat_cell_ids 是 layout.cell_ids(region, points, (lnm, tnm)) 返回的
    0-based 行主序编号；ordmap[flat_cell_id] 是该单元格的 0-based 谱序。
    每期每区域一个 .dat 文件，不写独立的点数或偏移索引。
    """
    points, ids, ranks = _validate_layout(points, flat_cell_ids, ordmap)
    target = Path(file_name)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and not overwrite:
        raise FileExistsError(f"数据文件已存在，未覆盖：{target}")

    # 只按谱序分桶；桶内直接使用读入次序，不做任何位置或时间排序。
    # 因而每个单元格的数据连续存放，但不保证单元格内部的坐标顺序。
    buckets = [[] for _ in range(len(ranks))]
    for point_id, flat_id in enumerate(ids):
        buckets[int(ranks[int(flat_id)])].append(point_id)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="wb", dir=target.parent,
                                         prefix=target.name + ".", suffix=".tmp",
                                         delete=False) as file:
            temporary = Path(file.name)
            page = bytearray()
            for bucket in buckets:
                for point_id in bucket:
                    pos, t = points[point_id]
                    page.extend(RECORD.pack(float(pos), float(t)))
                    if len(page) == PAGE_SIZE:
                        file.write(page)
                        page.clear()
            if page:
                file.write(page)
        if target.exists() and not overwrite:
            raise FileExistsError(f"数据文件已存在，未覆盖：{target}")
        os.replace(temporary, target)
        buffer.invalidate_path(target)
        return len(points)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def write_cluster_period(period, data_root, disk_root, layout, grid, overwrite=False):
    """读取已有 EP_n/n_gm.txt，并为簇内每个 gm 写出 EP_n/n_gm.dat。

    grid 是 cluster_X_grid.json 的内容；只使用其中的 lnm、tnm、
    ordmap 和不带期数的 region_keys。layout 须已加载固定区域边界。
    """
    if not isinstance(period, int) or period < 1:
        raise ValueError("period 必须是正整数")
    lnm, tnm = int(grid["lnm"]), int(grid["tnm"])
    if lnm < 1 or tnm < 1 or lnm * tnm != len(grid["ordmap"]):
        raise ValueError("网格形状与 ordmap 长度不一致")
    regions = [int(key) for key in grid["region_keys"]]
    if len(set(regions)) != len(regions) or any(region < 1 for region in regions):
        raise ValueError("region_keys 必须是不重复的正整数区域编号")
    destinations = [Path(disk_root) / f"EP_{period}" / f"{period}_{region}.dat"
                    for region in regions]
    if not overwrite:
        existing = [path for path in destinations if path.exists()]
        if existing:
            raise FileExistsError(f"数据文件已存在，未覆盖：{existing[0]}")

    saved = []
    for region, destination in zip(regions, destinations):
        source = Path(data_root) / f"EP_{period}" / f"{period}_{region}.txt"
        with source.open(encoding="utf-8-sig") as stream:
            header = stream.readline().split()
        if header not in (["pos", "t"], ["lc", "tm"]):
            raise ValueError(f"区域数据表头不是 pos,t 或 lc,tm：{source}")
        points = np.loadtxt(source, dtype=np.float64, ndmin=2, skiprows=1,
                            encoding="utf-8-sig")
        if points.size == 0:
            points = np.empty((0, 2), dtype=np.float64)
        if points.shape[1] != 2:
            raise ValueError(f"区域数据应有两列：{source}")
        flat_ids = layout.cell_ids(region, points, (lnm, tnm))
        write_region_data(destination, points, flat_ids, grid["ordmap"],
                          overwrite=overwrite)
        saved.append(destination)
    return saved


def _get_data_from_disk(cls, path, region_id, page_id):
    """返回 (页内记录, 本次数据页 I/O)。

    这是内部函数；外部使用 read_data_page 才会同步累计全局 IO。
    """
    if not isinstance(page_id, int) or page_id < 0:
        raise ValueError("page_id 必须是非负整数")
    absolute = os.path.abspath(os.fspath(path))
    stat = os.stat(absolute)
    if stat.st_size % RECORD.size:
        raise ValueError(f"数据文件长度不是 {RECORD.size} 字节的整数倍：{path}")
    page_count = math.ceil(stat.st_size / PAGE_SIZE)
    if page_id >= page_count:
        return [], 0  # 没有发起页读取，不计 I/O

    # 文件属性变化时会生成新键，避免命中内容已变化的缓存页。
    key = (absolute, int(region_id), page_id, stat.st_mtime_ns, stat.st_size)
    if key in cls.memory_page_data:
        return cls.memory_page_data[key], 0

    with open(absolute, "rb") as reader:
        reader.seek(page_id * PAGE_SIZE)
        content = reader.read(PAGE_SIZE)
    data = [list(values) for values in struct.iter_unpack(RECORD.format, content)]
    if len(cls.memory_page_ids) >= cls.max_pages:
        # 按进入顺序淘汰最早缓存的页。
        oldest = cls.memory_page_ids.pop(0)
        cls.memory_page_data.pop(oldest, None)
    cls.memory_page_ids.append(key)
    cls.memory_page_data[key] = data
    return data, 1


def read_data_page(path, region_id, page_id, cache=buffer):
    """读取一个数据页，并把未命中的一次页读取累计到 IO。"""
    global IO
    data, io = _get_data_from_disk(cache, path, region_id, page_id)
    IO += io
    return data, io


def read_data_pages(path, region_id, page_ids, cache=buffer):
    """去重读取候选页；返回 (页号到记录的映射, 本次 I/O 次数)。"""
    result = {}
    io_total = 0
    for page_id in sorted(set(page_ids)):
        data, io = read_data_page(path, region_id, int(page_id), cache)
        result[int(page_id)] = data
        io_total += io
    return result, io_total


def read_prediction_window(path, region_id, predicted_start, predicted_end,
                           error_bound, cache=buffer):
    """由模型给出的累计点数预测及保守误差界，读出相交的候选数据页。

    [predicted_start, predicted_end) 是 0-based 记录位置范围。它可以来自
    相邻单元格的累计点数预测；error_bound 由调用方按现有模型误差提供。
    返回值包含整页数据，查询仍须按区域、单元格或 pos/t 条件过滤。
    """
    numbers = (predicted_start, predicted_end, error_bound)
    if any(not math.isfinite(float(value)) for value in numbers):
        raise ValueError("预测位置和误差界必须是有限数值")
    if predicted_start > predicted_end or error_bound < 0:
        raise ValueError("预测范围或误差界无效")
    size = os.path.getsize(path)
    if size % RECORD.size:
        raise ValueError("数据文件长度不是完整记录的整数倍")
    count = size // RECORD.size
    first = max(0, math.floor(predicted_start - error_bound))
    last = min(count, math.ceil(predicted_end + error_bound))
    if first >= last:
        return {}, 0
    return read_data_pages(path, region_id,
                           range(first // BLOCK_SIZE, (last - 1) // BLOCK_SIZE + 1),
                           cache)
