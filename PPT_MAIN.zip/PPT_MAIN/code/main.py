from PPT.model.dp_plane import *


def separate_train():
    create_index()  # ppt construct index


from PPT.query.range_query import *


def range_():
    range_query()  # ppt range query


from PPT.query.point_query import *


def point_():
    point_query()  # ppt point query


from TPARINET.t_parinet import *


def tparinet():
    main_tparinet()


from LISA.main import *


def lisa():
    main_lisa()


from SPRIG.main import *


def sprig():
    main_sprig()


from RSMI.RSMI import *


def rsmi():
    main_rsmi()


from RSTAR.rstartree import *


def rstar():
    main_rstar()


if __name__ == '__main__':
    separate_train()  # ppt construct index
    #range_()  # PPT range query
    #point_()  # PPT point query

    # tparinet()  # tparinet construct index

    # LISA()  # LISA  construct index

    # SPRIG()  # SPRIG construct index

    # RSMI()  # RSMI construct index

    # RSTAR()  #RSTAR construct index
