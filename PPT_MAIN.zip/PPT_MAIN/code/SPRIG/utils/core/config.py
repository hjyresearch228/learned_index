"""参数配置"""

PAGE_SIZE = 8192
BUFFER_SIZE = 2 * 1024 * 1024  # 缓冲区大小

# 页大小：8KB
# 一个数据：两个float 16B
# 一页存512个数据

root_dir = r'E:\chengxu\SPRIG\data_200_2'
data_ppt_dir = r'E:\dataset'

# data_pth = r'D:\BaiduNetdiskDownload\模拟数据\sumo_pos_time.npy'
# data_pth = fr'{root_dir}\sumo_pos_time.npy'
# data_pth = fr'{root_dir}\test\data.txt'
# data_pth = fr'{data_ppt_dir}\成都数据-分期txt\npy\period_0.npy'  # ppt-chd-pd0
# data_pth = fr'{data_ppt_dir}\成都数据-分期txt\0-2\0-2.npy'  # ppt-chd-pd0_2
data_pth = fr'{data_ppt_dir}\txt_simulation4-1_point_1\0.txt'  # ppt-sim-pd0

save_pth = root_dir
load_pth = save_pth
