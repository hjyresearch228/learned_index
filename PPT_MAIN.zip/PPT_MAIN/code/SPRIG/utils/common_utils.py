import scipy
import numpy as np

NP_DATA_TYPE = np.float64
NP_IDX_TYPE = np.int64

np.set_printoptions(precision=50)

def convert_txt_to_npy(src: str):
    """txt格式：每行数据按 ',' 分隔"""
    data = np.loadtxt(src, dtype=str)
    row = data.shape[0]
    data_new = []
    for i_ in range(row):
        r_ = data[i_].split(',')
        item = [float(_) for _ in r_]
        # data_new.append(item)
        data_new.append([item[1], item[2]])  # 可修改

    dst = src.replace('.txt', '')
    f_n = f'{dst}.npy'
    np.save(f_n, data_new)
    data_npy = np.load(f_n)

    return data_npy


def convert_npy_to_txt(src: str, dst: str):
    """
    将.npy文件转换为.txt文件
    :param src: .npy文件路径
    :param dst: .txt文件路径
    """
    print('$ convert_npy_to_txt')

    data_ = np.load(src)
    print(f'data.shape = {data_.shape}')
    shape_len = len(data_.shape)
    data_ = data_.tolist()

    with open(dst, 'w') as writer:
        if shape_len == 1:
            for x in data_:
                writer.write('%.10f\n' % x)
        else:
            for row_data in data_:
                writer.write(' '.join(['%.10f' % i for i in row_data]) + '\n')

    print('$$ convert_npy_to_txt: done')
