import numpy as np

from src.utils.common_utils import *

class SpatialInterpolFunc:
    x_inputs = None
    y_inputs = None
    outputs = None
    args = None  # 参数列表

    def __init__(self, xs, ys, outputs):
        self.x_inputs = xs
        self.y_inputs = ys
        self.outputs = outputs

        # 拟合空间插值函数
        x_1 = self.x_inputs[0]
        x_2 = x_1
        x_3 = self.x_inputs[1]
        x_4 = x_3
        y_1 = self.y_inputs[0]
        y_3 = y_1
        y_2 = self.y_inputs[1]
        y_4 = y_2

        row_0 = [1, x_1, y_1, x_1 * y_1]
        row_1 = [1, x_2, y_2, x_2 * y_2]
        row_2 = [1, x_3, y_3, x_3 * y_3]
        row_3 = [1, x_4, y_4, x_4 * y_4]
        matrix = np.array([row_0, row_1, row_2, row_3])
        try:
            m_I = np.linalg.inv(matrix)
        except np.linalg.LinAlgError:
            m_I = np.linalg.pinv(matrix)  # 若矩阵不可逆，则求伪逆矩阵

        assert len(self.outputs) == 4
        v_1, v_2, v_3, v_4 = self.outputs
        vector = np.array([v_1, v_2, v_3, v_4])
        v_T = vector.T

        args = np.dot(m_I, v_T)
        self.args = args

    def predict(self, x, y) -> int:
        """预测网格id"""
        x = np.float64(x)
        y = np.float64(y)
        z = np.float64(x * y)
        vec = np.array([1, x, y, z])
        return int(np.dot(vec, self.args))
