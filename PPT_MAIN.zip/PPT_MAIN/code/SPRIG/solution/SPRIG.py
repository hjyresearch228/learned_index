import os
import pickle
import sys
import time

import numpy as np

from src.solution.spatial_interpolation_function_fit import SpatialInterpolFunc
from src.utils.common_utils import *

sys.path.append('../../')

table_dic_size = 479 * 1024
cell_bound_dic_size = 753 * 1024
PAGE_SIZE = 8192
DATA_SIZE = 36
DATA_NUM_ONE_PAGE = int(PAGE_SIZE / DATA_SIZE)
BUFFER_SIZE = 2 * 1024 * 1024

PAGE_NUM_BUFFER = int(BUFFER_SIZE / PAGE_SIZE)


# PAGE_NUM_BUFFER = 0

class SPRIG:
    data_dir = None
    raw_data = None
    sorted_data_one_dim = None
    sorted_data_for_cell = None  # 按照网格排序的数据

    IO_count = 0

    x_col_num = 0  # 沿x轴分割的列数
    y_col_num = 0  # 沿y轴分割的列数
    x_bounds = None
    y_bounds = None
    error_bd_x = None  # x轴误差上界
    error_bd_y = None  # y轴误差上界

    cell_bound_dic = {}  # 存储网格id和边界信息
    # cell_id_mat = None  # 网格下边界矩阵
    cell_data_num_dic = {}  # {网格id: 数据个数}
    table_T_dic = {}  # 表T，存储网格id和网格内数据的指针 {网格id: [网格起始指针，网格内数据总数]}
    interpolation_function = None  # 空间线性插值函数参数表

    page_in_memory = []  # 缓冲区

    def __init__(self, data_dir: str, raw_data=None, x_col_num=0, y_col_num=0):
        self.data_dir = data_dir
        self.raw_data = raw_data
        self.x_col_num, self.y_col_num = x_col_num, y_col_num
        if raw_data is not None:
            self.sorted_data_one_dim = self._cal_xy_col_nums(raw_data)

    def build(self):
        t_0 = time.time()
        print('$ SPRIG build: begin.')

        raw_data = self.raw_data
        st_data_one_dm = self.sorted_data_one_dim
        bds_tuple = self._bulid_grid(raw_data)  # 建立网格边界
        print(len(bds_tuple[0]))
        print(len(bds_tuple[1]))
        print('$ gird build: success.')

        i = 0
        x_bds, y_bds = bds_tuple

        len_x = len(x_bds[:-1])
        len_y = len(y_bds[:-1])
        cl_ids_mt = np.zeros(shape=(len_x, len_y))

        cell_bd_dic = {}
        cell_data_num_dic = {}
        y_arr_pre = np.array(y_bds[:-1])
        y_arr_po = np.array(y_bds[1:])

        for x_bd, x_bd_po in zip(x_bds[:-1], x_bds[1:]):
            print(f'process: {i}')

            x_arr_pre = np.full(len_y, x_bd)
            x_arr_po = np.full(len_y, x_bd_po)
            # 获取网格id
            j_arr = np.arange(len_y)
            cl_id_arr = j_arr * self.x_col_num + i
            # 获取网格边界
            cell_bd_arr = np.array(list(zip(x_arr_pre, x_arr_po, y_arr_pre, y_arr_po)))
            # 计算网格内数据量
            data_num_arr = np.apply_along_axis(self._cal_grid_data_num, axis=1, arr=cell_bd_arr)

            cl_bd_dic_ = dict(zip(cl_id_arr, cell_bd_arr))
            cl_dt_n_dic_ = dict(zip(cl_id_arr, data_num_arr))

            cell_bd_dic.update(cl_bd_dic_)
            cell_data_num_dic.update(cl_dt_n_dic_)
            i += 1

        # self.cell_id_mat = cl_ids_mt
        self.cell_bound_dic = cell_bd_dic
        self.cell_data_num_dic = cell_data_num_dic
        self.x_bounds = x_bds
        self.y_bounds = y_bds
        print('$ cell bounds matrix build: success.')

        # 将数据按照网格排序
        npy_data_file = os.path.join(self.data_dir, 'data_sorted_by_cell.npy')
        if not os.path.exists(npy_data_file):
            start = 0
            end = 0
            dt_sort_for_cl = np.copy(raw_data)
            for cl_bd, cl_num in zip(self.cell_bound_dic.values(), self.cell_data_num_dic.values()):
                end += cl_num
                x_min, x_max, y_min, y_max = cl_bd

                x_args = np.where((st_data_one_dm[:, 0] >= x_min) & (st_data_one_dm[:, 0] < x_max))
                part_dt = st_data_one_dm[x_args]
                y_args = np.where((part_dt[:, 1] >= y_min) & (part_dt[:, 1] < y_max))
                dt_res = part_dt[y_args]

                dt_sort_for_cl[start: end] = dt_res
                start = end
            print('$ data sort by cell: success.')

            np.save(npy_data_file, dt_sort_for_cl)
            print('$ sorted data save: success.')

        # 空间插值函数Fin拟合，并保存参数
        x_bds_pre = x_bds[:-1]
        y_bds_pre = y_bds[:-1]

        xs = [x_bds[0], x_bds_pre[-1]]
        ys = [y_bds[0], y_bds_pre[-1]]

        cl_0 = 0
        cl_1 = (len(y_bds_pre) - 1) * self.x_col_num
        cl_2 = len(x_bds_pre) - 1
        cl_3 = (len(y_bds) - 1) * (len(x_bds) - 1) - 1
        cl_ids = [cl_0, cl_1, cl_2, cl_3]

        Fin = SpatialInterpolFunc(xs, ys, cl_ids)
        self.interpolation_function = Fin
        self.error_bd_x, self.error_bd_y = self._cal_xy_error_bound()  # 计算误差上界
        print('$ interpolation function build: success.')

        self.table_T_dic = self._bulid_table_T()  # 建立表T
        print('$ table T build: success.')

        print(f'$$ total build time :{round(time.time() - t_0, 5)} s')

    def range_query(self, bottom_point: np.ndarray, top_point: np.ndarray):
        result = []
        IO = 0
        IO_time = 0
        CPU_time = 0
        t_0 = time.time()
        cl_id_pred_ = self.interpolation_function.predict(x=bottom_point[0], y=bottom_point[1])
        real_id_b = self._get_real_cl_id(cl_id_pred_, bottom_point)
        cl_id_pred_ = self.interpolation_function.predict(x=top_point[0], y=top_point[1])
        real_id_t = self._get_real_cl_id(cl_id_pred_, top_point)

        i_btm = self._get_i_for_cl(real_id_b)
        j_btm = self._get_j_for_cl(real_id_b)
        i_top = self._get_i_for_cl(real_id_t)
        j_top = self._get_j_for_cl(real_id_t)

        for i in range(i_btm, i_top + 1):
            for j in range(j_btm, j_top + 1):
                cl_id_ = j * self.x_col_num + i
                if i == i_btm or i == i_top or j == j_btm or j == j_top:
                    data_, io, io_time = self._get_cell_data_in_range(cl_id_, bottom_point, top_point)  # 查询交叉区域的数据
                elif i_btm < i < i_top and j_btm < j < j_top:
                    data_, io, io_time = self._get_cell_data_all(cl_id_)  # 查询非交叉区域的数据
                else:
                    continue
                result.extend(data_)
                IO_time += io_time
                IO += io

        t_u = time.time() - t_0
        CPU_time = round(t_u - IO_time, 5)
        IO_time = round(IO_time, 5)
        result = np.array(result)

        return result, IO, CPU_time, IO_time

    @staticmethod
    def _cal_xy_col_nums(data: np.ndarray) -> np.ndarray:
        one_dim_sort_idx = np.argsort(data[:, 0])  # 按照单个维度排序数据，可修改
        data_sort = data[one_dim_sort_idx]
        return data_sort

    def _cal_grid_data_num(self, row):
        data = self.raw_data
        x_min, x_max, y_min, y_max = row
        arg_x = np.where((data[:, 0] >= x_min) & (data[:, 0] < x_max))[0]
        data_part = data[arg_x, :]
        arg_y = np.where((data_part[:, 1] >= y_min) & (data_part[:, 1] < y_max))[0]
        data_res = data_part[arg_y, :]
        data_num = data_res.shape[0]

        return data_num

    def _bulid_grid(self, data: np.ndarray) -> tuple:
        maps_x = {}
        maps_y = {}

        for one_data in data:
            x_val = one_data[0]
            y_val = one_data[1]

            cnt_x = 1 if x_val not in maps_x.keys() else maps_x[x_val] + 1
            maps_x[x_val] = cnt_x
            cnt_y = 1 if y_val not in maps_y.keys() else maps_y[y_val] + 1
            maps_y[y_val] = cnt_y

        x_min = min(maps_x.keys())
        y_min = min(maps_y.keys())
        x_max = max(maps_x.keys())
        y_max = max(maps_y.keys())

        mps_x_sorted = self._sort_map_by_key(maps_x)
        mps_y_sorted = self._sort_map_by_key(maps_y)

        x_avg_val = data.shape[0] / self.x_col_num
        y_avg_val = data.shape[0] / self.y_col_num

        bounds_x = self._get_boundary_x(mps_x_sorted, x_avg_val, x_min, x_max)
        bounds_y = self._get_boundary_y(mps_y_sorted, y_avg_val, y_min, y_max)

        return bounds_x, bounds_y

    @staticmethod
    def _get_boundary_x(maps: dict, avg: float, min_val, max_val) -> list:
        bounds = [min_val]
        cont = 0
        pre_k = 0
        for k, v in maps.items():
            single_cont = v
            if single_cont > avg:  # 单维度重复数量 > 均值
                bd_ = (k + pre_k) / 2
                bounds.append(bd_)
                cont = 0
                continue
            cont += single_cont

            if cont > avg:
                bd_ = (k + pre_k) / 2
                bounds.append(bd_)
                cont = 0
            else:
                pre_k = k
        if len(bounds) < 100:
            bounds.append((bounds[-1] + bounds[-2]) / 2)
        bounds.sort()
        bounds.append(max_val)

        return bounds
    @staticmethod
    def _get_boundary_y(maps: dict, avg: float, min_val, max_val) -> list:
        bounds = [min_val]
        cont = 0
        pre_k = 0
        for k, v in maps.items():
            single_cont = v
            if single_cont > avg:  # 单维度重复数量 > 均值
                bd_ = (k + pre_k) / 2
                bounds.append(bd_)
                cont = 0
                continue
            cont += single_cont

            if cont > avg:
                bd_ = (k + pre_k) / 2
                bounds.append(bd_)
                cont = 0
            else:
                pre_k = k
        if len(bounds) < 300:
            bounds.append((bounds[-1] + bounds[-2]) / 2)
        bounds.sort()
        bounds.append(max_val)

        return bounds
    @staticmethod
    def _sort_map_by_key(maps: dict):
        mp_new = {}
        for k in sorted(maps.keys()):
            v = maps[k]
            mp_new[k] = v

        return mp_new

    def _bulid_table_T(self) -> dict:
        table_T = {}
        ptr = 0
        cl_bd_dic = self.cell_bound_dic
        for cl_id, cl_bd in cl_bd_dic.items():
            first_dt_ptr = ptr  # 指向网格首个数据的指针(数据文件行号)
            cl_dt_num = self.cell_data_num_dic[cl_id]  # 每个网格中的数据个数
            table_T[cl_id] = [first_dt_ptr, cl_dt_num]
            ptr += cl_dt_num

        return table_T

    def _cal_xy_error_bound(self) -> tuple:
        x_err_bd = 0
        y_err_bd = 0
        for cl_id, dt_pt in self.cell_bound_dic.items():
            x_true = self._get_i_for_cl(cl_id)
            y_true = self._get_j_for_cl(cl_id)

            cl_id_pred = self.interpolation_function.predict(x=dt_pt[0], y=dt_pt[2])
            x_pred = self._get_i_for_cl(cl_id_pred)
            y_pred = self._get_j_for_cl(cl_id_pred)

            x_err_bd = max(abs(x_pred - x_true), x_err_bd)
            y_err_bd = max(abs(y_pred - y_true), y_err_bd)

        return x_err_bd, y_err_bd

    def _get_real_cl_id(self, cell_id_pred: int, data_point: np.ndarray) -> int:
        """根据预测id计算真实id"""
        n = self.x_col_num
        m = self.y_col_num
        x_val = data_point[0]
        y_val = data_point[1]
        i_pred = self._get_i_for_cl(cell_id_pred)
        j_pred = self._get_j_for_cl(cell_id_pred)

        """low_bd_ = i_pred - self.error_bd_x
        high_bd_ = i_pred + self.error_bd_x"""
        low_bd_ = i_pred - 199
        high_bd_ = i_pred + 199
        search_range_x = [max(0, low_bd_), min(n - 1, high_bd_)]
        i_true = self._binary_search_x(search_range_x[0], search_range_x[1] + 1, x_val)

        """low_bd_ = j_pred - self.error_bd_y - 1
        high_bd_ = j_pred + self.error_bd_y + 1"""
        low_bd_ = j_pred - 199
        high_bd_ = j_pred + 199
        search_range_y = [max(0, low_bd_), min(m - 1, high_bd_)]
        j_true = self._binary_search_y(search_range_y[0], search_range_y[1] + 1, y_val)

        cl_id_true = j_true * n + i_true
        return cl_id_true

    def _binary_search_x(self, start, end, value):
        """二分查找查找数据网格下边界"""
        x_bds_part = self.x_bounds[start: end]
        low = 0
        high = len(x_bds_part) - 1
        mid = int((low + high) / 2)

        while low <= high and mid + 1 < len(x_bds_part):
            if x_bds_part[mid] <= value < x_bds_part[mid + 1]:
                return mid + start

            if value < x_bds_part[mid]:
                high = mid - 1
                mid = int((low + high) / 2)
            elif value > x_bds_part[mid]:
                low = mid + 1
                mid = int((low + high) / 2)
        if mid + 1 == len(x_bds_part):
            return len(x_bds_part) - 1

        raise ValueError(f'key: {value} NOT found.')

    def _binary_search_y(self, start, end, value):
        """二分查找查找数据网格下边界"""
        y_bds_part = self.y_bounds[start: end]
        low = 0
        high = len(y_bds_part) - 1
        mid = int((low + high) / 2)

        while low <= high and mid + 1 < len(y_bds_part):
            if y_bds_part[mid] <= value < y_bds_part[mid + 1]:
                return mid + start

            if value < y_bds_part[mid]:
                high = mid - 1
                mid = int((low + high) / 2)
            elif value > y_bds_part[mid]:
                low = mid + 1
                mid = int((low + high) / 2)
        if mid + 1 == len(y_bds_part):
            return len(y_bds_part) - 1
        raise ValueError(f'key: {value} NOT found.')

    def _get_i_for_cl(self, cell_id: int) -> int:
        """根据网格编号计算对应的横轴坐标"""
        return cell_id % self.x_col_num

    def _get_j_for_cl(self, cell_id: int) -> int:
        """根据网格编号计算对应的纵轴坐标"""
        return int(cell_id / self.x_col_num)

    def _get_cell_data_in_range(self, cell_id: int, bottom, top):
        result = []
        x_min, y_min = bottom
        x_max, y_max = top
        # 取网格内所有点，检查是否在范围内
        data_in_cell, IO, IO_t = self._get_cell_data_all(cell_id)
        for dt in data_in_cell:
            x_, y_ = dt
            if x_min <= x_ <= x_max and y_min <= y_ <= y_max:
                result.append(list(dt))

        return result, IO, IO_t

    def _get_cell_data_all(self, cell_id: int):
        """获取单个网格中的所有数据，返回二维列表"""
        result = []
        IO = 0
        IO_time = 0
        # 从表T中提取数据地址，再从数据文件中提取数据
        cl_info = self.table_T_dic[cell_id]
        ptr, cl_siz = cl_info
        start = ptr
        end = ptr + cl_siz

        data_npy = os.path.join(self.data_dir, 'data_sorted_by_cell.npy')
        data_arr = np.load(data_npy)
        data_lines = data_arr[start: end]

        # 计算I/O
        page_start = int(start / DATA_NUM_ONE_PAGE)
        page_end = int(end / DATA_NUM_ONE_PAGE)
        page_ids = [i for i in range(page_start, page_end + 1)]
        print(f'page_ids: {page_ids}')
        page_in_memo = self.page_in_memory
        for page_id in page_ids:
            if page_id in page_in_memo:
                continue
            if len(page_in_memo) >= PAGE_NUM_BUFFER and len(page_in_memo) != 0:
                page_in_memo.pop(0)
            page_in_memo.append(page_id)
            # 模拟I/O
            t_0_ = time.time()
            data_arr_ = np.load(data_npy)
            t_1_ = time.time() - t_0_

            IO_time += t_1_
            IO += 1

        for line in data_lines:
            result.append(line)

        return result, IO, IO_time
