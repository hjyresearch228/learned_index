import numpy as np
import os
import pickle

from solution.SPRIG import SPRIG
from utils.core.config import *
from utils.common_utils import *


def bulid_SPRIG(data_src: str, data_dir: str, x_col_num=10, y_col_num=10) -> SPRIG:
    """
    构建索引
    :param data_src: 数据源文件
    :param data_dir: 数据所在文件夹
    :param x_col_num: x轴列数
    :param y_col_num: y轴列数
    :return: 索引对象
    """
    data = None
    if data_src.endswith('.txt'):
        data = convert_txt_to_npy(data_src)
    else:
        assert data_src.endswith('.npy'), 'Data file type ERROR, expect npy file.'
        data = np.load(data_src)

    my_idx = SPRIG(data_dir, data, x_col_num, y_col_num)
    my_idx.build()

    return my_idx


def save_SPRIG(index: SPRIG, save_path: str):
    """保存模型参数到指定路径"""
    save_dir = os.path.join(save_path, 'SPRIG_args')
    if not os.path.exists(save_dir):
        os.mkdir(save_dir)
    assert len(os.listdir(save_dir)) == 0, AssertionError('save dir is not empty.')

    f_n_ = os.path.join(save_dir, 'cell_bound_dic.kpl')
    with open(f_n_, 'wb') as f_:
        pickle.dump(index.cell_bound_dic, f_)

    f_n_ = os.path.join(save_dir, 'table_T_dic.kpl')
    with open(f_n_, 'wb') as f_:
        pickle.dump(index.table_T_dic, f_)

    f_n_ = os.path.join(save_dir, 'in_func.kpl')
    with open(f_n_, 'wb') as f_:
        pickle.dump(index.interpolation_function, f_)

    f_n_ = os.path.join(save_dir, 'arg_tuple.kpl')
    arg_tuple = (index.x_col_num, index.y_col_num, index.x_bounds, index.y_bounds, index.error_bd_x, index.error_bd_y)
    with open(f_n_, 'wb') as f_:
        pickle.dump(arg_tuple, f_)

    print('$$ SPRIG saved.')


def load_SPRIG(load_path: str, data_dir: str) -> SPRIG:
    """加载模型"""
    index = SPRIG(data_dir)
    load_dir = os.path.join(load_path, 'SPRIG_args')

    f_n_ = os.path.join(load_dir, 'cell_bound_dic.kpl')
    with open(f_n_, 'rb') as f_:
        index.cell_bound_dic = pickle.load(f_)

    f_n_ = os.path.join(load_dir, 'table_T_dic.kpl')
    with open(f_n_, 'rb') as f_:
        index.table_T_dic = pickle.load(f_)

    f_n_ = os.path.join(load_dir, 'in_func.kpl')
    with open(f_n_, 'rb') as f_:
        index.interpolation_function = pickle.load(f_)

    f_n_ = os.path.join(load_dir, 'arg_tuple.kpl')
    with open(f_n_, 'rb') as f_:
        arg_tuple = pickle.load(f_)
        index.x_col_num, index.y_col_num, index.x_bounds, index.y_bounds, index.error_bd_x, index.error_bd_y = arg_tuple

    return index
def main_sprig():
    my_index = bulid_SPRIG(data_pth, root_dir, 100, 300)
    save_SPRIG(my_index, save_path=save_pth)
    my_index = load_SPRIG(load_path=load_pth, data_dir=root_dir)

    # # 范围查询测试
    # 26646.0,32240.87594448067 26646.0,32240.87594448067
    b_pt = np.array([32240.87594448067, 26646.0])
    t_pt = np.array([32240.87594448067, 26646.0])
    result, IO, CPU_time, IO_time = my_index.range_query(b_pt, t_pt)
    print(f'query result: {len(result)}\n {result}')  # real 3

if __name__ == '__main__':
    my_index = bulid_SPRIG(data_pth, root_dir, 100, 300)
    save_SPRIG(my_index, save_path=save_pth)
    my_index = load_SPRIG(load_path=load_pth, data_dir=root_dir)

    # # 范围查询测试
    # 26646.0,32240.87594448067 26646.0,32240.87594448067
    b_pt = np.array([32240.87594448067, 26646.0])
    t_pt = np.array([32240.87594448067, 26646.0])
    result, IO, CPU_time, IO_time = my_index.range_query(b_pt, t_pt)
    print(f'query result: {len(result)}\n {result}')  # real 3

    pass
