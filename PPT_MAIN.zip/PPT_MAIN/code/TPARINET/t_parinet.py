import csv
import math
import struct
import time
from datetime import datetime

import matplotlib.pyplot as plt
import pandas as pd
import os
import metis
import networkx as nx
import pickle


TOTAL = 0
DATABLOCKSIZE = 8 * 1024
DATAITEMSIZE = 40

TPINDEXFILE = 'TPINDEX.txt'
RPINDEXFILE = 'RPINDEX.txt'
PAGESIZE = 8 * 1024
DATAFILE_PERITEM = 40

FAN = int((PAGESIZE - 24) / 12)
BSD = int(DATABLOCKSIZE / 40)  # 每个数据页的存储实体数量
BSI = int((PAGESIZE - 24) / 12)  # 每个索引页的存储实体数量
MAX_BLOCKS = 256


class LeafNode:
    def __init__(self, page_id):
        self.page_id = page_id  # 叶子节点所在的数据页
        self.time_max = float('-inf')  # 叶子节点包含的数据项的最大开始时间
        self.data_items = []
        self.parent_id = 0
        self.next = 0
        self.is_leaf = 11

    def add_item(self, t, record_id):
        self.data_items.append([t, record_id])
        self.data_items = sorted(self.data_items, key=lambda x: x[0])
        self.time_max = self.data_items[-1][0]

    def is_full(self):
        """
        判断当前叶子节点是否已满
        :return:
        """
        return len(self.data_items) * 12 + 28 > PAGESIZE

    def pack(self):
        """
        压缩当前叶子节点页
        :return:
        """
        packed_items = struct.pack('IIdIII', self.is_leaf, self.page_id, float(self.time_max),
                                   len(self.data_items),
                                   self.parent_id,
                                   self.next)
        for t, record_id in self.data_items:
            packed_items += struct.pack('dI', float(t), record_id)
        return packed_items

    @staticmethod
    def unpack(cls, data):
        """
        解压缩叶子节点页
        :param cls:
        :param data:
        :return:
        """

        unpacked_items = struct.unpack('IIdIII', data[:28])
        page_id = unpacked_items[1]
        time_max = float(unpacked_items[2])
        length = unpacked_items[3]
        parent_id = unpacked_items[4]
        next = unpacked_items[5]
        is_leaf = unpacked_items[0]
        page = cls(page_id)
        page.page_id = page_id
        page.time_max = time_max
        page.parent_id = parent_id
        page.next = next
        page.is_leaf = is_leaf
        offset = 28
        for i in range(length):
            t = struct.unpack('d', data[offset:offset + 8])[0]

            record_id = struct.unpack('I', data[offset + 8:offset + 12])[0]
            page.add_item(t, record_id)
            offset += 12
        return page


class InternalNode:
    def __init__(self, page_id):
        self.page_id = page_id
        self.time_max = float('-inf')
        self.child_items = []
        self.parent_id = 0
        self.is_leaf = 10

    def add_child(self, t, page_id):
        self.child_items.append([t, page_id])
        self.child_items = sorted(self.child_items, key=lambda x: x[0])
        self.time_max = self.child_items[-1][0]

    def delete_child_page(self, page_id):
        for i in range(len(self.child_items)):

            if self.child_items[i][1] == page_id:
                del self.child_items[i]
                self.child_items = sorted(self.child_items, key=lambda x: x[0])
                self.time_max = self.child_items[-1][0]
                break

    def is_full(self):
        """
        判断当前内部节点是否已满
        :return:
        """
        return len(self.child_items) * 12 + 24 > PAGESIZE

    def pack(self):
        """
        压缩当前内部节点页
        :return:
        """
        packed_items = struct.pack('IIdII', self.is_leaf, self.page_id, float(self.time_max),
                                   len(self.child_items),
                                   self.parent_id
                                   )
        for t, page_id in self.child_items:
            packed_items += struct.pack('dI', float(t), page_id)
        return packed_items

    @staticmethod
    def unpack(cls, data):
        """
        解压缩内部节点页
        :param cls:
        :param data:
        :return:
        """

        unpacked_items = struct.unpack('IIdII', data[:24])
        page_id = unpacked_items[1]
        time_max = float(unpacked_items[2])
        length = unpacked_items[3]
        parent_id = unpacked_items[4]
        is_leaf = unpacked_items[0]

        page = cls(page_id)
        page.page_id = page_id
        page.time_max = time_max

        page.parent_id = parent_id
        page.is_leaf = is_leaf
        offset = 24

        for i in range(length):
            t = struct.unpack('d', data[offset:offset + 8])[0]

            page_id = struct.unpack('I', data[offset + 8:offset + 12])[0]
            page.add_child(t, page_id)
            offset += 12
        return page


class MemoryManager:
    """
    内存管理类，相当于一个缓存。
    在创建的索引的时候，新建或者更新块后是先写入缓存中，不是立即写入磁盘，减少IO数
    在查询数据时，会设置缓存，首先先从缓存读取数据，如果没有该块，则再从磁盘中读取，也减少了访存时间
    """

    def __init__(self, max_pages):
        self.max_pages = max_pages
        self.pages = []
        self.page_ids = []

    def is_full(self):
        return len(self.pages) >= self.max_pages

    def add_page(self, page, file_path):
        """
        当有新块加入，则添加到缓存中，如果缓存已满，则替换缓存中的块
        :param page:
        :param file_path:
        :return:
        """
        if page.page_id not in self.page_ids:
            self.pages.append(page)
            self.page_ids.append(page.page_id)

            if self.is_full():
                page_to_replace = self.replace_page()

                self.write_page_to_file(file_path, page_to_replace)

        else:
            self.delete(page)
            self.pages.append(page)
            self.page_ids.append(page.page_id)

    def delete(self, page):
        pages = []

        for i in range(len(self.pages)):
            if self.pages[i].page_id != page.page_id:
                pages.append(self.pages[i])
        self.pages = pages

        self.page_ids.remove(page.page_id)

    def replace_page(self):
        """
        当缓存满了，寻找一个合适的块替换，这里采用的是先进先出策略
        :return:
        """
        page_id_to_replace = self.page_ids.pop(0)
        page_to_replace = self.get_page(page_id_to_replace)

        self.pages.pop(0)

        return page_to_replace

    def get_page(self, page_id):
        for page in self.pages:
            if page.page_id == page_id:
                return page
        return None

    def write_page_to_file(self, file_path, page):
        """
        将相应块写入磁盘
        :param file_path:
        :param page:
        :return:
        """
        with open(file_path, 'rb+') as file:
            file.seek(page.page_id * PAGESIZE)

            file.write(page.pack())

    def load_page_from_file(self, file_path, page_id):
        """
        从磁盘上获取相应块的数据
        :param file_path:
        :param page_id:
        :return:
        """
        with open(file_path, 'rb') as file:
            file.seek(page_id * PAGESIZE)
            page_data = file.read(PAGESIZE)

            page_type = struct.unpack('I', page_data[0:4])[0]

            if page_type == 11:
                page = LeafNode.unpack(LeafNode, page_data)
            if page_type == 10:
                page = InternalNode.unpack(InternalNode, page_data)

            return page

class MemoryManager_query:
    """
    内存管理类，相当于一个缓存。
    在创建的索引的时候，新建或者更新块后是先写入缓存中，不是立即写入磁盘，减少IO数
    在查询数据时，会设置缓存，首先先从缓存读取数据，如果没有该块，则再从磁盘中读取，也减少了访存时间
    """

    def __init__(self, max_pages):
        self.max_pages = max_pages
        self.pages = []
        self.page_ids = []

    def is_full(self):
        return len(self.pages) >= self.max_pages

    def add_page(self, page, file_path):
        """
        当有新块加入，则添加到缓存中，如果缓存已满，则替换缓存中的块
        :param page:
        :param file_path:
        :return:
        """
        if page.page_id not in self.page_ids:
            self.pages.append(page)
            self.page_ids.append(page.page_id)

            if self.is_full():
                self.replace_page()







    def replace_page(self):
        """
        当缓存满了，寻找一个合适的块替换，这里采用的是先进先出策略
        :return:
        """
        page_id_to_replace = self.page_ids.pop(0)

        self.pages.pop(0)



    def get_page(self, page_id):
        for page in self.pages:
            if page.page_id == page_id:
                return page
        return None

    def write_page_to_file(self, file_path, page):
        """
        将相应块写入磁盘
        :param file_path:
        :param page:
        :return:
        """
        with open(file_path, 'rb+') as file:
            file.seek(page.page_id * PAGESIZE)

            file.write(page.pack())

    def load_page_from_file(self, file_path, page_id):
        """
        从磁盘上获取相应块的数据
        :param file_path:
        :param page_id:
        :return:
        """
        with open(file_path, 'rb') as file:
            file.seek(page_id * PAGESIZE)
            page_data = file.read(PAGESIZE)

            page_type = struct.unpack('I', page_data[0:4])[0]

            if page_type == 11:
                page = LeafNode.unpack(LeafNode, page_data)
            if page_type == 10:
                page = InternalNode.unpack(InternalNode, page_data)

            return page
class MemoryManager_DATA:
    """
    内存管理类，相当于一个缓存。
    在创建的索引的时候，新建或者更新块后是先写入缓存中，不是立即写入磁盘，减少IO数
    在查询数据时，会设置缓存，首先先从缓存读取数据，如果没有该块，则再从磁盘中读取，也减少了访存时间
    """

    def __init__(self, max_pages):
        self.max_pages = max_pages
        self.pages = []
        self.page_ids = []

    def is_full(self):
        return len(self.pages) >= self.max_pages

    def add_page(self, page, page_id):
        """
        当有新块加入，则添加到缓存中，如果缓存已满，则替换缓存中的块
        :param page:
        :param file_path:
        :return:
        """
        if page_id not in self.page_ids:
            self.pages.append([page_id,page])
            self.page_ids.append(page_id)

            if self.is_full():
                self.replace_page()

    def replace_page(self):
        """
        当缓存满了，寻找一个合适的块替换，这里采用的是先进先出策略
        :return:
        """
        self.page_ids.pop(0)

        self.pages.pop(0)

    def get_page(self, page_id):
        if page_id in self.page_ids:
            for page in self.pages:
                if page[0] == page_id :
                    return page[1]
        return None


class RP:
    """
    1.分区
    2.对每个分区按照时间间隔排序
    3.对每个分区按照时间建立复合B+树索引，存对应数据的id和时间时间
    """

    def __init__(self, file_path, datafile_path, query, G, partition, road_in_partition, memorymanager):
        self.file_path = file_path  # 索引文件
        self.dataset_path = datafile_path  # 数据集

        self.query = query  # 查询负载
        self.G = G  # 地图
        self.partition = partition
        self.road_in_partition = road_in_partition

        self.memorymanager = memorymanager  # 缓存
        self.num = 0

    def create_index(self):
        # 先读取数据，开始在对应索引文件插入数据
        header = self.load_header_from_file()
        if header is None:
            pid_map_tree = {}
            for p in self.partition.keys():
                pid_map_tree[p] = 0

            header = Header(END_BLOCK_NUMBER=0, id_map_tree=pid_map_tree, length=len(self.partition))
            header.write_block_to_file(self.file_path)

            for p in self.partition.keys():
                header = self.load_header_from_file()
                root_id = header.data[p]

                if root_id == 0:
                    header.END_BLOCK_NUMBER += 1

                    root = LeafNode(header.END_BLOCK_NUMBER)

                    header.data[p] = root.page_id
                    header.write_block_to_file(self.file_path)

                    self.memorymanager.add_page(root, self.file_path)

        offset = 0
        page_id = 0
        with open(self.dataset_path, 'rb') as file:
            file_size = file.read()
            while page_id * DATABLOCKSIZE + offset + DATAFILE_PERITEM <= len(file_size):
                if offset + DATAFILE_PERITEM > DATABLOCKSIZE:
                    page_id += 1
                    offset = 0

                file.seek(page_id * DATABLOCKSIZE + offset)

                record_data = file.read(DATAFILE_PERITEM)

                record_id, rid, pos1, t1, lon, lat = struct.unpack('IIdddd', record_data)

                offset += DATAFILE_PERITEM
                partition_id = self.road_in_partition[int(float(pos1))]

                print(f'插入第{record_id}个数据')
                print(f'{[record_id, rid, pos1, t1, lon, lat], partition_id}')

                self.num += 1
                self.insert([t1, record_id], partition_id)

        self.flush_to_disk()

    def insert(self, record, partition_id, cur_node=None):

        if cur_node is None:
            header = self.load_header_from_file()

            page_id = header.data[partition_id]

            page = self.memorymanager.get_page(page_id)

            if page is None:
                page = self.memorymanager.load_page_from_file(self.file_path, page_id)
                self.memorymanager.add_page(page, self.file_path)
            cur_node = page
        if cur_node.is_leaf == 11:
            cur_node.add_item(record[0], record[1])

            if cur_node.is_full():
                self.handle_overflow(cur_node, partition_id)
            else:
                self.memorymanager.add_page(cur_node, self.file_path)
                self.adjust_tree(cur_node)

        if cur_node.is_leaf == 10:
            chosen_child_node = self.choose_best_child_node(cur_node, record, partition_id)

            self.insert(record, partition_id, cur_node=chosen_child_node)

    def handle_overflow(self, cur_node, partition_id):
        if cur_node.is_leaf == 11:
            cur_node, new_node = self.split_leaf_node(cur_node)
        if cur_node.is_leaf == 10:
            cur_node, new_node = self.split_internal_node(cur_node)
        if cur_node.parent_id == 0:
            header = self.load_header_from_file()
            header.END_BLOCK_NUMBER += 1
            root_node = InternalNode(header.END_BLOCK_NUMBER)

            root_node.add_child(cur_node.time_max, cur_node.page_id)

            root_node.add_child(new_node.time_max, new_node.page_id)
            cur_node.parent_id = root_node.page_id
            new_node.parent_id = root_node.page_id

            header.data[partition_id] = root_node.page_id
            if partition_id == 265:
                print(header.data[265])
                print(root_node.child_items)

            self.memorymanager.add_page(root_node, self.file_path)
            self.memorymanager.add_page(cur_node, self.file_path)
            self.memorymanager.add_page(new_node, self.file_path)

            header.write_block_to_file(self.file_path)
        else:
            parent_node = self.get_parent_node(cur_node.parent_id)
            parent_node.delete_child_page(cur_node.page_id)
            parent_node.add_child(new_node.time_max, new_node.page_id)
            new_node.parent_id = cur_node.parent_id

            parent_node.add_child(cur_node.time_max, cur_node.page_id)

            self.memorymanager.add_page(new_node, self.file_path)
            self.memorymanager.add_page(cur_node, self.file_path)
            self.memorymanager.add_page(parent_node, self.file_path)
            if parent_node.is_full():
                self.handle_overflow(parent_node, partition_id)
            else:
                self.adjust_tree(parent_node)

    def get_parent_node(self, parent_id):
        """
        获取父节点
        :param parent_id:
        :return:
        """
        parent_node = self.memorymanager.get_page(parent_id)
        if parent_node is None:
            parent_node = self.memorymanager.load_page_from_file(self.file_path, parent_id)
            self.memorymanager.add_page(parent_node, self.file_path)
        return parent_node

    def split_leaf_node(self, cur_node):
        header = self.load_header_from_file()
        header.END_BLOCK_NUMBER += 1
        new_node = LeafNode(header.END_BLOCK_NUMBER)
        header.write_block_to_file(self.file_path)

        mid_index = len(cur_node.data_items) // 2
        right_items = cur_node.data_items[mid_index:]
        left_items = cur_node.data_items[:mid_index]
        new_node.data_items = right_items

        new_node.time_max = cur_node.data_items[-1][0]
        cur_node.data_items = left_items
        cur_node.time_max = cur_node.data_items[mid_index - 1][0]
        new_node.parent_id = cur_node.parent_id
        new_node.next = cur_node.next
        cur_node.next = new_node.page_id
        self.memorymanager.add_page(new_node, self.file_path)
        self.memorymanager.add_page(cur_node, self.file_path)
        return cur_node, new_node

    def split_internal_node(self, cur_node):
        header = self.load_header_from_file()
        header.END_BLOCK_NUMBER += 1
        new_node = InternalNode(header.END_BLOCK_NUMBER)
        header.write_block_to_file(self.file_path)

        mid_index = len(cur_node.child_items) // 2
        right_items = cur_node.child_items[mid_index:]
        left_items = cur_node.child_items[:mid_index]
        new_node.child_items = right_items
        for child in new_node.child_items:
            child_page = self.memorymanager.get_page(child[1])
            if child_page is None:
                child_page = self.memorymanager.load_page_from_file(self.file_path, child[1])
            child_page.parent_id = new_node.page_id
            self.memorymanager.add_page(child_page, self.file_path)

        new_node.time_max = cur_node.child_items[-1][0]
        cur_node.child_items = left_items
        cur_node.time_max = cur_node.child_items[mid_index - 1][0]
        new_node.parent_id = cur_node.parent_id
        self.memorymanager.add_page(new_node, self.file_path)
        self.memorymanager.add_page(cur_node, self.file_path)
        return cur_node, new_node

    def adjust_tree(self, cur_node):

        if cur_node.parent_id != 0:

            parent_node = self.memorymanager.get_page(cur_node.parent_id)
            print(cur_node.parent_id)
            if parent_node is None:
                parent_node = self.memorymanager.load_page_from_file(self.file_path, cur_node.parent_id)

            parent_node.delete_child_page(cur_node.page_id)
            parent_node.add_child(cur_node.time_max, cur_node.page_id)
            self.memorymanager.write_page_to_file(self.file_path, parent_node)

            self.memorymanager.add_page(parent_node, self.file_path)

            self.adjust_tree(parent_node)

    def choose_best_child_node(self, cur_node, record, partition_id):
        best_child_node = None
        print(cur_node.page_id)
        print(cur_node.time_max)
        print(cur_node.child_items)

        for i in range(len(cur_node.child_items)):

            if cur_node.child_items[i][0] >= record[0]:
                best_child_node = cur_node.child_items[i]

                break
        if best_child_node is None:
            header = self.load_header_from_file()

            page_id = header.data[partition_id]

            page = self.memorymanager.get_page(page_id)

            if page is None:
                page = self.memorymanager.load_page_from_file(self.file_path, page_id)
                self.memorymanager.add_page(page, self.file_path)
            cur_node = page

            self.child_time_max(cur_node, record)
            for i in range(len(cur_node.child_items)):

                if cur_node.child_items[i][0] >= record[0]:
                    best_child_node = cur_node.child_items[i]
                    break
        print(f'最好孩子节点：{best_child_node[1]}')
        print(cur_node.child_items)
        chosen_page = self.memorymanager.get_page(best_child_node[1])
        if chosen_page is None:
            chosen_page = self.memorymanager.load_page_from_file(self.file_path, best_child_node[1])
            self.memorymanager.add_page(chosen_page, self.file_path)

        return chosen_page

    def child_time_max(self, cur_node, record):
        cur_node.time_max = record[0]
        if cur_node.is_leaf == 10:
            cur_node.child_items[-1][0] = record[0]

            self.memorymanager.add_page(cur_node, self.file_path)
            cur_node_id = cur_node.child_items[-1][1]
            cur_node = self.memorymanager.get_page(cur_node_id)

            if cur_node is None:
                cur_node = self.memorymanager.load_page_from_file(self.file_path, cur_node_id)
                self.memorymanager.add_page(cur_node, self.file_path)
            self.child_time_max(cur_node, record)

    def flush_to_disk(self):
        """
        当构建索引结束后，将缓存中的块写入磁盘
        :return:
        """
        for page in self.memorymanager.pages:
            self.memorymanager.write_page_to_file(self.file_path, page)

        self.memorymanager.pages = []
        self.memorymanager.page_ids = []

    def _save_page(self, page):
        """
        保存块到磁盘上
        :param page:
        :return:
        """
        with open(self.file_path, 'rb+') as file:
            file.seek(page.page_id * PAGESIZE)
            file.write(page.pack())

    def load_header_from_file(self):
        try:
            with open(self.file_path, 'rb') as file:
                file.seek(0)
                page_data = file.read(PAGESIZE)

                if len(page_data) == 0:
                    return None
                page = Header.unpack(Header, page_data)
                return page
        except FileNotFoundError:
            with open(self.file_path, 'wb'):
                pass
            return None

    def range_query(self, data_dict, data_file_tans, data_buffer):
        total_results = []
        global TOTAL
        for query in self.query:

            header = self.load_header_from_file()
            partition_id = self.road_in_partition[int(query[1])]

            root_id = header.data[partition_id]
            root = self.memorymanager.get_page(root_id)
            if root is None:
                root = self.memorymanager.load_page_from_file(self.file_path, root_id)
                self.memorymanager.add_page(root, self.file_path)

                TOTAL += 1

            results = self.query_(query, root, data_dict, data_file_tans, data_buffer)

            #print(results)
            print(TOTAL)
        return total_results

    def query_(self, query, cur_node, data_dict, data_file_trans, data_buffer):

        global TOTAL
        result = []
        with open(data_file_trans, 'rb') as file:
            if cur_node.is_leaf == 11:
                flag = 0
                for record in cur_node.data_items:

                    if query[2] > record[0] >= query[0]:
                        record_id = data_dict[record[1]]
                        data_block_id = (record_id // (DATABLOCKSIZE // 36))
                        data_list = data_buffer.get_page(data_block_id)
                        if data_list is None:
                            file.seek(data_block_id * DATABLOCKSIZE)
                            record_data = file.read(DATABLOCKSIZE)

                            TOTAL += 1
                            data_list = []
                            offset = 0
                            for i in range(DATABLOCKSIZE // 36):
                                pos1, t1, pos2, t2, rid = struct.unpack('ddddI', record_data[offset:offset + 36])
                                offset += 36
                                data_list.append([pos1, t1, pos2, t2, rid])

                            data_buffer.add_page(data_list, data_block_id)



                        for i in range(len(data_list)):
                            pos1 = data_list[i][0]
                            rid = data_list[i][4]
                            pos2 = data_list[i][2]
                            t1 = data_list[i][1]
                            t2 = data_list[i][3]
                            if query[1] <= pos1 < query[3]:
                                result.append([rid, pos1, pos2, t1, t2])
                    """elif query[2] < record[0]:
                        flag = 1
                        break"""

                next_node_id = cur_node.next
                while next_node_id != 0 and flag == 0:
                    next_node = self.memorymanager.get_page(next_node_id)
                    if next_node is None:
                        next_node = self.memorymanager.load_page_from_file(self.file_path, next_node_id)
                        self.memorymanager.add_page(next_node, self.file_path)

                        TOTAL += 1
                    for record in next_node.data_items:
                        if query[2] > record[0] >= query[0]:

                            record_id = data_dict[record[1]]
                            data_block_id = (record_id // (DATABLOCKSIZE // 36))
                            record_data = data_buffer.get_page(data_block_id)
                            if record_data is None:
                                file.seek(data_block_id * DATABLOCKSIZE)
                                record_data = file.read(DATABLOCKSIZE)
                                TOTAL += 1
                                data_list = []
                                offset = 0
                                for i in range(DATABLOCKSIZE // 36):
                                    pos1, t1, pos2, t2, rid = struct.unpack('ddddI', record_data[offset:offset + 36])

                                    offset += 36

                                    data_list.append([pos1, t1, pos2, t2, rid])
                                data_buffer.add_page(data_list, data_block_id)

                            for i in range(len(data_list)):
                                pos1 = data_list[i][0]
                                rid = data_list[i][4]
                                pos2 = data_list[i][2]
                                t1 = data_list[i][1]
                                t2 = data_list[i][3]
                                if query[1] <= pos1 < query[3]:
                                    result.append([rid, pos1, pos2, t1, t2])
                        """elif query[2] < record[0]:
                            flag = 1
                            break"""

                    next_node_id = next_node.next
            else:
                for i, child in enumerate(cur_node.child_items):

                    if query[0] <= child[0]:
                        child_node = self.memorymanager.get_page(child[1])
                        if child_node is None:
                            child_node = self.memorymanager.load_page_from_file(self.file_path, child[1])
                            self.memorymanager.add_page(child_node, self.file_path)

                            TOTAL += 1
                        result = self.query_(query, child_node, data_dict, data_file_trans, data_buffer)

                        break

            return result


class Header:
    """

    """

    def __init__(self, END_BLOCK_NUMBER, id_map_tree, length):
        self.END_BLOCK_NUMBER = END_BLOCK_NUMBER  # 最后一个块号
        self.data = id_map_tree  # 分区和树的根节点的块号的映射
        self.length = length  # 树的数量

    def pack(self):
        count = self.length * 2
        data = []
        for i, j in self.data.items():
            data.append(i)
            data.append(j)
        return struct.pack(f'II{count}I', self.END_BLOCK_NUMBER, self.length, *data)

    @staticmethod
    def unpack(cls, data):
        END_BLOCK_NUMBER, length = struct.unpack('II', data[:8])

        id_map_tree = {}
        for i in range(length):
            partition_, root_block = struct.unpack('II', data[8 + i * 8:16 + i * 8])
            id_map_tree[partition_] = root_block

        return cls(END_BLOCK_NUMBER, id_map_tree, length)

    def write_block_to_file(self, file_path):
        """
        将头节点写入索引文件
        :param file_path:
        :return:
        """
        with open(file_path, 'rb+') as file:
            file.seek(0)
            file.write(self.pack())


class Partition:
    def __init__(self, datafile_path, query, graph, segment_dict, segMerged_to_int):
        self.datafile_path = datafile_path
        self.query = query
        self.graph = graph
        self.segment_dict = segment_dict
        self.segMerged_to_int = segMerged_to_int  # 路段id映射到的数字对应的id，方便后面存储
        self.QI_optimal = float('inf')

    # 计算成本最小的分区
    def partition(self):

        best_paritions = None
        best_node_in_partition = None
        best_QI = float('inf')
        print(self.graph.number_of_nodes())
        for m in range(2, 1020, 20):
            (cuts, parts) = metis.part_graph(graph=self.graph, nparts=m)
            node_in_partition = {}
            for node in self.graph.nodes:
                node_in_partition[node] = None
            partitions = {}

            for i in range(len(parts)):
                if parts[i] not in partitions.keys():
                    partitions[parts[i]] = []

            for i, node in enumerate(self.graph.nodes):
                partitions[parts[i]].append(node)
                node_in_partition[node] = parts[i]
            # 成本函数
            QI = self.cost_function(partitions, node_in_partition)
            print(f'm={m},QI={QI}')
            # 比较大小
            if QI < best_QI:
                best_QI = QI
                best_paritions = partitions
                best_node_in_partition = node_in_partition
        return best_paritions, best_node_in_partition

    def cost_function(self, partitions, node_in_partition):
        QI = 0
        NP = {}  # 每个分区中的单元个数
        time_unit_per_partition = {}

        tmax = [float('inf'), float('-inf')]  # 数据集最大时间间隔
        for key, roads in partitions.items():

            Np = 0
            for road in roads:
                Np += self.graph.nodes[road]['weight']  # 求每个分区的单元数
                time_unit_per_partition[key] = [float('inf'), float('-inf')]
            NP[key] = Np
        offset = 0
        page_id = 0

        with open(self.datafile_path, 'rb') as file:
            file_size = file.read()
            while page_id * DATABLOCKSIZE + offset + DATAFILE_PERITEM <= len(file_size):
                if offset + DATAFILE_PERITEM > DATABLOCKSIZE:
                    page_id += 1
                    offset = 0

                file.seek(page_id * DATABLOCKSIZE + offset)

                record_data = file.read(DATAFILE_PERITEM)
                # 所验证的数据都是在地图范围内的

                record_id, mo, pos1, t1, lon, lat = struct.unpack('IIdddd', record_data)

                key = node_in_partition[int(float(pos1))]

                if time_unit_per_partition[key][0] > t1:
                    time_unit_per_partition[key][0] = t1

                if time_unit_per_partition[key][1] < t1:
                    time_unit_per_partition[key][1] = t1
                offset += DATAFILE_PERITEM
        for query_ in self.query:  # 之前求的交点，key是路段，value是交点,id=-1000147292&&-201724129&&-1000147291,ll=[0.760526871012579, 0.885307926495941]

            key = node_in_partition[int(float(query_[1]))]
            if NP[key] > 0:
                QI += (math.log(NP[key], FAN) + NP[key] * (math.fabs(
                    query_[2] - query_[0])) * (
                               1 / math.fabs(time_unit_per_partition[key][0] - time_unit_per_partition[key][1])) * (
                               1 / BSD + 1 / BSI))
            else:
                QI = float('inf')

        return QI


# 修改，直接统计转换之后的数据
def calculate_density(partition_dict, traj_path, segMerged_to_int_file):
    """file_list = os.listdir(traj_path)
    segment_traversed = {}
    for key, value in partition_dict.items():
        for next_ in value.next_segments:
            segment_traversed[(segMerged_to_int_file[key], segMerged_to_int_file[next_])] = 0
    for file_name in file_list:
        print(file_name)
        file = os.path.join(traj_path, file_name)
        df = pd.read_csv(file)

        df = df.drop_duplicates(subset=['edgeID'], keep='first')

        for i in range(len(df) - 1):
            if pd.isnull(df.iloc[i]['edgeID']) or pd.isnull(df.iloc[i + 1]['edgeID']):
                break
            seg_id1 = segMerged_to_int_file[seg_to_segMerged[df.iloc[i]['edgeID']]]
            seg_id2 = segMerged_to_int_file[seg_to_segMerged[df.iloc[i + 1]['edgeID']]]
            if seg_id1 != seg_id2:
                if (seg_id1, seg_id2) not in segment_traversed.keys():
                    segment_traversed[(seg_id1, seg_id2)] = 1
                else:
                    segment_traversed[(seg_id1, seg_id2)] += 1
    return segment_traversed"""

    segment_traversed = {}
    for key, value in partition_dict.items():
        for next_ in value.next_segments:
            segment_traversed[(segMerged_to_int_file[key], segMerged_to_int_file[next_])] = 0
    file_list = os.listdir(traj_path)
    for file_name in file_list:
        if file_name.endswith('txt'):
            file_path = os.path.join(traj_path, file_name)
            with open(file_path, 'r') as file:

                lines = file.readlines()

                for i in range(1, len(lines)):
                    fields1 = lines[i - 1].strip().split(',')
                    fields2 = lines[i].strip().split(',')
                    seg_id1 = int(float(fields1[1]))
                    seg_id2 = int(float(fields2[1]))
                    if seg_id1 != seg_id2:
                        if (seg_id1, seg_id2) not in segment_traversed.keys():
                            segment_traversed[(seg_id1, seg_id2)] = 1
                        else:
                            segment_traversed[(seg_id1, seg_id2)] += 1
    return segment_traversed


def sava_traj_unit(traj_path, data_file, segMerged_to_int):
    road_traversed = {}
    for key, value in segMerged_to_int.items():
        road_traversed[value] = 0
    with open(data_file, 'wb') as output:
        num_block = 0
        record_id = 0
        file_list = os.listdir(traj_path)
        for file_name in file_list:
            if file_name.endswith('txt'):
                file_path = os.path.join(traj_path, file_name)
                with open(file_path, 'r') as file:
                    data_block = b''

                    for line in file.readlines():

                        fields = line.strip().split(',')

                        if len(data_block) + DATAFILE_PERITEM > DATABLOCKSIZE:
                            output.seek(num_block * DATABLOCKSIZE)
                            num_block += 1
                            output.write(data_block)
                            data_block = b''

                        data_block += struct.pack('IIdddd', record_id, int(fields[-5]),
                                                  float(fields[-4]), float(fields[-3]),
                                                  float(fields[-2]),
                                                  float(fields[-1]))
                        record_id += 1
                        road_traversed[int(float(fields[-4]))] += 1
                    output.seek(num_block * DATABLOCKSIZE)

                    output.write(data_block)
    return road_traversed


def read_seg_to_merged(file_path):
    with open(file_path, 'rb') as f:
        seg_to_segMerged = pickle.load(f)
    return seg_to_segMerged


def transfer_segMerged_to_int(seg_to_segMerged, segMerged_to_int_file):
    count = 0
    segMerged_to_int = {}
    for key, value in seg_to_segMerged.items():
        segMerged_to_int[value] = count
        count += 1
    with open(segMerged_to_int_file, 'wb') as file:
        pickle.dump(segMerged_to_int, file)


def load_file(filename):
    with open(filename, 'rb') as file:
        return pickle.load(file)


def save_file(seg_start_end, filename):
    with open(filename, 'wb') as file:
        pickle.dump(seg_start_end, file)


class Point:
    def __init__(self, seg_id, seg_pos, t):
        """
        轨迹点类
        :param seg_id:路段id
        :param seg_pos: 轨迹点在路段相对位置
        :param t: 轨迹点的时间
        """
        self.seg_id = seg_id
        self.seg_pos = seg_pos
        self.t = t

    def __eq__(self, other):
        return self.seg_id == other.seg_id and self.seg_pos == other.seg_pos and self.t == other.t

    def __hash__(self):
        return hash(self.seg_id) * hash(self.seg_pos) * hash(self.t)

    def __str__(self):
        return "{seg_id:%s\tseg_pos:%f\tt:%f}" % (self.seg_id, self.seg_pos, self.t)


class Segment:
    def __init__(self, seg_id, start_junction, end_junction, length, lane_number, edgesMerged, rect):
        """
        路段类
        :param seg_id: 路段id
        :param start_junction:路段开始交叉口
        :param end_junction: 路段结束交叉口
        :param length: 路段长度
        :param lane_number: 路段车道数
        :param edgesMerged: 合并的路段
        """
        self.seg_id = seg_id
        self.start_junction = start_junction
        self.end_junction = end_junction
        self.length = length
        self.lane_number = lane_number
        self.edgesMerged = edgesMerged
        self.rect = rect
        self.next_segments = []
        self.pre_segments = []
        self.next_segments_dict = {}
        self.pre_segments_dict = {}

    def __hash__(self):
        return hash(self.seg_id)

    def __eq__(self, other):
        return self.seg_id == other.seg_id

    def __str__(self):
        return "{seg_id:%s\tstart_junction:%s\tend_junction:%s\tseg_len:%f\tlane_number:%s}" % \
               (self.seg_id, self.start_junction, self.end_junction, self.length, self.lane_number)


def read_seg(seg_path, segMerged_path):
    df = pd.read_csv(seg_path)
    df_ = pd.read_csv(segMerged_path)
    seg_to_start_and_end = {}
    for i in range(len(df)):
        seg_to_start_and_end[df.iloc[i]['start']] = df.iloc[i]['startLocation']
        seg_to_start_and_end[df.iloc[i]['end']] = df.iloc[i]['endLocation']

    seg_start_end = {}

    for i in range(len(df_)):
        start = seg_to_start_and_end[df_.iloc[i]['start']].replace("(", "").replace(")", "").split(",")
        end = seg_to_start_and_end[df_.iloc[i]['end']].replace("(", "").replace(")", "").split(",")
        seg_start_end[df_.iloc[i]['edgeId']] = [float(start[0]), float(start[1]), float(end[0]), float(end[1])]
        print(seg_start_end[df_.iloc[i]['edgeId']])

    return seg_start_end


def read_segMerged(segMerged_path, seg_start_end):
    seg_csv = pd.read_csv(segMerged_path)
    segment_list = []
    segment_dict = {}
    junction_next_seg = {}
    junction_pre_seg = {}
    for i in range(len(seg_csv)):

        start_junction = seg_csv.iloc[i]['start']
        end_junction = seg_csv.iloc[i]['end']
        if start_junction not in junction_next_seg.keys():
            junction_next_seg[start_junction] = []
        if start_junction not in junction_pre_seg.keys():
            junction_pre_seg[start_junction] = []
        if end_junction not in junction_next_seg.keys():
            junction_next_seg[end_junction] = []
        if end_junction not in junction_pre_seg.keys():
            junction_pre_seg[end_junction] = []
        seg_id = seg_csv.iloc[i]['edgeId']
        if seg_id not in segment_dict.keys():
            segment_dict[seg_id] = None

    for i in range(len(seg_csv)):
        print(i)
        seg_id = seg_csv.iloc[i]['edgeId']
        start_junction = seg_csv.iloc[i]['start']
        end_junction = seg_csv.iloc[i]['end']
        length = int(seg_csv.iloc[i]['length'])
        lane_number = int(seg_csv.iloc[i]['laneNumber'])

        edgesMerged = seg_csv.iloc[i]['edgesMerged'].replace("[", "").replace("]", "").replace("'", "").replace(" ",
                                                                                                                "").split(
            ',')
        if edgesMerged == ['None']:
            edgesMerged = [seg_id]
        if len(junction_next_seg[start_junction]) == 0:
            junction_next_seg[start_junction] = [seg_id]
        else:
            junction_next_seg[start_junction].append(seg_id)
        if len(junction_pre_seg[end_junction]) == 0:
            junction_pre_seg[end_junction] = [seg_id]
        else:
            junction_pre_seg[end_junction].append(seg_id)

        rect = seg_start_end[seg_id]

        seg = Segment(seg_id, start_junction, end_junction, length, lane_number, edgesMerged, rect)
        segment_list.append(seg)
        segment_dict[seg_id] = seg
    for i in range(len(segment_list)):
        segment_list[i].pre_segments = junction_pre_seg[segment_list[i].start_junction]
        segment_list[i].next_segments = junction_next_seg[segment_list[i].end_junction]
        segment_dict[segment_list[i].seg_id].next_segments = junction_next_seg[segment_list[i].end_junction]
        segment_dict[segment_list[i].seg_id].pre_segments = junction_pre_seg[segment_list[i].start_junction]
    return segment_dict


def create_graph(segment_dict, traversed_road, segMerged_to_int, road_traversed):
    G = nx.Graph()
    for key, value in segment_dict.items():
        G.add_node(segMerged_to_int[key], weight=road_traversed[segMerged_to_int[key]])
        for i in range(len(value.next_segments)):
            G.add_node(segMerged_to_int[value.next_segments[i]],
                       weight=road_traversed[segMerged_to_int[value.next_segments[i]]])
            if traversed_road[(segMerged_to_int[key], segMerged_to_int[value.next_segments[i]])] == 0:
                traversed_road[(segMerged_to_int[key], segMerged_to_int[value.next_segments[i]])] = 1
            G.add_edge(segMerged_to_int[key], segMerged_to_int[value.next_segments[i]],
                       weights=traversed_road[(segMerged_to_int[key], segMerged_to_int[value.next_segments[i]])])

    return G


def create(datafile_path, index_path, query, G, partition, road_in_partition, data_dict_file, data_file_trans):
    """
    创建索引
    :param data_file:
    :param index_path:
    :return:
    """

    memorymanager = MemoryManager(MAX_BLOCKS)

    index = RP(index_path, datafile_path, query, G, partition, road_in_partition, memorymanager)

    index.create_index()
    place_data(index_path, datafile_path, data_dict_file, data_file_trans)


def search(datafile_path, index_path, query, G, partition, road_in_partition, data_dict, data_file_trans):
    """
    查询数据
    :param data_file:
    :param index_file:
    :return:
    """
    memorymanager = MemoryManager_query(MAX_BLOCKS)
    data_buffer = MemoryManager_DATA(MAX_BLOCKS)
    index = RP(index_path, datafile_path, query, G, partition, road_in_partition, memorymanager)
    with open(data_dict, 'rb') as file:
        data_dict = pickle.load(file)
    result = index.range_query(data_dict, data_file_trans, data_buffer)

    print(TOTAL)
    return result


def get_search_range(search_file):
    query_range = []
    file_list = os.listdir(search_file)
    for file_name in file_list:
        if file_name.endswith('txt'):
            file_path = os.path.join(search_file, file_name)

            with open(file_path, 'r') as file:
                for line in file.readlines():
                    fields = line.strip().split(',')
                    query_range.append([float(fields[0]), float(fields[1]), float(fields[2]), float(fields[3])])

    return query_range


def place_data(model_file, raw_data_file, data_dict_file, data_file):
    data_dict = {}
    mm = 0
    num_block = 0
    with open(data_file, 'wb') as file:
        data_block = b''
        with open(raw_data_file, 'rb') as data:
            with open(model_file, 'rb') as model:
                model.seek(0)

                block = model.read(PAGESIZE)
                END_BLOCK_NUMBER, length = struct.unpack('II', block[:8])

                id_map_tree = {}
                for i in range(length):
                    partition_, root_block = struct.unpack('II', block[8 + i * 8:16 + i * 8])
                    id_map_tree[partition_] = root_block

                for key, value in id_map_tree.items():
                    leaf_node_result = []
                    get_leaf_node(value, model_file, leaf_node_result)

                    for record_id in leaf_node_result:

                        data.seek(((record_id // (DATABLOCKSIZE // DATAITEMSIZE)) * DATABLOCKSIZE) + (
                                record_id % (DATABLOCKSIZE // DATAITEMSIZE)) * DATAITEMSIZE)
                        record = data.read(DATAITEMSIZE)
                        id, mo, pos, t, lon, lat = struct.unpack('IIdddd', record)

                        data_dict[id] = mm
                        serialized_data = struct.pack('ddddI', pos, t, lon, lat, mo)
                        if len(data_block) + len(serialized_data) > DATABLOCKSIZE:
                            file.seek(num_block * DATABLOCKSIZE)
                            num_block += 1
                            file.write(data_block)
                            data_block = b''

                        data_block += serialized_data

                        mm += 1
            file.seek(num_block * DATABLOCKSIZE)

            file.write(data_block)
    with open(data_dict_file, 'wb') as pkl:
        pickle.dump(data_dict, pkl)


def get_leaf_node(b_id, model_path, leaf_node_result):
    with open(model_path, 'rb') as model:
        model.seek(b_id * PAGESIZE)
        block_data = model.read(PAGESIZE)

        block_type = struct.unpack('I', block_data[0:4])[0]

        if block_type == 11:
            unpacked_values = struct.unpack('IIdII', block_data[:24])
            num_items = unpacked_values[3]
            offset = 28
            for i in range(num_items):
                record_id = struct.unpack('I', block_data[offset + 8:offset + 12])[0]
                leaf_node_result.append(record_id)
                offset += 12
        if block_type == 10:
            unpacked_values = struct.unpack('IIdII', block_data[:24])
            num_items = unpacked_values[3]

            offset = 24
            for i in range(num_items):
                block_id = struct.unpack('I', block_data[offset + 8:offset + 12])[0]
                get_leaf_node(block_id, model_path, leaf_node_result)
                offset += 12


def main_tparinet():
    os.chdir("..")

    base=os.getcwd()
    traj_path = f'{base}\\dataset\\sim'
    index_path = f'{base}\\model\\TPARINET\\tparinet0_index.idx'
    segMerged_to_int_file = f'{base}\\code\TPARINET\\pkl文件\\sort_segment.pkl'
    data_file = f'{base}\\model\\TPARINET\\data0.dat'
    segment_dict_file = f'{base}\\code\TPARINET\\pkl文件\\segment_dict.pkl'
    segment_traversed_file = f'{base}\\code\TPARINET\\pkl文件\\segment_traversed.pkl'
    search_file = f"{base}\\model\\TPARINET\\query0"
    data_file_trans = f"{base}\\model\\TPARINET\\data_trans.dat"
    data_dict_file = f"{base}\\model\\TPARINET\\data_dict.pkl"
    query_range = get_search_range(search_file)
    segMerged_to_int = load_file(segMerged_to_int_file)

    segment_dict = load_file(segment_dict_file)
    road_traversed = sava_traj_unit(traj_path, data_file, segMerged_to_int)
    """segment_traversed = calculate_density(segment_dict, traj_path, segMerged_to_int)
    save_segs_to_file(segment_traversed, segment_traversed_file)"""
    # segment_traversed = load_file(segment_traversed_file)
    # G = create_graph(segment_dict, segment_traversed, segMerged_to_int, road_traversed)
    G = None
    """partition = Partition(data_file, query_range, G, segment_dict, segMerged_to_int)
    best_paritions, best_node_in_partition = partition.partition()
    save_segs_to_file(best_paritions, 'best_paritions.pkl')
    save_segs_to_file(best_node_in_partition, 'best_node_in_partition.pkl')"""
    best_paritions = load_file(f'{base}\\code\TPARINET\\pkl文件\\best_paritions.pkl')
    best_node_in_partition = load_file(f'{base}\\code\TPARINET\\pkl文件\\best_node_in_partition.pkl')
    while True:
        print("请选择操作：")
        print("1. 创建索引")
        print("2. 从索引中搜索")
        print("0. 退出")

        choice = input("请输入操作编号: ")

        if choice == "1":

            create(data_file, index_path, query_range, G, best_paritions, best_node_in_partition, data_dict_file,
                   data_file_trans)
        elif choice == "2":
            t1 = time.time()
            search(data_file, index_path, query_range, G, best_paritions, best_node_in_partition, data_dict_file,
                   data_file_trans)

            t2 = time.time()
            print((t2 - t1) / 100)
            print(TOTAL / 100)
        elif choice == "0":
            break
        else:
            print("无效的选择，请重新输入。")


if __name__ == "__main__":
    main_tparinet()

