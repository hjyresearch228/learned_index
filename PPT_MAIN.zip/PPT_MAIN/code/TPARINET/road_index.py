import pickle
import pandas as pd

from rtree import index
from shapely.geometry import LineString, box
import math


def create_road_index(segment_list):
    seg_id_mapping = {}
    count = 0

    road_index = index.Index()
    for i in range(len(segment_list)):
        seg_id_mapping[count] = segment_list[i].seg_id

        if float(segment_list[i].rect[0]) < float(segment_list[i].rect[2]) and float(segment_list[i].rect[1]) < float(
                segment_list[i].rect[3]):
            road_index.insert(count, (
                float(segment_list[i].rect[0]), float(segment_list[i].rect[1]), float(segment_list[i].rect[2]),
                float(segment_list[i].rect[3])))
        if float(segment_list[i].rect[0]) > float(segment_list[i].rect[2]) and float(segment_list[i].rect[1]) < float(
                segment_list[i].rect[3]):
            road_index.insert(count, (
                float(segment_list[i].rect[2]), float(segment_list[i].rect[1]), float(segment_list[i].rect[0]),
                float(segment_list[i].rect[3])))
        if float(segment_list[i].rect[0]) < float(segment_list[i].rect[2]) and float(segment_list[i].rect[1]) > float(
                segment_list[i].rect[3]):
            road_index.insert(count, (
                float(segment_list[i].rect[0]), float(segment_list[i].rect[3]), float(segment_list[i].rect[2]),
                float(segment_list[i].rect[1])
            ))
        if float(segment_list[i].rect[0]) > float(segment_list[i].rect[2]) and float(segment_list[i].rect[1]) > float(
                segment_list[i].rect[3]):
            road_index.insert(count, (
                float(segment_list[i].rect[2]), float(segment_list[i].rect[3]), float(segment_list[i].rect[0]),
                float(segment_list[i].rect[1])))
        count += 1

    return road_index, seg_id_mapping


def search_intersection(road_index, query, seg_id_mapping, segment_dict):
    query_bbox = box(query[0], query[1], query[2], query[3])

    query_results = list(road_index.intersection(query_bbox.bounds))
    intersections = {}
    for result_id in query_results:

        segment_rect = segment_dict[seg_id_mapping[result_id]].rect
        seg_box = LineString([(segment_rect[0], segment_rect[1]), (segment_rect[2], segment_rect[3])])

        intersection = query_bbox.intersection(seg_box)

        if not intersection.is_empty and intersection.geom_type == 'LineString':
            seg_length=segment_dict[seg_id_mapping[result_id]].length
            intersection_coords = list(intersection.coords)



            ll=[]
            for i in range(len(intersection_coords)):
                ll.append(math.sqrt((intersection_coords[i][0]-segment_rect[0])**2+(intersection_coords[i][1]-segment_rect[1])**2)/seg_length)
            intersections[seg_id_mapping[result_id]]=ll
            print(f'id={seg_id_mapping[result_id]},ll={ll}')

    return intersections





def save_segs_to_file(seg_start_end, filename):
    with open(filename, 'wb') as file:
        pickle.dump(seg_start_end, file)


def load_segs_from_file(filename):
    with open(filename, 'rb') as file:
        return pickle.load(file)


class Point:
    def __init__(self, seg_id, seg_pos, t):
        """
        轨迹点类
        :param seg_id:路段id
        :param seg_pos: 轨迹点在路段相对位置
        :param t: 轨迹点的时间
        """
        self.seg_id = seg_id
        self.seg_pos = seg_pos
        self.t = t

    def __eq__(self, other):
        return self.seg_id == other.seg_id and self.seg_pos == other.seg_pos and self.t == other.t

    def __hash__(self):
        return hash(self.seg_id) * hash(self.seg_pos) * hash(self.t)

    def __str__(self):
        return "{seg_id:%s\tseg_pos:%f\tt:%f}" % (self.seg_id, self.seg_pos, self.t)


class Segment:
    def __init__(self, seg_id, start_junction, end_junction, length, lane_number, edgesMerged, rect):
        """
        路段类
        :param seg_id: 路段id
        :param start_junction:路段开始交叉口
        :param end_junction: 路段结束交叉口
        :param length: 路段长度
        :param lane_number: 路段车道数
        :param edgesMerged: 合并的路段
        """
        self.seg_id = seg_id
        self.start_junction = start_junction
        self.end_junction = end_junction
        self.length = length
        self.lane_number = lane_number
        self.edgesMerged = edgesMerged
        self.rect = rect
        self.next_segments = []
        self.pre_segments = []
        self.next_segments_dict = {}
        self.pre_segments_dict = {}

    def __hash__(self):
        return hash(self.seg_id)

    def __eq__(self, other):
        return self.seg_id == other.seg_id

    def __str__(self):
        return "{seg_id:%s\tstart_junction:%s\tend_junction:%s\tseg_len:%f\tlane_number:%s}" % \
               (self.seg_id, self.start_junction, self.end_junction, self.length, self.lane_number)


def read_seg(seg_path, segMerged_path):
    df = pd.read_csv(seg_path)
    df_ = pd.read_csv(segMerged_path)
    seg_to_start_and_end = {}
    for i in range(len(df)):
        seg_to_start_and_end[df.iloc[i]['start']] = df.iloc[i]['startLocation']
        seg_to_start_and_end[df.iloc[i]['end']] = df.iloc[i]['endLocation']

    seg_start_end = {}

    for i in range(len(df_)):
        start = seg_to_start_and_end[df_.iloc[i]['start']].replace("(", "").replace(")", "").split(",")
        end = seg_to_start_and_end[df_.iloc[i]['end']].replace("(", "").replace(")", "").split(",")
        seg_start_end[df_.iloc[i]['edgeId']] = [float(start[0]), float(start[1]), float(end[0]), float(end[1])]
        print(seg_start_end[df_.iloc[i]['edgeId']])

    """x_min = df['startLocation'].apply(lambda x: float(x.replace('(', "").replace(')', "").split(',')[0])).min()
    y_min = df['startLocation'].apply(lambda x: float(x.replace('(', "").replace(')', "").split(',')[1])).min()
    x_min_ = df['endLocation'].apply(lambda x: float(x.replace('(', "").replace(')', "").split(',')[0])).min()
    y_min_ = df['endLocation'].apply(lambda x: float(x.replace('(', "").replace(')', "").split(',')[1])).min()
    xmin = min(x_min_, x_min)
    ymin = min(y_min, y_min_)
    for i in range(len(df)):
        seg_start_end[df.iloc[i]['edgeId']] = [
            float(df.iloc[i]['startLocation'].replace('(', "").replace(')', "").split(',')[0]) - xmin,
            float(df.iloc[i]['startLocation'].replace('(', "").replace(')', "").split(',')[1]) - ymin,
            float(df.iloc[i]['endLocation'].replace('(', "").replace(')', "").split(',')[0]) - xmin,
            float(df.iloc[i]['endLocation'].replace('(', "").replace(')', "").split(',')[1]) - ymin]
        print(seg_start_end[df.iloc[i]['edgeId']])"""

    return seg_start_end


def read_segMerged(segMerged_path, seg_start_end):
    seg_csv = pd.read_csv(segMerged_path)
    segment_list = []
    segment_dict = {}
    junction_next_seg = {}
    junction_pre_seg = {}
    for i in range(len(seg_csv)):

        start_junction = seg_csv.iloc[i]['start']
        end_junction = seg_csv.iloc[i]['end']
        if start_junction not in junction_next_seg.keys():
            junction_next_seg[start_junction] = []
        if start_junction not in junction_pre_seg.keys():
            junction_pre_seg[start_junction] = []
        if end_junction not in junction_next_seg.keys():
            junction_next_seg[end_junction] = []
        if end_junction not in junction_pre_seg.keys():
            junction_pre_seg[end_junction] = []
        seg_id = seg_csv.iloc[i]['edgeId']
        if seg_id not in segment_dict.keys():
            segment_dict[seg_id] = None

    for i in range(len(seg_csv)):
        print(i)
        seg_id = seg_csv.iloc[i]['edgeId']
        start_junction = seg_csv.iloc[i]['start']
        end_junction = seg_csv.iloc[i]['end']
        length = int(seg_csv.iloc[i]['length'])
        lane_number = int(seg_csv.iloc[i]['laneNumber'])

        edgesMerged = seg_csv.iloc[i]['edgesMerged'].replace("[", "").replace("]", "").replace("'", "").replace(" ",
                                                                                                                "").split(
            ',')
        if edgesMerged == ['None']:
            edgesMerged = [seg_id]
        if len(junction_next_seg[start_junction]) == 0:
            junction_next_seg[start_junction] = [seg_id]
        else:
            junction_next_seg[start_junction].append(seg_id)
        if len(junction_pre_seg[end_junction]) == 0:
            junction_pre_seg[end_junction] = [seg_id]
        else:
            junction_pre_seg[end_junction].append(seg_id)
        """minx = float('inf')
        miny = float('inf')
        maxx = float('-inf')
        maxy = float('-inf')
        for edge in edgesMerged:

            if seg_start_end[edge][0] > maxx:
                maxx = seg_start_end[edge][0]
            if seg_start_end[edge][2] > maxx:
                maxx = seg_start_end[edge][2]
            if seg_start_end[edge][0] < minx:
                minx = seg_start_end[edge][0]
            if seg_start_end[edge][2] < minx:
                minx = seg_start_end[edge][2]
            if seg_start_end[edge][1] > maxy:
                maxy = seg_start_end[edge][1]
            if seg_start_end[edge][3] > maxy:
                maxy = seg_start_end[edge][3]
            if seg_start_end[edge][1] < miny:
                miny = seg_start_end[edge][1]
            if seg_start_end[edge][3] < miny:
                miny = seg_start_end[edge][1]
        rect = [minx, miny, maxx, maxy]"""
        rect = seg_start_end[seg_id]

        seg = Segment(seg_id, start_junction, end_junction, length, lane_number, edgesMerged, rect)
        segment_list.append(seg)
        segment_dict[seg_id] = seg
    for i in range(len(segment_list)):
        segment_list[i].pre_segments = junction_pre_seg[segment_list[i].start_junction]
        segment_list[i].next_segments = junction_next_seg[segment_list[i].end_junction]
        segment_dict[segment_list[i].seg_id].next_segments = junction_next_seg[segment_list[i].end_junction]
        segment_dict[segment_list[i].seg_id].pre_segments = junction_pre_seg[segment_list[i].start_junction]
    return segment_list, segment_dict


if __name__ == '__main__':
    merged_segment_path = 'C:\\Users\lcy\Desktop\论文\路段车道修改后路网数据\\合并前后对照字典imulation_merge_name_dict.pkl'
    seg_path = 'C:\\Users\lcy\Desktop\论文\路段车道修改后路网数据\\原路段表edit_lanes_BeijingEdges.csv'
    segMerged_path = 'C:\\Users\lcy\Desktop\论文\路段车道修改后路网数据\\合并后路段表merge_edit_lanes_BeijingEdges.csv'
    seg_start_end_file = 'seg_start_end.pkl'
    road_index_file = "road_index.pkl"
    seg_id_mapping_file = "seg_id_mapping.pkl"
    traj_path = 'E:\dataset\lunwen\simulation3-2'

    seg_to_segMerged = load_segs_from_file(merged_segment_path)
    # seg_start_end = read_seg(seg_path, segMerged_path)

    # save_segs_to_file(seg_start_end, seg_start_end_file)
    seg_start_end = load_segs_from_file(seg_start_end_file)
    segment_list, segment_dict = read_segMerged(segMerged_path, seg_start_end)
    road_index, seg_id_mapping = create_road_index(segment_list)
    # print(road_index)
    # save_segs_to_file(road_index,road_index_file)
    # save_segs_to_file(seg_id_mapping,seg_id_mapping_file)
    # road_index=load_segs_from_file(road_index_file)
    # print(road_index.bounds)
    # seg_id_mapping=load_segs_from_file(seg_id_mapping_file)
    query = [21426.24, 13676.13, 21427.61, 13681.21]
    intersections = search_intersection(road_index, query, seg_id_mapping, segment_dict)
