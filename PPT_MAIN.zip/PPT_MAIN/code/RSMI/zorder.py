def rank_to_zorder(y, x1, order, start=0):   # 用y与x1的排序来确定z曲线的值，如P4(1,7)->(0,6)=40;order是Z曲线的阶
    if start == 1:
        y, x1 = y-1, x1-1   # 若从1开始则需要
    b_y = bin(y)[2:].zfill(order)    # 第一个维度，dimension1
    b_x1 = bin(x1)[2:].zfill(order)  # 第二个维度，dimension2
    b_res = ''
    for index in range(order):    # 先第二个维度，再第一个维度
        b_res += b_x1[index]
        b_res += b_y[index]
    res = int(b_res, base=2)
    return res
