import copy
import sys
import time
import tensorflow as tf
import pandas as pd
from collections import deque
import numpy as np
import math
from operator import attrgetter
import os
import struct
import zorder as zo
import pickle
import sys
import random

data_file_name = "geo"
# ep
ep = 0   # 第几批，一共7天，第一天为ep0
"""dim = 2  维度"""
N = 50000  # 学习模型精度
B = 227  # 块容量(数据最多有多少条)  现在设定为8kb，每一条数据占多少字节？8kb/一条数据的字节数=数据条数
block_id_length = 28  # 磁盘中每个块的前28个字节存储块id，29-32号字节存储一个int（记录块中数据量）
data_element = ['double', 'double']   # 块中数据项的个数与类型(仅用于展示说明），如当前每个数据项是两个double型，那么一个数据项占16字节，从而一整个块占 28+4+512*16=8224 字节
data_element_bytes = 36  # 一个数据项所占的字节数，当前为36，即4*double+1*int型
min_x = 0
min_y = 0
max_x = 100000   # 两个维度的最大值
max_y = 86400
split_part_val = 4  # 原论文中的值是4，代表最多分成ceil(N/B)个,这里若取16则是接着开根号得到的
part_num = int(math.pow(4, math.floor(math.log(N / B, split_part_val))))  # 部分数,递归划分，第一次把整个数据集划分成part_num个部分，随后对多于N的部分再一次划分，少于N的部分即为叶结点，直接预测块号
print("部分数：" + str(part_num))
nx = int(math.pow(2, math.floor(math.log(N / B, split_part_val))))  # x列数
print("行列数：" + str(nx))
ny = nx  # y列数
middle_order = math.floor(math.log(N / B, split_part_val))  # 仅为划分中间节点时采用的Z曲线阶数
print("阶数:" + str(middle_order))
epoch_middle = 100        # 中间节点的参数
epoch_leaf = 400   # 叶结点的参数
BLOCK_DIVIDE = 10   # 用于RSMI论文中的公式1，p.rank·n太大，改为p.rank·BLOCK_DIVIDE
# 全局块id，弃用，改为用block_list这个索引里面已经构建的块的顺序来确定id
# block_id = 0
this_ep = 0
model_parent_path = r'models/simulation/{}/'.format(this_ep)
buffer_model_path = r'models/simulation/{}/buffer/'.format(this_ep)
if not os.path.isdir(model_parent_path):
    os.makedirs(model_parent_path)
if not os.path.isdir(buffer_model_path):
    os.makedirs(buffer_model_path)


class Cache(object):
    def __init__(self):
        self._fifo_cache = deque()  # 存储块号，最多256个块

    def get_cache_len(self): return self._fifo_cache.__len__()

    def push(self, obj):
        self._fifo_cache.append(obj)

    def popleft(self):
        buf = self._fifo_cache.popleft()
        return buf


class IndexCache(Cache):
    def __init__(self): super().__init__()
    def is_duplicated(self, block_id): return block_id in self._fifo_cache


class Block(object):   # 存储在block_list中，链式结构
    def __init__(self, thisId='0', newInsert=False, passiveCreate=False):
        self._id = thisId       # 块号
        self._offset = -1000    # 在文件中的起始位置(起始点在第几个字节),-1000代表未被写入过磁盘
        self._data = deque()    # 块中数据的数量最大为B=277;每个元素是一个Point对象
        self._total_num = 0     # 这个块中一共被插入了多少数据
        self._is_newInsert = newInsert    # 是否为更新操作时新插入的块
        self._is_passiveCreate = passiveCreate    # 是否为原始数据在生成过程中插入时，原本所预测的块已满，因而新生成一个块并插入在原来的块之后
        self._loaded = False               # 此块中是否有从磁盘中读取的数据
        self._next = None

    def getID(self): return self._id

    def isLoaded(self): return self._loaded

    def isDumped(self):
        if self._offset == -1000:   # 没有被存入磁盘过
            return False
        else:
            return True

    def clearData(self):
        # 对已保存块数据的块，可以在内存中清除其数据块(self._data)，仅保留其他属性信息
        self._data.clear()
        self._loaded = False

    def update_to_disk(self, fp):
        """
        用于向磁盘中更新数据
        对self._loaded：如果内存中的此块，其中的数据是由读取的磁盘中的数据加上本次更新的数据，则为True；若未从磁盘中读取原有数据，self._data仅仅只存有本次新得到的数据，则为False
        :param fp: 文件句柄
        :param loaded:
        :return:
        """
        if self._loaded:
            fp.seek(self._offset, 0)      # 已经被装入过磁盘，则读取块在文件中的位置
            fp.seek(block_id_length, 1)   # 从块头的位置跳到存放块中数据量的起始位置
            data_len = fp.read(4)         # 注意指针已到数据项的开头处;这是磁盘中该块已保存的数据量
            data_len = struct.unpack('i', data_len)[0]
            update = self._data[data_len:]
            fp.seek(data_element_bytes*data_len, 1)
            for point in update:
                x, y, x1, x2, x3 = point.get_all_attr()
                x = struct.pack('i', x)  # int
                y = struct.pack('d', y)  # double
                x1 = struct.pack('d', x1)
                x2 = struct.pack('d', x2)
                x3 = struct.pack('d', x3)
                # 写入数据项
                write_data = [x, y, x1, x2, x3]
                for i in write_data:
                    fp.write(i)
            data_len = self._total_num
            data_len = struct.pack('i', data_len)
            fp.seek(self._offset+block_id_length, 0)    # 跳转到存放数据量的位置
            fp.write(data_len)                          # 更新数据量
        else:    # self._data仅仅只存有本次新得到的数据
            if not self.isDumped():   # 从没有写入磁盘过
                self.dump_to_disk(fp)
            else:
                fp.seek(self._offset+block_id_length, 0)  # 已经被装入过磁盘，跳到存放块中数据量的起始位置
                data_len = fp.read(4)  # 注意指针已到数据项的开头处;这是磁盘中该块已保存的数据量
                data_len = struct.unpack('i', data_len)[0]
                fp.seek(data_element_bytes * data_len, 1)    # 跳转到该块已存储的最后一个数据项的末尾位置
                for point in self._data:
                    x, y, x1, x2, x3 = point.get_all_attr()
                    x = struct.pack('i', x)  # int
                    y = struct.pack('d', y)  # double
                    x1 = struct.pack('d', x1)
                    x2 = struct.pack('d', x2)
                    x3 = struct.pack('d', x3)
                    # 写入数据项
                    write_data = [x, y, x1, x2, x3]
                    for i in write_data:
                        fp.write(i)
                data_len = self._total_num
                data_len = struct.pack('i', data_len)
                fp.seek(self._offset + block_id_length, 0)  # 跳转到存放数据量的位置
                fp.write(data_len)  # 更新数据量

    def dump_to_disk(self, fp):
        """
        用于第一次存储到磁盘的存储行为，若未从磁盘读取块，内存中（即self._data）只是接收了新数据，那么不应使用本函数存储到磁盘！
        :param fp: 文件句柄
        :param first_dump: 是否是该块第一次存入磁盘
        :return:
        """
        block_name = self._id
        block_name = block_name.encode('utf-8')
        while len(block_name) < block_id_length:
            block_name += b'\0'   # block的id不足28位，用 \0 补满
        block_data_len = len(self._data)
        if not self.isDumped():  # 此块从来没有被装入磁盘过，则从文件末尾开始存储
            fp.seek(0, 2)
            self._offset = fp.tell()    # 开始存储的位置到文件头的字节数
            block_data_len = struct.pack('i', block_data_len)
            fp.write(block_name)   # 写入块id
            fp.write(block_data_len)    # 写入块数据量
            data_occupy_len = B * data_element_bytes   # 数据项实际最多占用的空间。目前32位块头+227*36的最大容量=8204，即一个块实际占用8204字节，数据项最多占用8172字节
            for i in range(data_occupy_len):   # 先用 \0 填满本块数据项应占的空间(若需要)
                fp.write(b'\0')
            fp.seek(self._offset+block_id_length+4, 0)    # 跳到存放块中数据项的起始位置，4是块长数据的占用
            for point in self._data:
                x, y, x1, x2, x3 = point.get_all_attr()
                x = struct.pack('i', x)   # int
                y = struct.pack('d', y)   # double
                x1 = struct.pack('d', x1)
                x2 = struct.pack('d', x2)
                x3 = struct.pack('d', x3)
                # 写入数据项
                write_data = [x, y, x1, x2, x3]
                for i in write_data:
                    fp.write(i)

    def read_from_disk(self, fp):
        if self.isDumped() and not self._loaded:   # 没有被写入内存过，且已被写入磁盘过
            fp.seek(self._offset + block_id_length, 0)  # 已经被装入过磁盘，跳到存放块中数据量的起始位置
            data_len = fp.read(4)  # 注意指针已到数据项的开头处;这是磁盘中该块已保存的数据量
            data_len = struct.unpack('i', data_len)[0]
            if data_len != self._total_num:
                raise ValueError('数据项不一致')
            buffer = [None for x in range(data_len)]
            for i in range(data_len):
                disk_data = fp.read(data_element_bytes)
                int_data = disk_data[:4]
                double_data = disk_data[4:]
                x = struct.unpack('i', int_data)[0]  # 一个数据项有1*int+4*double###################################
                y, x1, x2, x3 = struct.unpack('dddd', double_data)
                new_point = Point(x, y, x1, x2, x3)
                buffer[i] = new_point
            self._data = buffer
            self._loaded = True

    def is_empty(self):
        if self._total_num == 0:
            print('块{}为空'.format(self._id))
            return True
        else:
            return False

    def getNext(self):
        return self._next

    def getData(self):
        # return copy.deepcopy(self._data)
        print('浅拷贝')
        return self._data

    def isNewInsert(self):return self._is_newInsert

    def getCreateStatus(self):return self._is_passiveCreate

    def insert(self, data):
        if self._total_num >= B:
            return -1
        self._total_num += 1
        self._data.append(data)

    def isFull(self):   # 在插入一条数据前，永远应该先判满
        if self._total_num != self._data.__len__():
            return "计数错误！"
        if self._total_num < B:
            return False
        elif self._total_num == B:
            return True
        else:
            return '块中数据量超出最大值'

    def findNoEmptySuccessor(self, newInsert=False):
        """
        从块头结点(或当前节点开始，向后寻找第一个非满的后继块)，若找不到，则新建一个
        :param newInsert: 是否为更新数据时新插入的块
        :return: 非满后继块
        """
        bef, cur = self, self._next
        c = 1   # 子块号,如第0组块链有2个子块(第一个为头结点)，则分别为 '0' 号、'0_1' 号块
        while cur is not None:
            c += 1
            if not cur.isFull():   # 若当前的后继块未满
                return cur
            else:
                bef, cur = cur, cur._next
        else:
            bef_id = bef.getID()
            if '_' not in bef_id:   # 处理子块的序号(头结点在创建时一定有id，且没有下划线，如 '0' 号块)
                this_id = '{}_{}'.format(bef_id, 1)
            else:
                id_list = bef_id.split('_')
                first, second = id_list[0], int(id_list[1]) + 1
                this_id = '{}_{}'.format(first, second)
            successor = Block(thisId=this_id, newInsert=newInsert, passiveCreate=True)
            bef._next = successor
            successor._next = cur
            return successor  # 返回指向新生成的block的指针


class BlockList(object):           # 即index,训练时全部读入内存，但查询时按照cache，缓冲区最多存放256个块
    def __init__(self):
        self._block_list = deque()
        self._cache = Cache()   # 存储块号
        self._saved_id = set()    # 判断是否已加入过索引（不一定是正在内存中）

    def self_init(self, list_path=''):    # 从已有的索引表中加载
        if os.path.isfile(list_path):
            with open(list_path, 'rb') as fp:
                self._block_list = pickle.load(fp)

    def get_list(self): return self._block_list

    def load_list(self, block_list_path):
        with open(block_list_path, 'rb+') as fp:
            self._block_list = pickle.load(fp)

    def add_block(self, block_obj: Block):
        block_id = block_obj.getID()
        if not self.judge_in(block_id):
            self._saved_id.add(block_id)
            self._block_list.append(block_obj)

    def judge_in(self, block_id):
        if block_id not in self._saved_id:
            return False
        else:
            return True

    def find_block(self, block_id):
        block_id = str(block_id)
        if '_' in block_id:
            group_id = block_id.split('_')[0]
        else:
            group_id = block_id
        group_id = int(group_id)
        cur = self._block_list[group_id]
        while cur:
            if cur.getID() == block_id:
                return cur
            cur = cur.getNext()

    def dump_blocks(self, file_fp, block_list_path='', cache_path=''):   # file_fp是存储数据块文件的文件句柄
        """
        将block_list中所有的数据块全部写入磁盘，并保存block_list等成员中的iterable类的信息(防止奇怪的bug)
        :param file_fp:存储数据块文件的文件句柄
        :param block_list_path:存储索引block_list
        :return:
        """
        for group in self._block_list:
            cur = group
            while cur:
                if not cur.isDumped():
                    cur.dump_to_disk(file_fp)
                else:
                    cur.update_to_disk(file_fp)
                cur.clearData()
                cur = cur.getNext()

    def load_all(self, fp):  # 将磁盘上已存储的所有数据全部读入内存
        for item in self._block_list:
            cur = item
            while cur:
                cur.read_from_disk(fp)
                cur = cur.getNext()

    def load_group(self, id_list, fp):
        """
        将磁盘上的该组的数据块全部挂载到块索引表上
        :param id_list: id_list: 磁盘块(组)的id(这也是叶子结点中模型预测出来的id)
        :param path: 保存数据块的文件的路径
        :return:
        """
        for num in id_list:  # 对每个id，将这一组的块全部读入内存
            cur_p = self._block_list[num]  # 指向头结点
            while cur_p:
                cur_p.read_from_disk(fp)
                cur_p = cur_p.getNext()


class BlockIndex(BlockList):
    def __init__(self, block_list):
        super().__init__()
        self._block_list = block_list
        self._cache = IndexCache()
        self._cache_max_len = 256
        self._io = 0
        self._io_history = []
        self.disk_fp = None

    def free_block(self, block_id):   # 从缓存中清除
        cur = self.find_block(block_id)
        cur.clearData()

    def add_to_cache(self, block_id, disk_fp):
        cur_cache_len = self._cache.get_cache_len()
        if cur_cache_len < self._cache_max_len:
            is_duplicated = self._cache.is_duplicated(block_id)
            if not is_duplicated:   # 不在内存中，则从磁盘读取
                cur = self.find_block(block_id)
                if not cur.isLoaded():
                    self._cache.push(block_id)
                    cur.read_from_disk(disk_fp)
                    self._io += 1

        else:
            block_to_pop = self._cache.popleft()   # 缓冲区已满，先把最久的那个移出队列
            self.free_block(block_to_pop)
            is_duplicated = self._cache.is_duplicated(block_id)
            if not is_duplicated:
                cur = self.find_block(block_id)
                if not cur.isLoaded():
                    self._cache.push(block_id)
                    cur.read_from_disk(disk_fp)
                    self._io += 1

    def io_count(self): return self._io

    def judge(self, target_list, index, dim1, dim2):
        tar_dim1 = target_list[index].get_dimension_x()
        tar_dim2 = target_list[index].get_dimension_y()
        if math.isclose(tar_dim1, dim1) and math.isclose(tar_dim2, dim2):
            return True
        else:
            return False

    def find_point_in_range_linger(self, block_id, low_dim, high_dim):   # 线性查找
        block_id = str(block_id)
        cur = self.find_block(block_id)
        block_res = 0
        while cur:
            cur_id = cur.getID()
            print('查找块{}'.format(cur_id))
            if cur.is_empty():
                return 0
            self.add_to_cache(cur_id, self.disk_fp)
            block_data = list(cur.getData())
            length = len(block_data)
            for i in range(length):
                this_dim1, this_dim2 = block_data[i].get_dimension_x(), block_data[i].get_dimension_y()
                if low_dim[0] < this_dim1 < high_dim[0] and low_dim[1] < this_dim2 < high_dim[1]:
                    block_res += 1
            cur = cur.getNext()
        return block_res

    def find_point_single(self, block_id, dim1=0.0, dim2=0.0, binary=False):
        block_id = str(block_id)
        cur = self.find_block(block_id)   # 找到头结点
        time1 = time.time()   # 应该减去的时间
        block_data = list(cur.getData())
        block_data.sort(key=attrgetter('y'))
        time2 = time.time()
        length = len(block_data)
        if binary:
            start, end = 0, length - 1
            mid = int((start + end)/2)
            while start <= end:
                if self.judge(block_data, mid, dim1, dim2):
                    return True, time2-time1
                else:
                    if block_data[mid].get_dimension_x() < dim1:
                        end = mid - 1
                        mid = int((start + end) / 2)
                    else:
                        start = mid + 1
                        mid = int((start + end) / 2)
            else:
                return False, time2-time1  # 应该减去的时间
        else:
            while cur:
                cur_id = cur.getID()
                self.add_to_cache(cur_id, self.disk_fp)
                block_data = list(cur.getData())
                length = len(block_data)
                for i in range(length):
                    if self.judge(block_data, i, dim1, dim2):
                        return True, time2 - time1
                cur = cur.getNext()
            else:
                return False, time2-time1  # 应该减去的时间

    def find_point(self, target_block_list, dim1, dim2, disk_fp):
        # dim1, dim2 = point_obj.get_dimension_x(), point_obj.get_dimension_y()
        reduces = []  # 应该减去的时间
        for block_id in target_block_list:
            self.add_to_cache(block_id, disk_fp)
            flag, reduce_time = self.find_point_single(block_id, dim1, dim2, binary=False)
            reduces.append(reduce_time)
            if flag:
                return True, reduces
        else:
            return False, reduces


class Scaler(object):
    def __init__(self, min_val, max_val):
        self._min = min_val
        self._max = max_val

    def min_max_scaler(self, val):
        if not math.isclose(self._max - self._min, 0):
            return (val - self._min) / (self._max - self._min)
        else:
            return 1

    def inverse_scaler(self, val):
        return val * (self._max - self._min) + self._min

    def set_min_max(self, val1, val2):
        self._min, self._max = val1, val2

    def get_min_max(self): return self._min, self._max


# 全局模型id
model_id = 0
block_list_class = BlockList()    # 整体的块索引表，self._block_list中每个元素是一个数据块链表（元素是Block类）；如果同一批数据已经生成过索引表文件和数据文件，那么运行程序之前一定要先初始化block_list_class中的self._block_list！(通过调用self_init函数)
node_num = 0
loss_sum = 0
max_error_upper = 0
max_error_lower = 0
all_point_sum = 0
read_time = 0


# x, y分别是pos, t
# 点对象
class Point:
    def __init__(self, x=0.0, y=0.0, x1=0, x2=0, x3=0):
        # 五个数据，按顺序排列
        self.x = x
        self.y = y
        self.x1 = x1
        self.x2 = x2
        self.x3 = x3
        self.rank_x = 0   # z曲线排序的第一个维度，目前对应self.y,既用于中间划分，也用于叶结点分块
        self.rank_y = 0   # z曲线排序的第2个维度，目前对应self.x1
        self.cv = 0.0
        self.predict_cv = 0.0
        self.blk = 0
        self.predict_blk = 0.0

    def __eq__(self, other):
        return self.x == other.x and self.y == other.y

    def __hash__(self):
        return hash(self.x) * hash(self.y)

    def getAttr(self):
        return [self.x, self.y]

    def set_rank_1(self, dim1=-100):   # 设定第一个维度的排序，注意对应
        self.rank_x = dim1

    def set_rank_2(self, dim2=-100):
        self.rank_y = dim2

    def get_ranks(self): return self.rank_x, self.rank_y

    def set_cv(self, cv): self.cv = cv   # 设置曲线值

    def get_cv(self): return self.cv

    def get_all_attr(self):
        return [self.x, self.y, self.x1, self.x2, self.x3]

    def set_all_attr(self, attr_list):
        self.x = int(attr_list[0])
        self.y = float(attr_list[1])
        self.x1 = float(attr_list[2])
        self.x2 = float(attr_list[3])
        self.x3 = float(attr_list[4])

    def get_dimension_x(self): return self.y   # 第一个维度：pos，对应第二个数据项，即y

    def get_dimension_y(self): return self.x1  # 第二个维度：t，对应第3个数据项，即x1


class Rang:
    def __init__(self,x_min,x_max,y_min,y_max):
        self.x_min = x_min
        self.x_max = x_max
        self.y_min = y_min
        self.y_max = y_max

# 树节点
class Node:
    # 初始化一个节点
    def __init__(self, model_id=-1, child_list=None):
        if child_list is not None:
            self.child_list = deque(child_list)   # 子节点列表
        else:
            self.child_list = deque()
        self.model_id = model_id   # 读取磁盘上的模型时根据此编号读取
        self._MBR = np.zeros(4, dtype=np.float64)   # 顺序为min_x, min_y, max_x, max_y
        self._model = None
        self.cord_scaler = Scaler(0, 0)
        self.blk_scaler = Scaler(0, 0)
        self._max_lower = -100   # 记录误差
        self._max_upper = -100

    # 添加子节点
    def add_child(self, node):
        self.child_list.append(node)

    def setMBR(self, MBRlist):   #  每个节点存储一个MBR
        for i in range(len(MBRlist)):
            self._MBR[i] = MBRlist[i]

    def set_loss(self, lower, upper):
        self._max_lower, self._max_upper = lower, upper

    def get_loss(self): return self._max_lower, self._max_upper

    def set_model(self, model_path):   # 有问题，弃用
        name = model_path + '/{}.h5'.format(self.model_id)
        model = tf.keras.Sequential(
            [tf.keras.layers.Dense(32, input_shape=(2,), activation='relu'), tf.keras.layers.Dense(1)])
        model.load_weights(name)
        self._model = model

    def get_model(self): return self._model

    def clear_model(self):
        del self._model
        self._model = None

    def dump_model(self, path):
        if self._model is not None:     # 有可能为空？####################################################################
            self._model.save(path)

    def getMBR(self):
        return [x for x in self._MBR]

    def get_child(self):return self.child_list

    def updateMBR(self, x, y):
        min_x, min_y, max_x, max_y = self._MBR
        min_x = min([min_x, x])
        max_x = max([max_x, x])
        min_y = min([min_y, y])
        max_y = max([max_y, y])
        self._MBR = np.array([min_x, min_y, max_x, max_y], dtype=np.float64)


def dump_tree(tree, path, model_path='', mount=False):
    """
    保存树结构;若mount为True，则树节点中保存了所有的模型，要全部保存
    :param tree:
    :param path:
    :param model_path:
    :param mount:是否保存模型
    :return:
    """
    with open(path, 'wb+') as fp:
        support = deque()
        support.append(tree)
        while support and mount:   # 层序遍历，保存所有的模型
            cur = support.popleft()
            name = model_path + '/{}.h5'.format(cur.model_id)
            cur.dump_model(name)
            cur.clear_model()
            children = cur.get_child()
            for child in children:
                support.append(child)
        pickle.dump(tree, fp)


def load_tree(path, model_path='', mount=False):    # 加载树结构，并挂载所有的模型；若单纯预测则应使用node类的set_model对特定节点的模型做挂载
    with open(path, 'rb') as fp:
        tree = pickle.load(fp)
        support = deque()
        support.append(tree)
        while support and mount:  # 层序遍历，加载所有的模型
            cur = support.popleft()
            if cur is None:   # 子节点可能为None
                continue
            if not cur.get_child():  # 子节点列表为空，则为叶结点
                model = tf.keras.Sequential([tf.keras.layers.Dense(128, input_shape=(2,), activation='relu'),
                                             tf.keras.layers.Dropout(0.5),
                                             tf.keras.layers.Dense(1)])
            else:
                model = tf.keras.Sequential([tf.keras.layers.Dense(128, input_shape=(2,), activation='sigmoid'),
                                             tf.keras.layers.Dropout(0.5),
                                             tf.keras.layers.Dense(1)])
            name = model_path + '/{}.h5'.format(cur.model_id)
            model.load_weights(name)
            # cur.set_model(model)
            cur._model = model
            children = cur.get_child()
            for child in children:
                support.append(child)
    return tree


def caculateMBR(point_array):
    data_x = sorted([item.get_dimension_x() for item in point_array])
    data_y = sorted([item.get_dimension_y() for item in point_array])
    min_x, max_x = data_x[0], data_x[-1]
    min_y, max_y = data_y[0], data_y[-1]
    return min_x, min_y, max_x, max_y


def cal_loss(arr):
    """
    计算模型的误差
    :param arr: 块
    :return: 点个数， 总损失， 大于误差， 小于误差
    """
    point_sum = 0
    loss_m = 0
    error_upper = 0
    error_lower = 0
    for i in range(len(arr)):
        loss = arr[i].predict_blk - arr[i].blk          # 计算损失
        loss_m += abs(loss)                   # 计算模型总损失
        if loss > 0:
            if loss > error_upper:
                error_upper = loss          # 计算最大大于误差
        if loss < 0:
            if abs(loss) > error_lower:
                error_lower = abs(loss)     # 计算最大小于误差
        point_sum += 1
    return point_sum, loss_m, error_upper, error_lower


def construct_RSMI(arr, model_path='', load=False):
    """
    构建递归模型树
    :param arr: 点数组
    :param load: 是否是从磁盘读取已有模型
    :param model_path: 保存树的节点模型
    :return: 构建好的模型树
    """
    global node_num
    print("数据量："+str(len(arr)))
    global model_id
    # 如果小于N，则到叶子节点，训练模型
    if len(arr) <= N:
        if len(arr) == 0:
            return None
        node = Node(model_id)
        node.setMBR(caculateMBR(arr))
        mbr = node.getMBR()
        data_scaler = node.cord_scaler
        blk_scaler = node.blk_scaler
        # 训练叶子模型并划分
        print("=========训练叶子模型：" + str(model_id)+"=========")
        model, max_lower, max_upper = train_leaf_model(arr, data_scaler, blk_scaler, mbr, load=load)
        node.set_loss(max_lower, max_upper)

        # 保存叶子模型
        name = model_path + '/{}.h5'.format(node.model_id)
        model.save(name)

        model_id += 1
        # 叶子节点构建完后返回上一层
        node_num += 1
        return node
    else:
        node = Node(model_id, [])
        node.setMBR(caculateMBR(arr))
        mbr = node.getMBR()
        data_scaler = node.cord_scaler
        blk_scaler = node.blk_scaler
        if not load:
            print("=========训练中间模型：" + str(model_id)+"=========")
            model, part_list = train_middle_model(arr, data_scaler, blk_scaler, mbr)
            # node.set_model(model)
            # 保存中间模型
            name = model_path + '/{}.h5'.format(node.model_id)
            model.save(name)
        else:   # 实际上现在没有作用了
            name = model_path + '/{}.h5'.format(node.model_id)
            model = tf.keras.Sequential([tf.keras.layers.Dense(32, input_shape=(2,), activation='relu'),tf.keras.layers.Dense(1)])
            # model.load_weights(model_path)
            model.load_weights(name)
            cords, _, part_list = partition(arr)
            pre_blk = model.predict(cords)
            # add_point_to_block(arr, pre_blk, part_list)

        model_id += 1
        # 对每一个块再次递归
        # 用来记录同一层模型的序号
        part_id = 0
        for part in part_list:
            print("第"+str(part_id)+"部分")
            part_id += 1
            print("数据量："+str(len(part)))
            if part:
                child_node = construct_RSMI(part, model_path=model_path, load=False)
            else:
                child_node = None
            node.add_child(child_node)
        node_num += 1
        return node


def find_pos(p, X, Y):
    """
    在grid_array中查找位置
    :param p: 点
    :param X: X刻度
    :param Y: Y刻度
    :return: grid_array中的坐标
    """
    pos = [0, 0]
    for i in range(nx):
        if p.get_dimension_x() <= X[i]:
            pos[0] = i - 1
            break
    for i in range(ny):
        if p.get_dimension_y() <= Y[i]:
            pos[1] = i - 1
            break
    return pos


def partition(arr):
    # 将arr按照数据分布分割为part个部分
    # 注意用于排序的维度是什么，这里暂用attrgetter直接按类属性的名字读取
    part_list = [[] for i in range(nx * ny)]  # nx*ny：中间节点要划分的区块数
    num = len(arr)
    arr.sort(key=attrgetter("y"))   # 第一个维度，排序后将排序的顺序写入rank_x
    split_div = int(num / nx) + 1    # 用于确定rank,+1 是为了让最后一个不整除，防止越界
    for i in range(len(arr)):
        this_rank = int(i / split_div)
        arr[i].set_rank_1(dim1=this_rank)
    arr.sort(key=attrgetter("x1"))    # 排序的两个值要核对
    split_div = int(num / ny) + 1  # 用于确定rank
    for i in range(len(arr)):
        this_rank = int(i / split_div)
        arr[i].set_rank_2(dim2=this_rank)

    # 给每个点分配此次划分的cv值
    for point in arr:
        rank1, rank2 = point.get_ranks()
        z_order_val = zo.rank_to_zorder(rank1, rank2, middle_order)
        point.set_cv(z_order_val)
    arr.sort(key=attrgetter("cv"))  # 排序的两个值要核对
    return part_list


def add_point_to_block(arr, pre_blk, part_list, blk_scaler):
    # 将点根据预测加入对应的块
    for i in range(len(arr)):
        # 将点加入预测的块,注意归一化
        predict_blk = int(round(pre_blk[i][0]))
        # predict_blk = blk_scaler.inverse_scaler(predict_blk)
        arr[i].predict_blk = predict_blk
        print(arr[i].predict_blk)
        if arr[i].predict_blk > part_num - 1:
            arr[i].predict_blk = part_num - 1
        if arr[i].predict_blk <= 0:
            arr[i].predict_blk = 0
        part_list[arr[i].predict_blk].append(arr[i])


def train_middle_model(arr, data_scaler, blk_scaler, mbr):
    """
    训练中间节点模型
    :param arr: 点数组
    :return: 模型，分类好的点数组
    """
    global ep
    global model_id
    # 将arr按照数据分布分割为part个部分
    # gird划分格子
    # cords, block, part_list = partition(arr)
    this_part_num = len(arr)
    min_cord1, min_cord2, max_cord1, max_cord2 = mbr
    min_cv, max_cv = 0, part_num - 1   # 分区的最小Z-curve值与最大值
    blk_scaler.set_min_max(min_cv, max_cv)
    part_list = partition(arr)   # 确定此次各点的z-order值，在Point.cv里;part_list用于存放预测后对应区块的点
    cords, block = [[] for i in range(this_part_num)], [0.0 for i in range(this_part_num)]
    for i in range(this_part_num):
        point = arr[i]
        dim1, dim2 = point.get_dimension_x(), point.get_dimension_y()
        # 归一化
        data_scaler.set_min_max(min_cord1, max_cord1)
        dim1 = data_scaler.min_max_scaler(dim1)
        data_scaler.set_min_max(min_cord2, max_cord2)
        dim2 = data_scaler.min_max_scaler(dim2)
        # 训练集是坐标,标签是curve值
        this_cord = [dim1, dim2]
        this_cv = point.get_cv()
        # this_cv = blk_scaler.min_max_scaler(this_cv)    # 分区的标签是否要归一化？归一化之后效果似乎不好
        cords[i].extend(this_cord)
        block[i] = this_cv
    model_best_path = buffer_model_path + '/' + str(model_id) + ".h5"  # 对训练时中间模型最好结果的缓存
    # 单隐层神经网络
    model = tf.keras.Sequential([tf.keras.layers.Dense(128, input_shape=(2,), activation='sigmoid'),
                                 tf.keras.layers.Dropout(0.5),
                                 tf.keras.layers.Dense(1)])
    # 训练数据
    model.compile(optimizer='SGD',
                  loss='mse')

    # checkpoint
    # 保存最好的模型
    checkpoint = tf.keras.callbacks.ModelCheckpoint(filepath=model_best_path, monitor='loss', verbose=1,
                                                    save_best_only=True, save_weights_only=True, mode='min')
    callback_list = [checkpoint]

    model.fit(cords, block, batch_size=10000, epochs=epoch_middle, callbacks=callback_list)
    # 预测块号
    pre_blk = model.predict(cords)
    # print(pre_blk)
    # 在此函数中反归一化
    add_point_to_block(arr, pre_blk, part_list, blk_scaler)
    return model, part_list
    

def train_leaf_model(arr, data_scaler, blk_scaler, mbr, load=False):
    """
    训练叶子节点的模型
    :param arr: 点数组
    :return: 模型
    """
    global model_id
    global ep
    global BLOCK_DIVIDE
    # 继续前面的块号
    global block_list_class
    global buffer_model_path
    block_list = block_list_class.get_list()
    block_id = len(block_list)   # 确保block_id连续线性增长
    # 计算此叶结点Z曲线的阶数，注意与middle_order不一样
    this_part_num = len(arr)

    leaf_order = math.ceil(math.log2(this_part_num))   # 确保2**order>=this_part_num
    if leaf_order == 0:   # 如果该部分只有1个
        leaf_order = 1
    # 点排序
    # 分别按x坐标和y坐标排序，计算rank_dim1和rank_dim2
    time1 = time.time()
    arr.sort(key=attrgetter("y"))     # 维度注意与类属性名注意对应
    for i in range(len(arr)):
        arr[i].set_rank_1(dim1=i)
    # for i in range(len(arr)):
    #     arr[i].rank_x = i + 1
    arr.sort(key=attrgetter("x1"))
    for i in range(len(arr)):
        arr[i].set_rank_2(dim2=i)
    time2 = time.time() - time1
    print('叶子结点区域1运行时间', time2)
    time3 = time.time()
    for i in range(this_part_num):
        rank1, rank2 = arr[i].get_ranks()
        z_order_val = zo.rank_to_zorder(rank1, rank2, leaf_order)
        arr[i].set_cv(z_order_val)
    time4 = time.time()-time3
    print('叶子结点区域2运行时间', time4)
    # 按照cv值排序,叶子只要cv值，不需要分块预测
    arr.sort(key=attrgetter("cv"))
    # 每B个点划入一个块，但原来的那种 ceil(rank*n/B) 生成的块太多了，改成生成2*n/B个块，每个块均分点来生成blk
    time5 = time.time()
    for i in range(this_part_num):   # 按Z-curve生成的排序
        this_rank = i   # 论文中的p.rank
        arr[i].blk = block_id + int(this_rank * BLOCK_DIVIDE / B)
    # 根据公式,那么min为block_id（之前索引中块的长度），max即为加上此处生成的块的个数
    min_blk = block_id
    max_blk = block_id + int(this_part_num * BLOCK_DIVIDE / B)
    time6 = time.time()-time5
    print('叶子结点区域3运行时间', time6)
    # begin = len(block_list)
    time7 = time.time()
    for i in range(min_blk, max_blk + 1):   # 构建实际的块
        this_id = str(i)
        if not block_list_class.judge_in(this_id):   # 是否已加入过索引
            new_block = Block(thisId=this_id, newInsert=False)
            block_list_class.add_block(new_block)
    time8 = time.time()-time7
    print('叶子结点区域4运行时间', time8)
    # 模型学习
    time9 = time.time()
    # 要归一化cord，blk
    cords, blk_list = [[] for i in range(this_part_num)], [0 for i in range(this_part_num)]
    min_cord1, min_cord2, max_cord1, max_cord2 = mbr  # 边界矩形
    blk_scaler.set_min_max(min_blk, max_blk)
    for i in range(this_part_num):
        dim1, dim2 = arr[i].get_dimension_x(), arr[i].get_dimension_y()
        # 归一化
        data_scaler.set_min_max(min_cord1, max_cord1)
        dim1 = data_scaler.min_max_scaler(dim1)
        data_scaler.set_min_max(min_cord2, max_cord2)
        dim2 = data_scaler.min_max_scaler(dim2)
        arr[i].blk = blk_scaler.min_max_scaler(arr[i].blk)

        cord = [dim1, dim2]
        cords[i].extend(cord)
        blk_list[i] = arr[i].blk
    time10 = time.time()-time9
    print('叶子结点区域5运行时间', time10)
    model_best_path = buffer_model_path + '/' + str(model_id) + ".h5"  # 对训练时最好结果的缓存
    # 神经网络
    model = tf.keras.Sequential()
    model.add(tf.keras.layers.Dense(128, input_shape=(2,), activation='relu'))
    model.add(tf.keras.layers.Dropout(0.5))
    model.add(tf.keras.layers.Dense(1))
    if not load:   # 不是从已有模型加载，而是新训练
        # 训练数据
        model.compile(optimizer='SGD', loss='mse')
        # checkpoint
        # 保存最好的模型
        checkpoint = tf.keras.callbacks.ModelCheckpoint(filepath=model_best_path, monitor='loss', verbose=1,save_best_only=True, save_weights_only=True, mode='min')
        callback_list = [checkpoint]
        model.fit(cords, blk_list, batch_size=10000, epochs=epoch_leaf, callbacks=callback_list)
    else:
        model.load_weights(buffer_model_path)

    # 预测块号
    pre_blk = model.predict(cords)
    max_lower, max_upper = [0], [0]   # 有可能为空
    for i in range(len(arr)):
        # 将点加入预测的块
        # 反归一化块id
        predict = pre_blk[i][0]
        if not np.isnan(predict):   # 数据量过少时，可能梯度爆炸
            predict_blk = blk_scaler.inverse_scaler(predict)  # 确保是已归一化的数值，则反归一化
            predict_blk = int(round(predict_blk))
        else:
            predict_blk = random.randint(min_blk, max_blk)  # 梯度爆炸，则随机选取
        arr[i].predict_blk = predict_blk

        # 记录误差
        raw_blk = int(round(blk_scaler.inverse_scaler(arr[i].blk)))
        if predict_blk < raw_blk:
            diff = raw_blk - predict_blk
            max_lower.append(diff)
        if predict_blk > raw_blk:
            diff = abs(raw_blk - predict_blk)
            max_upper.append(diff)

        print('原预测块id：', arr[i].predict_blk)
        if arr[i].predict_blk > max_blk:
            arr[i].predict_blk = max_blk   # 若大于最大的那个块id，则放入最后一个块
        if arr[i].predict_blk < min_blk:
            arr[i].predict_blk = min_blk
        print('修正后块id：', arr[i].predict_blk)

        # 数据放入块时要判断块容量是否已满
        blk_index = arr[i].predict_blk
        this_block = block_list[blk_index]
        if not this_block.isFull():
            this_block.insert(arr[i])
        else:
            successor_block = this_block.findNoEmptySuccessor(newInsert=False)
            successor_block.insert(arr[i])
    max_lower_val, max_upper_val = max(max_lower), max(max_upper)
    # 返回模型
    return model, max_lower_val, max_upper_val


def predict_scaler(cur, dim1, dim2):
    min_cord1, min_cord2, max_cord1, max_cord2 = cur.getMBR()  # 用于归一化
    # 归一化
    data_scaler = cur.cord_scaler
    data_scaler.set_min_max(min_cord1, max_cord1)
    dim1 = data_scaler.min_max_scaler(dim1)
    data_scaler.set_min_max(min_cord2, max_cord2)
    dim2 = data_scaler.min_max_scaler(dim2)
    cord_scaler = [[dim1, dim2]]
    return cord_scaler


def point_predict(dim1, dim2, root, model_path='', insert=False):
    """
    输入点在训练好的模型树中预测点的块号
    :param root: 模型树根节点
    :return: 块号
    """
    global ep
    this_x, this_y = dim1, dim2
    cord = [[float(this_x), float(this_y)]]
    cur = root

    cord_scaler = predict_scaler(cur, dim1, dim2)   # 用于归一化
    cord_scaler = tf.convert_to_tensor(cord_scaler)
    model = cur.get_model()

    num = model.predict(cord_scaler)
    num = int(round(num[0][0]))
    # 一直预测，一直到叶子模型
    while cur.child_list:   # child_list不为空，则为中间节点，否则是叶子结点
        if cur is None:    # 走到了null
            return -1, -1, None
        if num > len(cur.child_list) - 1:
            num = len(cur.child_list) - 1
        if num < 0:
            num = 0
        cur = cur.child_list[num]
        cord_scaler = predict_scaler(cur, dim1, dim2)
        cord_scaler = tf.convert_to_tensor(cord_scaler)
        # 节点的模型id

        model = cur.get_model()

        # 预测下一个模型
        num = model.predict(cord_scaler)
        num = int(round(num[0][0]))   # num是Z-curve值
    else:   # 到达叶结点
        cord_scaler = predict_scaler(cur, dim1, dim2)
        cord_scaler = tf.convert_to_tensor(cord_scaler)
        model = cur.get_model()
        max_lower, max_upper = cur.get_loss()
        min_blk, max_blk = cur.blk_scaler.get_min_max()   # 此节点控制的范围
        blk_id = model.predict(cord_scaler)
        blk_id = cur.blk_scaler.inverse_scaler(blk_id)   # 对block id反归一化
        blk_id = int(round(blk_id[0][0]))
        min_id, max_id = blk_id - max_lower, blk_id + max_upper
        if min_id < min_blk:
            min_id = min_blk
        if max_id > max_blk:
            max_id = max_blk
    return min_id, max_id, blk_id, [min_blk, max_blk]   # 返回的是一个范围(int值)加本身的预测值，再加上范围


def read_data(file_path):
    """
    读取数据集
    :param file_path: 文件路径
    :return: 点列表
    """
    dirs = os.listdir(file_path)
    for file_name in dirs:
        with open(file_path + "/" + file_name) as fp:
            count = 0
            for line in fp:
                l = line.rstrip()
                if l:
                    count += 1
            fp.seek(0)
            c = 0
            point_list = [Point() for i in range(count)]
            for line in fp:
                data = line.rstrip()
                if data:
                    print('第{}条数据'.format(c+1))
                    data = data.split(',')
                    point_list[c].set_all_attr(data)
                    c += 1
    print()
    return point_list


def cal_depth(root):
    if root is None:
        return 0
    max_depth = 0
    if root.child_list is not None:
        # print(root.child_list)
        for child in root.child_list:
            if child is None:
                depth = 0
            else:
                depth = cal_depth(child)
            if max_depth < depth:
                max_depth = depth
        return max_depth + 1
    else:
        return 1


def RSMI_Geo(index_path='', disk_path='', tree_path='tree/tree0.pkl', file_path='', block_list_path='',loadTree=False, loadAllDisk=False, this_ep=0):
    """
    :param index_path:
    :param disk_path:
    :param tree_path:
    :param loadTree: 是否加载先前的树(只用于预测),还是构建新的树
    :param loadAllDisk: 是否将磁盘上所有的块都一次性读入内存
    :return:
    """
    global loss_sum, max_error_upper, max_error_lower, all_point_sum, block_list_class, model_parent_path
    model_path = model_parent_path + r'/{}/'.format(this_ep)  # 第几批由this_ep控制
    if not os.path.isdir(model_path):
        os.makedirs(model_path)
    if os.path.isfile(index_path):
        with open(index_path, 'rb+') as fp:
            block_list_class = pickle.load(fp)

    point_list = read_data(file_path)
    point_list = list(point_list)
    max_num = len(point_list)  # 数据量
    print("数据量:" + str(max_num))
    # 构建递归模型
    print("=========开始构建模型树=========")
    if not loadTree:
        tree = construct_RSMI(point_list, model_path=model_path, load=False)
    else:
        tree = load_tree(tree_path)

    if os.path.isfile(disk_path):   # 磁盘数据块
        with open(disk_path, 'rb+') as fp:    # 已存在，则rb+
            block_list_class.dump_blocks(fp)
    else:
        with open(disk_path, 'wb+') as fp:
            block_list_class.dump_blocks(fp)
    if os.path.isfile(index_path):
        with open(index_path, 'rb+') as fp:
            pickle.dump(block_list_class, fp)
    else:
        with open(index_path, 'wb+') as fp:
            pickle.dump(block_list_class, fp)
    depth = cal_depth(tree)
    print("树的深度：" + str(depth))

    dump_tree(tree, tree_path, model_path=model_parent_path, mount=False)   # 模型已经在训练过程中保存


def search(block_index, tree_path, model_path, query_file_path, disk_fp, data_path='', raw_data_path='', pointQuery=True):
    query_data = []
    block_index.disk_fp = disk_fp
    with open(query_file_path, 'r+') as fp:
        for line in fp:
            data = line.rstrip()
            if data:
                query_data.append(data)
    if pointQuery:    # 点查询
        for i in range(len(query_data)):
            dim2, dim1 = query_data[i].split(',')  # 注意顺序
            attr_list = [0, dim1, dim2, 0.0, 0.0]
            p = Point()
            p.set_all_attr(attr_list)
            query_data[i] = p
        # 调用树与模型进行预测，获取可能得block_id范围
        root = load_tree(tree_path, model_path=model_path, mount=True)
        time_start = time.time()
        res_list = []
        time_reduce_list = []
        for point in query_data:
            dim1, dim2 = point.get_dimension_x(), point.get_dimension_y()
            # 确定block的id范围
            min_id, max_id, blk_id, _ = point_predict(dim1, dim2, root)   # 预测块所在的范围与预测值
            if blk_id is None:   # 走到了错误的节点，无法预测
                res_list.append(False)
                continue
            # 读取块，进行查找
            block_id_list = [x for x in range(min_id, max_id + 1) if x != blk_id]
            block_index.add_to_cache(blk_id, disk_fp)  # 不要忘记加进内存
            flag, time_reduce = block_index.find_point_single(blk_id, dim1, dim2, binary=False)
            if flag:
                res_list.append(True)
                time_reduce_list.append(time_reduce)
                continue
            else:
                time_reduce_list.append(time_reduce)
                flag, reduces = block_index.find_point(block_id_list, dim1, dim2, disk_fp)
                if flag:
                    res_list.append(True)
                    time_reduce_list.extend(reduces)
                else:
                    res_list.append(False)
                    time_reduce_list.extend(reduces)
        time_end = time.time()
        total_time = time_end - time_start - sum(time_reduce_list)
        total_io = block_index.io_count()
        recall_num = len([0 for x in res_list if x])
        print(total_time, total_io, recall_num)
        pass
    else:          # 范围查询
        raw_data = []
        if not os.path.isfile(raw_data_path):
            with open(data_path, 'r+') as fp:    # 读取原始数据，存入内存
                c = 1
                for line in fp:
                    data = line.rstrip()
                    if data:
                        print('第{}条数据'.format(c))
                        c += 1
                        d_list = data.split(',')
                        raw_data.append([d_list[1], d_list[2]])
            with open(raw_data_path, 'wb+') as fp:
                pickle.dump(raw_data, fp)
        else:
            with open(raw_data_path, 'rb+') as fp:
                raw_data = pickle.load(fp)
        for i in range(len(query_data)):
            low_dim2, low_dim1, high_dim2, high_dim1 = query_data[i].split(',')  # 注意顺序
            low = [float(low_dim1), float(low_dim2)]
            high = [float(high_dim1), float(high_dim2)]
            query_data[i] = [low, high]
        # 直接执行两次点查询，这会确定块的id范围，随后在块id范围内对block进行线性扫描
        root = load_tree(tree_path, model_path=model_path, mount=True)
        res_list = []
        total_time = 0
        for point_index, point_range_data in enumerate(query_data):
            low, high = point_range_data   # 对应左下角与右上角
            # 从原始数据中找，计数，看recall
            raw_num = 0
            for i, val in enumerate(raw_data):
                this_dim1, this_dim2 = float(val[0]), float(val[1])   # 注意对应，数据类型为float
                if low[0] < this_dim1 < high[0] and low[1] < this_dim2 < high[1]:
                    raw_num += 1
            # 两次点查询
            time1 = time.time()
            low_min, low_max, find_low, node_range_low = point_predict(low[0], low[1], root)  # find_low记录了左下角对应的块id
            high_min, high_max, find_high, node_range_high = point_predict(high[0], high[1], root)
            # 但是经过预测，这四个数的大小不一定是low_min<low_max<high_min<high_max
            this_query_range = sorted([low_min, low_max, high_min, high_max])

            time2 = time.time()
            this_time = time2 - time1
            total_time += this_time
            print('两次点查询的时间{}，第{}次查询'.format(this_time, point_index+1))
            if find_high is None or find_low is None:
                res_list.append([0, raw_num])
                continue
            # 确定范围，首先要看范围查询边界的两个点对应的预测块是否能找到
            time1 = time.time()
            flag_low, t_reduce_low = block_index.find_point_single(find_low, low[0], low[1], binary=False)
            flag_high, t_reduce_high = block_index.find_point_single(find_high, high[0], high[1], binary=False)
            if flag_low:
                low_min = find_low
            if flag_high:
                high_max = find_high
            if node_range_low[0] <= high_max <= node_range_low[1]:   # 两个点查询落在一个节点内
                # id_range = [[this_query_range[0], this_query_range[-1]]]  # high_max 可能小于 low_min
                id_range = [[low_min, high_max]]
            else:
                id_range = [[low_min, node_range_low[1]], [node_range_high[0], high_max]]   # 落在多个节点内
            time2 = time.time()
            this_time = time2 - time1 - t_reduce_high - t_reduce_low
            total_time += this_time
            # 线性扫描
            # 读取块，进行查找
            print('线性扫描第{}个查询'.format(point_index+1))
            print(id_range)
            time1 = time.time()
            count = 0
            block_id_list = []
            for item in id_range:
                block_id_list.extend([x for x in range(item[0], item[1]+1)])
            for blk_id in block_id_list:
                point_count = block_index.find_point_in_range_linger(blk_id, low, high)
                print('第{}个查询，范围：'.format(point_index + 1), id_range)
                count += point_count
            res_list.append([count, raw_num])    # 计算recall
            time2 = time.time()
            this_time = time2 - time1
            total_time += this_time
            print('线性查找的时间{}，第{}次查询'.format(this_time, point_index + 1))
        total_io = block_index.io_count()
        all_count = [x[0] for x in res_list]
        all_raw_num = [x[1] for x in res_list]
        num_count = sum(all_count)
        num_raw = sum(all_raw_num)
        recall = num_count / num_raw
        print('总时间：{}，总io：{}，recall：{}/{}={}'.format(total_time, total_io, num_count, num_raw, recall))


def main_rsmi():
    global this_ep
    index_p_path = 'index/simulation/{}/'.format(this_ep)
    index_path = index_p_path + '/index_{}.pkl'.format(this_ep)  # 注意全局模型id里的block_list_path的路径一定要准确！
    disk_p_path = 'disk/simulation/{}/'.format(this_ep)
    disk_file_path = disk_p_path + '/disk_{}'.format(this_ep)
    tree_path = index_p_path + 'tree_{}.pkl'.format(this_ep)
    if not os.path.isdir(index_p_path):
        os.makedirs(index_p_path)
    if not os.path.isdir(disk_p_path):
        os.makedirs(disk_p_path)

    # file_path = r'E:\实验数据\模拟数据\txt_simulation4-1_point_1\0/'
    file_path = r'E:\实验数据\模拟数据\txt_simulation4-1_point_1\combine/'
    # file_path = r'E:\实验数据\模拟数据\txt_simulation4-1_point_1\test/'
    # block_list_path = 'chengdu/index/block_list.pkl'
    # 每次调用函数跑1天的数据(1个ep)
    # RSMI_Geo(index_path, disk_file_path, tree_path=tree_path, file_path=file_path, block_list_path='', loadTree=False, this_ep=this_ep)

    model_path = model_parent_path + r'/{}/'.format(this_ep)  # 第几批由this_ep控制
    # query_file_path = r'E:\实验数据\模拟数据\查询数据\sim_data_query_point_20/0.txt'   # 点查询数据
    query_file_path = r'E:\实验数据\模拟数据\查询数据\sim_data_query_20_1/0.txt'  # 范围查询数据
    query_file_path_new = r'E:\实验数据\模拟数据\查询数据\最新\sim_range_query/0.txt'
    data_path = r'E:\实验数据\模拟数据\txt_simulation4-1_point_1\0/0.txt'
    raw_data_path = 'raw_data/0/0.pkl'
    with open(index_path, 'rb+') as fp:
        bl = pickle.load(fp)
        block_list = bl.get_list()
        block_index = BlockIndex(block_list)
        with open(disk_file_path, 'rb+') as disk_fp:
            # search(block_index, tree_path, model_path, query_file_path, disk_fp, pointQuery=True)
            search(block_index, tree_path, model_path, query_file_path, disk_fp, data_path=data_path, raw_data_path=raw_data_path, pointQuery=False)
        pass


if __name__ == "__main__":
    main_rsmi()
