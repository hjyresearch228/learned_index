import struct
import math
import os
import random
import sqlite3
import datetime
import sys
import pickle
from datetime import datetime, timedelta

TOTAL = 0
DATA_PER_ITEM = 44

INDEXBLOCKSIZE = 8 * 1024  # 索引块大小
MAX_BLOCKS = 256  # 缓存大小
DATABLOCKSIZE = 8 * 1024  # 数据块大小
DATAFILE = 'data1.dat'  # 数据文件
INDEXFILE = 'index1.idx'  # 索引文件
"""
如果系统发生中断，缓存中的数据怎么办
在程序启动时和程序执行过程中的固定时间间隔内定期保存缓存内容到磁盘。例如，可以设置一个定时任务或使用定时器，在一定时间间隔内调用 write_cache_to_disk 方法，将缓存内容写入磁盘。
在程序异常终止或系统检测到故障时，通过捕获异常或使用信号处理机制，在异常处理代码中调用 write_cache_to_disk 方法，以尽可能多地保存已更改的缓存内容。
"""


class Block:
    """
    索引块和数据块
    """

    def __init__(self, block_id):
        self.block_id = block_id
        self.mbr = None


class DataBlock:

    def __init__(self, block_id):
        self.block_id = block_id
        self.items = []

    def add_child_block(self, data):
        self.items.append(data)

    def is_full(self):
        """
        判断当前节点块是否已经满（数据大小超过规定的每个索引块的大小）
        :return:
        """
        return (len(self.items)) * 36 + 8 > DATABLOCKSIZE

    def pack(self):
        """
        压缩叶子节点块
        :return:
        """

        packed_items = struct.pack('II', self.block_id, len(self.items)
                                   )
        for data in self.items:
            packed_items += struct.pack('4dI', float(data[0]), float(data[1]), float(data[2]), float(data[3]),
                                        int(data[4]))
        return packed_items

    @staticmethod
    def unpack(cls, data):
        """
        解压缩叶子节点块
        :param cls:
        :param data:
        :return:
        """
        unpacked_values = struct.unpack('II', data[:8])

        block_id = unpacked_values[0]
        num_items = unpacked_values[1]

        block = cls(block_id)

        offset = 8
        for i in range(num_items - 1):
            data_ = list(struct.unpack('4dI', data[offset:offset + 36]))
            pos = data_[0]
            t = data_[1]
            lon = data_[2]
            lat = data_[3]
            mo = data_[4]

            block.items.append([pos, t, lon, lat, mo])
            offset += 36
        return block


class LeafBlock(Block):
    """
    叶子节点
    """

    def __init__(self, block_id):
        super(LeafBlock, self).__init__(block_id)
        self.mbr = [float('inf'), float('inf'), float('-inf'), float('-inf')]
        self.child_blocks = []

        self.is_leaf = 1  # 叶子节点
        self.parent_id = 0

    def add_child_block(self, mbr, record_id):
        """
        叶子节点添加记录，记录形式为[最小包围矩形，记录id]
        :param mbr:
        :param record_id:
        :return:
        """
        self.child_blocks.append([mbr, record_id])
        # self.child_blocks.append([mbr, record_id])
        self.mbr = update_mbr(self.mbr, mbr)

    def get_mbr(self):
        """
        获取该节点包含所有数据的最小包围矩形的最小包围矩形
        :return:
        """
        xmin, ymin, xmax, ymax = float('inf'), float('inf'), float('-inf'), float('-inf')
        for data_item in self.child_blocks:
            if data_item[0][0] < data_item[0][2]:
                xmin = min(xmin, data_item[0][0])
                xmax = max(xmax, data_item[0][2])
            else:
                xmin = min(xmin, data_item[0][2])
                xmax = max(xmax, data_item[0][0])
            if data_item[0][1] < data_item[0][3]:
                ymin = min(ymin, data_item[0][1])
                ymax = max(ymax, data_item[0][3])
            else:
                ymin = min(ymin, data_item[0][3])
                ymax = max(ymax, data_item[0][1])

        return [xmin, ymin, xmax, ymax]

    def delete(self, block_id):
        for block in self.child_blocks:
            if block[1] == block_id:
                self.child_blocks.remove(block)

    def is_full(self):
        """
        判断当前节点块是否已经满（数据大小超过规定的每个索引块的大小）
        :return:
        """
        return (len(self.child_blocks)) * 36 + 48 > INDEXBLOCKSIZE

    def pack(self):
        """
        压缩叶子节点块
        :return:
        """
        mbr_ = [self.mbr[0], self.mbr[1], self.mbr[2], self.mbr[3]]
        packed_items = struct.pack('4dIIII', *mbr_, self.block_id, len(self.child_blocks), self.parent_id,
                                   self.is_leaf)

        for mbr, record_id in self.child_blocks:
            mbr1 = [mbr[0], mbr[1], mbr[2], mbr[3]]
            packed_items += struct.pack('4dI', *mbr1, record_id)
        return packed_items

    @staticmethod
    def unpack(cls, data):
        """
        解压缩叶子节点块
        :param cls:
        :param data:
        :return:
        """
        unpacked_values = struct.unpack('4dIIII', data[:48])
        mbr = list(unpacked_values[:4])
        block_id = unpacked_values[4]
        num_items = unpacked_values[5]
        tag = unpacked_values[7]
        parent_id = unpacked_values[6]
        block = cls(block_id)
        mbr_ = [mbr[0], mbr[1], mbr[2], mbr[3]]
        block.mbr = mbr_
        block.is_leaf = tag
        block.parent_id = parent_id

        offset = 48
        for i in range(num_items):
            mbr = list(struct.unpack('4d', data[offset:offset + 32]))
            mbr1 = [mbr[0], mbr[1], mbr[2], mbr[3]]
            record_id = struct.unpack('I', data[offset + 32:offset + 36])[0]

            block.child_blocks.append([mbr1, record_id])
            offset += 36
        return block


class InternalBLock(Block):
    """
    索引内部节点块
    """

    def __init__(self, block_id):
        super(InternalBLock, self).__init__(block_id)
        self.mbr = [float('inf'), float('inf'), float('-inf'), float('-inf')]
        self.child_blocks = []
        self.is_leaf = 0
        self.parent_id = 0

    def add_child_block(self, mbr, block_id):
        """
        添加一个新的内部节点块
        :param mbr:
        :param block_id:
        :return:
        """

        self.child_blocks.append([mbr, block_id])
        self.mbr = update_mbr(self.mbr, mbr)

    def delete(self, block_id):
        for block in self.child_blocks:
            if block[1] == block_id:
                self.child_blocks.remove(block)

    def get_mbr(self):
        """
        获取该节点包含所有节点块的最小包围矩形的最小包围矩形
        :return:
        """
        xmin, ymin, xmax, ymax = float('inf'), float('inf'), float('-inf'), float('-inf')

        for child_block in self.child_blocks:

            if child_block[0][0] < child_block[0][2]:
                xmin = min(xmin, child_block[0][0])
                xmax = max(xmax, child_block[0][2])
            else:
                xmin = min(xmin, child_block[0][2])
                xmax = max(xmax, child_block[0][0])
            if child_block[0][1] < child_block[0][3]:
                ymin = min(ymin, child_block[0][1])
                ymax = max(ymax, child_block[0][3])
            else:
                ymin = min(ymin, child_block[0][3])
                ymax = max(ymax, child_block[0][1])
        return [xmin, ymin, xmax, ymax]

    def is_full(self):
        """
        判断当前节点块是否已经满（数据大小超过规定的每个索引块的大小）
        :return:
        """
        return (len(self.child_blocks)) * 36 + 48 > INDEXBLOCKSIZE

    def pack(self):
        """
        压缩节点块
        :return:
        """
        mbr_ = [self.mbr[0], self.mbr[1], self.mbr[2], self.mbr[3]]
        packed_items = struct.pack('4dIIII', *mbr_, self.block_id, len(self.child_blocks), self.parent_id,
                                   self.is_leaf)
        for mbr, block_id in self.child_blocks:
            mbr1 = [float(mbr[0]), float(mbr[1]), float(mbr[2]), float(mbr[3])]
            packed_items += struct.pack('4dI', *mbr1, block_id)
        return packed_items

    @staticmethod
    def unpack(cls, data):
        """
        解压缩节点块
        :param cls:
        :param data:
        :return:
        """
        unpacked_values = struct.unpack('4dIIII', data[:48])
        mbr = list(unpacked_values[:4])
        block_id = unpacked_values[4]
        num_items = unpacked_values[5]
        tag = unpacked_values[7]
        parent_id = unpacked_values[6]

        block = cls(block_id)
        mbr_ = [mbr[0], mbr[1], mbr[2], mbr[3]]
        block.mbr = mbr_
        block.is_leaf = tag
        block.parent_id = parent_id
        offset = 48
        for i in range(num_items - 1):
            mbr = list(struct.unpack('4d', data[offset:offset + 32]))
            mbr1 = [mbr[0], mbr[1], mbr[2], mbr[3]]
            block_id = struct.unpack('I', data[offset + 32:offset + 36])[0]
            # block.add_child_block(mbr1, block_id)
            block.child_blocks.append([mbr1, block_id])
            offset += 36
        return block


class BlockStack:
    """
    用于自下向上查询的时候所需的栈
    """

    def __init__(self):
        self.stack_ = []

    def push(self, block):
        self.stack_.append(block)

    def pop(self):
        if self.stack_:
            return self.stack_.pop()
        return None


class Header:
    """
    索引的头节点块，用与存储初始存储位置，整个索引文件的最小包围矩形，根节点指针，块大小，最后结束的块号
    """

    def __init__(self, begin_offset, GMBR, GPTR, BLOCKSIZE, END_BLOCK_NUMBER, data_block_end_number):
        self.begin_offset = begin_offset
        self.GMBR = GMBR if GMBR is not None else self.calculate_empty_gmbr()
        self.GPTR = GPTR if GPTR is not None else 0
        self.BLOCKSIZE = BLOCKSIZE
        self.END_BLOCK_NUMBER = END_BLOCK_NUMBER
        self.data_block_end_number = data_block_end_number

    def calculate_empty_gmbr(self):
        # 返回一个表示空的最小包围矩形的字典
        empty_gmbr = [float('inf'), float('inf'), float('-inf'), float('-inf')]
        return empty_gmbr

    def pack(self):
        return struct.pack('IIII4dI', self.begin_offset, self.GPTR, self.BLOCKSIZE, self.END_BLOCK_NUMBER, *self.GMBR,
                           self.data_block_end_number)

    @staticmethod
    def unpack(cls, data):
        begin_offset, GPTR, BLOCKSIZE, END_BLOCK_NUMBER, GMBR0, GMBR1, GMBR2, GMBR3, data_block_end_number = struct.unpack(
            'IIII4dI', data[:52])
        return cls(begin_offset, [GMBR0, GMBR1, GMBR2, GMBR3], GPTR, BLOCKSIZE, END_BLOCK_NUMBER, data_block_end_number)

    def write_block_to_file(self, file_path):
        """
        将头节点写入索引文件
        :param file_path:
        :return:
        """
        with open(file_path, 'rb+') as file:
            file.seek(0)
            file.write(self.pack())


class MemoryManager:
    """
    内存管理类，相当于一个缓存。
    在创建的索引的时候，新建或者更新块后是先写入缓存中，不是立即写入磁盘，减少IO数
    在查询数据时，会设置缓存，首先先从缓存读取数据，如果没有该块，则再从磁盘中读取，也减少了访存时间
    """

    def __init__(self, max_blocks):
        self.max_blocks = max_blocks
        self.blocks = []
        self.block_ids = []

    def is_full(self):
        return len(self.blocks) >= self.max_blocks

    def add_block(self, block, file_path):

        """
        当有新块加入，则添加到缓存中，如果缓存已满，则替换缓存中的块
        :param block:
        :param file_path:
        :return:
        """

        if block.block_id not in self.block_ids:
            self.blocks.append(block)
            self.block_ids.append(block.block_id)

            if self.is_full():
                block_to_replace = self.replace_block()

                self.write_block_to_file(file_path, block_to_replace)
        else:
            self.delete(block)
            self.blocks.append(block)
            self.block_ids.append(block.block_id)

    def delete(self, block):
        blocks = []
        for i in range(len(self.blocks)):
            if self.blocks[i].block_id != block.block_id:
                blocks.append(self.blocks[i])
        self.blocks = blocks

        self.block_ids.remove(block.block_id)

    def replace_block(self):
        """
        当缓存满了，寻找一个合适的块替换，这里采用的是先进先出策略
        :return:
        """
        block_id_to_replace = self.block_ids.pop(0)
        block_to_replace = self.get_block(block_id_to_replace)
        self.blocks.pop(0)

        return block_to_replace

    def get_block(self, block_id):
        for block in self.blocks:
            if block.block_id == block_id:
                return block
        return None

    def write_block_to_file(self, file_path, block):
        """
        将相应块写入磁盘
        :param file_path:
        :param block:
        :return:
        """
        with open(file_path, 'rb+') as file:
            file.seek(block.block_id * INDEXBLOCKSIZE)
            data_block = block.pack()
            file.write(data_block)

    def load_block_from_file(self, file_path, block_id):
        """
        从磁盘上获取相应块的数据
        :param file_path:
        :param block_id:
        :return:
        """
        with open(file_path, 'rb') as file:
            file.seek(block_id * INDEXBLOCKSIZE)
            block_data = file.read(INDEXBLOCKSIZE)

            block_type = struct.unpack('I', block_data[44:48])[0]

            if block_type == 1:
                block = LeafBlock.unpack(LeafBlock, block_data)
            if block_type == 0:
                block = InternalBLock.unpack(InternalBLock, block_data)

            return block


class MemoryManager_query:
    """
    内存管理类，相当于一个缓存。
    在创建的索引的时候，新建或者更新块后是先写入缓存中，不是立即写入磁盘，减少IO数
    在查询数据时，会设置缓存，首先先从缓存读取数据，如果没有该块，则再从磁盘中读取，也减少了访存时间
    """

    def __init__(self, max_blocks):
        self.max_blocks = max_blocks
        self.blocks = []
        self.block_ids = []

    def is_full(self):
        return len(self.blocks) >= self.max_blocks

    def add_block(self, block):

        if block.block_id not in self.block_ids:
            self.blocks.append(block)
            self.block_ids.append(block.block_id)

            if self.is_full():
                self.replace_block()


        else:
            self.delete(block)
            self.blocks.append(block)
            self.block_ids.append(block.block_id)

    def delete(self, block):
        blocks = []
        for i in range(len(self.blocks)):
            if self.blocks[i].block_id != block.block_id:
                blocks.append(self.blocks[i])
        self.blocks = blocks

        self.block_ids.remove(block.block_id)

    def replace_block(self):
        """
        当缓存满了，寻找一个合适的块替换，这里采用的是先进先出策略
        :return:
        """
        block_id_to_replace = self.block_ids.pop(0)

        self.blocks.pop(0)

    def get_block(self, block_id):
        for block in self.blocks:
            if block.block_id == block_id:
                return block
        return None

    def load_block_from_file(self, file_path, block_id):
        """
        从磁盘上获取相应块的数据
        :param file_path:
        :param block_id:
        :return:
        """
        with open(file_path, 'rb') as file:
            file.seek(block_id * INDEXBLOCKSIZE)
            block_data = file.read(INDEXBLOCKSIZE)

            block_type = struct.unpack('I', block_data[44:48])[0]

            if block_type == 1:
                block = LeafBlock.unpack(LeafBlock, block_data)
            if block_type == 0:
                block = InternalBLock.unpack(InternalBLock, block_data)

            return block


class DataBuffer:
    """
    内存管理类，相当于一个缓存。
    在创建的索引的时候，新建或者更新块后是先写入缓存中，不是立即写入磁盘，减少IO数
    在查询数据时，会设置缓存，首先先从缓存读取数据，如果没有该块，则再从磁盘中读取，也减少了访存时间
    """

    def __init__(self, max_blocks):
        self.max_blocks = max_blocks
        self.blocks = []

    def is_full(self):
        return len(self.blocks) >= self.max_blocks

    def add_block(self, block, file_path):

        for block_ in self.blocks:
            if block_.block_id == block.block_id:
                # self.delete(block_)
                self.blocks.remove(block_)

        self.blocks.append(block)

        if self.is_full():
            block_to_replace = self.replace_block()

            self.write_block_to_file(file_path, block_to_replace)

    """def delete(self, block):
        blocks = []
        for i in range(len(self.blocks)):
            if self.blocks[i].block_id != block.block_id:
                blocks.append(self.blocks[i])
        self.blocks = blocks"""

    def replace_block(self):
        """
        当缓存满了，寻找一个合适的块替换，这里采用的是先进先出策略
        :return:
        """

        block_to_replace = self.blocks.pop(0)

        return block_to_replace

    def get_block(self, block_id):
        for block in self.blocks:
            if block.block_id == block_id:
                return block
        return None

    def write_block_to_file(self, file_path, block):
        with open(file_path, 'rb+') as file:
            file.seek(block.block_id * DATABLOCKSIZE)
            data_block = block.pack()

            file.write(data_block)

    def load_block_from_file(self, file_path, block_id):
        with open(file_path, 'rb') as file:
            file.seek(block_id * DATABLOCKSIZE)
            block_data = file.read(DATABLOCKSIZE)
            block = DataBlock.unpack(DataBlock, block_data)

            return block


class DataBuffer_query:
    """
    内存管理类，相当于一个缓存。
    在创建的索引的时候，新建或者更新块后是先写入缓存中，不是立即写入磁盘，减少IO数
    在查询数据时，会设置缓存，首先先从缓存读取数据，如果没有该块，则再从磁盘中读取，也减少了访存时间
    """

    def __init__(self, max_blocks):
        self.max_blocks = max_blocks
        self.blocks = []

    def is_full(self):
        return len(self.blocks) >= self.max_blocks

    def add_block(self, block):

        """
        当有新块加入，则添加到缓存中，如果缓存已满，则替换缓存中的块
        :param block:
        :param file_path:
        :return:
        """

        self.blocks.append(block)

        if self.is_full():
            self.replace_block()

    def replace_block(self):

        self.blocks.pop(0)

    def get_block(self, block_id):
        for block in self.blocks:
            if block.block_id == block_id:
                return block
        return None

    def load_block_from_file(self, file_path, block_id):
        with open(file_path, 'rb') as file:
            file.seek(block_id * DATABLOCKSIZE)
            block_data = file.read(DATABLOCKSIZE)

            block = DataBlock.unpack(DataBlock, block_data)

            return block


def get_mbr(child_blocks):
    xmin, ymin, xmax, ymax = float('inf'), float('inf'), float('-inf'), float('-inf')

    for i in range(len(child_blocks)):

        if child_blocks[i][0][0] < child_blocks[i][0][2]:
            xmin = min(xmin, child_blocks[i][0][0])
            xmax = max(xmax, child_blocks[i][0][2])
        else:
            xmin = min(xmin, child_blocks[i][0][2])
            xmax = max(xmax, child_blocks[i][0][0])
        if child_blocks[i][0][1] < child_blocks[i][0][3]:
            ymin = min(ymin, child_blocks[i][0][1])
            ymax = max(ymax, child_blocks[i][0][3])
        else:
            ymin = min(ymin, child_blocks[i][0][3])
            ymax = max(ymax, child_blocks[i][0][1])
    return [xmin, ymin, xmax, ymax]


def get_data_mbr(data_items):
    xmin, ymin, xmax, ymax = float('inf'), float('inf'), float('-inf'), float('-inf')
    for i in range(len(data_items)):
        xmin = min(xmin, data_items[i][0])
        xmax = max(xmax, data_items[i][0])
        ymin = min(ymin, data_items[i][1])
        ymax = max(ymax, data_items[i][1])
    return [xmin, ymin, xmax, ymax]


def get_mbr_(range_):
    if range_[0] <= range_[2] and range_[1] <= range_[3]:
        return range_
    if range_[0] > range_[2] and range_[1] <= range_[3]:
        return [range_[2], range_[1], range_[0], range_[3]]
    if range_[0] <= range_[2] and range_[1] > range_[3]:
        return [range_[0], range_[3], range_[2], range_[1]]
    if range_[0] > range_[2] and range_[1] > range_[3]:
        return [range_[2], range_[3], range_[0], range_[1]]


def overlap_area_three(mbr1, mbr2, mbr3):
    """
    计算三个矩形的重叠面积
    :param mbr1:
    :param mbr2:
    :param mbr3:
    :return:
    """
    if mbr1[0] > mbr2[2] or mbr1[2] < mbr2[0] or mbr1[1] > mbr2[3] or mbr1[3] < mbr2[1] or mbr1[0] > mbr3[2] or mbr1[
        2] < mbr3[0] or mbr1[1] > mbr3[3] or mbr1[3] < mbr3[1] or mbr2[0] > mbr3[2] or mbr2[2] < mbr3[0] or mbr2[1] > \
            mbr3[3] or mbr2[3] < mbr3[1]:
        return 0
    x1 = max(mbr1[0], mbr2[0], mbr3[0])
    y1 = max(mbr1[1], mbr2[1], mbr3[1])
    x2 = min(mbr1[2], mbr2[2], mbr3[2])
    y2 = min(mbr1[3], mbr2[3], mbr3[3])

    width = x2 - x1
    height = y2 - y1
    return width * height


def overlap_area(mbr1, mbr2):
    """
    计算mbr1和mbr2的重叠面积
    :param mbr1:
    :param mbr2:
    :return:
    """
    if mbr1[0] > mbr2[2] or mbr1[2] < mbr2[0] or mbr1[1] > mbr2[3] or mbr1[3] < mbr2[1]:
        return 0
    x1 = max(mbr1[0], mbr2[0])
    y1 = max(mbr1[1], mbr2[1])
    x2 = min(mbr1[2], mbr2[2])
    y2 = min(mbr1[3], mbr2[3])

    width = x2 - x1
    height = y2 - y1
    return width * height


def calculate_distance(mbr1, mbr2):
    """
    计算两个最下包围矩形的矩形
    :param mbr1:
    :param mbr2:
    :return:
    """
    x1 = (mbr1[0] + mbr1[2]) / 2
    y1 = (mbr1[1] + mbr1[3]) / 2
    x2 = (mbr2[0] + mbr2[2]) / 2
    y2 = (mbr2[1] + mbr2[3]) / 2
    return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)


def update_mbr_point(mbr1, point):
    if mbr1[2] >= point[0] >= mbr1[0] and mbr1[3] >= point[1] >= mbr1[1]:
        return mbr1
    xmin = min(point[0], mbr1[0])
    ymin = min(point[1], mbr1[1])
    xmax = max(point[0], mbr1[2])
    ymax = max(point[1], mbr1[3])
    return [xmin, ymin, xmax, ymax]


def update_mbr(mbr1, mbr2):
    """
    给定两个最小包围矩形，获取这两个矩形最小包围矩形
    :param mbr1:
    :param mbr2:
    :return:
    """
    if mbr1[0] == float('inf') and mbr1[1] == float('inf') and mbr1[2] == float('-inf') and mbr1[
        3] == float('-inf'):
        return mbr2
    if mbr1[0] < mbr1[2]:
        if mbr2[0] < mbr2[2]:
            xmin = min(mbr1[0], mbr2[0])
            xmax = max(mbr1[2], mbr2[2])
        else:
            xmin = min(mbr1[0], mbr2[2])
            xmax = max(mbr1[2], mbr2[0])
    else:
        if mbr2[0] < mbr2[2]:
            xmin = min(mbr1[2], mbr2[0])
            xmax = max(mbr1[0], mbr2[2])
        else:
            xmin = min(mbr1[2], mbr2[2])
            xmax = max(mbr1[0], mbr2[0])
    if mbr1[1] < mbr1[3]:
        if mbr2[1] < mbr2[3]:
            ymin = min(mbr1[1], mbr2[1])
            ymax = max(mbr1[3], mbr2[3])
        else:
            ymin = min(mbr1[1], mbr2[3])
            ymax = max(mbr1[3], mbr2[1])
    else:
        if mbr2[1] < mbr2[3]:
            ymin = min(mbr1[3], mbr2[1])
            ymax = max(mbr1[1], mbr2[3])
        else:
            ymin = min(mbr1[3], mbr2[3])
            ymax = max(mbr1[1], mbr2[1])

    return [xmin, ymin, xmax, ymax]


def _has(mbr, query):
    """
    判断查询的最小包围矩形是否包围mbr
    :param mbr:
    :param query:
    :return:
    """
    mbr[0] = round(mbr[0], 2)
    mbr[1] = round(mbr[1], 2)
    mbr[2] = round(mbr[2], 2)
    mbr[3] = round(mbr[3], 2)
    if mbr[0] > mbr[2]:
        t = mbr[0]
        mbr[0] = mbr[2]
        mbr[2] = t
    if mbr[1] > mbr[3]:
        t = mbr[1]
        mbr[1] = mbr[3]
        mbr[3] = t
    if query[0] > query[2]:
        t = query[0]
        query[0] = query[2]
        query[2] = t
    if query[1] > query[3]:
        t = query[1]
        query[1] = query[3]
        query[3] = t
    if mbr[0] < query[0]:
        return False
    if mbr[1] < query[1]:
        return False
    if mbr[2] > query[2]:
        return False
    if mbr[3] > query[3]:
        return False

    return True


def min_mbr(mbr1, mbr2):
    x1 = min(mbr1[0], mbr2[0])
    y1 = min(mbr1[1], mbr2[1])
    x2 = max(mbr1[2], mbr2[2])
    y2 = max(mbr1[3], mbr2[3])

    return [x1, y1, x2, y2]


def _intersects(mbr, query):
    """
    判断查询包围矩形是否与mbr相交
    :param mbr:
    :param query:
    :return:
    """
    mbr[0] = round(mbr[0], 2)
    mbr[1] = round(mbr[1], 2)
    mbr[2] = round(mbr[2], 2)
    mbr[3] = round(mbr[3], 2)

    if mbr[0] > mbr[2]:
        t = mbr[0]
        mbr[0] = mbr[2]
        mbr[2] = t
    if mbr[1] > mbr[3]:
        t = mbr[1]
        mbr[1] = mbr[3]
        mbr[3] = t
    if query[0] > query[2]:
        t = query[0]
        query[0] = query[2]
        query[2] = t
    if query[1] > query[3]:
        t = query[1]
        query[1] = query[3]
        query[3] = t
    if mbr[0] > query[2]:
        return False
    if mbr[1] > query[3]:
        return False
    if mbr[2] < query[0]:
        return False
    if mbr[3] < query[1]:
        return False

    return True


def calculate_area_enlargement_point(mbr1, point):
    if mbr1[2] >= point[0] >= mbr1[0] and mbr1[3] >= point[1] >= mbr1[1]:
        return 0
    xmin = min(point[0], mbr1[0])
    ymin = min(point[1], mbr1[1])
    xmax = max(point[0], mbr1[2])
    ymax = max(point[1], mbr1[3])
    return (xmax - xmin) * (ymax - ymin) - (mbr1[2] - mbr1[0]) * (mbr1[3] - mbr1[1])


def calculate_area_enlargement_(mbr1, mbr2):
    """
    计算两个矩形框最大扩充面积，用于分裂
    :param mbr1:
    :param mbr2:
    :return:
    """
    minx = min(mbr1[0], mbr2[0])
    miny = min(mbr1[1], mbr2[1])
    maxx = max(mbr1[2], mbr2[2])
    maxy = max(mbr1[3], mbr2[3])
    return (maxx - minx) * (maxy - miny) - (mbr1[2] - mbr1[0]) * (mbr1[3] - mbr1[1]) - (mbr2[2] - mbr2[0]) * (
            mbr2[3] - mbr2[1])


def calculate_area_enlargement_point_(mbr1, point):
    """
    计算将mbr2加入到mbr1后的增加的面积，用于选择插入节点
    :param mbr1:
    :param mbr2:
    :return:
    """

    xmin = min(mbr1[0], point[0])
    xmax = max(mbr1[2], point[0])

    ymin = min(mbr1[1], point[1])
    ymax = max(mbr1[3], point[1])

    return (xmax - xmin) * (ymax - ymin) - (mbr1[2] - mbr1[0]) * (mbr1[3] - mbr1[1])


def calculate_area_point_(mbr1, point):
    """
    计算将mbr2加入到mbr1后的增加的面积，用于选择插入节点
    :param mbr1:
    :param mbr2:
    :return:
    """

    mbr_x = 0.5 * (mbr1[2] + mbr1[0])
    mbr_y = 0.5 * (mbr1[3] + mbr1[1])
    return math.sqrt(((mbr_x - point[0]) ** 2) + ((mbr_y - point[1]) ** 2))


def calculate_area_enlargement(mbr1, mbr2):
    """
    计算将mbr2加入到mbr1后的增加的面积，用于选择插入节点
    :param mbr1:
    :param mbr2:
    :return:
    """

    if mbr1[0] < mbr1[2]:
        if mbr2[0] < mbr2[2]:
            xmin = min(mbr1[0], mbr2[0])
            xmax = max(mbr1[2], mbr2[2])
        else:
            xmin = min(mbr1[0], mbr2[2])
            xmax = max(mbr1[2], mbr2[0])
    else:
        if mbr2[0] < mbr2[2]:
            xmin = min(mbr1[2], mbr2[0])
            xmax = max(mbr1[0], mbr2[2])
        else:
            xmin = min(mbr1[2], mbr2[2])
            xmax = max(mbr1[0], mbr2[0])
    if mbr1[1] < mbr1[3]:
        if mbr2[1] < mbr2[3]:
            ymin = min(mbr1[1], mbr2[1])
            ymax = max(mbr1[3], mbr2[3])
        else:
            ymin = min(mbr1[1], mbr2[3])
            ymax = max(mbr1[3], mbr2[1])
    else:
        if mbr2[1] < mbr2[3]:
            ymin = min(mbr1[3], mbr2[1])
            ymax = max(mbr1[1], mbr2[3])
        else:
            ymin = min(mbr1[3], mbr2[3])
            ymax = max(mbr1[1], mbr2[1])

    return (xmax - xmin) * (ymax - ymin) - (mbr1[2] - mbr1[0]) * (mbr1[3] - mbr1[1])


class RtreeIndex:
    def __init__(self, file_path, memorymanager, data_buffer, data_file):
        self.file_path = file_path
        self.data_file = data_file
        self.num = 0
        self.memorymanager = memorymanager
        self.data_buffer = data_buffer
        self.search_result = []

    def create_index(self, input_files):
        """
        构建R树索引
        :param data_file_path:
        :return:
        """
        header = self._load_header_from_file()
        global TOTAL
        TOTAL += 1
        mm = 0
        if header is None:
            header = Header(INDEXBLOCKSIZE, GMBR=None, GPTR=None, BLOCKSIZE=INDEXBLOCKSIZE, END_BLOCK_NUMBER=0,
                            data_block_end_number=0)
            # header.write_block_to_file(self.file_path)

            # header = self._load_header_from_file()
        root_id = header.GPTR

        if root_id == 0:
            root = LeafBlock(block_id=1)

            data_block = DataBlock(block_id=0)

            root.add_child_block([float('inf'), float('inf'), float('-inf'), float('-inf')], data_block.block_id)
            header.data_block_end_number += 1
            header.GPTR = root.block_id
            header.END_BLOCK_NUMBER += 1
            # header.write_block_to_file(self.file_path)

            self.memorymanager.add_block(root, self.file_path)
            self.data_buffer.add_block(data_block, self.data_file)
        with open(input_files, 'r') as file:
            for line in file.readlines():
                fields = line.strip().split(',')
                print(f"插入数据{mm}")

                self.insert(
                    [float(fields[-4]), float(fields[-3]), float(fields[-2]), float(fields[-1]), int(fields[-5])],
                    header)
                mm += 1

        self.flush_to_disk(header)

    def flush_to_disk(self, header):
        """
        当构建索引结束后，将缓存中的块写入磁盘
        :return:
        """
        for block in self.memorymanager.blocks:
            self.memorymanager.write_block_to_file(self.file_path, block)

        for block in self.data_buffer.blocks:
            self.data_buffer.write_block_to_file(self.data_file, block)
        header.write_block_to_file(self.file_path)
        self.memorymanager.blocks = []
        self.memorymanager.block_ids = []

    """
    插入过程
    1.如果没有根节点，建立根节点，同时num_blocks加1,内存缓存添加一个块，把数据项添加到根节点中，同时根节点发生了改变，改变标志位
    2.如果有根节点，判断根节点是否已经满了
        已满
            新建一个叶子块，选择根节点数据两个距离最远的，也就是这两个mbr合成的mbr面积减去两个mbr的面积是最大的，则选择这两个数据分别插入到根节点
            块和新建的块，这时候需要建立一个新的内部块，作为这两个叶子节点的父节点，
    """

    # 插入过程cur_block可以指向根节点
    def insert(self, data, header, cur_block=None):
        """
        将数据插入到R树索引中
        1.如果当前块为空，则从文件中加载头节点，获取根节点，不为空，直接使用该节点
        2.判断当前节点是否为叶子节点，
        如果是，
            则将数据加入该节点，更新头节点的最小包围矩形，修改缓存中该块是否修改的标记，
            判断当前在加入新数据后是否满了，如果满，则分裂该节点，如果该节点父节点在该节点分裂后也满了，则继续分裂，直到块不满
            在分裂之后，调整涉及块的最小包围矩形
        如果不是，
            则选择最适合插入数据的节点，直至到达根节点

        :param header:
        :param data:
        :param cur_block:
        :return:
        """
        header.GMBR = update_mbr(header.GMBR, [data[0], data[1], data[0], data[1]])
        if cur_block is None:

            root_id = header.GPTR
            root = self.memorymanager.get_block(root_id)
            if root is not None:

                cur_block = root
            else:
                root = self.memorymanager.load_block_from_file(self.file_path, root_id)

                self.memorymanager.add_block(root, self.file_path)
                cur_block = root
        if cur_block.is_leaf == 1:

            if len(cur_block.child_blocks) == 1:
                data_block = self.data_buffer.get_block(cur_block.child_blocks[0][1])
                if data_block is None:
                    data_block = self.data_buffer.load_block_from_file(self.data_file, cur_block.child_blocks[0][1])

                data_block.add_child_block(data)

                data_block_mbr = get_data_mbr(data_block.items)
                cur_block.delete(data_block.block_id)
                cur_block.add_child_block(data_block_mbr, data_block.block_id)
                self.data_buffer.add_block(data_block, self.data_file)

                self.memorymanager.add_block(cur_block, self.file_path)

                if data_block.is_full():
                    self.handle_overflow_data_block(data_block, cur_block, header)
                return
            if len(cur_block.child_blocks) > 1:
                chosen_child_block = self.choose_best_child_block(cur_block, data)
                chosen_child_block.add_child_block(data)
                data_block_mbr = get_data_mbr(chosen_child_block.items)
                cur_block.delete(chosen_child_block.block_id)
                cur_block.add_child_block(data_block_mbr, chosen_child_block.block_id)
                self.data_buffer.add_block(chosen_child_block, self.data_file)

                self.memorymanager.add_block(cur_block, self.file_path)

                if chosen_child_block.is_full():
                    self.handle_overflow_data_block(chosen_child_block, cur_block, header)
        if cur_block.is_leaf == 0:
            chosen_child_block = self.choose_best_child_block(cur_block, data)

            self.insert(data, header, cur_block=chosen_child_block)

    def adjust_tree(self, cur_block):
        """
        在分裂之后，调整涉及块的最小包围矩形
        :param cur_block:
        :return:
        """
        if cur_block.parent_id != 0:

            parent_block = self.memorymanager.get_block(cur_block.parent_id)
            if parent_block is None:
                parent_block = self.memorymanager.load_block_from_file(self.file_path, cur_block.parent_id)
            parent_block.delete(cur_block.block_id)
            parent_block.add_child_block(cur_block.mbr, cur_block.block_id)

            self.memorymanager.add_block(parent_block, self.file_path)

            self.adjust_tree(parent_block)

    def choose_best_child_block_(self, cur_block, data):
        """
        R*树的版本，判断节点的孩子节点是不是叶子节点，是叶子节点，则选择加入新记录后相应的条目应该重叠面积增加程度最小，如果重叠面积相同，判断面积增加大小，加入面积小的条目
        如果不是叶子节点，则插入新纪录后条目增加的面积最小，如果面积增加大小相同，则选择面积最小的条目
        :param cur_block:
        :param data:
        :return:
        """
        global TOTAL
        enlargement_area_ = {}
        for block in cur_block.child_blocks:
            enlargement_area_[block[1]] = calculate_area_enlargement_point(block[0], data)
        cur_block.child_blocks = sorted(cur_block.child_blocks, key=lambda block: enlargement_area_[block[1]])
        if cur_block.is_leaf == 1:
            b = self.data_buffer.get_block(cur_block.child_blocks[0][1])
            if b is None:
                print(cur_block.child_blocks[0][1])
                b = self.data_buffer.load_block_from_file(self.data_file, cur_block.child_blocks[0][1])

                TOTAL += 1
                self.data_buffer.add_block(b, self.data_file)

            overlap_area_enlargement = {}
            for i in range(len(cur_block.child_blocks)):
                overlap_area_enlargement[cur_block.child_blocks[i][1]] = 0
            for i in range(len(cur_block.child_blocks)):
                for j in range(len(cur_block.child_blocks)):
                    if i != j:

                        new_mbr = update_mbr_point(cur_block.child_blocks[i][0], data)

                        overlap_area_enlargement[cur_block.child_blocks[i][1]] += (
                                overlap_area(new_mbr, cur_block.child_blocks[j][0]) - overlap_area(
                            cur_block.child_blocks[i][0], cur_block.child_blocks[j][0]))

                    else:
                        continue

            min_value = min(overlap_area_enlargement.values())
            min_value_list = []
            for key, value in overlap_area_enlargement.items():
                if value == min_value:
                    min_value_list.append(key)
            if len(min_value_list) == 1:
                block = self.data_buffer.get_block(min_value_list[0])
                if block is None:
                    block = self.data_buffer.load_block_from_file(self.data_file, min_value_list[0])
                    TOTAL += 1
                    self.data_buffer.add_block(block, self.data_file)
                return block
            else:
                min_item_list = []
                for block in cur_block.child_blocks:
                    if block[1] in min_value_list:
                        min_item_list.append(block)
                enlargement_area = {}

                for item in min_item_list:
                    enlargement_area[item[1]] = calculate_area_enlargement_point(item[0],
                                                                                 data)
                min_enlargement_area_value = min(enlargement_area.values())
                min_enlargement_area_value_list = []
                for key, value in enlargement_area.items():
                    if value == min_enlargement_area_value:
                        min_enlargement_area_value_list.append(key)
                if len(min_enlargement_area_value_list) == 1:
                    block = self.data_buffer.get_block(min_enlargement_area_value_list[0])
                    if block is None:
                        block = self.data_buffer.load_block_from_file(self.data_file,
                                                                      min_enlargement_area_value_list[0])
                        TOTAL += 1
                        self.data_buffer.add_block(block, self.data_file)
                    return block
                else:
                    min_item_list_ = []
                    for block in cur_block.child_blocks:
                        if block[1] in min_enlargement_area_value_list:
                            min_item_list_.append(block)
                    best_item = None
                    best_area = float('inf')
                    for item in min_item_list_:
                        area = (item[0][2] - item[0][0]) * (item[0][3] - item[0][1])
                        if area < best_area:
                            best_item = item
                            best_area = area
                    block = self.data_buffer.get_block(best_item[1])

                    if block is None:

                        block = self.data_buffer.load_block_from_file(self.data_file, best_item[1])

                        self.data_buffer.add_block(block, self.data_file)
                        return block

                    else:
                        return block

        if cur_block.is_leaf == 0:
            b = self.memorymanager.get_block(cur_block.child_blocks[0][1])
            if b is None:
                b = self.memorymanager.load_block_from_file(self.file_path, cur_block.child_blocks[0][1])
                TOTAL += 1
                self.memorymanager.add_block(b, self.file_path)

            overlap_area_enlargement = {}
            for i in range(len(cur_block.child_blocks)):
                overlap_area_enlargement[cur_block.child_blocks[i][1]] = 0
            for i in range(len(cur_block.child_blocks)):
                for j in range(len(cur_block.child_blocks)):
                    if i != j:

                        new_mbr = update_mbr_point(cur_block.child_blocks[i][0], data)

                        overlap_area_enlargement[cur_block.child_blocks[i][1]] += (
                                overlap_area(new_mbr, cur_block.child_blocks[j][0]) - overlap_area(
                            cur_block.child_blocks[i][0], cur_block.child_blocks[j][0]))

                    else:
                        continue

            min_value = min(overlap_area_enlargement.values())
            min_value_list = []
            for key, value in overlap_area_enlargement.items():
                if value == min_value:
                    min_value_list.append(key)
            if len(min_value_list) == 1:
                block = self.memorymanager.get_block(min_value_list[0])
                if block is None:
                    block = self.memorymanager.load_block_from_file(self.file_path, min_value_list[0])
                    TOTAL += 1
                    self.memorymanager.add_block(block, self.file_path)
                return block
            else:
                min_item_list = []
                for block in cur_block.child_blocks:
                    if block[1] in min_value_list:
                        min_item_list.append(block)
                enlargement_area = {}

                for item in min_item_list:
                    enlargement_area[item[1]] = calculate_area_enlargement_point(item[0],
                                                                                 data)
                min_enlargement_area_value = min(enlargement_area.values())
                min_enlargement_area_value_list = []
                for key, value in enlargement_area.items():
                    if value == min_enlargement_area_value:
                        min_enlargement_area_value_list.append(key)
                if len(min_enlargement_area_value_list) == 1:
                    block = self.memorymanager.get_block(min_enlargement_area_value_list[0])
                    if block is None:
                        block = self.memorymanager.load_block_from_file(self.file_path,
                                                                        min_enlargement_area_value_list[0])
                        TOTAL += 1
                        self.memorymanager.add_block(block, self.file_path)
                    return block
                else:
                    min_item_list_ = []
                    for block in cur_block.child_blocks:
                        if block[1] in min_enlargement_area_value_list:
                            min_item_list_.append(block)
                    best_item = None
                    best_area = float('inf')
                    for item in min_item_list_:
                        area = (item[0][2] - item[0][0]) * (item[0][3] - item[0][1])
                        if area < best_area:
                            best_item = item
                            best_area = area
                    block = self.memorymanager.get_block(best_item[1])

                    if block is None:

                        block = self.memorymanager.load_block_from_file(self.file_path, best_item[1])

                        TOTAL += 1
                        self.memorymanager.add_block(block, self.file_path)
                        return block

                    else:
                        return block

    def choose_best_child_block(self, cur_block, data):
        """

        :param cur_block:
        :param data:
        :return:
        """
        """best_child_block_list = []
        best_enlargement = float('inf')

        for child_block in cur_block.child_blocks:
            child_mbr = child_block[0]
            enlargement = calculate_area_enlargement_point(child_mbr, data)
            if enlargement <= best_enlargement:
                best_child_block_list.append(child_block)

                best_enlargement = enlargement"""
        enlargement_list = []
        for child_block in cur_block.child_blocks:
            child_mbr = child_block[0]
            enlargement = calculate_area_enlargement_point(child_mbr, data)
            enlargement_list.append([child_block, enlargement])
        enlargement_list.sort(key=lambda x: x[1])
        best_enlargement_value = enlargement_list[0][1]
        best_child_block_list = [enlargement_list[0]]
        for i in range(1, len(enlargement_list)):
            if enlargement_list[i][1] == best_enlargement_value:
                best_child_block_list.append(enlargement_list[i])
        best_child_block = None
        if len(best_child_block_list) == 1:
            best_child_block = best_child_block_list[0][0]
        else:
            min_area = float('inf')
            for i in range(len(best_child_block_list)):
                area = (best_child_block_list[i][0][0][2] - best_child_block_list[i][0][0][0]) * (
                        best_child_block_list[i][0][0][3] - best_child_block_list[i][0][0][1])
                if area < min_area:
                    best_child_block = best_child_block_list[i][0]

        if cur_block.is_leaf == 1:
            b = self.data_buffer.get_block(best_child_block[1])
            if b is None:
                b = self.data_buffer.load_block_from_file(self.data_file, best_child_block[1])

                self.data_buffer.add_block(b, self.data_file)
            return b
        if cur_block.is_leaf == 0:
            b = self.memorymanager.get_block(cur_block.child_blocks[0][1])
            if b is None:
                b = self.memorymanager.load_block_from_file(self.file_path, cur_block.child_blocks[0][1])

                self.memorymanager.add_block(b, self.file_path)
            return b

    """
    1.如果cur_block是根块，则新建一个内部块作为cur_block和new_block的父块，将其child_blocks包含cur_block和new_block,更新新根块的MBR,并将parent_id设置为1
    2.如果cur_block不是根块，通过parent_id找到其父块，先从缓存中查找是否有对应块号的块，如果有，则该块就是对应的父块，如果没有，则从磁盘中找对应
    块号的块，选择一个块替换出去，将该父块读取到缓存中，该父块的child_blocks包含new_block,更新父块的MBR包含cur_block和new_block
    3.递归重复步骤2，直到找到根节点
    
    """

    def handle_overflow_data_block(self, data_block, cur_block, header):
        data_block, new_block_ = self.split_data_block_(data_block, header)

        data_block_mbr = get_data_mbr(data_block.items)
        new_block_mbr = get_data_mbr(new_block_.items)
        cur_block.delete(data_block.block_id)
        cur_block.add_child_block(data_block_mbr, data_block.block_id)
        cur_block.add_child_block(new_block_mbr, new_block_.block_id)
        self.memorymanager.add_block(cur_block, self.file_path)
        if cur_block.is_full():
            self.handle_overflow_(cur_block, header)
        else:
            self.adjust_tree(cur_block)

    def handle_overflow_(self, cur_block, header):
        """
        当前节点已满，需要分裂
        :param cur_block:
        :return:
        """

        if cur_block.is_leaf == 1:
            cur_block, new_block = self.split_leaf_block(cur_block, header)

        elif cur_block.is_leaf == 0:
            cur_block, new_block = self.split_internal_block(cur_block, header)

        if cur_block.parent_id == 0:

            header.END_BLOCK_NUMBER += 1
            root_block = InternalBLock(header.END_BLOCK_NUMBER)

            root_block.delete(cur_block.block_id)
            root_block.add_child_block(cur_block.mbr, cur_block.block_id)

            root_block.add_child_block(new_block.mbr, new_block.block_id)

            cur_block.parent_id = root_block.block_id

            new_block.parent_id = root_block.block_id
            header.GPTR = root_block.block_id
            header.GMBR = root_block.mbr
            self.memorymanager.add_block(new_block, self.file_path)
            self.memorymanager.add_block(root_block, self.file_path)
            self.memorymanager.add_block(cur_block, self.file_path)


        else:
            parent_block = self.get_parent_block(cur_block.parent_id)

            parent_block.add_child_block(new_block.mbr, new_block.block_id)
            new_block.parent_id = cur_block.parent_id
            parent_block.delete(cur_block.block_id)
            parent_block.add_child_block(cur_block.mbr, cur_block.block_id)

            self.memorymanager.add_block(cur_block, self.file_path)
            self.memorymanager.add_block(new_block, self.file_path)
            self.memorymanager.add_block(parent_block, self.file_path)
            if parent_block.is_full():
                self.handle_overflow_(parent_block, header)
            else:
                self.adjust_tree(parent_block)

    def get_parent_block(self, parent_id):
        """
        获取父节点
        :param parent_id:
        :return:
        """
        parent_block = self.memorymanager.get_block(parent_id)
        if parent_block is None:
            parent_block = self.memorymanager.load_block_from_file(self.file_path, parent_id)
            self.memorymanager.add_block(parent_block, self.file_path)
        return parent_block

    def split_data_block_(self, data_block, header):

        new_block = DataBlock(header.data_block_end_number)

        header.data_block_end_number += 1
        print(f'header.data_block_end_number={header.data_block_end_number}')

        max_distance = -1
        max_items = None

        for i in range(len(data_block.items) - 1):
            for j in range(i + 1, len(data_block.items)):

                distance = math.sqrt((data_block.items[i][0] - data_block.items[j][0]) ** 2 + (
                        data_block.items[i][1] - data_block.items[j][1]) ** 2)
                if distance > max_distance:
                    max_distance = distance
                    max_items = [data_block.items[i],
                                 data_block.items[j]]

        new_block.add_child_block(max_items[1])
        new_block_mbr = [max_items[1][0], max_items[1][1], max_items[1][0], max_items[1][1]]
        cur_block_ = [max_items[0]]
        cur_block_mbr = [max_items[0][0], max_items[0][1], max_items[0][0], max_items[0][1]]
        min_distance1 = float('inf')
        item1 = None
        for data_item in data_block.items:
            if data_item not in max_items:
                distance = math.sqrt(((max_items[0][0] - data_item[0]) ** 2) + ((
                                                                                        max_items[0][1] -
                                                                                        data_item[1]) ** 2))
                if min_distance1 > distance:
                    item1 = data_item
        cur_block_.append(item1)
        cur_block_mbr = get_data_mbr(cur_block_)
        min_distance2 = float('inf')
        item2 = None
        for data_item in data_block.items:
            if data_item not in max_items and data_item not in cur_block_:
                distance = math.sqrt(((max_items[1][0] - data_item[0]) ** 2) + ((
                                                                                        max_items[1][1] -
                                                                                        data_item[1]) ** 2))
                if min_distance2 > distance:
                    item2 = data_item
        new_block.add_child_block(item2)
        new_block_mbr = get_data_mbr(new_block.items)

        i = 0
        while i < len(data_block.items) - 5:

            enlargement_area_list_ = []
            for data_item in data_block.items:
                if data_item not in new_block.items and data_item not in cur_block_:
                    area = calculate_area_enlargement_point_(cur_block_mbr, [data_item[0], data_item[
                        1]]) + calculate_area_enlargement_point_(new_block_mbr, [data_item[0], data_item[1]])
                    enlargement_area_list_.append([data_item, area])
            enlargement_area_list_.sort(key=lambda x: x[1],reverse=True)
            if calculate_area_enlargement_point_(cur_block_mbr,
                                                 [enlargement_area_list_[0][0][0],
                                                  enlargement_area_list_[0][0][1]]) > calculate_area_enlargement_point_(
                new_block_mbr, [enlargement_area_list_[0][0][0], enlargement_area_list_[0][0][1]]):
                new_block.add_child_block(enlargement_area_list_[0][0])
                new_block_mbr = get_data_mbr(new_block.items)
            elif calculate_area_enlargement_point_(cur_block_mbr,
                                                   [enlargement_area_list_[0][0][0], enlargement_area_list_[0][0][
                                                       1]]) < calculate_area_enlargement_point_(
                new_block_mbr, [enlargement_area_list_[0][0][0], enlargement_area_list_[0][0][1]]):
                cur_block_.append(enlargement_area_list_[0][0])
                cur_block_mbr = get_data_mbr(cur_block_)
            else:
                if (cur_block_mbr[2] - cur_block_mbr[0]) * (cur_block_mbr[3] - cur_block_mbr[1]) > (
                        new_block_mbr[2] - new_block_mbr[0]) * (new_block_mbr[3] - new_block_mbr[1]):
                    new_block.add_child_block(enlargement_area_list_[0][0])
                    new_block_mbr = get_data_mbr(new_block.items)
                else:
                    cur_block_.append(enlargement_area_list_[0][0])
                    cur_block_mbr = get_data_mbr(cur_block_)
            i += 1
        """for data_item in data_block.items:

            if calculate_area_point_(cur_block_mbr,
                                     [data_item[0], data_item[1]]) > calculate_area_point_(
                new_block_mbr,
                [data_item[0],
                 data_item[1]
                 ]):
                if data_item not in new_block.items:
                    new_block.add_child_block(data_item)
                    new_block_mbr = get_data_mbr(new_block.items)
                    print(new_block_mbr)
            elif calculate_area_point_(cur_block_mbr,
                                       [data_item[0], data_item[1]]) < calculate_area_point_(
                new_block_mbr,
                [data_item[0],
                 data_item[1]
                 ]):
                if data_item not in cur_block_:
                    cur_block_.append(data_item)
                    cur_block_mbr = get_data_mbr(cur_block_)
                    print(cur_block_mbr)
            else:
                if (cur_block_mbr[2] - cur_block_mbr[0]) * (cur_block_mbr[3] - cur_block_mbr[1]) > (
                        new_block_mbr[2] - new_block_mbr[0]) * (new_block_mbr[3] - new_block_mbr[1]):
                    new_block.add_child_block(data_item)
                    new_block_mbr = get_data_mbr(new_block.items)
                else:
                    cur_block_.append(data_item)
                    cur_block_mbr = get_data_mbr(cur_block_)"""

        data_block.items = cur_block_

        self.data_buffer.add_block(new_block, self.data_file)
        self.data_buffer.add_block(data_block, self.data_file)

        return data_block, new_block

    def split_leaf_block_(self, cur_block, header):

        """
        R*树版本
        :param cur_block:
        :return:
        """

        header.END_BLOCK_NUMBER += 1

        new_block = LeafBlock(header.END_BLOCK_NUMBER)

        child_blocks_sorted_x = sorted(cur_block.child_blocks, key=lambda x: (x[0][0], x[0][2]))
        child_blocks_sorted_y = sorted(cur_block.child_blocks, key=lambda x: (x[0][1], x[0][3]))

        min_margin_value1 = float('inf')

        min_margin_value2 = float('inf')

        for i in range(len(child_blocks_sorted_x) // 2 - 1, len(child_blocks_sorted_x) // 2 + 2):

            mbr1 = get_mbr(child_blocks_sorted_x[0:i + 1])
            mbr2 = get_mbr(child_blocks_sorted_x[i + 1:])

            margin_value = (mbr1[2] - mbr1[0] + mbr1[3] - mbr1[1]) * 2 + (mbr2[2] - mbr2[0] + mbr2[3] - mbr2[1]) * 2
            if margin_value < min_margin_value1:
                min_margin_value1 = margin_value

        for j in range(len(child_blocks_sorted_y) // 2 - 1, len(child_blocks_sorted_y) // 2 + 2):
            """mbr1 = min_mbr(child_blocks_sorted_y[0][0], child_blocks_sorted_y[j][0])
            mbr2 = min_mbr(child_blocks_sorted_y[j + 1][0], child_blocks_sorted_y[-1][0])"""
            mbr1 = get_mbr(child_blocks_sorted_y[0:j + 1])
            mbr2 = get_mbr(child_blocks_sorted_y[j + 1:])

            margin_value = (mbr1[2] - mbr1[0] + mbr1[3] - mbr1[1]) * 2 + (mbr2[2] - mbr2[0] + mbr2[3] - mbr2[1]) * 2
            if margin_value < min_margin_value2:
                min_margin_value2 = margin_value

        if min_margin_value1 < min_margin_value2:
            overlap_area_ = {}
            group_mbr = {}
            for i in range(len(child_blocks_sorted_x) // 2 - 1, len(child_blocks_sorted_x) // 2 + 2):
                """mbr1 = min_mbr(child_blocks_sorted_x[0][0], child_blocks_sorted_x[i][0])
                mbr2 = min_mbr(child_blocks_sorted_x[i + 1][0], child_blocks_sorted_x[-1][0])"""
                mbr1 = get_mbr(child_blocks_sorted_x[0:i + 1])
                mbr2 = get_mbr(child_blocks_sorted_x[i + 1:])
                area = overlap_area(mbr1, mbr2)
                overlap_area_[i] = area
                group_mbr[i] = [mbr1, mbr2]
            min_overlap_area = min(overlap_area_.values())
            min_overlap_area_list = []
            for key, value in overlap_area_.items():
                if value == min_overlap_area:
                    min_overlap_area_list.append(key)
            if len(min_overlap_area_list) == 1:

                cur_block.child_blocks = child_blocks_sorted_x[0:min_overlap_area_list[0] + 1]

                cur_block.mbr = group_mbr[min_overlap_area_list[0]][0]

                new_block.child_blocks = child_blocks_sorted_x[min_overlap_area_list[0] + 1:]

                new_block.mbr = group_mbr[min_overlap_area_list[0]][1]

                self.memorymanager.add_block(new_block, self.file_path)
                self.memorymanager.add_block(cur_block, self.file_path)

                return cur_block, new_block
            else:
                min_area = float('inf')
                min_area_index = -1
                for m in min_overlap_area_list:
                    mbr1 = get_mbr(child_blocks_sorted_x[0:m + 1])
                    mbr2 = get_mbr(child_blocks_sorted_x[m + 1:])
                    area = (mbr1[2] - mbr1[0]) * (mbr1[3] - mbr1[1]) + (mbr2[2] - mbr2[0]) * (mbr2[3] - mbr2[1])
                    if area < min_area:
                        min_area_index = m

                cur_block.child_blocks = child_blocks_sorted_x[0:min_area_index + 1]
                cur_block.mbr = group_mbr[min_area_index][0]

                new_block.child_blocks = child_blocks_sorted_x[min_area_index + 1:]
                new_block.mbr = group_mbr[min_area_index][1]

                self.memorymanager.add_block(new_block, self.file_path)
                self.memorymanager.add_block(cur_block, self.file_path)

                return cur_block, new_block
        else:
            overlap_area_ = {}
            group_mbr = {}
            for i in range(len(child_blocks_sorted_y) // 2 - 1, len(child_blocks_sorted_y) // 2 + 2):
                mbr1 = get_mbr(child_blocks_sorted_y[0:i + 1])
                mbr2 = get_mbr(child_blocks_sorted_y[i + 1:])
                area = overlap_area(mbr1, mbr2)
                overlap_area_[i] = area
                group_mbr[i] = [mbr1, mbr2]
            min_overlap_area = min(overlap_area_.values())
            min_overlap_area_list = []
            for key, value in overlap_area_.items():
                if value == min_overlap_area:
                    min_overlap_area_list.append(key)
            if len(min_overlap_area_list) == 1:
                cur_block.child_blocks = child_blocks_sorted_y[0:min_overlap_area_list[0] + 1]
                cur_block.mbr = group_mbr[min_overlap_area_list[0]][0]
                new_block.child_blocks = child_blocks_sorted_y[min_overlap_area_list[0] + 1:]

                new_block.mbr = group_mbr[min_overlap_area_list[0]][1]

                self.memorymanager.add_block(new_block, self.file_path)
                self.memorymanager.add_block(cur_block, self.file_path)

                return cur_block, new_block
            else:
                min_area = float('inf')
                min_area_index = -1
                for m in min_overlap_area_list:
                    mbr1 = get_mbr(child_blocks_sorted_y[0:m + 1])
                    mbr2 = get_mbr(child_blocks_sorted_y[m + 1:])
                    area = (mbr1[2] - mbr1[0]) * (mbr1[3] - mbr1[1]) + (mbr2[2] - mbr2[0]) * (mbr2[3] - mbr2[1])
                    if area < min_area:
                        min_area_index = m
                cur_block.child_blocks = child_blocks_sorted_y[0:min_area_index + 1]
                cur_block.mbr = group_mbr[min_area_index][0]
                new_block.child_blocks = child_blocks_sorted_y[min_area_index + 1:]

                new_block.mbr = group_mbr[min_area_index][1]

                self.memorymanager.add_block(new_block, self.file_path)
                self.memorymanager.add_block(cur_block, self.file_path)

                return cur_block, new_block

    def split_leaf_block(self, cur_block, header):
        """
        分裂叶子节点
        :param cur_block:
        :return:
        """

        header.END_BLOCK_NUMBER += 1

        new_block = LeafBlock(header.END_BLOCK_NUMBER)

        max_distance = -1
        max_items = None
        max_items_ids = None
        for i in range(len(cur_block.child_blocks) - 1):
            for j in range(i + 1, len(cur_block.child_blocks)):
                distance = calculate_area_enlargement_(cur_block.child_blocks[i][0], cur_block.child_blocks[j][0])
                if distance > max_distance:
                    max_distance = distance
                    max_items = [[cur_block.child_blocks[i][0], cur_block.child_blocks[i][1]],
                                 [cur_block.child_blocks[j][0], cur_block.child_blocks[j][1]]]
                    max_items_ids = [cur_block.child_blocks[i][1], cur_block.child_blocks[j][1]]
                """distance = calculate_distance(cur_block.child_blocks[i][0], cur_block.child_blocks[j][0])
                if distance > max_distance:
                    max_distance = distance
                    max_items = [[cur_block.child_blocks[i][0], cur_block.child_blocks[i][1]],
                                 [cur_block.child_blocks[j][0], cur_block.child_blocks[j][1]]]
                    max_items_ids = [cur_block.child_blocks[i][1], cur_block.child_blocks[j][1]]"""
        new_block.add_child_block(max_items[1][0], max_items[1][1])

        cur_block_ = [[max_items[0][0], max_items[0][1]]]
        cur_block_mbr = max_items[0][0]

        for data_item in cur_block.child_blocks:
            if data_item[1] not in max_items_ids:

                if calculate_area_enlargement(cur_block_mbr, data_item[0]) > calculate_area_enlargement(new_block.mbr,
                                                                                                        data_item[0]):

                    new_block.add_child_block(data_item[0], data_item[1])
                elif calculate_area_enlargement(cur_block_mbr, data_item[0]) < calculate_area_enlargement(new_block.mbr,
                                                                                                          data_item[0]):
                    cur_block_.append([data_item[0], data_item[1]])
                    cur_block_mbr = update_mbr(cur_block_mbr, data_item[0])
                else:
                    if (cur_block_mbr[2] - cur_block_mbr[0]) * (cur_block_mbr[3] - cur_block_mbr[1]) > (
                            new_block.mbr[2] - new_block.mbr[0]) * (new_block.mbr[3] - new_block.mbr[1]):
                        new_block.add_child_block(data_item[0], data_item[1])
                    else:
                        cur_block_.append([data_item[0], data_item[1]])
                        cur_block_mbr = update_mbr(cur_block_mbr, data_item[0])
        cur_block.child_blocks = cur_block_
        cur_block.mbr = cur_block_mbr

        self.memorymanager.add_block(new_block, self.file_path)
        self.memorymanager.add_block(cur_block, self.file_path)
        return cur_block, new_block

    def split_internal_block_(self, cur_block, header):
        """
        R*树分裂内部节点
        :param cur_block:
        :return:
        """

        header.END_BLOCK_NUMBER += 1

        new_block = InternalBLock(header.END_BLOCK_NUMBER)

        child_blocks_sorted_x = sorted(cur_block.child_blocks, key=lambda x: (x[0][0], x[0][2]))
        child_blocks_sorted_y = sorted(cur_block.child_blocks, key=lambda x: (x[0][1], x[0][3]))

        min_margin_value1 = float('inf')

        min_margin_value2 = float('inf')

        for i in range(len(child_blocks_sorted_x) // 2 - 1, len(child_blocks_sorted_x) // 2 + 2):
            """mbr1 = min_mbr(child_blocks_sorted_x[0][0], child_blocks_sorted_x[i][0])
            mbr2 = min_mbr(child_blocks_sorted_x[i + 1][0], child_blocks_sorted_x[-1][0])"""
            mbr1 = get_mbr(child_blocks_sorted_x[0:i + 1])
            mbr2 = get_mbr(child_blocks_sorted_x[i + 1:])

            margin_value = (mbr1[2] - mbr1[0] + mbr1[3] - mbr1[1]) * 2 + (mbr2[2] - mbr2[0] + mbr2[3] - mbr2[1]) * 2
            if margin_value < min_margin_value1:
                min_margin_value1 = margin_value

        for j in range(len(child_blocks_sorted_y) // 2 - 1, len(child_blocks_sorted_y) // 2 + 2):
            """mbr1 = min_mbr(child_blocks_sorted_y[0][0], child_blocks_sorted_y[j][0])
            mbr2 = min_mbr(child_blocks_sorted_y[j + 1][0], child_blocks_sorted_y[-1][0])"""
            mbr1 = get_mbr(child_blocks_sorted_y[0:j + 1])
            mbr2 = get_mbr(child_blocks_sorted_y[j + 1:])
            margin_value = (mbr1[2] - mbr1[0] + mbr1[3] - mbr1[1]) * 2 + (mbr2[2] - mbr2[0] + mbr2[3] - mbr2[1]) * 2
            if margin_value < min_margin_value2:
                min_margin_value2 = margin_value

        if min_margin_value1 < min_margin_value2:
            overlap_area_ = {}
            group_mbr = {}
            for i in range(len(child_blocks_sorted_x) // 2 - 1, len(child_blocks_sorted_x) // 2 + 2):
                mbr1 = get_mbr(child_blocks_sorted_x[0:i + 1])
                mbr2 = get_mbr(child_blocks_sorted_x[i + 1:])
                area = overlap_area(mbr1, mbr2)
                overlap_area_[i] = area
                group_mbr[i] = [mbr1, mbr2]
            min_overlap_area = min(overlap_area_.values())
            min_overlap_area_list = []
            for key, value in overlap_area_.items():
                if value == min_overlap_area:
                    min_overlap_area_list.append(key)
            if len(min_overlap_area_list) == 1:
                cur_block.child_blocks = child_blocks_sorted_x[0:min_overlap_area_list[0] + 1]
                cur_block.mbr = group_mbr[min_overlap_area_list[0]][0]
                new_block.child_blocks = child_blocks_sorted_x[min_overlap_area_list[0] + 1:]
                for child in new_block.child_blocks:
                    child_page = self.memorymanager.get_block(child[1])
                    if child_page is None:
                        child_page = self.memorymanager.load_block_from_file(self.file_path, child[1])
                    child_page.parent_id = new_block.block_id
                    self.memorymanager.add_block(child_page, self.file_path)
                new_block.mbr = group_mbr[min_overlap_area_list[0]][1]

                self.memorymanager.add_block(new_block, self.file_path)
                self.memorymanager.add_block(cur_block, self.file_path)
                return cur_block, new_block
            else:
                min_area = float('inf')
                min_area_index = -1
                for m in min_overlap_area_list:
                    mbr1 = get_mbr(child_blocks_sorted_x[0:m + 1])
                    mbr2 = get_mbr(child_blocks_sorted_x[m + 1:])
                    area = (mbr1[2] - mbr1[0]) * (mbr1[3] - mbr1[1]) + (mbr2[2] - mbr2[0]) * (mbr2[3] - mbr2[1])
                    if area < min_area:
                        min_area_index = m
                cur_block.child_blocks = child_blocks_sorted_x[0:min_area_index + 1]
                cur_block.mbr = group_mbr[min_area_index][0]
                new_block.child_blocks = child_blocks_sorted_x[min_area_index + 1:]
                for child in new_block.child_blocks:
                    child_page = self.memorymanager.get_block(child[1])
                    if child_page is None:
                        child_page = self.memorymanager.load_block_from_file(self.file_path, child[1])
                    child_page.parent_id = new_block.block_id
                    self.memorymanager.add_block(child_page, self.file_path)
                new_block.mbr = group_mbr[min_area_index][1]

                self.memorymanager.add_block(new_block, self.file_path)
                self.memorymanager.add_block(cur_block, self.file_path)
                return cur_block, new_block
        else:
            overlap_area_ = {}
            group_mbr = {}
            for i in range(len(child_blocks_sorted_y) // 2 - 1, len(child_blocks_sorted_y) // 2 + 2):
                mbr1 = get_mbr(child_blocks_sorted_y[0:i + 1])
                mbr2 = get_mbr(child_blocks_sorted_y[i + 1:])
                area = overlap_area(mbr1, mbr2)
                overlap_area_[i] = area
                group_mbr[i] = [mbr1, mbr2]
            min_overlap_area = min(overlap_area_.values())
            min_overlap_area_list = []
            for key, value in overlap_area_.items():
                if value == min_overlap_area:
                    min_overlap_area_list.append(key)
            if len(min_overlap_area_list) == 1:
                cur_block.child_blocks = child_blocks_sorted_y[0:min_overlap_area_list[0] + 1]
                cur_block.mbr = group_mbr[min_overlap_area_list[0]][0]
                new_block.child_blocks = child_blocks_sorted_y[min_overlap_area_list[0] + 1:]
                for child in new_block.child_blocks:
                    child_page = self.memorymanager.get_block(child[1])
                    if child_page is None:
                        child_page = self.memorymanager.load_block_from_file(self.file_path, child[1])
                    child_page.parent_id = new_block.block_id
                    self.memorymanager.add_block(child_page, self.file_path)
                new_block.mbr = group_mbr[min_overlap_area_list[0]][1]

                self.memorymanager.add_block(new_block, self.file_path)
                self.memorymanager.add_block(cur_block, self.file_path)
                return cur_block, new_block
            else:
                min_area = float('inf')
                min_area_index = -1
                for m in min_overlap_area_list:
                    mbr1 = get_mbr(child_blocks_sorted_y[0:m + 1])
                    mbr2 = get_mbr(child_blocks_sorted_y[m + 1:])
                    area = (mbr1[2] - mbr1[0]) * (mbr1[3] - mbr1[1]) + (mbr2[2] - mbr2[0]) * (mbr2[3] - mbr2[1])
                    if area < min_area:
                        min_area_index = m
                cur_block.child_blocks = child_blocks_sorted_y[0:min_area_index + 1]
                cur_block.mbr = group_mbr[min_area_index][0]
                new_block.child_blocks = child_blocks_sorted_y[min_area_index + 1:]
                for child in new_block.child_blocks:
                    child_page = self.memorymanager.get_block(child[1])
                    if child_page is None:
                        child_page = self.memorymanager.load_block_from_file(self.file_path, child[1])
                    child_page.parent_id = new_block.block_id
                    self.memorymanager.add_block(child_page, self.file_path)
                new_block.mbr = group_mbr[min_area_index][1]

                self.memorymanager.add_block(new_block, self.file_path)
                self.memorymanager.add_block(cur_block, self.file_path)
                return cur_block, new_block

    # 获取mbr2添加到mbr1中的面积与mb1原有面积的差

    def split_internal_block(self, cur_block, header):
        """
        分裂内部节点
        :param cur_block:
        :return:
        """

        header.END_BLOCK_NUMBER += 1

        new_block = InternalBLock(header.END_BLOCK_NUMBER)

        max_distance = -1
        max_items = None
        max_items_ids = None
        for i in range(len(cur_block.child_blocks) - 1):
            for j in range(i + 1, len(cur_block.child_blocks)):
                """distance = calculate_distance(cur_block.child_blocks[i][0], cur_block.child_blocks[j][0])
                if distance > max_distance:
                    max_distance = distance
                    max_items = [[cur_block.child_blocks[i][0], cur_block.child_blocks[i][1]],
                                 [cur_block.child_blocks[j][0], cur_block.child_blocks[j][1]]]
                    max_items_ids = [cur_block.child_blocks[i][1], cur_block.child_blocks[j][1]]"""
                distance = calculate_area_enlargement_(cur_block.child_blocks[i][0], cur_block.child_blocks[j][0])
                if distance > max_distance:
                    max_distance = distance
                    max_items = [[cur_block.child_blocks[i][0], cur_block.child_blocks[i][1]],
                                 [cur_block.child_blocks[j][0], cur_block.child_blocks[j][1]]]
                    max_items_ids = [cur_block.child_blocks[i][1], cur_block.child_blocks[j][1]]
        new_block.add_child_block(max_items[1][0], max_items[1][1])
        cur_block_ = [[max_items[0][0], max_items[0][1]]]
        cur_block_mbr = max_items[0][0]
        for child_block in cur_block.child_blocks:
            if child_block[1] not in max_items_ids:
                if calculate_area_enlargement(cur_block_mbr, child_block[0]) > calculate_area_enlargement(new_block.mbr,
                                                                                                          child_block[
                                                                                                              0]):
                    child_page = self.memorymanager.get_block(child_block[1])
                    if child_page is None:
                        child_page = self.memorymanager.load_block_from_file(self.file_path, child_block[1])
                    child_page.parent_id = new_block.block_id
                    new_block.add_child_block(child_block[0], child_block[1])
                    self.memorymanager.add_block(child_page, self.file_path)

                elif calculate_area_enlargement(cur_block_mbr, child_block[0]) < calculate_area_enlargement(
                        new_block.mbr,
                        child_block[
                            0]):
                    cur_block_.append([child_block[0], child_block[1]])
                    cur_block_mbr = update_mbr(cur_block_mbr, child_block[0])
                else:
                    if (cur_block_mbr[2] - cur_block_mbr[0]) * (cur_block_mbr[3] - cur_block_mbr[1]) > (
                            new_block.mbr[2] - new_block.mbr[0]) * (new_block.mbr[3] - new_block.mbr[1]):
                        new_block.add_child_block(child_block[0], child_block[1])
                    else:
                        cur_block_.append([child_block[0], child_block[1]])
                        cur_block_mbr = update_mbr(cur_block_mbr, child_block[0])

        cur_block.child_blocks = cur_block_
        cur_block.mbr = cur_block_mbr

        self.memorymanager.add_block(new_block, self.file_path)
        self.memorymanager.add_block(cur_block, self.file_path)
        return cur_block, new_block

    def _get_mbr(self, child_blocks):
        xmin, ymin, xmax, ymax = float('inf'), float('inf'), float('-inf'), float('-inf')
        for data_item in child_blocks:
            if data_item[0][0] < data_item[0][2]:
                xmin = min(xmin, data_item[0][0])
                xmax = max(xmax, data_item[0][2])
            else:
                xmin = min(xmin, data_item[0][2])
                xmax = max(xmax, data_item[0][0])
            if data_item[0][1] < data_item[0][3]:
                ymin = min(ymin, data_item[0][1])
                ymax = max(ymax, data_item[0][3])
            else:
                ymin = min(ymin, data_item[0][3])
                ymax = max(ymax, data_item[0][1])

        return [xmin, ymin, xmax, ymax]

    def range_search(self, query, data_file, node=None):
        """
        范围搜素
        :param query:
        :param memorymanager:
        :param node:
        :return:
        """

        global TOTAL
        if node is None:
            header = self._load_header_from_file()

            root_id = header.GPTR

            node = self.memorymanager.get_block(root_id)
            if node is None:
                node = self.memorymanager.load_block_from_file(self.file_path, root_id)

        # result = []

        if node.is_leaf == 1:

            for data in node.child_blocks:
                mbr = data[0]

                if _intersects(mbr, query):

                    data_block = self.data_buffer.get_block(data[1])
                    if data_block is None:
                        data_block = self.data_buffer.load_block_from_file(data_file, data[1])
                        self.data_buffer.add_block(data_block)
                        TOTAL += 1
                    for item in data_block.items:
                        if query[0] <= item[1] < query[2] and query[1] <= item[0] <= query[3]:
                            self.search_result.append([item[4], item[0], item[1], item[2], item[3]])
        elif node.is_leaf == 0:
            m = 0
            for child_block in node.child_blocks:

                if _intersects(child_block[0], query):

                    block = self.memorymanager.get_block(child_block[1])
                    if block is None:
                        block = self.memorymanager.load_block_from_file(self.file_path, child_block[1])
                        TOTAL += 1

                        self.memorymanager.add_block(block)

                    self.range_search(query, data_file, block)

    def _save_block(self, block):
        """
        保存块到磁盘上
        :param block:
        :return:
        """
        with open(self.file_path, 'rb+') as file:
            file.seek(block.block_id * INDEXBLOCKSIZE)
            file.write(block.pack())

    def _load_header_from_file(self):
        """
        从磁盘上加载头节点
        :return:
        """
        try:
            with open(self.file_path, 'rb') as file:
                file.seek(0)
                block_data = file.read(INDEXBLOCKSIZE)
                if len(block_data) == 0:
                    return None
                block = Header.unpack(Header, block_data)
                return block
        except FileNotFoundError:
            with open(self.file_path, 'wb'):
                pass
            return None


# 数据类，用于将数据分块存储到文件上
class Data:

    def __init__(self, input_files, output_file):
        self.input_files = input_files
        self.output_file = output_file

    """
    将.txt文件里的数据分块存储到.dat文件中
    """

    def extract_data(self):

        num_block = 0
        record_id = 0
        with open(self.output_file, 'wb') as output:
            file_list = os.listdir(self.input_files)
            for file_name in file_list:
                if file_name.endswith('txt'):
                    file_path = os.path.join(self.input_files, file_name)
                    with open(file_path, 'r') as file:
                        data_block = b''

                        for line in file.readlines():

                            fields = line.strip().split(',')

                            serialized_data = struct.pack('ddddII', float(fields[-4]), float(fields[-3]),
                                                          float(fields[-2]),
                                                          float(fields[-1]), int(fields[-5]), record_id)
                            if len(data_block) + len(serialized_data) > DATABLOCKSIZE:
                                output.seek(num_block * DATABLOCKSIZE)
                                num_block += 1
                                output.write(data_block)
                                data_block = b''

                            data_block += serialized_data
                            record_id += 1
                        output.seek(num_block * DATABLOCKSIZE)

                        output.write(data_block)

    def extract_data1(self, data_raw_file):
        with open(data_raw_file, 'rb') as file1:
            file_size = file1.read()
            num_block = 0

            record_id = (len(file_size) // DATABLOCKSIZE) * 204 + int(len(file_size) % DATABLOCKSIZE / DATA_PER_ITEM)
            data_block_ = b''

            with open(self.output_file, 'wb') as output:

                with open(self.input_files, 'r') as file:

                    for line in file.readlines():

                        fields = line.strip().split(',')

                        serialized_data = struct.pack('ddddII', float(fields[-4]), float(fields[-3]),
                                                      float(fields[-2]),
                                                      float(fields[-1]), int(fields[-5]), record_id)
                        if len(data_block_) + len(serialized_data) > DATABLOCKSIZE:
                            output.seek(num_block * DATABLOCKSIZE)
                            num_block += 1

                            output.write(data_block_)
                            data_block_ = b''

                        data_block_ += serialized_data
                        record_id += 1
                    output.seek(num_block * DATABLOCKSIZE)

                    output.write(data_block_)
        with open(data_raw_file, 'rb+') as file1:
            file_size = file1.read()

            num_block = len(file_size) // DATABLOCKSIZE
            record_id = len(file_size) // DATABLOCKSIZE * 204 + int(len(file_size) % DATABLOCKSIZE / DATA_PER_ITEM)
            data_block_ = b''
            length_num = int((len(file_size) - (len(file_size) // DATABLOCKSIZE) * DATABLOCKSIZE) / DATA_PER_ITEM)
            offset = 0

            for i in range(length_num):
                file1.seek((len(file_size) // DATABLOCKSIZE) * DATABLOCKSIZE + offset)
                data = struct.unpack('ddddII', file1.read(DATA_PER_ITEM))
                print(data)
                data_block_ += struct.pack('ddddII', float(data[0]), float(data[1]), float(data[2]),
                                           float(data[3]), int(data[4]), int(data[5]))
                offset += DATA_PER_ITEM
            with open(self.input_files, 'r') as file:

                for line in file.readlines():

                    fields = line.strip().split(',')

                    serialized_data = struct.pack('ddddII', float(fields[-4]), float(fields[-3]),
                                                  float(fields[-2]),
                                                  float(fields[-1]), int(fields[-5]), record_id)
                    if len(data_block_) + len(serialized_data) > DATABLOCKSIZE:
                        file1.seek(num_block * DATABLOCKSIZE)
                        num_block += 1

                        file1.write(data_block_)
                        data_block_ = b''

                    data_block_ += serialized_data
                    record_id += 1
                file1.seek(num_block * DATABLOCKSIZE)

                file1.write(data_block_)


def create(data_file, index_path):
    """
    创建索引
    :param data_file:
    :param index_path:
    :return:
    """
    file_path = index_path
    memorymanager = MemoryManager(MAX_BLOCKS)
    data_buffer = DataBuffer(MAX_BLOCKS)

    input_files = data_file
    output_file_name = input_files.split(".")[0]
    output_file = output_file_name + '.dat'
    if not os.path.exists(output_file):
        with open(output_file, 'wb') as file:
            pass
    index = RtreeIndex(file_path, memorymanager, data_buffer, output_file)
    """data = Data(input_files, output_file)
    data.extract_data()"""
    index.create_index(input_files)


def create1(data_raw_file, data_file, index_path):
    """
    创建索引
    :param data_file:
    :param index_path:
    :return:
    """
    file_path = index_path
    memorymanager = MemoryManager(MAX_BLOCKS)

    index = RtreeIndex(file_path, memorymanager)
    input_files = data_file
    output_file_name = input_files.split(".")[0]
    output_file = output_file_name + '.dat'
    data = Data(input_files, output_file)
    data.extract_data1(data_raw_file)
    index.create_index(output_file)

    print(TOTAL / index.num)  # 平均13次"""


def search(range_data_file, index_file, data_file):
    """
    查询数据
    :param data_file:
    :param index_file:
    :return:
    """
    memorymanager = MemoryManager_query(MAX_BLOCKS)
    data_buffer = DataBuffer_query(MAX_BLOCKS)

    index = RtreeIndex(index_file, memorymanager, data_buffer, data_file)

    with open(range_data_file, 'r') as file:
        lines = file.readlines()  # 读取所有行

    totaltime = timedelta()
    total_ = 0
    for line in lines:
        line = line.strip()  # 去除行尾的换行符
        data = line.split(',')  # 按逗号分隔每行的数据
        time1 = datetime.now()
        sum = []
        # result = index.range_search([float(data[0]), float(data[2]), float(data[1]), float(data[3])], memorymanager,data_file)
        index.range_search([float(data[1]), float(data[3]), float(data[0]), float(data[2])],
                           data_file)
        sum.append(TOTAL)
        print(TOTAL)
        # print(index.search_result)
        time2 = datetime.now()
        time = time2 - time1
        totaltime += time
    totaltime = totaltime.total_seconds()
    avgtime = totaltime / 100
    print(avgtime)  # 平均查询时间0.02
    print(TOTAL / 100)


def place_data(model_file, raw_data_file, data_file):
    data_dict = {}
    mm = 0
    num_block = 0
    with open(data_file, 'wb') as file:
        data_block = b''
        with open(raw_data_file, 'rb') as data:
            with open(model_file, 'rb') as model:
                model.seek(0)

                block = model.read(INDEXBLOCKSIZE)
                begin_offset, GPTR, BLOCKSIZE, END_BLOCK_NUMBER, GMBR0, GMBR1, GMBR2, GMBR3 = struct.unpack('IIII4d',
                                                                                                            block[:48])

                leaf_node_result = []
                get_leaf_node(GPTR, model_file, leaf_node_result)
                print(leaf_node_result)
                for record_id in leaf_node_result:

                    data.seek(((record_id // (DATABLOCKSIZE // DATA_PER_ITEM)) * DATABLOCKSIZE) + (
                            record_id % (DATABLOCKSIZE // DATA_PER_ITEM)) * DATA_PER_ITEM)
                    record = data.read(DATA_PER_ITEM)
                    pos, t, lon, lat, mo, id = struct.unpack('ddddII', record)

                    data_dict[id] = mm
                    serialized_data = struct.pack('ddddI', pos, t, lon, lat, mo)
                    if len(data_block) + len(serialized_data) > DATABLOCKSIZE:
                        file.seek(num_block * DATABLOCKSIZE)
                        num_block += 1
                        file.write(data_block)
                        data_block = b''

                    data_block += serialized_data

                    mm += 1
            file.seek(num_block * DATABLOCKSIZE)

            file.write(data_block)
    with open('data_dict.pkl', 'wb') as pkl:
        pickle.dump(data_dict, pkl)


def get_leaf_node(b_id, model_path, leaf_node_result):
    with open(model_path, 'rb') as model:
        model.seek(b_id * INDEXBLOCKSIZE)
        block = model.read(INDEXBLOCKSIZE)

        block_type = struct.unpack('?', block[44:45])[0]
        print(type(block_type))
        if block_type:
            unpacked_values = struct.unpack('4dIII?', block[:45])
            num_items = unpacked_values[5]
            offset = 45
            for i in range(num_items):
                record_id = struct.unpack('I', block[offset + 32:offset + 36])[0]
                leaf_node_result.append(record_id)
                offset += 36
        else:
            unpacked_values = struct.unpack('4dIII?', block[:45])
            num_items = unpacked_values[5]

            offset = 45
            for i in range(num_items):
                block_id = struct.unpack('I', block[offset + 32:offset + 36])[0]
                get_leaf_node(block_id, model_path, leaf_node_result)
                offset += 36


def main_rstar():
    """file_path = INDEXFILE
    memorymanager = MemoryManager(MAX_BLOCKS)
    memorymanager.connect_to_database()
    memorymanager.recover_cache(file_path=file_path)
    index = RtreeIndex(file_path, memorymanager)
    input_files = "data1.txt"
    output_file = DATAFILE
    data = Data(input_files, output_file)
    data.extract_data()
    index.create_index(output_file)
    memorymanager.close_database()
    cache_path='./cache.db'
    last_point_path='./insert_point.txt'
    os.remove(cache_path)
    os.remove(last_point_path)
    print(TOTAL / index.num)


    memorymanager = MemoryManager(MAX_BLOCKS)
    memorymanager.connect_to_database()
    memorymanager.recover_cache(file_path=file_path)
    index = RtreeIndex(file_path, memorymanager)

    with open('data1.txt', 'r') as file:
        lines = file.readlines()  # 读取所有行

    totaltime = timedelta()
    for i in range(0, 500):
        line = lines[i].strip()  # 去除行尾的换行符
        data = line.split(',')  # 按逗号分隔每行的数据
        time1 = datetime.now()

        result = index.range_search([float(data[0]), float(data[1]), float(data[2]), float(data[3])],memorymanager)
        print(result)
        time2 = datetime.now()
        time = time2 - time1
        totaltime += time
    totaltime = totaltime.total_seconds()
    avgtime = totaltime /500
    print(avgtime)  """
    while True:
        print("请选择操作：")
        print("1. 创建索引")
        print("2. 从索引中搜索")
        print("0. 退出")

        choice = input("请输入操作编号: ")

        if choice == "1":
            data_file_build = input("请输入已经建立数据文件位置（如果有，输入文件位置，如果没有输入数字9）:")
            if data_file_build == "9":

                data_file = input("请输入数据文件位置: ")
                index_file = input("请输入新建立索引文件的位置: ")
                """data_file = "E:\chengxu\Rtree2\\0.txt"
                index_file = "E:\chengxu\Rtree2\\model.idx"""
                create(data_file, index_file)
            else:
                data_file = input("请输入需要建立索引的数据文件位置: ")
                index_file = input("请输入原来建立索引文件的位置: ")
                create1(data_file_build, data_file, index_file)
        elif choice == "2":
            """range_data_file = input("请输入查询数据文件位置: ")
            index_file = input("请输入索引文件位置: ")
            data_file = input("请输入数据文件位置(以.dat结尾): ")"""
            data_file = "E:\chengxu\Rtree2\\0.dat"
            index_file = "E:\chengxu\Rtree2\\model.idx"
            range_data_file = "E:\dataset\sim_range_query\\0.txt"
            search(range_data_file, index_file, data_file)
        elif choice == "0":
            break
        else:
            print("无效的选择，请重新输入。")


if __name__ == "__main__":
    main_rstar()
    """model_file = "E:\dataset\模拟数据-R树\\r_0\model.idx"
    raw_data_file = "E:\dataset\模拟数据-R树\\r_0\data.dat"
    data_file = "E:\dataset\模拟数据-R树\\r_0\data_trans.dat"
    place_data(model_file, raw_data_file, data_file)"""
