import pandas as pd
import numpy as np
import os
from collections import deque
import networkx as nx
import pickle


class Point:
    def __init__(self, seg_id, seg_pos, t):
        """
        轨迹点类
        :param seg_id:路段id
        :param seg_pos: 轨迹点在路段相对位置
        :param t: 轨迹点的时间
        """
        self.seg_id = seg_id
        self.seg_pos = seg_pos
        self.t = t

    def __eq__(self, other):
        return self.seg_id == other.seg_id and self.seg_pos == other.seg_pos and self.t == other.t

    def __hash__(self):
        return hash(self.seg_id) * hash(self.seg_pos) * hash(self.t)

    def __str__(self):
        return "{seg_id:%s\tseg_pos:%f\tt:%f}" % (self.seg_id, self.seg_pos, self.t)


class Segment:
    def __init__(self, seg_id, start_junction, end_junction, length, lane_number, edgesMerged):
        """
        路段类
        :param seg_id: 路段id
        :param start_junction:路段开始交叉口
        :param end_junction: 路段结束交叉口
        :param length: 路段长度
        :param lane_number: 路段车道数
        :param edgesMerged: 合并的路段
        """
        self.seg_id = seg_id
        self.start_junction = start_junction
        self.end_junction = end_junction
        self.length = length
        self.lane_number = lane_number
        self.edgesMerged = edgesMerged
        self.next_segments = []
        self.pre_segments = []
        self.next_segments_dict = {}
        self.pre_segments_dict = {}

    def __hash__(self):
        return hash(self.seg_id)

    def __eq__(self, other):
        return self.seg_id == other.seg_id

    def __str__(self):
        return "{seg_id:%s\tstart_junction:%s\tend_junction:%s\tseg_len:%f\tlane_number:%s}" % \
               (self.seg_id, self.start_junction, self.end_junction, self.length, self.lane_number)


def sort_segment(G, segment_list, segment_dict):
    stack = []
    sort_segs = {}
    current_order = 0

    while len(segment_list) > 0:
        start_node = segment_list[0].seg_id
        stack.append(start_node)
        sort_segs[start_node] = current_order
        current_order += 1

        while len(stack) > 0:
            current_node = stack.pop()

            if segment_dict[current_node] in segment_list:
                segment_list.remove(segment_dict[current_node])
                neighbors = list(G.neighbors(current_node))
                unvisited_neighbors = [node for node in neighbors if segment_dict[node] in segment_list]
                if len(unvisited_neighbors) > 0:
                    # 找到未访问的邻居中权值最大的边
                    max_weight = -float('inf')
                    max_weight_neighbor = None

                    for neighbor in unvisited_neighbors:
                        edge_data = G[current_node][neighbor]
                        weight = edge_data['weight']

                        if weight > max_weight:
                            max_weight = weight
                            max_weight_neighbor = neighbor

                    stack.append(max_weight_neighbor)
                    sort_segs[max_weight_neighbor] = current_order
                    print(len(sort_segs))
                    current_order += 1

    # 打印节点的排序序号
    for node, node_order in sort_segs.items():
        print(f'节点 {node} 的排序序号: {node_order}')
    return sort_segs


def calculate_traversal_frequency(traj_path, segment_list, segment_dict, segment_to_segmentMerged):
    file_list = os.listdir(traj_path)
    segment_traversed = {}
    for key, value in segment_dict.items():
        segment_traversed[key] = 0
    for file_name in file_list:
        print(file_name)
        file = os.path.join(traj_path, file_name)
        df = pd.read_csv(file)
        df = df.drop_duplicates(subset=['edgeID'], keep='first')
        tra = []
        tra_seg = []
        for i in range(len(df)):
            if pd.isnull(df.iloc[i]['edgeID']):
                break
            seg_id = df.iloc[i]['edgeID']

            seg_pos = df.iloc[i]['edgePos']
            t = df.iloc[i]['timestep']
            p = Point(seg_id, seg_pos, t)
            tra.append(p)
        for i in range(len(tra) - 1):
            p = tra[i]
            p_next = tra[i + 1]
            seg = segment_dict[segment_to_segmentMerged[p.seg_id]]
            seg_next = segment_dict[segment_to_segmentMerged[p_next.seg_id]]
            if seg.seg_id not in tra_seg:
                tra_seg.append(seg.seg_id)
            if seg_next.seg_id not in tra_seg:
                tra_seg.append(seg_next.seg_id)

            if p.seg_id != p_next.seg_id:
                for j in range(len(seg.next_segments)):
                    if seg.next_segments[j][0] == p_next.seg_id:
                        seg.next_segments[j][1] += 1
        for i in range(len(tra_seg)):
            segment_traversed[tra_seg[i]] += 1
    # for key, value in segment_dict.items():
    for i in range(len(segment_list)):
        for j in range(len(segment_list[i].next_segments)):
            if segment_list[i].next_segments[j][1] == 0 or segment_traversed[segment_list[i].seg_id] == 0:
                segment_dict[segment_list[i].seg_id].next_segments[j][1] = 0
                segment_list[i].next_segments[j][1] = 0

            else:
                segment_dict[segment_list[i].seg_id].next_segments[j][1] = segment_list[i].next_segments[j][1] / \
                                                                           segment_traversed[segment_list[i].seg_id]
                segment_list[i].next_segments[j][1] = segment_list[i].next_segments[j][1] / segment_traversed[
                    segment_list[i].seg_id]
    return segment_list, segment_dict


def segmentMerged_to_segment(segment_dict):
    segment_to_segmentMerged = {}
    for key, value in segment_dict.items():
        key_list = value.edgesMerged

        if key_list == ['None']:
            segment_to_segmentMerged[key] = key
        else:
            for k in key_list:
                segment_to_segmentMerged[k] = key
    return segment_to_segmentMerged


def construct_graph(segment_dict):
    G = nx.Graph()
    for key, value in segment_dict.items():
        G.add_node(key)
        for i in range(len(value.next_segments)):
            G.add_node(value.next_segments[i][0])
            G.add_edge(key, value.next_segments[i][0], weight=value.next_segments[i][1])

    return G


def read_seg(seg_path):
    seg_csv = pd.read_csv(seg_path)
    segment_list = []
    segment_dict = {}
    junction_next_seg = {}

    junction_pre_seg = {}
    for i in range(len(seg_csv)):

        start_junction = seg_csv.iloc[i]['start']
        end_junction = seg_csv.iloc[i]['end']
        if start_junction not in junction_next_seg.keys():
            junction_next_seg[start_junction] = []
        if start_junction not in junction_pre_seg.keys():
            junction_pre_seg[start_junction] = []
        if end_junction not in junction_next_seg.keys():
            junction_next_seg[end_junction] = []
        if end_junction not in junction_pre_seg.keys():
            junction_pre_seg[end_junction] = []
        seg_id = seg_csv.iloc[i]['edgeId']
        if seg_id not in segment_dict.keys():
            segment_dict[seg_id] = None
    for i in range(len(seg_csv)):
        seg_id = seg_csv.iloc[i]['edgeId']
        start_junction = seg_csv.iloc[i]['start']
        end_junction = seg_csv.iloc[i]['end']
        length = int(seg_csv.iloc[i]['length'])
        lane_number = int(seg_csv.iloc[i]['laneNumber'])
        edgesMerged = seg_csv.iloc[i]['edgesMerged'].replace("[", "").replace("]", "").replace("'", "").replace(" ",
                                                                                                                "").split(
            ',')

        if len(junction_next_seg[start_junction]) == 0:
            junction_next_seg[start_junction] = [[seg_id, 0]]
        else:
            junction_next_seg[start_junction].append([seg_id, 0])
        if len(junction_pre_seg[end_junction]) == 0:
            junction_pre_seg[end_junction] = [[seg_id, 0]]
        else:
            junction_pre_seg[end_junction].append([seg_id, 0])
        seg = Segment(seg_id, start_junction, end_junction, length, lane_number, edgesMerged)
        segment_list.append(seg)
        segment_dict[seg_id] = seg
    for i in range(len(segment_list)):
        segment_list[i].pre_segments = junction_pre_seg[segment_list[i].start_junction]
        segment_list[i].next_segments = junction_next_seg[segment_list[i].end_junction]
        segment_dict[segment_list[i].seg_id].next_segments = junction_next_seg[segment_list[i].end_junction]
        segment_dict[segment_list[i].seg_id].pre_segments = junction_pre_seg[segment_list[i].start_junction]
    return segment_list, segment_dict


def save_sort_segs_to_file(sort_segs, filename):
    with open(filename, 'wb') as file:
        pickle.dump(sort_segs, file)


def load_sort_segs_from_file(filename):
    with open(filename, 'rb') as file:
        return pickle.load(file)


if __name__ == '__main__':
    seg_path = '合并后路段表merge_edit_lanes_BeijingEdges.csv'
    traj_path = 'E:\dataset\simulation4-1'
    segment_to_segmentMerged_file='合并前后对照字典imulation_merge_name_dict.pkl'
    # traj_path = 'E:\\dataset\\lunwen\\test'
    sort_segs_file = 'sort_segment.pkl'
    segment_list, segment_dict = read_seg(seg_path)
    segment_to_segmentMerged=load_sort_segs_from_file(segment_to_segmentMerged_file)

    segment_list, segment_dict = calculate_traversal_frequency(traj_path, segment_list, segment_dict,
                                                               segment_to_segmentMerged)
    G = construct_graph(segment_dict)
    sort_segs = sort_segment(G, segment_list, segment_dict)
    print(len(segment_dict))
    save_sort_segs_to_file(sort_segs, sort_segs_file)
