import os
import pickle
import numpy as np
import pandas as pd


def inner_partition_all_pd(time_partition: dict, segment_partition: dict, seg_mapping_partition: dict,
                           time_mapping: dict,
                           seg_mapping_sort, all_file_path,
                           output_file_paths, W):
    file_name_list = os.listdir(all_file_path)
    file_number = 0
    for file_name in file_name_list:
        print(f'file_name')

        ff_ = os.path.splitext(file_name)[0]
        output_file_path = os.path.join(output_file_paths, ff_)
        os.makedirs(output_file_path)
        file_path = os.path.join(all_file_path, file_name)
        base_time = 0
        inner_partition(time_partition, segment_partition, seg_mapping_partition, time_mapping,
                        seg_mapping_sort, file_path,
                        output_file_path, file_number, W, base_time)
        file_number += 1


def inner_partition(time_partition: dict, segment_partition: dict, seg_mapping_partition: dict, time_mapping: dict,
                    seg_mapping_sort, file_path,
                    output_file_path, file_number, W, base_time):
    """

    :param time_partition:存储字典，键值为0，1，对应时间区间
    :param segment_partition:存储字典，划分的分区1，2，3……，对应的路段列表[seg1,seg2……],[seg5,seg6……]
    :return:
    """
    output_file_paths = {}
    out_dict = {}
    for time_partition_id, seg_partition in segment_partition.items():
        for seg_partition_id in seg_partition.keys():
            file_name = output_file_path + "\\" + str(time_partition_id) + "_" + str(seg_partition_id) + '.txt'
            output_file_paths[seg_partition_id] = file_name
            out_dict[seg_partition_id] = []
            with open(file_name, 'w'):
                pass
    with open(file_path, 'r') as file:
        print(file_path)

        nn = 0
        cc = 0
        # base_time = file_number * 86400

        for line in file.readlines():

            line = line.strip().split(',')
            mo1 = line[0]
            pos1 = float(line[1])
            timestamp1 = float(line[2])
            lon = float(line[3])
            lat = float(line[4])
            mo2 = line[0]
            pos2 = float(line[1])
            timestamp2 = float(line[2])

            time_partition_id = None
            time_id = None
            for key, value in time_partition.items():
                for i in range(len(value)):
                    if value[i][0] <= timestamp2 % 86400 < value[i][1]:
                        time_partition_id = key
                        time_id = (key, i)
            if (int(pos2) in seg_mapping_partition[time_partition_id].keys()) and (
                    int(pos2) in seg_mapping_sort[time_partition_id].keys()):

                seg_partition_id = seg_mapping_partition[time_partition_id][int(pos2)]
                pos2 = seg_mapping_sort[time_partition_id][int(pos2)] + (pos2 - int(pos2))
                time_ = timestamp2 % 86400
                tf = 0
                n = 0
                m = 0
                key = -1
                for i in range(len(time_partition[0])):
                    if (time_partition[0][i][0] - base_time) <= time_ < (time_partition[0][i][1] - base_time):

                        if i == 0:
                            tf = (n + time_ - (time_partition[0][i][0] - base_time))
                            key = 0
                        else:
                            n += (time_partition[0][i - 1][1] - time_partition[0][i - 1][0])
                            tf = (n + time_ - (time_partition[0][i][0] - base_time))
                            key = 0

                for i in range(len(time_partition[1])):
                    if (time_partition[1][i][0] - base_time) <= time_ < (time_partition[1][i][1] - base_time):

                        if i != 0:
                            m += (time_partition[1][i - 1][1] - time_partition[1][i - 1][0])
                        tf = (m + time_ - (time_partition[1][i][0] - base_time))
                        key = 1
                # timestamp = ((timestamp - base_time) // 86400) * (W[key]) + tf
                timestamp2 = tf
                # timestamp = timestamp - time_mapping[time_id[0]][time_id[1]]
                out_dict[seg_partition_id].append([mo2, pos2, timestamp2, mo1, pos1, timestamp1, lon, lat])
                nn += 1
            else:
                cc += 1
                print(f'cc={cc}')

    file_list = os.listdir(output_file_path)
    for file_name in file_list:

        seg_partition_id = int(os.path.splitext(file_name)[0].split('_')[1])
        file_ = os.path.join(output_file_path, file_name)
        with open(file_, 'w') as file:
            for item in out_dict[seg_partition_id]:
                file.write(f'{item[0]},{item[1]},{item[2]},{item[3]},{item[4]},{item[5]},{item[6]},{item[7]}\n')


def time_seg_partition(time_partition: dict, segment_partition: dict, sort_segment: dict):
    """
    存储时间分区和路段分区对应的SM矩阵
    :param time_partition:
    :param segment_partition:
    :return:
    """
    seg_mapping_sort = {}  # 路段在对应区间的重新排序值
    seg_mapping_partition = {}  # 路段对应的路段分区
    SM = [[None for _ in range(len(sort_segment))] for _ in range(len(time_partition))]

    for time_partition_id, time_range in time_partition.items():
        time_partition_id = int(time_partition_id)
        segs_dict = segment_partition[time_partition_id]
        seg_mapping_sort[time_partition_id] = {}
        seg_mapping_partition[time_partition_id] = {}

        for seg_partition_id, segs in segs_dict.items():
            seg_partition_id = int(seg_partition_id)

            sort_segs = sorted(segs)
            sort_segs = [(sort_segs.index(x), x) for x in segs]

            for seg in sort_segs:
                seg_mapping_partition[time_partition_id][int(seg[1])] = seg_partition_id
                seg_mapping_sort[time_partition_id][int(seg[1])] = seg[0]
                SM[time_partition_id][int(seg[1])] = (seg_partition_id, seg[0])
    return seg_mapping_sort, seg_mapping_partition, SM


def sort(file_path, outputfile_path):
    if not os.path.exists(outputfile_path):
        os.makedirs(outputfile_path)
    folders_name = os.listdir(file_path)
    for folder in folders_name:
        folder_path = os.path.join(file_path, folder)
        f_list = os.listdir(folder_path)
        output_folder = os.path.join(outputfile_path, folder)
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)
        for f_ in f_list:
            f_path = os.path.join(folder_path, f_)
            ff_ = os.path.splitext(f_)[0] + '_new.txt'

            out_path = os.path.join(output_folder, ff_)
            data = pd.read_csv(f_path, delimiter=',', header=None,
                               names=['mo', 'pos', 't', 'mo1', 'pos1', 't1', 'lon', 'lat'])
            mo_list = data['mo'].values
            t_list = data['t'].values
            pos_list = data['pos'].values
            mo1_list = data['mo1'].values
            t1_list = data['t1'].values
            pos1_list = data['pos1'].values
            lon_list = data['lon'].values
            lat_list = data['lat'].values
            data1 = list(zip(mo_list, t_list, pos_list, mo1_list, t1_list, pos1_list, lon_list, lat_list))

            sorted_data = sorted(data1, key=lambda item: (item[2]))
            sorted_data = sorted(sorted_data, key=lambda item: int(item[1] / 1800))

            sorted_data = [(mo, x, y, idx, mo1, x1, y1, lon, lat) for idx, (mo, x, y, mo1, x1, y1, lon, lat) in
                           enumerate(sorted_data)]

            sorted_data = sorted(sorted_data, key=lambda item: item[3])
            with open(out_path, 'w') as f:

                for i in range(len(sorted_data)):
                    mo = sorted_data[i][0]
                    t = sorted_data[i][1]
                    pos = sorted_data[i][2]
                    idx = sorted_data[i][3]
                    mo1 = sorted_data[i][4]
                    t1 = sorted_data[i][5]
                    pos1 = sorted_data[i][6]
                    lon = sorted_data[i][7]
                    lat = sorted_data[i][8]
                    f.write(f'{mo},{t},{pos},{idx},{mo1},{t1},{pos1},{lon},{lat}\n')


def k_order(file_path):
    f_list = os.listdir(file_path)
    for f_ in f_list:
        f_path = os.path.join(file_path, f_)
        ff_ = os.path.splitext(f_)[0] + '_k_order.txt'
        out_path = os.path.join(file_path, ff_)
        data = pd.read_csv(f_path, delimiter=',', header=None, names=['pos', 't', 'sort_value'])
        t_list = data['t'].values
        pos_list = data['pos'].values
        sort_value_list = data['sort_value'].values
        data_list = list(zip(t_list, pos_list, sort_value_list))
        data_new_list = []
        for i in range(len(data_list)):
            if i == 0:
                data_new_list.append(
                    [(data_list[i][0] + data_list[i + 1][0]) / 2, (data_list[i][1] + data_list[i + 1][1]) / 2,
                     data_list[i][2]])
            elif i == len(data_list) - 1:
                data_new_list.append(
                    [(data_list[i][0] + data_list[i - 1][0]) / 2, (data_list[i][1] + data_list[i - 1][1]) / 2,
                     data_list[i][2]])
            else:
                data_new_list.append([(data_list[i][0] + data_list[i - 1][0] + data_list[i + 1][0]) / 3,
                                      (data_list[i][1] + data_list[i - 1][1] + data_list[i + 1][1]) / 3,
                                      data_list[i][2]])
        with open(out_path, 'w') as f:

            for i in range(len(data_new_list)):
                t = '{:.2f}'.format(data_new_list[i][0])
                pos = '{:.2f}'.format(data_new_list[i][1])
                idx = data_new_list[i][2]
                f.write(f'{t},{pos},{idx}\n')


def save_to_file(file_, filename):
    with open(filename, 'wb') as file:
        pickle.dump(file_, file)


def load_from_file(filename):
    with open(filename, 'rb') as file:
        return pickle.load(file)


def seg_partition_mapping_consistent(segment_partition):
    num = 0
    new_segment_partition = {}
    for time_partition_id, partition in segment_partition.items():
        new_segment_partition[time_partition_id] = {}
    for time_partition_id, partition in segment_partition.items():
        new_segment_partition = {}
        for key, value in partition.items():
            new_segment_partition[time_partition_id][num] = value
            num += 1
    return new_segment_partition


def data_(txt_file, output_file):
    file_list = os.listdir(txt_file)
    for file_name in file_list:
        print(f'file_name')

        #ff_ = os.path.splitext(file_name)[0]
        output_file_path = os.path.join(output_file, file_name)
        if not os.path.exists(output_file_path):
            with open(output_file_path,"w") as fff:
                pass
        file_path = os.path.join(txt_file, file_name)
        m = 0
        with open(output_file_path, 'w') as output_file_:
            with open(file_path, 'r') as file:
                for line in file.readlines():
                    if m % 10 == 0:
                        line = line.strip().split(',')
                        mo1 = line[0]
                        pos1 = float(line[1])
                        timestamp1 = float(line[2])
                        lon = float(line[3])
                        lat = float(line[4])
                        mo2 = line[0]
                        pos2 = float(line[1])
                        timestamp2 = float(line[2])
                        output_file_.write(f'{mo1},{pos1},{timestamp1},{lon},{lat},{mo2},{pos2},{timestamp2}\n')

                        m += 1
                    else:
                        m += 1
def presort():
    os.chdir("..")
    os.chdir("..")
    os.chdir("..")
    os.chdir("..")
    cur_dir=os.getcwd()
    print(cur_dir)
    file_path = f'{cur_dir}\\dataset\\sim'
    sort_file_path = f"{cur_dir}\\dataset\\sort_file"
    output_file_paths = f"{cur_dir}\\dataset\\period_file"
    seg_mapping_sort_pkl = f'{cur_dir}\\code\\PPT\\preprocess\\preprocess_sim\\pkl_sim\\seg_mapping_sort_3.pkl'
    seg_mapping_partition_pkl = f'{cur_dir}\\code\\PPT\\preprocess\\preprocess_sim\\pkl_sim\\seg_mapping_partition_3.pkl'
    sort_segment_pkl = f'{cur_dir}\\code\\PPT\\preprocess\\preprocess_sim\\pkl_sim\\sort_segment.pkl'
    segment_partition_pkl = f'{cur_dir}\\code\\PPT\\preprocess\\preprocess_sim\\pkl_sim\\assignments_3.pkl'
    SM_pkl = f'{cur_dir}\\code\\PPT\\preprocess\\preprocess_sim\\pkl_sim\\SM_3.pkl'

    time_partition = {0: [[25200, 68400]], 1: [[0, 25200], [68400, 86400]]}
    time_mapping = {0: {0: 25200}, 1: {0: 0, 1: 43200}}
    W = {0: 43200, 1: 43200}
    #data_(file_path, output_file)
    # segment_partition = {0: {0: [2, 3, 1], 1: [5, 0, 4]}, 1: {2: [2, 1], 3: [5, 4], 4: {3, 0}}}
    segment_partition = load_from_file(segment_partition_pkl)

    sort_segment = load_from_file(sort_segment_pkl)
    """seg_mapping_sort, seg_mapping_partition, SM = time_seg_partition(time_partition, segment_partition, sort_segment)
    save_to_file(SM, SM_pkl)
    save_to_file(seg_mapping_sort, seg_mapping_sort_pkl)
    save_to_file(seg_mapping_partition, seg_mapping_partition_pkl)"""
    seg_mapping_sort = load_from_file(seg_mapping_sort_pkl)
    seg_mapping_partition = load_from_file(seg_mapping_partition_pkl)
    SM = load_from_file(SM_pkl)
    inner_partition_all_pd(time_partition, segment_partition, seg_mapping_partition, time_mapping,
                           seg_mapping_sort, file_path,
                           output_file_paths, W)
    sort(output_file_paths, sort_file_path)

if __name__ == '__main__':
    """file_path = 'E:\dataset\\txt_simulation4-1_point_1'
    sort_file_path = "E:\dataset\\txt_simulation4-1_period_sort_200"
    output_file_paths = 'E:\dataset\\txt_simulation4-1_period_200'
    seg_mapping_sort_pkl = 'seg_mapping_sort_3.pkl'
    seg_mapping_partition_pkl = 'seg_mapping_partition_3.pkl'
    sort_segment_pkl = 'E:\chengxu\experiment\pkl文件\\sort_segment.pkl'
    segment_partition_pkl = 'E:\chengxu\experiment\pkl文件\\assignments_3.pkl'
    SM_pkl = 'E:\chengxu\experiment\pkl文件\\SM_3.pkl'
    output_file="E:\dataset\\txt_simulation4-1_point_200"
    time_partition = {0: [[25200, 68400]], 1: [[0, 25200], [68400, 86400]]}
    time_mapping = {0: {0: 25200}, 1: {0: 0, 1: 43200}}
    W = {0: 43200, 1: 43200}
    data_(file_path, output_file)
    # segment_partition = {0: {0: [2, 3, 1], 1: [5, 0, 4]}, 1: {2: [2, 1], 3: [5, 4], 4: {3, 0}}}
    segment_partition = load_from_file(segment_partition_pkl)

    sort_segment = load_from_file(sort_segment_pkl)
    seg_mapping_sort, seg_mapping_partition, SM = time_seg_partition(time_partition, segment_partition, sort_segment)
    save_to_file(SM, SM_pkl)
    save_to_file(seg_mapping_sort, seg_mapping_sort_pkl)
    save_to_file(seg_mapping_partition, seg_mapping_partition_pkl)
    seg_mapping_sort = load_from_file(seg_mapping_sort_pkl)
    seg_mapping_partition = load_from_file(seg_mapping_partition_pkl)
    SM = load_from_file(SM_pkl)
    inner_partition_all_pd(time_partition, segment_partition, seg_mapping_partition, time_mapping,
                           seg_mapping_sort, output_file,
                           output_file_paths, W)
    sort(output_file_paths, sort_file_path)"""

    preprocess()
