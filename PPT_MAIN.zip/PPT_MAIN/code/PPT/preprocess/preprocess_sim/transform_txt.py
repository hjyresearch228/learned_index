import pandas as pd
import pickle
import os
import copy
import numpy as np


def transform(sort_segment, seg_to_Merged, data_file, txt_data_file, seg_mg_lens_dic):
    """
    原始数据转化为pos,t
    :param sort_segment:
    :param seg_to_Merged:
    :param data_file:
    :return:
    """
    if not os.path.exists(txt_data_file):
        os.makedirs(txt_data_file)
    file_list = os.listdir(data_file)
    directory, filename = os.path.split(data_file)
    filename = filename + ".txt"
    txt_data_file_ = os.path.join(txt_data_file, filename)

    with open(txt_data_file_, 'a') as txt_file:
        mo_list = []
        pos_list = []
        time_list = []
        lon_list=[]
        lat_list=[]
        for file in file_list:
            print(file)
            mo = file.split('_')[0]
            file_ = os.path.join(data_file, file)
            df = pd.read_csv(file_)
            df.dropna(subset=['edgeID'])
            for index, row in df.iterrows():
                if row['edgeID'] in seg_to_Merged.keys():
                    edgeID_ = sort_segment[seg_to_Merged[row['edgeID']]]
                    edges = seg_to_Merged[row['edgeID']].split('&&')

                    length = 0
                    for i in range(len(edges)):
                        if edges[i] != row['edgeID']:
                            length += seg_mg_lens_dic[seg_to_Merged[row['edgeID']]][i]
                        else:
                            break
                    total_length = 0
                    for i in range(len(seg_mg_lens_dic[seg_to_Merged[row['edgeID']]])):
                        total_length += seg_mg_lens_dic[seg_to_Merged[row['edgeID']]][i]
                    pos = int(edgeID_) + ((float(row['edgePos']) + length) / total_length)
                    t = row['timestep']
                    lon=row['Lon']
                    lat=row['Lat']
                    mo_list.append(mo)
                    pos_list.append(pos)
                    time_list.append(t)
                    lon_list.append(lon)
                    lat_list.append(lat)
        for mo_, pos_, t_ ,lon_,lat_ in zip(mo_list, pos_list, time_list,lon_list,lat_list):
            txt_file.write(f'{mo_},{pos_},{t_},{lon_},{lat_}\n')
            """df['edgeID_merged']=df['edgeID'].map(seg_to_Merged)
            df['edgeID_'] = df['edgeID'].map(seg_to_Merged).map(sort_segment)

            df['edges'] = df['edgeID_merged'].str.split('&&')
            df['length'] = 0
            df['total_length'] = 0
            for index,row in df.iterrows():

                length = 0

                for i in range(len(row['edges'])):
                    if row['edges'][i] != row['edgeID']:
                        length += seg_mg_lens_dic[row['edgeID_merged']][i]
                    else:
                        break
                total_length = 0
                for i in range(len(seg_mg_lens_dic[row['edgeID_merged']])):
                    total_length += seg_mg_lens_dic[row['edgeID_merged']][i]
                df.at[index, 'length'] = length
                df.at[index, 'total_length'] = total_length
            df['pos'] = df['edgeID_'] + ((df['edgePos'] + df['length']) / df['total_length'])
            df['mo'] = [mo for _ in range(len(df['pos']))]

            df = df[['mo', 'pos', 'timestep']]

            df.to_csv(txt_file, sep=',', index=False, header=False)"""


def load_file(pkl_file):
    with open(pkl_file, 'rb') as file:
        return pickle.load(file)


if __name__ == "__main__":
    seg_to_Merged_file = "E:\chengxu\experiment\\pkl文件\合并前后对照字典imulation_merge_name_dict.pkl"
    sort_segment_file = "E:\chengxu\experiment\\sort\sort_segment.pkl"
    seg_mg_lens_dic_path = 'seg_merged_lens_dict.plk'
    seg_to_Merged = load_file(seg_to_Merged_file)

    sort_segment = load_file(sort_segment_file)
    seg_mg_lens_dic = load_file(seg_mg_lens_dic_path)
    data_file = 'E:\dataset\simulation4-2'
    f = os.listdir(data_file)
    txt_data_file = 'E:\dataset\\txt_simulation4-1_point_1'

    for f_ in f:
        data_file_ = os.path.join(data_file, f_)

        transform(sort_segment, seg_to_Merged, data_file_, txt_data_file, seg_mg_lens_dic)
