import random
import sqlite3

import pandas as pd
import pickle
import csv
import math
import os
import numpy as np
import zlib
from sklearn.cluster import MiniBatchKMeans, KMeans
from sklearn.cluster import DBSCAN
import matplotlib.pyplot as plt
from collections import defaultdict
from random import uniform
from math import sqrt


class Point:
    def __init__(self, seg_id, seg_pos, t):
        """
        轨迹点类
        :param seg_id:路段id
        :param seg_pos: 轨迹点在路段相对位置
        :param t: 轨迹点的时间
        """
        self.seg_id = seg_id
        self.seg_pos = seg_pos
        self.t = t

    def __eq__(self, other):
        return self.seg_id == other.seg_id and self.seg_pos == other.seg_pos and self.t == other.t

    def __hash__(self):
        return hash(self.seg_id) * hash(self.seg_pos) * hash(self.t)

    def __str__(self):
        return "{seg_id:%s\tseg_pos:%f\tt:%f}" % (self.seg_id, self.seg_pos, self.t)


class Segment:
    def __init__(self, seg_id, start_junction, end_junction, rect):
        """
        路段类
        :param seg_id: 路段id
        :param start_junction:路段开始交叉口
        :param end_junction: 路段结束交叉口
        :param length: 路段长度
        :param lane_number: 路段车道数
        :param edgesMerged: 合并的路段
        """
        self.seg_id = seg_id
        self.start_junction = start_junction
        self.end_junction = end_junction
        self.rect = rect
        self.next_segments = []
        self.pre_segments = []
        self.next_segments_dict = {}
        self.pre_segments_dict = {}

    def __hash__(self):
        return hash(self.seg_id)

    def __eq__(self, other):
        return self.seg_id == other.seg_id

    def __str__(self):
        return "{seg_id:%s\\tstart_junction:%s\\tend_junction:%s}" % \
               (self.seg_id, self.start_junction, self.end_junction)


def generate_k(data_set, k):
    """centers = []
    dimensions = len(data_set[0])
    print(dimensions)
    min_max = defaultdict(int)

    for point in data_set:
        for i in range(1, dimensions):
            val = point[i]
            min_key = 'min_%d' % i
            max_key = 'max_%d' % i
            if min_key not in min_max or val < min_max[min_key]:
                min_max[min_key] = val
            if max_key not in min_max or val > min_max[max_key]:
                min_max[max_key] = val

    for _k in range(k):
        rand_point = []
        for i in range(1, dimensions):
            min_val = min_max['min_%d' % i]
            print(min_val)
            max_val = min_max['max_%d' % i]
            print(max_val)
            rand_point.append(uniform(min_val, max_val))

        centers.append(rand_point)"""
    centers = random.sample(data_set, k)
    centers_ = []
    for i in range(len(centers)):
        centers_.append([centers[i][1], centers[i][2], centers[i][3]])
    return centers_


def initCentroids(data_set, k):
    centers = []

    numSamples = len(data_set)
    index = int(random.uniform(0, numSamples))

    centers.append(data_set[index][1:])
    max_distance_index = -1
    max_distance = -1
    for i in range(len(data_set)):
        dis = distance(data_set[i], data_set[index][1:])
        if dis > max_distance:
            max_distance_index = i
            max_distance = dis
    centers.append(data_set[max_distance_index][1:])
    j = 1
    while j <= k - 2:
        index1 = -1
        max_dist = -1
        for i in range(numSamples):

            if data_set[i][1:] not in centers:
                dis1 = distance(data_set[i], centers[j])
                dis2 = distance(data_set[i], centers[j - 1])
                min_dis = min(dis1, dis2)
                if min_dis > max_dist:
                    max_dist = min_dis
                    index1 = i
        centers.append(data_set[index1][1:])
        j = j + 1
    return centers


def assign_points(data_points, centers):
    assignments = []
    sse_distance = 0
    for point in data_points:
        shortest = float('inf')  # positive infinity
        shortest_index = 0

        for i in range(len(centers)):
            val = distance(point, centers[i])
            if val < shortest:
                shortest = val
                shortest_index = i
        sse_distance += shortest
        assignments.append(shortest_index)
    return assignments, sse_distance


def point_avg(points):
    dimensions = len(points[0])

    new_center = []

    for i in range(1, dimensions):
        dim_sum = 0  # dimension sum
        for p in points:
            dim_sum += p[i]

        # average of each dimension
        new_center.append(dim_sum / float(len(points)))

    return new_center


def distance(a, b):
    return (sigmoid(math.sqrt((a[1] - b[0]) ** 2 + (a[2] - b[1]) ** 2))) * abs(a[3] - b[2])


def update_centers(data_set, assignments):
    new_means = defaultdict(list)
    centers = []
    for assignment, point in zip(assignments, data_set):
        new_means[assignment].append(point)

    for points in new_means.values():
        centers.append(point_avg(points))

    return centers


def SSE(k_range, dataset):
    sse_result = []
    for k in k_range:
        assignments, sse_distance = k_means(dataset, k)
        sse_result.append(sse_distance)

    plt.plot(k_range, sse_result, 'gx-')
    plt.xlabel('k')
    plt.ylabel(u'平均畸变程度')
    plt.title(u'optimal k value')
    plt.savefig('example1.png')


def k_means(dataset, k):
    k_points = initCentroids(dataset, k)
    print(f'中心点：{k_points}')
    assignments, sse_distance = assign_points(dataset, k_points)
    old_assignments = None
    while assignments != old_assignments:
        # print(f'分配：{assignments}\n')
        new_centers = update_centers(dataset, assignments)
        print(f'新的中心点：{new_centers}')
        old_assignments = assignments
        assignments, sse_distance = assign_points(dataset, new_centers)
    return assignments, sse_distance


def read_segMerged(adjlist, junc_csv_path):
    junc_csv = pd.read_csv(junc_csv_path)
    segment_list = []
    segment_dict = {}
    junction_next_seg = {}
    junction_pre_seg = {}
    junction = {}
    for i in range(len(junc_csv)):
        junc = int(junc_csv.iloc[i]['id'])
        junction[junc] = [junc_csv.iloc[i]['lon'], junc_csv.iloc[i]['lat']]

        if junc not in junction_next_seg.keys():
            junction_next_seg[junc] = []
        if junc not in junction_pre_seg.keys():
            junction_pre_seg[junc] = []

    for key, value in adjlist.items():
        for v in value:
            start_junction = key
            seg_id = v[1]
            end_junction = v[0]
            if len(junction_next_seg[int(key)]) == 0:
                junction_next_seg[int(key)] = [seg_id]
            else:
                junction_next_seg[start_junction].append(seg_id)
            if len(junction_pre_seg[end_junction]) == 0:
                junction_pre_seg[end_junction] = [seg_id]
            else:
                junction_pre_seg[end_junction].append(seg_id)
            minx = min(junction[start_junction][0], junction[end_junction][0])
            maxx = max(junction[start_junction][0], junction[end_junction][0])
            miny = min(junction[start_junction][1], junction[end_junction][1])
            maxy = max(junction[start_junction][1], junction[end_junction][1])
            rect = [minx, miny, maxx, maxy]
            seg = Segment(seg_id, start_junction, end_junction, rect)
            segment_list.append(seg)
            segment_dict[seg_id] = seg
    for i in range(len(segment_list)):
        segment_list[i].pre_segments = junction_pre_seg[segment_list[i].start_junction]
        segment_list[i].next_segments = junction_next_seg[segment_list[i].end_junction]
        segment_dict[segment_list[i].seg_id].next_segments = junction_next_seg[segment_list[i].end_junction]
        segment_dict[segment_list[i].seg_id].pre_segments = junction_pre_seg[segment_list[i].start_junction]

    return segment_list, segment_dict


def calculate_density_(segment_dict, time_frame, traj_path):
    f_list = os.listdir(traj_path)
    # file_list = os.listdir(traj_path)
    time_frame_dict = {}
    segment_time_traversed_time = {}  # 在时间frame下路段的遍历次数
    for time_partition_id in time_frame.keys():
        for j in range(len(time_frame[time_partition_id])):
            time_frame_dict[
                (time_frame[time_partition_id][j][0], time_frame[time_partition_id][j][1])] = time_partition_id
            segment_time_traversed_time[time_partition_id] = {k: 0 for k in segment_dict.keys()}
    cc = 0
    for f_ in f_list:
        file_ = os.path.join(traj_path, f_)
        file_list = os.listdir(file_)
        for file_name in file_list:
            print(file_name)
            file = os.path.join(file_, file_name)
            df = pd.read_csv(file)

            df['time'] = pd.to_datetime(df['time'], errors='coerce')

            df['time'] = df['time'].fillna(0)

            df['time'] = df['time'].astype(np.int64)
            df['time'] = df['time'].astype(int)
            print(df['time'] % 86400)
            df['time_frame_label'] = -1
            for frame_list in time_frame.values():
                for frame in frame_list:
                    df.loc[((df['time'] % 86400) >= frame[0]) & (
                            (df['time'] % 86400) <= frame[1]), 'time_frame_label'] = \
                        time_frame_dict[(frame[0], frame[1])]
            # df = df.drop_duplicates(subset=['edgeID', 'time_frame_label'], keep='first')

            for i in range(len(df)):

                if pd.isnull(df.iloc[i]['segment_id']):
                    break
                seg_id = df.iloc[i]['segment_id']

                t = df.iloc[i]['time_frame_label']
                if seg_id not in segment_dict.keys():
                    cc += 1
                    continue
                else:
                    segment_time_traversed_time[t][seg_id] += 1

    return segment_time_traversed_time


def sigmoid(x):
    a = 0.004
    return 1 / (1 + np.exp(-a * x))


def save_segs_to_file(seg_start_end, filename):
    with open(filename, 'wb') as file:
        pickle.dump(seg_start_end, file)


def read_seg_to_merged(file_path):
    with open(file_path, 'rb') as f:
        seg_to_segMerged = pickle.load(f)
    return seg_to_segMerged


def load_segs_from_file(filename):
    with open(filename, 'rb') as file:
        return pickle.load(file)


def seg_partition_mapping_consistent(segment_partition):
    num = 0
    new_segment_partition = {}
    for time_partition_id_, partition in segment_partition.items():
        new_segment_partition[time_partition_id_] = {}
    for time_partition_id_, partition in segment_partition.items():

        for key_, value_ in partition.items():
            new_segment_partition[time_partition_id_][num] = value_
            num += 1
    return new_segment_partition


if __name__ == '__main__':

    adjlist_pkl = "E:\chengxu\experiment_ch\pkl_cd\\adjlist.pkl"
    junc_csv = "E:\chengxu\experiment_ch\pkl_cd\\chengdu_square_node_on_way.csv"
    segment_traversed_file = 'segment_time_traversed_file.pkl'
    segment_dict_pkl="segment_dict.pkl"
    sort_segment_pkl = 'E:\chengxu\experiment_ch\pkl_cd\\chd_order_dict.kpl'
    sort_segment = load_segs_from_file(sort_segment_pkl)
    traj_path = 'E:\dataset\成都数据-分期csv'

    time_frame = {0: [[54000, 82800]], 1: [[0, 54000], [82800, 86400]]}

    adjlist = load_segs_from_file(adjlist_pkl)


    segment_list, segment_dict = read_segMerged(adjlist, junc_csv)
    save_segs_to_file(segment_dict, segment_dict_pkl)
    segment_traversed = calculate_density_(segment_dict, time_frame, traj_path)
    save_segs_to_file(segment_traversed, segment_traversed_file)
    segment_traversed = load_segs_from_file(segment_traversed_file)

    k_range = [10, 80]
    k_range_ = []
    for j in range(k_range[0], k_range[1] + 1, 10):
        k_range_.append(j)

    print(k_range_)
    seg_t_list = {}
    for i in range(len(time_frame)):
        seg_t_list[i] = None
    sse_value = [3,3]
    for time_partition_id in time_frame.keys():
        data_list = []
        for key, value in segment_traversed[time_partition_id].items():
            if key in sort_segment.keys():

                data_list.append([key, (segment_dict[key].rect[0] + segment_dict[key].rect[2]) / 2,
                                  (segment_dict[key].rect[1] + segment_dict[key].rect[3]) / 2, value])

        #SSE(k_range_, data_list)

        assignments, sse_distance = k_means(data_list, sse_value[time_partition_id])
        assignments_dict = {}
        list1 = []
        for i in range(len(data_list)):
            if assignments[i] not in assignments_dict.keys():
                assignments_dict[assignments[i]] = [sort_segment[data_list[i][0]]]
            else:
                assignments_dict[assignments[i]].append(sort_segment[data_list[i][0]])
        seg_t_list[time_partition_id] = assignments_dict

        for value in assignments_dict.values():
            list1.append(len(value))
        df = pd.DataFrame(columns=['segs_number', 'segs_name'])

        df['segs_number'] = list1
        df['segs_name'] = assignments_dict.values()

        # 尝试追加到现有文件（如果文件存在）
        try:
            existing_df = pd.read_excel('partition_cd3.xlsx')
            empty_row = pd.DataFrame({col: [''] for col in existing_df.columns})

            updated_df = pd.concat([existing_df, empty_row, df], ignore_index=True)
        except FileNotFoundError:

            updated_df = df

        # 将更新后的 DataFrame 写入 Excel 文件
        updated_df.to_excel('partition_cd3.xlsx', index=False)

    with open(f'partition_cd3.pkl', 'wb') as file:
        pickle.dump(seg_t_list, file)
    """segment_partition = load_segs_from_file("partition_cd1.pkl")
    segment_partition = seg_partition_mapping_consistent(segment_partition)
    save_segs_to_file(segment_partition,'partition_cd1.pkl')"""
