import pandas as pd
import pickle
import os


def transform(sort_segment, data_file, txt_data_file,traj_id_mapping):
    """
    原始数据转化为pos,t
    :param sort_segment:
    :param seg_to_Merged:
    :param data_file:
    :return:
    """
    file_list = os.listdir(data_file)
    directory, filename = os.path.split(data_file)
    filename = filename + ".txt"
    txt_data_file_ = os.path.join(txt_data_file, filename)

    with open(txt_data_file_, 'a') as txt_file:
        for file in file_list:
            mo=traj_id_mapping[file]
            file_ = os.path.join(data_file, file)
            df = pd.read_csv(file_)
            df.dropna(subset=['segment_id'])

            df['segment_id'] = df['segment_id'].map(sort_segment)
            df.dropna(subset=['segment_id'], inplace=True)
            df['pos'] = df['segment_id'] + (df['dist'] / df['segment_length'])
            df['mo'] = [mo] * len(df)
            df = df[['mo','pos', 'time','lon','lat']]
            print(len(df))
            df.to_csv(txt_file, sep=',', index=False, header=False)


def load_file(pkl_file):
    with open(pkl_file, 'rb') as file:
        return pickle.load(file)


if __name__ == "__main__":

    sort_segment_file = "E:\chengxu\experiment\\chd_order_dict.kpl"
    traj_id_mapping_file="E:\chengxu\experiment\pkl文件\\traj_id_mapping.pkl"
    #traj_id_mapping={}

    #id_traj_mapping={}
    sort_segment = load_file(sort_segment_file)

    data_file = "E:\dataset\成都数据-分期csv"
    f=os.listdir(data_file)
    txt_data_file = 'E:\dataset\成都数据-分期txt'
    number=0
    traj_id_mapping=load_file(traj_id_mapping_file)
    for f_ in f:
        data_file_=os.path.join(data_file,f_)
        """f1=os.listdir(data_file_)
        for f1_ in f1:
            id_traj_mapping[number]=f1_
            traj_id_mapping[f1_]=number
            number+=1

    with open(traj_id_mapping_file,'wb') as file:
        pickle.dump(traj_id_mapping,file)"""

        transform(sort_segment, data_file_, txt_data_file,traj_id_mapping)
