import os
import pickle
import struct
import time

import numpy as np

DATAFILE_PERITEM = 36
DATABLOCKSIZE = 8 * 1024
TOTAL = 0
MAX_BLOCKS = 256


class MemoryManager:
    """
    内存管理类，相当于一个缓存。
    在创建的索引的时候，新建或者更新块后是先写入缓存中，不是立即写入磁盘，减少IO数
    在查询数据时，会设置缓存，首先先从缓存读取数据，如果没有该块，则再从磁盘中读取，也减少了访存时间
    """

    def __init__(self, max_blocks):
        self.max_blocks = max_blocks
        self.blocks = []
        self.block_ids = []

    def is_full(self):
        return len(self.blocks) >= self.max_blocks

    def add_block(self, block):

        """
        当有新块加入，则添加到缓存中，如果缓存已满，则替换缓存中的块
        :param block:

        :return:
        """

        if block[0] not in self.block_ids:
            self.blocks.append(block)
            self.block_ids.append(block[0])
            if self.is_full():
                self.replace_block()

    def replace_block(self):
        """
        当缓存满了，寻找一个合适的块替换，这里采用的是先进先出策略
        :return:
        """
        self.block_ids.pop(0)
        self.blocks.pop(0)

    def get_block(self, block_id):
        for block in self.blocks:
            if block[0] == block_id:
                return block
        return None


def intersection(list1, list2):
    return [max(list1[0], list2[0]), min(list1[1], list2[1])]


def decomposeTimeForRangeQuery(time_range, time_partition, W, base_time):
    # 这里的base_time每期数据不一样
    time_segments = {}  # 查询所映射的时间分区以及对应的时间段

    t1 = time_range[0]
    t2 = time_range[1]
    n1 = ((t1 - base_time) // 86400) // 7
    m1 = (t1 - base_time) % 86400
    n2 = ((t2 - base_time) // 86400) // 7
    m2 = (t2 - base_time) % 86400
    if n2 - n1 == 0:
        nn1 = 0
        nn2 = 0
        m1_ = 0
        m2_ = 0
        tf1 = -1
        tf2 = -1
        for i in range(len(time_partition[0])):
            if (time_partition[0][i][0] - base_time) <= m1 < (time_partition[0][i][1] - base_time):

                if i != 0:
                    nn1 += (time_partition[0][i - 1][1] - time_partition[0][i - 1][0])
                tf1 = n1 * W[0] + (nn1 + m1 - (time_partition[0][i][0] - base_time))

            if (time_partition[0][i][0] - base_time) <= m2 < (time_partition[0][i][1] - base_time):

                if i != 0:
                    nn2 += (time_partition[0][i - 1][1] - time_partition[0][i - 1][0])
                tf2 = n1 * W[0] + (nn2 + m2 - (time_partition[0][i][0] - base_time))
        key = 0
        if tf1 != -1 and tf2 != -1:
            time_segments[key] = [tf1, tf2]
        if tf1 != -1 and tf2 == -1:
            time_segments[key] = [tf1, W[key]]
        if tf1 == -1 and tf2 != -1:
            time_segments[key] = [0, tf2]

        tf3 = -1
        tf4 = -1
        for i in range(len(time_partition[1])):
            if (time_partition[1][i][0] - base_time) <= m1 < (time_partition[1][i][1] - base_time):

                if i != 0:
                    m1_ += (time_partition[1][i - 1][1] - time_partition[1][i - 1][0])
                tf3 = n1 * W[1] + (m1_ + m1 - (time_partition[1][i][0] - base_time))

            if (time_partition[1][i][0] - base_time) <= m2 < (time_partition[1][i][1] - base_time):

                if i != 0:
                    m2_ += (time_partition[1][i - 1][1] - time_partition[1][i - 1][0])
                tf4 = n1 * W[1] + (m2_ + m2 - (time_partition[1][i][0] - base_time))

        if tf3 != -1 and tf4 != -1:
            time_segments[key] = [tf3, tf4]
        if tf3 != -1 and tf4 == -1:
            time_segments[key] = [tf3, W[key]]
        if tf1 == -1 and tf2 != -1:
            time_segments[key] = [0, tf4]

    if n2 - n1 >= 1:
        for key, value in time_partition.items():
            inter_list1 = []
            inter_list2 = []
            inter_list3 = []
            start = -1
            lenf = -1
            lenl = -1
            for i in range(len(value)):
                list1 = [time_partition[key][i][0] - base_time, time_partition[key][i][1] - base_time]
                list2 = [0, m1]
                inter_list1.append(intersection(list1, list2))
            for i in range(len(inter_list1)):
                start += (inter_list1[i][1] - inter_list1[i][0])
            start += n1 * W[key]
            for i in range(len(value)):
                list1 = [time_partition[key][i][0] - base_time, time_partition[key][i][1] - base_time]
                list2 = [m1, W[0] + W[1]]
                inter_list2.append(intersection(list1, list2))
            for i in range(len(inter_list1)):
                lenf += (inter_list2[i][1] - inter_list2[i][0])
            ack = (n2 - n1 - 1) * W[key]
            for i in range(len(value)):
                list1 = [time_partition[key][i][0] - base_time, time_partition[key][i][1] - base_time]
                list2 = [m1, W[0] + W[1]]
                inter_list3.append(intersection(list1, list2))
            for i in range(len(inter_list1)):
                lenl += (inter_list3[i][1] - inter_list3[i][0])
            end = start + lenf + ack + lenl
            time_segments[key] = [start, end]
    return time_segments


def decomposeNetwork(seg_range, tf, SM):
    seg_segments = {}
    seg_start = seg_range[0]
    seg_end = seg_range[1]
    seg_list = [seg_start]
    i = int(seg_start) + 1
    GP = {}

    while i < seg_end:
        seg_list.append(i)
        i += 1
    seg_list.append(seg_end)
    for seg in seg_list:
        if SM[tf][int(seg)] is not None:
            cid = SM[tf][int(seg)][0]
            nid = SM[tf][int(seg)][1]
            if cid not in GP.keys():
                GP[cid] = [(nid + seg - int(seg))]
            else:
                GP[cid].append((nid + seg - int(seg)))
    for key, value in GP.items():
        value.append(value[-1] + 1)
        GP[key] = value
    for key, value in GP.items():
        qu = sorted(value)
        for q in qu:
            if key not in seg_segments.keys():
                seg_segments[key] = [q]
            else:
                seg_segments[key].append(q)
    return seg_segments


def unpack_header(cid, model_path):
    with open(model_path, 'rb') as file:
        file.seek(cid * 20)

        header_item = file.read(20)
        global TOTAL

        cid_, tt, start, plane_num, nr = struct.unpack('IIIIf', header_item)
        nr = np.float32(nr)
        return cid_, tt, start, plane_num, nr


def unpack_model(cid, model_path, cid_num):
    with open(model_path, 'rb') as file:
        cid_, tt, start, plane_num, nr = unpack_header(cid, model_path)
        file.seek(cid_num * 20 + start * 28)
        model_item = file.read(plane_num * 28)

        offset = 0
        model_dict = {}
        for i in range(plane_num):
            l, r, b_, t, a, b, c = struct.unpack('fffffff', model_item[offset:offset + 28])

            model_dict[(np.float32(l), np.float32(r), np.float32(b_), np.float32(t))] = [np.float32(a), np.float32(b),
                                                                                         np.float32(c)]
            offset += 28

        return model_dict, tt, nr


def decomposeTimeAndNetwork(RQ, time_partition, W, base_time, SM, df, model_path, memorymanager):
    # RQ是[[时间范围],[空间范围]]
    ZQ = {}
    RT = []
    global TOTAL
    time_segments = decomposeTimeForRangeQuery(RQ[0], time_partition, W, base_time)
    for key, value in time_segments.items():
        seg_segments = decomposeNetwork(RQ[1], key, SM)
        for k, v in seg_segments.items():
            ZQ[k] = [value[0], value[1], v[0], v[-1]]

    for c_id, value in ZQ.items():
        qs = []
        model_list, tt, nr = unpack_model(int(c_id), model_path, 6)

        start_x = value[0] // 1800
        end_x = value[1] // 1800
        if start_x == end_x:
            qs.append([value[0], value[1], value[2], value[3]])
        else:
            qs.append([value[0], ((start_x + 1) * 1800) - 0.01, value[2], value[3]])
            qs.append([end_x * 1800, value[1], value[2], value[3]])
            while start_x + 1 < end_x:
                qs.append([((start_x + 1) * 1800), ((start_x + 2) * 1800 - 0.01), value[2], value[3]])
                start_x += 1
        for q in qs:
            with open(df, 'rb') as file:

                offset = 0
                file.seek(0)
                header = file.read(6 * 12)

                limit = None

                for j in range(6):
                    cid, number, overflown = struct.unpack('III', header[offset:offset + 12])
                    offset += 12
                    if cid == c_id:
                        limit = number

                        break
            start = [q[0], q[2]]
            end = [q[1], q[3]]
            bl = None
            tr = None

            for key, model in model_list.items():
                if key[0] <= start[0] < key[1] and key[2] <= start[1] <= key[3]:
                    bl = int((int(model[0] * start[0] + model[1] * start[1] + model[2]) * nr))

                if key[0] <= end[0] < key[1] and key[2] <= end[1] <= key[3]:
                    tr = int((int(model[0] * end[0] + model[1] * end[1] + model[2]) * nr))

            key_dict = {}
            for key in model_list.keys():
                if (key[0], key[1]) not in key_dict.keys():
                    key_dict[(key[0], key[1])] = [[key[2], key[3]]]
                else:
                    key_dict[(key[0], key[1])].append([key[2], key[3]])
            if bl is None:
                if len(key_dict.keys()) != 0:
                    if start[0] < list(key_dict.keys())[0][0]:
                        v = model_list.get(list(model_list.keys())[0])
                        bl = int((int(v[0] * start[0] + v[1] * start[1] + v[2]) * nr))

                    elif start[0] > list(model_list.keys())[-1][1]:
                        v = model_list.get(list(model_list.keys())[-1])
                        bl = int((int(v[0] * start[0] + v[1] * start[1] + v[2]) * nr))
                    else:
                        key_value = [None, None, None, None]
                        for key, value in key_dict.items():
                            if key[0] <= float(start[0]) < key[1]:
                                if float(start[1]) < value[0][0]:
                                    key_value = [key[0], key[1], value[0][0], value[0][1]]
                                    break
                                elif float(start[1]) > value[-1][1]:
                                    key_value = [key[0], key[1], value[-1][0], value[-1][1]]
                                    break
                                else:
                                    for j in range(len(value) - 1):

                                        if value[j][1] < float(start[1]) < value[j + 1][0]:
                                            key_value = [key[0], key[1], value[j][0], value[j][1]]
                                            break
                        for key, value in model_list.items():
                            if key_value[0] == key[0] and key_value[1] == key[1] and key_value[2] == key[2] and \
                                    key_value[
                                        3] == \
                                    key[3]:
                                bl = int(
                                    (int(value[0] * start[0] + value[1] * start[1] + value[2]) * nr))
                                break

            if bl >= limit:
                bl = limit
            if bl < 0:
                bl = 0
            key_dict1 = {}
            for key in model_list.keys():
                if (key[0], key[1]) not in key_dict1.keys():
                    key_dict1[(key[0], key[1])] = [[key[2], key[3]]]
                else:
                    key_dict1[(key[0], key[1])].append([key[2], key[3]])
            if tr is None:
                if len(key_dict1.keys()) != 0:
                    if end[0] < list(key_dict1.keys())[0][0]:
                        v = model_list.get(list(model_list.keys())[0])
                        tr = int((int(v[0] * end[0] + v[1] * end[1] + v[2]) * nr))

                    elif end[0] > list(model_list.keys())[-1][1]:
                        v = model_list.get(list(model_list.keys())[-1])
                        tr = int((int(v[0] * end[0] + v[1] * end[1] + v[2]) * nr))
                    else:
                        key_value = [None, None, None, None]
                        for key, value in key_dict1.items():
                            if key[0] <= float(end[0]) < key[1]:
                                if float(end[1]) < value[0][0]:
                                    key_value = [key[0], key[1], value[0][0], value[0][1]]
                                    break
                                elif float(end[1]) > value[-1][1]:
                                    key_value = [key[0], key[1], value[-1][0], value[-1][1]]
                                    break
                                else:
                                    for j in range(len(value) - 1):

                                        if value[j][1] < float(end[1]) < value[j + 1][0]:
                                            key_value = [key[0], key[1], value[j][0], value[j][1]]
                                            break
                        for key, value in model_list.items():
                            if key_value[0] == key[0] and key_value[1] == key[1] and key_value[2] == key[2] and \
                                    key_value[
                                        3] == \
                                    key[3]:
                                tr = int(
                                    (int(value[0] * end[0] + value[1] * end[1] + value[2]) * nr))
                                break

            if tr >= limit:
                tr = limit
            if tr < 0:
                tr = 0
            with open(df, 'rb') as file:

                offset = 0
                file.seek(0)
                header = file.read(6 * 12)
                start_block_number = 0
                end_block_number = 0

                for j in range(6):
                    cid, number, overflown = struct.unpack('III', header[offset:offset + 12])
                    offset += 12
                    if cid != c_id:
                        start_block_number += number
                    else:
                        end_block_number = start_block_number + number

                        break
                file.seek(c_id * 12)
                file.read(24)
                start_overflown_num = struct.unpack('III', header[offset:offset + 12])[2]

                end_overflown_num = struct.unpack('III', header[offset + 12:offset + 24])[2]
                left1 = bl - tt
                right1 = tr + tt
                if left1 < 0:
                    left1 = 0
                if right1 < 0:
                    right1 = 0

                s_range = [start_block_number + left1, start_block_number + right1]

                if s_range[1] < end_block_number and s_range[0] < end_block_number:

                    start_offset = 6 * 12 + s_range[0] // (DATABLOCKSIZE // DATAFILE_PERITEM) * DATABLOCKSIZE

                    start_block_id = s_range[0] // (DATABLOCKSIZE // DATAFILE_PERITEM)
                    end_block_id = s_range[1] // (DATABLOCKSIZE // DATAFILE_PERITEM)

                    while start_block_id <= end_block_id:
                        block = memorymanager.get_block(start_block_id)
                        if block is None:

                            file.seek(start_offset)
                            block = file.read(DATABLOCKSIZE)
                            offset_ = 0
                            data_list = []
                            TOTAL += 1
                            for i in range(DATABLOCKSIZE // DATAFILE_PERITEM):
                                t, pos, lon, lat, mo = struct.unpack('ddddI', block[offset_:offset_ + DATAFILE_PERITEM])
                                data_list.append([mo, float(t), float(pos), float(lon), float(lat)])
                                offset_ += DATAFILE_PERITEM
                                if float(RQ[1][0]) <= pos < float(RQ[1][1]) and float(
                                        RQ[0][0]) <= t < float(RQ[0][1]):
                                    RT.append([mo, float(t), float(pos), float(lon), float(lat)])

                            memorymanager.add_block([start_block_id, data_list])
                        else:

                            for data in block[1]:

                                mo = data[0]
                                t = data[1]
                                pos = data[2]
                                lon = data[3]
                                lat = data[4]
                                if float(RQ[1][0]) <= pos < float(RQ[1][1]) and float(
                                        RQ[0][0]) <= t < float(RQ[0][1]):
                                    RT.append([mo, t, pos, lon, lat])

                        start_block_id += 1
                        start_offset += DATABLOCKSIZE
                if s_range[0] < end_block_number <= s_range[1]:

                    start_offset = 6 * 12 + s_range[0] // (DATABLOCKSIZE // DATAFILE_PERITEM) * DATABLOCKSIZE

                    start_block_id = s_range[0] // (DATABLOCKSIZE // DATAFILE_PERITEM)
                    end_block_id = end_block_number // (DATABLOCKSIZE // DATAFILE_PERITEM)

                    while start_block_id <= (end_block_id):
                        block = memorymanager.get_block(start_block_id)
                        if block is None:

                            file.seek(start_offset)
                            block = file.read(DATABLOCKSIZE)
                            data_list = []
                            TOTAL += 1
                            offset_ = 0
                            for i in range(DATABLOCKSIZE // DATAFILE_PERITEM):

                                t, pos, lon, lat, mo = struct.unpack('ddddI', block[offset_:offset_ + DATAFILE_PERITEM])
                                data_list.append([mo, float(t), float(pos), float(lon), float(lat)])
                                offset_ += DATAFILE_PERITEM
                                if float(RQ[1][0]) <= pos < float(RQ[1][1]) and float(
                                        RQ[0][0]) <= t < float(RQ[0][1]):
                                    RT.append([mo, float(t), float(pos), float(lon), float(lat)])
                            memorymanager.add_block([start_block_id, data_list])
                        else:

                            for data in block[1]:

                                mo = data[0]
                                t = data[1]
                                pos = data[2]
                                lon = data[3]
                                lat = data[4]
                                if float(RQ[1][0]) <= pos < float(RQ[1][1]) and float(
                                        RQ[0][0]) <= t < float(RQ[0][1]):
                                    RT.append([mo, t, pos, lon, lat])

                        start_block_id += 1
                        start_offset += DATABLOCKSIZE
                    start_overflown_offset = 6 * 12 + start_overflown_num // (
                            DATABLOCKSIZE // DATAFILE_PERITEM) * DATABLOCKSIZE
                    start_overflown_id = start_overflown_num // (DATABLOCKSIZE // DATAFILE_PERITEM)
                    end_overflown_id = end_overflown_num // (DATABLOCKSIZE // DATAFILE_PERITEM)
                    if start_overflown_id != 0:
                        while start_overflown_id <= (end_overflown_id):
                            block = memorymanager.get_block(start_overflown_id)
                            if block is None:

                                file.seek(start_overflown_offset)
                                block = file.read(DATABLOCKSIZE)
                                data_list = []
                                TOTAL += 1
                                offset_ = 0
                                for i in range(DATABLOCKSIZE // DATAFILE_PERITEM):

                                    t, pos, lon, lat, mo = struct.unpack('ddddI',
                                                                         block[offset_:offset_ + DATAFILE_PERITEM])
                                    data_list.append([mo, float(t), float(pos), float(lon), float(lat)])
                                    offset_ += DATAFILE_PERITEM
                                    if float(RQ[1][0]) <= pos < float(RQ[1][1]) and float(
                                            RQ[0][0]) <= t < float(RQ[0][1]):
                                        RT.append([mo, float(t), float(pos), float(lon), float(lat)])
                                memorymanager.add_block([start_overflown_id, data_list])
                            else:

                                for data in block[1]:

                                    mo = data[0]
                                    t = data[1]
                                    pos = data[2]
                                    lon = data[3]
                                    lat = data[4]
                                    if float(RQ[1][0]) <= pos < float(RQ[1][1]) and float(
                                            RQ[0][0]) <= t < float(RQ[0][1]):
                                        RT.append([mo, t, pos, lon, lat])
                            start_overflown_id += 1
                            start_overflown_offset += DATABLOCKSIZE
                if s_range[0] >= end_block_number and s_range[1] >= end_block_number:
                    start_overflown_offset = 6 * 12 + start_overflown_num // (
                            DATABLOCKSIZE // DATAFILE_PERITEM) * DATABLOCKSIZE
                    start_overflown_id = start_overflown_num // (DATABLOCKSIZE // DATAFILE_PERITEM)
                    end_overflown_id = end_overflown_num // (DATABLOCKSIZE // DATAFILE_PERITEM)
                    if start_overflown_id != 0:
                        while start_overflown_id <= (end_overflown_id):
                            block = memorymanager.get_block(start_overflown_id)
                            if block is None:

                                file.seek(start_overflown_offset)
                                block = file.read(DATABLOCKSIZE)
                                data_list = []
                                TOTAL += 1
                                offset_ = 0
                                for i in range(DATABLOCKSIZE // DATAFILE_PERITEM):

                                    t, pos, lon, lat, mo = struct.unpack('ddddI',
                                                                         block[offset_:offset_ + DATAFILE_PERITEM])
                                    data_list.append([mo, float(t), float(pos), float(lon), float(lat)])
                                    offset_ += DATAFILE_PERITEM
                                    if float(RQ[1][0]) <= pos < float(RQ[1][1]) and float(
                                            RQ[0][0]) <= t < float(RQ[0][1]):
                                        RT.append([mo, float(t), float(pos), float(lon), float(lat)])
                                memorymanager.add_block([start_overflown_id, data_list])
                            else:

                                for data in block[1]:

                                    mo = data[0]
                                    t = data[1]
                                    pos = data[2]
                                    lon = data[3]
                                    lat = data[4]
                                    if float(RQ[1][0]) <= pos < float(RQ[1][1]) and float(
                                            RQ[0][0]) <= t < float(RQ[0][1]):
                                        RT.append([mo, t, pos, lon, lat])

                            start_overflown_id += 1
                            start_overflown_offset += DATABLOCKSIZE

    return RT


def load_from_file(filename):
    with open(filename, 'rb') as file:
        return pickle.load(file)


def range_query():
    os.chdir("..")
    base=os.getcwd()
    print(base)
    pkl_path = f"{base}\\code\\PPT\\preprocess\\preprocess_sim\\pkl_sim"

    seg_mapping_sort_pkl = os.path.join(pkl_path, 'seg_mapping_sort_3.pkl')
    seg_mapping_partition_pkl = os.path.join(pkl_path, 'seg_mapping_partition_3.pkl')
    SM_pkl = os.path.join(pkl_path, 'SM_3.pkl')
    """seg_mapping_sort_pkl = 'E:\chengxu\experiment\pkl文件\seg_mapping_sort_3.pkl'
    seg_mapping_partition_pkl = 'E:\chengxu\experiment\pkl文件\seg_mapping_partition_3.pkl'
    SM_pkl = 'E:\chengxu\experiment\pkl文件\\SM_3.pkl'"""
    # query_file = "E:\chengxu\experiment\query\sim_data_query\\0.txt"
    query_file =f"{base}\\code\\PPT\\query\\range_query_0.txt"

    seg_mapping_sort = load_from_file(seg_mapping_sort_pkl)
    seg_mapping_partition = load_from_file(seg_mapping_partition_pkl)
    SM = load_from_file(SM_pkl)
    time_partition = {0: [[25200, 68400]], 1: [[0, 25200], [68400, 86400]]}
    time_mapping = {0: {0: 25200}, 1: {0: 0, 1: 43200}}
    W = {0: 43200, 1: 43200}

    df_path = f"{os.getcwd()}\\model\\PPT"

    df = os.path.join(df_path, 'data.dat')
    model_path = os.path.join(df_path, 'model.idx')
    query = []
    with open(query_file, 'r') as file:
        for line in file.readlines():
            line = line.strip().split(',')
            query.append([[float(line[0]), float(line[2])], [float(line[1]), float(line[3])]])
    RT_total = []
    base_time = 0
    memorymanager = MemoryManager(MAX_BLOCKS)
    t1 = time.time()
    m = 0
    for RQ in query:
        temp_RT = decomposeTimeAndNetwork(RQ, time_partition, W, base_time, SM, df, model_path, memorymanager)

        m += 1

        RT_total.append(temp_RT)

    t2 = time.time()
    print(TOTAL / 100)
    print((t2 - t1) / 100)


if __name__ == '__main__':
    range_query()
