import os
import pickle
import struct
import time

import numpy as np

DATAFILE_PERITEM = 36
DATABLOCKSIZE = 8 * 1024
TOTAL = 0
MAX_BLOCKS = 256


class MemoryManager:
    """
    内存管理类，相当于一个缓存。
    在创建的索引的时候，新建或者更新块后是先写入缓存中，不是立即写入磁盘，减少IO数
    在查询数据时，会设置缓存，首先先从缓存读取数据，如果没有该块，则再从磁盘中读取，也减少了访存时间
    """

    def __init__(self, max_blocks):
        self.max_blocks = max_blocks
        self.blocks = []
        self.block_ids = []

    def is_full(self):
        return len(self.blocks) >= self.max_blocks

    def add_block(self, block):

        """
        当有新块加入，则添加到缓存中，如果缓存已满，则替换缓存中的块
        :param block:

        :return:
        """

        if block[0] not in self.block_ids:
            self.blocks.append(block)
            self.block_ids.append(block[0])
            if self.is_full():
                self.replace_block()

    def replace_block(self):
        """
        当缓存满了，寻找一个合适的块替换，这里采用的是先进先出策略
        :return:
        """
        self.block_ids.pop(0)
        self.blocks.pop(0)

    def get_block(self, block_id):
        for block in self.blocks:
            if block[0] == block_id:
                return block
        return None


def load_from_file(filename):
    with open(filename, 'rb') as file:
        return pickle.load(file)


def timeFrameForPointQuery(query, time_partition, seg_mapping_partition, seg_mapping_sort,W):
    time_partition_id = None
    timestamp = query[0]
    pos = query[1]
    base_time = 0
    for key, value in time_partition.items():
        for i in range(len(value)):
            if value[i][0] <= timestamp % 86400 < value[i][1]:
                time_partition_id = key

    seg_partition_id = seg_mapping_partition[time_partition_id][int(pos)]
    pos = seg_mapping_sort[time_partition_id][int(pos)] + (pos - int(pos))
    time_ = (timestamp - base_time) % 86400
    n1 = ((timestamp - base_time) // 86400) // 7
    tf = 0
    n = 0
    m = 0
    key = -1
    for i in range(len(time_partition[0])):
        if (time_partition[0][i][0] - base_time) <= time_ < (time_partition[0][i][1] - base_time):

            if i == 0:
                tf = n1 * W[0] + (n + time_ - (time_partition[0][i][0] - base_time))
                key = 0
            else:
                n += (time_partition[0][i - 1][1] - time_partition[0][i - 1][0])
                tf = n1 * W[0] + (n + time_ - (time_partition[0][i][0] - base_time))
                key = 0

    for i in range(len(time_partition[1])):
        if (time_partition[1][i][0] - base_time) <= time_ < (time_partition[1][i][1] - base_time):

            if i != 0:
                m += (time_partition[1][i - 1][1] - time_partition[1][i - 1][0])
            tf = n1 * W[1] + (m + time_ - (time_partition[1][i][0] - base_time))
            key = 1

    timestamp = tf
    return seg_partition_id, [timestamp, pos]


def unpack_header(cid, model_path):
    with open(model_path, 'rb') as file:
        file.seek(cid * 20)
        header_item = file.read(20)
        cid_, tt, start, plane_num, nr = struct.unpack('IIIIf', header_item)
        nr = np.float32(nr)
        return cid_, tt, start, plane_num, nr


def unpack_model(cid, model_path, cid_num):
    with open(model_path, 'rb') as file:
        cid_, tt, start, plane_num, nr = unpack_header(cid, model_path)
        file.seek(cid_num * 20 + start * 28)
        model_item = file.read(plane_num * 28)
        offset = 0
        model_dict = {}
        for i in range(plane_num):
            l, r, b_, t, a, b, c = struct.unpack('fffffff', model_item[offset:offset + 28])

            model_dict[(np.float32(l), np.float32(r), np.float32(b_), np.float32(t))] = [np.float32(a), np.float32(b),
                                                                                         np.float32(c)]
            offset += 28

        return model_dict, tt, nr


def pointQueryResult(tp_mapping, tp, df, seg_partition_id, model_path, memorymanager):
    seg_partition_id = int(seg_partition_id)
    model_list, tt, nr = unpack_model(int(seg_partition_id), model_path, 6)
    RT = []
    global TOTAL
    z_pre = None
    with open(df, 'rb') as file:

        offset = 0
        file.seek(0)
        header = file.read(6 * 12)

        limit = None

        for j in range(6):
            cid, number, overflown = struct.unpack('III', header[offset:offset + 12])
            offset += 12
            if cid == int(seg_partition_id):
                limit = number

                break
    for key, value in model_list.items():
        if key[0] <= float(tp_mapping[0]) < key[1] and key[2] <= float(tp_mapping[1]) < key[3]:
            z_pre = int((int(value[0] * tp_mapping[0] + value[1] * tp_mapping[1] + value[2]) * nr))

    key_dict = {}
    for key in model_list.keys():
        if (key[0], key[1]) not in key_dict.keys():
            key_dict[(key[0], key[1])] = [[key[2], key[3]]]
        else:
            key_dict[(key[0], key[1])].append([key[2], key[3]])
    if z_pre is None:
        if len(key_dict.keys()) != 0:
            if float(tp_mapping[0]) < list(key_dict.keys())[0][0]:
                v = model_list.get(list(model_list.keys())[0])
                bl = int((int(v[0] * float(tp_mapping[0]) + v[1] * float(tp_mapping[1]) + v[2]) * nr))

            elif float(tp_mapping[0]) > list(model_list.keys())[-1][1]:
                v = model_list.get(list(model_list.keys())[-1])
                bl = int((int(v[0] * float(tp_mapping[0]) + v[1] * float(tp_mapping[1]) + v[2]) * nr))
            else:
                key_value = [None, None, None, None]
                for key, value in key_dict.items():
                    if key[0] <= float(tp_mapping[0]) < key[1]:
                        if float(tp_mapping[1]) < value[0][0]:
                            key_value = [key[0], key[1], value[0][0], value[0][1]]
                            break
                        elif float(tp_mapping[1]) > value[-1][1]:
                            key_value = [key[0], key[1], value[-1][0], value[-1][1]]
                            break
                        else:
                            for j in range(len(value) - 1):

                                if value[j][1] < float(tp_mapping[1]) < value[j + 1][0]:
                                    key_value = [key[0], key[1], value[j][0], value[j][1]]
                                    break
                for key, value in model_list.items():
                    if key_value[0] == key[0] and key_value[1] == key[1] and key_value[2] == key[2] and \
                            key_value[
                                3] == \
                            key[3]:
                        bl = int(
                            (int(value[0] * float(tp_mapping[0]) + value[1] * float(tp_mapping[1]) + value[2]) * nr))
                        break

    if z_pre >= limit:
        z_pre = limit
    if z_pre < 0:
        z_pre = 0


    with open(df, 'rb') as file:

        offset = 0
        file.seek(0)
        TOTAL += 1
        header = file.read(6 * 12)
        start_block_number = 0
        end_block_number = 0

        for j in range(6):
            cid, number, overflown = struct.unpack('III', header[offset:offset + 12])
            offset += 12
            if cid != seg_partition_id:
                start_block_number += number
            else:
                end_block_number = start_block_number + number

                break
        file.seek(seg_partition_id * 12)
        file.read(24)
        TOTAL += 1
        start_overflown_num = struct.unpack('III', header[offset:offset + 12])[2]

        end_overflown_num = struct.unpack('III', header[offset + 12:offset + 24])[2]
        left = z_pre - tt
        right = z_pre + tt
        if left < 0:
            left = 0
        if right < 0:
            right = 0
        s_range = [start_block_number + left, start_block_number + right]

        if s_range[0] < end_block_number and s_range[1] < end_block_number:

            start_offset = 6 * 12 + s_range[0] // (DATABLOCKSIZE // DATAFILE_PERITEM) * DATABLOCKSIZE

            start_block_id = s_range[0] // (DATABLOCKSIZE // DATAFILE_PERITEM)
            end_block_id = s_range[1] // (DATABLOCKSIZE // DATAFILE_PERITEM)

            while start_block_id <= (end_block_id):
                block = memorymanager.get_block(start_block_id)
                if block is None:

                    offset = 0

                    file.seek(start_offset)
                    block = file.read(DATABLOCKSIZE)

                    data_list = []
                    TOTAL += 1
                    for i in range(DATABLOCKSIZE // DATAFILE_PERITEM):
                        t, pos, lon, lat, mo = struct.unpack('ddddI',block[offset:offset + DATAFILE_PERITEM])

                        data_list.append([mo, float(t), float(pos), float(lon), float(lat)])
                        offset += DATAFILE_PERITEM
                        if pos == float(tp[1]) and t == float(tp[0]):
                            RT.append([mo, float(t), float(pos), float(lon), float(lat)])

                    memorymanager.add_block([start_block_id, data_list])
                else:

                    for data in block[1]:

                        mo = data[0]
                        t = data[1]
                        pos = data[2]
                        lon = data[3]
                        lat = data[4]
                        if pos == float(tp[1]) and t == float(tp[0]):
                            RT.append([mo, pos, t, lon, lat])

                start_block_id += 1
                start_offset += DATABLOCKSIZE
        if s_range[0] < end_block_number <= s_range[1]:
            start_offset = 6 * 12 + s_range[0] // (DATABLOCKSIZE // DATAFILE_PERITEM) * DATABLOCKSIZE

            start_block_id = s_range[0] // (DATABLOCKSIZE // DATAFILE_PERITEM)
            end_block_id = s_range[1] // (DATABLOCKSIZE // DATAFILE_PERITEM)

            while start_block_id <= end_block_id:
                block = memorymanager.get_block(start_block_id)
                if block is None:

                    offset = 0

                    file.seek(start_offset)
                    block = file.read(DATABLOCKSIZE)

                    data_list = []
                    TOTAL += 1
                    for i in range(DATABLOCKSIZE // DATAFILE_PERITEM):
                        t, pos, lon, lat, mo = struct.unpack('ddddI',block[offset:offset + DATAFILE_PERITEM])

                        data_list.append([mo, float(t), float(pos), float(lon), float(lat)])
                        offset += DATAFILE_PERITEM
                        if pos == float(tp[1]) and t == float(tp[0]):
                            RT.append([mo, float(t), float(pos), float(lon), float(lat)])

                    memorymanager.add_block([start_block_id, data_list])
                else:

                    for data in block[1]:

                        mo = data[0]
                        t = data[1]
                        pos = data[2]
                        lon = data[3]
                        lat = data[4]
                        if pos == float(tp[1]) and t == float(tp[0]):
                            RT.append([mo, pos, t, lon, lat])

                start_block_id += 1
                start_offset += DATABLOCKSIZE
            start_overflown_offset = 6 * 12 + start_overflown_num // (
                    DATABLOCKSIZE // DATAFILE_PERITEM) * DATABLOCKSIZE
            start_overflown_id = start_overflown_num // (DATABLOCKSIZE // DATAFILE_PERITEM)
            end_overflown_id = end_overflown_num // (DATABLOCKSIZE // DATAFILE_PERITEM)
            if start_overflown_id != 0:
                while start_overflown_id <= end_overflown_id:
                    block = memorymanager.get_block(start_overflown_id)
                    if block is None:
                        offset = 0
                        file.seek(start_overflown_offset)
                        block = file.read(DATABLOCKSIZE)
                        data_list = []
                        TOTAL += 1
                        for i in range(DATABLOCKSIZE // DATAFILE_PERITEM):
                            t, pos, lon, lat, mo = struct.unpack('ddddI',
                                                                         block[offset:offset + DATAFILE_PERITEM])

                            data_list.append([mo, float(t), float(pos), float(lon), float(lat)])
                            offset += DATAFILE_PERITEM
                            if pos == float(tp[1]) and t == float(tp[0]):
                                RT.append([mo, float(t), float(pos), float(lon), float(lat)])

                        memorymanager.add_block([start_block_id, data_list])
                    else:

                        for data in block[1]:

                            mo = data[0]
                            t = data[1]
                            pos = data[2]
                            lon = data[3]
                            lat = data[4]
                            if pos == float(tp[1]) and t == float(tp[0]):
                                RT.append([mo, pos, t, lon, lat])
                    start_overflown_id += 1
                    start_overflown_offset += DATABLOCKSIZE

        if s_range[0] >= end_block_number and s_range[1] >= end_block_number:
            start_overflown_offset = 6 * 12 + start_overflown_num // (DATABLOCKSIZE // DATAFILE_PERITEM) * DATABLOCKSIZE
            start_overflown_id = start_overflown_num // (DATABLOCKSIZE // DATAFILE_PERITEM)
            end_overflown_id = end_overflown_num // (DATABLOCKSIZE // DATAFILE_PERITEM)
            if start_overflown_id != 0:
                while start_overflown_id <= (end_overflown_id):
                    block = memorymanager.get_block(start_overflown_id)
                    if block is None:
                        offset = 0
                        file.seek(start_overflown_offset)
                        block = file.read(DATABLOCKSIZE)
                        data_list = []
                        TOTAL += 1
                        for i in range(DATABLOCKSIZE // DATAFILE_PERITEM):
                            t, pos, lon, lat, mo = struct.unpack('ddddI',
                                                                         block[offset:offset + DATAFILE_PERITEM])

                            data_list.append([mo, float(t), float(pos), float(lon), float(lat)])
                            offset += DATAFILE_PERITEM
                            if pos == float(tp[1]) and t == float(tp[0]):
                                RT.append([mo, float(t), float(pos), float(lon), float(lat)])

                        memorymanager.add_block([start_block_id, data_list])
                    else:

                        for data in block[1]:

                            mo = data[0]
                            t = data[1]
                            pos = data[2]
                            lon = data[3]
                            lat = data[4]
                            if pos == float(tp[1]) and t == float(tp[0]):
                                RT.append([mo, pos, t, lon, lat])

                    start_overflown_id += 1
                    start_overflown_offset += DATABLOCKSIZE
    return RT
def point_query():

    base=os.getcwd()
    print(base)
    pkl_path = f"{base}\\code\\PPT\\preprocess\\preprocess_sim\\pkl_sim"

    seg_mapping_sort_pkl = os.path.join(pkl_path, 'seg_mapping_sort_3.pkl')
    seg_mapping_partition_pkl = os.path.join(pkl_path, 'seg_mapping_partition_3.pkl')
    SM_pkl = os.path.join(pkl_path, 'SM_3.pkl')
    """seg_mapping_sort_pkl = 'E:\chengxu\experiment\pkl文件\seg_mapping_sort.pkl'
    seg_mapping_partition_pkl = 'E:\chengxu\experiment\pkl文件\seg_mapping_partition.pkl'"""
    query_file = f"{base}\\code\\PPT\\query\\point_query_0.txt"

    seg_mapping_sort = load_from_file(seg_mapping_sort_pkl)
    seg_mapping_partition = load_from_file(seg_mapping_partition_pkl)
    time_partition = {0: [[25200, 68400]], 1: [[0, 25200], [68400, 86400]]}
    time_mapping = {0: {0: 25200}, 1: {0: 0, 1: 43200}}
    W = {0: 43200, 1: 43200}

    df_path = f"{os.getcwd()}\\model\\PPT"


    df = os.path.join(df_path, 'data.dat')
    model_path = os.path.join(df_path, 'model.idx')
    """df = 'E:\dataset\实验数据1220\重新分区总的模型大小_sim_200\\900\\data.dat'
    model_path = 'E:\dataset\实验数据1220\重新分区总的模型大小_sim_200\\900\\model.idx'"""

    query = []
    with open(query_file, 'r') as file:
        for line in file.readlines():
            line = line.strip().split(',')
            query.append([float(line[0]), float(line[1])])
    RT_total = []
    memorymanager = MemoryManager(MAX_BLOCKS)
    t1 = time.time()
    for q in query:
        seg_partition_id, tp_mapping = timeFrameForPointQuery(q, time_partition, seg_mapping_partition,
                                                              seg_mapping_sort,W)
        temp_RT = pointQueryResult(tp_mapping, q, df, seg_partition_id, model_path, memorymanager)
        # print(temp_RT)
        RT_total.append(temp_RT)
    t2 = time.time()
    print(TOTAL / 100)
    print((t2 - t1) / 100)

if __name__ == '__main__':
    point_query()
