import random

import pandas as pd
import os


def generate_query_data(f_path, query_file, ff):
    query_path = query_file + "\\" + str(ff) + ".txt"
    if not os.path.exists(query_path):
        with open(query_path, 'w') as f:
            pass
    with open(query_path, 'a') as fff:
        nn = 0
        i = 0
        with open(f_path, 'r') as file:

            for line in file.readlines():
                if i < 100:
                    if nn % 50 == 0:
                        line = line.strip().split(',')
                        lt = float(line[5])
                        lp = float(line[6])

                        fff.write(f'{lt},{lp}\n')
                        i += 1

                    nn += 1


if __name__ == "__main__":
    f_path = "E:\dataset\\txt_simulation4-1_period_sort_20\\6\\0_1_new.txt"
    query_file = "E:\dataset\sim_data_query_point_20"
    generate_query_data(f_path, query_file, 6)
