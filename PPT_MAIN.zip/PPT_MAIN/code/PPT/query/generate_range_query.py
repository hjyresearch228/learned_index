import random

import pandas as pd
import os


def generate_query_data(f_path, query_file):
    file_list = os.listdir(f_path)
    for file_ in file_list:
        ff = os.path.splitext(file_)[0]
        query_path = query_file + "\\" + ff + ".txt"
        if not os.path.exists(query_path):
            with open(query_path, 'w') as f:
                pass
        file_path = os.path.join(f_path, file_)

        data = pd.read_csv(file_path, delimiter=',', header=None, names=['mo', 'pos', 't', 'lon', 'lat'])
        max_pos = data['pos'].astype(float).max()
        min_pos = data['pos'].astype(float).min()

        max_t = data['t'].astype(float).max()
        min_t = data['t'].astype(float).min()

        with open(query_path, 'a') as fff:
            range_value = 3
            time_range = 200
            while range_value <= 12:
                seg_range = [range_value - 3, range_value]
                time_range_list = [time_range - 200, time_range]
                for i in range(25):

                    lt = random.uniform(min_t, max_t - time_range_list[1])

                    lp = random.uniform(min_pos, max_pos - seg_range[1])

                    m = random.uniform(time_range_list[0], time_range_list[1])
                    n = random.uniform(seg_range[0], seg_range[1])
                    rt = lt + m
                    rp = lp + n

                    fff.write(f'{lt},{lp},{rt},{rp}\n')
                range_value += 3
                time_range += 200


if __name__ == "__main__":
    f_path = "E:\dataset\\txt_simulation4-1_point_1"
    query_file = "E:\dataset\sim_data_query_20_seg2"
    generate_query_data(f_path, query_file)
