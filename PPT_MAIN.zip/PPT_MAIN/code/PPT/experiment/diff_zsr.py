import numpy as np
import pandas as pd
import time

import math
import os
import struct
import pickle

MAX = 100000000
DATAFILE_PERITEM = 36
DATABLOCKSIZE = 8 * 1024


def sort(file_path, outputfile_path, datasize_percent):
    if not os.path.exists(outputfile_path):
        os.makedirs(outputfile_path)
    folders_name = os.listdir(file_path)
    for folder in folders_name:
        folder_path = os.path.join(file_path, folder)
        f_list = os.listdir(folder_path)
        output_folder = os.path.join(outputfile_path, folder)
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)
        for f_ in f_list:
            f_path = os.path.join(folder_path, f_)
            ff_ = os.path.splitext(f_)[0] + '_new.txt'

            out_path = os.path.join(output_folder, ff_)

            mo_list=[]
            t_list = []
            pos_list = []
            mo1_list = []
            t1_list = []
            pos1_list = []
            lon_list=[]
            lat_list=[]

            for chunk in pd.read_csv(f_path, chunksize=datasize_percent, names=['mo', 'pos', 't', 'mo1', 'pos1', 't1','lon','lat']):
                mo_list.append(chunk['mo'].iloc[0])
                t_list.append(chunk['t'].iloc[0])
                pos_list.append(chunk['pos'].iloc[0])

                mo1_list.append(chunk['mo1'].iloc[0])
                t1_list.append(chunk['t1'].iloc[0])
                pos1_list.append(chunk['pos1'].iloc[0])
                lon_list.append(chunk['lon'].iloc[0])
                lat_list.append(chunk['lat'].iloc[0])
            data1 = list(zip(mo_list, t_list, pos_list, mo1_list, t1_list, pos1_list,lon_list,lat_list))

            sorted_data = sorted(data1, key=lambda item: (item[2]))
            sorted_data = sorted(sorted_data, key=lambda item: int(item[1] / 1800))

            sorted_data = [(mo, x, y, idx, mo1, x1, y1,lon,lat) for idx, (mo, x, y, mo1, x1, y1,lon,lat) in enumerate(sorted_data)]

            sorted_data = sorted(sorted_data, key=lambda item: item[3])
            with open(out_path, 'w') as f:

                for i in range(len(sorted_data)):
                    mo = sorted_data[i][0]
                    t = sorted_data[i][1]
                    pos = sorted_data[i][2]
                    idx = sorted_data[i][3]
                    mo1 = sorted_data[i][4]
                    t1 = sorted_data[i][5]
                    pos1 = sorted_data[i][6]
                    lon=sorted_data[i][7]
                    lat=sorted_data[i][8]
                    f.write(f'{mo},{t},{pos},{idx},{mo1},{t1},{pos1},{lon},{lat}\n')


def save_to_file(file_, filename):
    with open(filename, 'wb') as file:
        pickle.dump(file_, file)


def load_from_file(filename):
    with open(filename, 'rb') as file:
        return pickle.load(file)


class spatial_function:
    def __init__(self):
        self.coef_ = []

    def fit(self, features, target):
        A = np.array([[sum(features[:, 0] ** 2), sum(features[:, 0] * features[:, 1]), sum(features[:, 0])],
                      [sum(features[:, 0] * features[:, 1]), sum(features[:, 1] ** 2), sum(features[:, 1])],
                      [sum(features[:, 0]), sum(features[:, 1]), features.shape[0]]])

        B = np.array([[np.sum(features[:, 0] * target, dtype=np.float64),
                       np.sum(features[:, 1] * target, dtype=np.float64), np.sum(target, dtype=np.float64)]])
        X = np.linalg.pinv(A).dot(B.T)
        # X = np.linalg.solve(A, B.T)
        self.coef_.append(X[0])
        self.coef_.append(X[1])
        self.coef_.append(X[2])

    def predict(self, features):
        z = np.zeros((1, features.shape[0]))
        z += (self.coef_[0] * features[:, 0] + self.coef_[1] * features[:, 1] + self.coef_[2])
        pre_ = z[0].astype(int)

        return pre_


def dp_plane(data, stop_error):
    stop_error = int(stop_error)
    mo = data['mo'].values
    x = data['t'].values
    y = data['pos'].values
    z = data['sort_value'].values

    train_ = np.column_stack((mo, x, y, z))

    x_ = np.floor(x / 1800)
    grouped_train = {}

    for i, group_key in enumerate(x_):
        if (group_key, group_key + 1) not in grouped_train.keys():
            grouped_train[(group_key, group_key + 1)] = []

        grouped_train[(group_key, group_key + 1)].append(train_[i])

    model_list = {}

    for key, train_set in grouped_train.items():

        dp_reg = DP(stop_error)

        dp_reg.fit(train_set)
        model = dp_reg.RL

        for item in model:
            model_list[
                (key[0] * 1800, key[1] * 1800, train_set[item[0][0]][2], train_set[item[0][1]][2])] = item[1].coef_

    return model_list


class DP:
    def __init__(self, stop_error):
        self.stop_error = stop_error
        self.RL = []

    def fit(self, points):
        start = 0
        end = len(points) - 1
        self._DP(points, start, end)

    def _DP(self, points, start, end):
        global ERROR_PLANE
        features = np.array([arr[1:3] for arr in points])[start:end + 1]

        target_ = [int(arr[3]) for arr in points][start:end + 1]
        target = np.array(target_)
        model = spatial_function()

        model.fit(features, target)
        max_error = -1
        split_point = end

        dist_ = []
        for i in range(start, end + 1):
            distance = self._cal_distance(points[i], model)
            dist_.append([distance, i])
            if distance > max_error:
                max_error = distance
        split_points = sorted(dist_, key=lambda x: x[0], reverse=True)[:6]
        for j in range(len(split_points)):
            if split_points[j][1] != start and split_points[j][1] != start + 1 and split_points[j][1] != start + 2 and \
                    split_points[j][1] != end and split_points[j][1] != end - 1:
                split_point = split_points[j][1]
        if max_error >= self.stop_error:
            if abs(end - start + 1) >= 6:
                self._DP(points, start, split_point - 1)
                self._DP(points, split_point, end)
            elif abs(end - start + 1) == 5:
                self._DP(points, start, start + 2)
                self._DP(points, end - 2, end)
            else:
                self.RL.append([(start, end), model, max_error])

                ERROR_PLANE += 1
                print(dist_)

        else:
            if abs(end - start + 1) >= 3:
                self.RL.append([(start, end), model, max_error])


    def _cal_distance(self, pt, model):

        pre = model.predict(np.array([[pt[1], pt[2]]]))

        z = pt[3]

        dist = abs(z - pre)
        return dist.astype(int)


def dp_plane_predict(data, model_list, nr, limit):
    mo = data['mo'].values
    x = data['t'].values
    y = data['pos'].values
    z = data['sort_value'].values
    mo1 = data['mo1'].values
    x1 = data['t1'].values
    y1 = data['pos1'].values
    lon = data['lon'].values
    lat = data['lat'].values
    x_predict = np.column_stack((mo, x, y))

    x_pre = np.column_stack((mo1, x1, y1, lon, lat))
    z_pre_list = []

    for i in range(len(x_predict)):
        z_pre = None
        for key, value in model_list.items():

            if key[0] <= float(x_predict[i][1]) < key[1] and key[2] <= float(x_predict[i][2]) <= key[3]:
                z_pre = int((int(value[0] * x_predict[i][1] + value[1] * x_predict[i][2] + value[2]) * nr))

        if z_pre is None:
            for key, value in model_list.items():
                if key[0] <= float(x_predict[i][1]) < key[1]:
                    if float(x_predict[i][2]) > key[3]:
                        z_pre = int((int(value[0] * x_predict[i][1] + value[1] * x_predict[i][2] + value[2]) * nr))
                        break

            if x_predict[i][1] < list(model_list.keys())[0][2] or x_predict[i][2] < list(model_list.keys())[0][3]:
                v = model_list.get(list(model_list.keys())[0])
                z_pre = int((int(v[0] * x_predict[i][1] + v[1] * x_predict[i][2] + v[2]) * nr))

            if x_predict[i][1] > list(model_list.keys())[-1][2] or x_predict[i][2] > list(model_list.keys())[-1][3]:
                v = model_list.get(list(model_list.keys())[-1])
                z_pre = int((int(v[0] * x_predict[i][1] + v[1] * x_predict[i][2] + v[2]) * nr))

        if z_pre >= limit:
            z_pre = limit
        if z_pre < 0:
            z_pre = 0

        z_pre_list.append(z_pre)

    z_pre_list = np.array(z_pre_list)

    results = np.c_[x_predict, z_pre_list, x_pre]

    return results


def create_cache(start, end, curve_a, curve_b):
    dp = [[MAX for _ in range(len(curve_b))] for _ in range(end - start + 1)]

    return dp


def frechet_distance(DL, PL, file):
    """
    frechet-distance 改进版
    :param DL:
    :param PL:
    :return:
    """

    cache_number = 5000
    start = 0
    if start + cache_number > len(DL):
        end = len(DL) - 1
    else:
        end = start + cache_number - 1
    while start < len(DL):
        dp = [[MAX for _ in range(len(PL))] for _ in range(end - start + 1)]
        with open(file, 'rb+') as f:
            for i in range(start, end + 1):
                for j in range(len(PL)):

                    if i - start == 0 and j == 0 and start == 0:
                        dp[i - start][j] = abs(DL[i][3] - PL[j])

                    elif i - start == 0 and j > 0 and start == 0:
                        dp[i - start][j] = min(abs(DL[i][3] - PL[j]), abs(DL[i][3] - PL[j - 1]))

                    elif i - start == 0 and j > 0 and start != 0:
                        k = j - 1
                        f.seek(4 * ((i - 1) * len(PL) + k))
                        value_ = f.read(4 * (len(PL) - 1 - k))

                        o = 0
                        for z in range((len(PL) - 1 - k)):
                            value = struct.unpack('i', value_[o:o + 4])[0]
                            o += 4
                            k += 1
                            dp[i - start][k] = min(max(value, abs(DL[i][3] - PL[k])),
                                                   dp[i - start][k - 1])
                        """f.seek(4 * ((i - 1) * len(PL) + (j - 1)))
                        value = f.read(4)
                        value = struct.unpack('i', value[:4])[0]

                        dp[i - start][j] = min(max(value, abs(DL[i][3] - PL[j])),
                                               dp[i - start][j - 1])"""
                        break

                    elif 0 < i - start and i <= j:
                        dp[i - start][j] = min(max(dp[i - start - 1][j - 1], abs(DL[i][3] - PL[j])),
                                               dp[i - start][j - 1])

        with open(file, 'rb+') as f:
            """for i in range(start, end + 1):
                for j in range(len(PL)):
                    f.seek(4 * (i * len(PL) + j))
                    f.write(struct.pack('i', int(dp[i - start][j])))"""
            items = []
            for i in range(start, end + 1):
                for j in range(len(PL)):
                    items.append(int(dp[i - start][j]))

            f.seek(4 * (start * len(PL)))

            count = '{}i'.format((end - start + 1) * (len(PL)))
            f.write(struct.pack(count, *items))
        start = end + 1
        if start + cache_number > len(DL):
            end = len(DL) - 1
        else:
            end = start + cache_number - 1

    n_ = len(PL) - 1
    n1 = n_
    n2 = n1 - 1
    match_results = []
    for i in range(len(DL) - 1, -1, -1):

        match_place = n1
        if n2 >= 0:
            with open(file, 'rb+') as f:
                f.seek(4 * (i * len(PL) + n2))
                value_2 = f.read(4)
                value2 = struct.unpack('i', value_2[:4])[0]
                f.seek(4 * (i * len(PL) + n1))
                value_1 = f.read(4)
                value1 = struct.unpack('i', value_1[:4])[0]
                while value2 == value1:
                    if abs(DL[i][3] - PL[n2]) < abs(DL[i][3] - PL[n1]):

                        match_place = n2
                        n1 -= 1
                        n2 -= 1
                        if n1 >= 0 and n2 >= 0:
                            print(f'i={i},n2={n2}')
                            print(len(PL))
                            f.seek(4 * (i * len(PL) + n2))
                            value_2 = f.read(4)
                            value2 = struct.unpack('i', value_2[:4])[0]
                            f.seek(4 * (i * len(PL) + n1))
                            value_1 = f.read(4)
                            value1 = struct.unpack('i', value_1[:4])[0]
                        else:
                            n1 += 1
                            n2 += 1
                            break
                    else:
                        n1 += 1
                        n2 += 1
                        break
                n1 -= 1
                n2 -= 1

        # print(f'DL[{i}]: {DL[i]} corresponds to pl[{match_place}]: {PL[match_place]}')
        arr_list = DL[i].tolist()[:3]
        arr_list1 = DL[i].tolist()[4:]
        arr_list.extend([PL[match_place]])
        arr_list.extend(arr_list1)
        match_results.append(arr_list)

    match_results = sorted(match_results, key=lambda x: x[3])
    with open(file, 'rb+') as f:
        f.seek(4 * ((len(DL) - 1) * len(PL) + len(PL) - 1))
        value_2 = f.read(4)
        max_ = struct.unpack('i', value_2[:4])[0]
    return max_, match_results


def pack_model(cid, model_list, max_error, cid_num, model_path):
    if not os.path.exists(model_path):
        with open(model_path, 'wb') as file:
            pass
        with open(model_path, 'rb+') as file:
            header = b''
            for i in range(cid_num):
                tt = 0
                start = 0
                plane_num = 0
                nr = 1
                header += struct.pack('IIIIf', i, tt, start, plane_num, np.float32(nr))
            file.write(header)

    with open(model_path, 'r+b') as file:

        offset = 0
        item_offset = 0
        for i in range(cid_num):

            file.seek(offset)
            cid_item = file.read(20)
            cid_, tt, start, plane_num, nr = struct.unpack('IIIIf', cid_item)
            nr = np.float32(nr)
            print(f'cid_={cid_},cid={cid}')
            if cid_ != cid:
                offset += 20
                item_offset = start + plane_num
                print(item_offset)
            else:
                break

        plane_item = b''
        plane_num = len(model_list)
        print(f'plane_num={plane_num}')
        for key, value in model_list.items():
            plane_item += struct.pack('fffffff',
                                      np.float32(key[0]),
                                      np.float32(key[1]),
                                      np.float32(key[2]),
                                      np.float32(key[3]),
                                      np.float32(value[0][0]),
                                      np.float32(value[1][0]),
                                      np.float32(value[2][0]))
            print(
                f'{np.float32(key[0])},{np.float32(key[1])},{np.float32(key[2])},{np.float32(key[3])},{np.float32(value[0][0])},{np.float32(value[1][0])},{np.float32(value[2][0])}')
        file.seek(offset)
        file.write(struct.pack('IIIIf', cid_, max_error, item_offset, plane_num, np.float32(nr)))

        file.seek(cid_num * 20 + item_offset * 28)
        file.write(plane_item)


def unpack_model(cid, model_path, cid_num):
    with open(model_path, 'rb') as file:
        cid_, tt, start, plane_num, nr = unpack_header(cid, model_path)
        file.seek(cid_num * 20 + start * 28)
        model_item = file.read(plane_num * 28)
        offset = 0
        model_dict = {}
        for i in range(plane_num):
            l, r, b_, t, a, b, c = struct.unpack('fffffff', model_item[offset:offset + 28])

            model_dict[(np.float32(l), np.float32(r), np.float32(b_), np.float32(t))] = [np.float32(a), np.float32(b),
                                                                                         np.float32(c)]
            offset += 28
        return model_dict, tt, nr


def unpack_header(cid, model_path):
    with open(model_path, 'rb') as file:
        file.seek(cid * 20)
        header_item = file.read(20)
        cid_, tt, start, plane_num, nr = struct.unpack('IIIIf', header_item)
        nr = np.float32(nr)
        return cid_, tt, start, plane_num, nr


def pack_header(cid, tt, nr, model_path):
    with open(model_path, 'rb+') as file:
        file.seek(cid * 20 + 4)
        file.write(struct.pack('I', tt))
        file.seek(cid * 20 + 16)
        file.write(struct.pack('f', np.float32(nr)))


def whole_part(file_period_path, stop_error, zsr, train_value, model_path, total_tuning_error_WD,
               ):
    stop_error = int(stop_error)
    zsr = float(zsr)
    m = 0
    # 由于pos范围小，所以先获取该区域的pos范围
    if train_value == "1":
        results = None

        files = os.listdir(file_period_path)
        files.sort(key=lambda x: int(x.split("_")[1]))
        files.sort(key=lambda x: int(x.split("_")[0]))
        cid_num = len(files)
        for file in files:
            print(file)
            cid = int(os.path.splitext(file)[0].split("_")[1])
            zone_path = os.path.join(file_period_path, file)

            data = pd.read_csv(zone_path, usecols=range(4), names=['mo', 't', 'pos', 'sort_value'])
            model_list = dp_plane(data, stop_error)
            m += len(model_list)
            pack_model(cid, model_list, stop_error, cid_num, model_path)
    if train_value == "0":
        files = os.listdir(file_period_path)
        files.sort(key=lambda x: int(x.split("_")[1]))
        files.sort(key=lambda x: int(x.split("_")[0]))
        cid_num = len(files)
        cid_list = []
        for file in files:
            total_match_results = {}
            cid = int(os.path.splitext(file)[0].split("_")[1])

            model_list, tt, nr = unpack_model(cid, model_path, cid_num)
            print(f"tt={tt}")
            zone_path = os.path.join(file_period_path, file)
            file1 = 'dp3.txt'

            data = pd.read_csv(zone_path, names=['mo', 't', 'pos', 'sort_value', 'mo1', 't1', 'pos1','lon','lat'])
            number1 = len(data)
            limit=math.ceil(number1 * zsr)
            results = dp_plane_predict(data, model_list, 1,limit)

            result1 = sorted(results, key=lambda x: x[3])

            DL1 = result1

            PL1 = list(range(math.ceil(number1 * zsr)))

            if not os.path.exists(file1):
                open(file1, 'w').close()
            max_error1, match_results = frechet_distance(DL1, PL1, file1)
            total_tuning_error_WD.append(max_error1)
            print(f"length={len(match_results)}")
            print(f"max_error1={max_error1}")
            if os.path.exists(file1):
                os.remove(file1)



if __name__ == '__main__':
    data_size_percent = 128

    sort_file_path = "E:\dataset\实验数据1220\sim_diff_zsr_128"
    output_file_paths = 'E:\dataset\\txt_simulation4-1_period_all'

    #sort(output_file_paths, sort_file_path, data_size_percent)
    files = os.listdir(sort_file_path)
    files.sort(key=lambda x: int(x))
    stop_error = 400
    zsr = 1.25
    model_path = "E:\dataset\实验数据1220\model_for_diff_zsr\model.idx"
    total_tuning_error_WD = []

    for file in files:
        file_period_path = sort_file_path + "\\" + file
        if int(file) == 0:
            whole_part(file_period_path, stop_error, zsr, "1", model_path, total_tuning_error_WD)
        if int(file) == 1:
            whole_part(file_period_path, stop_error, zsr, "0", model_path, total_tuning_error_WD)
    print(sum(total_tuning_error_WD) / len(total_tuning_error_WD))

