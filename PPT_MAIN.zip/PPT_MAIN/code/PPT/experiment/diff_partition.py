import math
import pickle
import os
import pickle
import numpy as np
import pandas as pd


def inner_partition_all_pd(time_partition: dict, segment_partition: dict, seg_mapping_partition: dict,
                           time_mapping: dict,
                           seg_mapping_sort, all_file_path,
                           output_file_paths, W):
    file_name_list = os.listdir(all_file_path)
    file_number = 0
    for file_name in file_name_list:
        print(f'file_name')

        ff_ = os.path.splitext(file_name)[0]
        output_file_path = os.path.join(output_file_paths, ff_)
        os.makedirs(output_file_path)
        file_path = os.path.join(all_file_path, file_name)
        base_time = 0
        inner_partition(time_partition, segment_partition, seg_mapping_partition, time_mapping,
                        seg_mapping_sort, file_path,
                        output_file_path, file_number, W, base_time)
        file_number += 1


def inner_partition(time_partition: dict, segment_partition: dict, seg_mapping_partition: dict, time_mapping: dict,
                    seg_mapping_sort, file_path,
                    output_file_path, file_number, W, base_time):
    """

    :param time_partition:存储字典，键值为0，1，对应时间区间
    :param segment_partition:存储字典，划分的分区1，2，3……，对应的路段列表[seg1,seg2……],[seg5,seg6……]
    :return:
    """
    output_file_paths = {}
    out_dict = {}
    for time_partition_id, seg_partition in segment_partition.items():
        for seg_partition_id in seg_partition.keys():
            file_name = output_file_path + "\\" + str(time_partition_id) + "_" + str(seg_partition_id) + '.txt'
            output_file_paths[seg_partition_id] = file_name
            out_dict[seg_partition_id] = []
            with open(file_name, 'w'):
                pass
    with open(file_path, 'r') as file:
        print(file_path)

        nn = 0
        # base_time = file_number * 86400

        for line in file.readlines():

            line = line.strip().split(',')
            mo1 = line[0]
            pos1 = float(line[1])
            timestamp1 = float(line[2])
            mo2 = line[0]
            pos2 = float(line[1])
            timestamp2 = float(line[2])

            time_partition_id = None
            time_id = None
            for key, value in time_partition.items():
                for i in range(len(value)):
                    if value[i][0] <= timestamp2 % 86400 < value[i][1]:
                        time_partition_id = key
                        time_id = (key, i)
            if (int(pos2) in seg_mapping_partition[time_partition_id].keys()) and (
                    int(pos2) in seg_mapping_sort[time_partition_id].keys()):
                seg_partition_id = seg_mapping_partition[time_partition_id][int(pos2)]
                pos2 = seg_mapping_sort[time_partition_id][int(pos2)] + (pos2 - int(pos2))
                time_ = timestamp2 % 86400
                tf = 0
                n = 0
                m = 0
                key = -1
                for i in range(len(time_partition[0])):
                    if (time_partition[0][i][0] - base_time) <= time_ < (time_partition[0][i][1] - base_time):

                        if i == 0:
                            tf = (n + time_ - (time_partition[0][i][0] - base_time))
                            key = 0
                        else:
                            n += (time_partition[0][i - 1][1] - time_partition[0][i - 1][0])
                            tf = (n + time_ - (time_partition[0][i][0] - base_time))
                            key = 0

                for i in range(len(time_partition[1])):
                    if (time_partition[1][i][0] - base_time) <= time_ < (time_partition[1][i][1] - base_time):

                        if i != 0:
                            m += (time_partition[1][i - 1][1] - time_partition[1][i - 1][0])
                        tf = (m + time_ - (time_partition[1][i][0] - base_time))
                        key = 1
                # timestamp = ((timestamp - base_time) // 86400) * (W[key]) + tf
                timestamp2 = tf
                # timestamp = timestamp - time_mapping[time_id[0]][time_id[1]]
                out_dict[seg_partition_id].append([mo2, pos2, timestamp2, mo1, pos1, timestamp1])

    file_list = os.listdir(output_file_path)
    for file_name in file_list:

        seg_partition_id = int(os.path.splitext(file_name)[0].split('_')[1])
        file_ = os.path.join(output_file_path, file_name)
        with open(file_, 'w') as file:
            for item in out_dict[seg_partition_id]:
                file.write(f'{item[0]},{item[1]},{item[2]},{item[3]},{item[4]},{item[5]}\n')


def time_seg_partition(time_partition: dict, segment_partition: dict, sort_segment: dict):
    """
    存储时间分区和路段分区对应的SM矩阵
    :param time_partition:
    :param segment_partition:
    :return:
    """
    seg_mapping_sort = {}  # 路段在对应区间的重新排序值
    seg_mapping_partition = {}  # 路段对应的路段分区
    SM = [[None for _ in range(len(sort_segment))] for _ in range(len(time_partition))]

    for time_partition_id, time_range in time_partition.items():
        time_partition_id = int(time_partition_id)
        segs_dict = segment_partition[time_partition_id]
        seg_mapping_sort[time_partition_id] = {}
        seg_mapping_partition[time_partition_id] = {}

        for seg_partition_id, segs in segs_dict.items():
            seg_partition_id = int(seg_partition_id)

            sort_segs = sorted(segs)
            sort_segs = [(sort_segs.index(x), x) for x in segs]

            for seg in sort_segs:
                seg_mapping_partition[time_partition_id][int(seg[1])] = seg_partition_id
                seg_mapping_sort[time_partition_id][int(seg[1])] = seg[0]
                SM[time_partition_id][int(seg[1])] = (seg_partition_id, seg[0])
    return seg_mapping_sort, seg_mapping_partition, SM


def sort(file_path, outputfile_path):
    if not os.path.exists(outputfile_path):
        os.makedirs(outputfile_path)
    folders_name = os.listdir(file_path)
    for folder in folders_name:
        folder_path = os.path.join(file_path, folder)
        f_list = os.listdir(folder_path)
        output_folder = os.path.join(outputfile_path, folder)
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)
        for f_ in f_list:
            f_path = os.path.join(folder_path, f_)
            ff_ = os.path.splitext(f_)[0] + '_new.txt'

            out_path = os.path.join(output_folder, ff_)
            data = pd.read_csv(f_path, delimiter=',', header=None, names=['mo', 'pos', 't', 'mo1', 'pos1', 't1'])
            mo_list = data['mo'].values
            t_list = data['t'].values
            pos_list = data['pos'].values
            mo1_list = data['mo1'].values
            t1_list = data['t1'].values
            pos1_list = data['pos1'].values
            data1 = list(zip(mo_list, t_list, pos_list, mo1_list, t1_list, pos1_list))

            sorted_data = sorted(data1, key=lambda item: (item[2]))
            sorted_data = sorted(sorted_data, key=lambda item: int(item[1] / 1800))

            sorted_data = [(mo, x, y, idx, mo1, x1, y1) for idx, (mo, x, y, mo1, x1, y1) in enumerate(sorted_data)]

            sorted_data = sorted(sorted_data, key=lambda item: item[3])
            with open(out_path, 'w') as f:

                for i in range(len(sorted_data)):
                    mo = sorted_data[i][0]
                    t = sorted_data[i][1]
                    pos = sorted_data[i][2]
                    idx = sorted_data[i][3]
                    mo1 = sorted_data[i][4]
                    t1 = sorted_data[i][5]
                    pos1 = sorted_data[i][6]
                    f.write(f'{mo},{t},{pos},{idx},{mo1},{t1},{pos1}\n')


def save_to_file(file_, filename):
    with open(filename, 'wb') as file:
        pickle.dump(file_, file)


def load_from_file(filename):
    with open(filename, 'rb') as file:
        return pickle.load(file)


def seg_partition_mapping_consistent(segment_partition):
    num = 0
    new_segment_partition = {}
    for time_partition_id, partition in segment_partition.items():
        new_segment_partition[time_partition_id] = {}
    for time_partition_id, partition in segment_partition.items():
        new_segment_partition = {}
        for key, value in partition.items():
            new_segment_partition[time_partition_id][num] = value
            num += 1
    return new_segment_partition


def time_area_partition_uniform():
    pass


def seg_partition(segment_partition):
    for time_partition_id, seg_part in segment_partition.items():
        m = 0
        for part_id, segs in seg_part.items():
            segment_partition[time_partition_id][part_id] = [_ for _ in range(m, m + len(segs))]
            m += len(segs)
        print(m)
    return segment_partition


class spatial_function:
    def __init__(self):
        self.coef_ = []

    def fit(self, features, target):
        A = np.array([[sum(features[:, 0] ** 2), sum(features[:, 0] * features[:, 1]), sum(features[:, 0])],
                      [sum(features[:, 0] * features[:, 1]), sum(features[:, 1] ** 2), sum(features[:, 1])],
                      [sum(features[:, 0]), sum(features[:, 1]), features.shape[0]]])

        B = np.array([[np.sum(features[:, 0] * target, dtype=np.float64),
                       np.sum(features[:, 1] * target, dtype=np.float64), np.sum(target, dtype=np.float64)]])
        X = np.linalg.pinv(A).dot(B.T)
        # X = np.linalg.solve(A, B.T)

        self.coef_.append(X[0])
        self.coef_.append(X[1])
        self.coef_.append(X[2])

    def predict(self, features):
        z = np.zeros((1, features.shape[0]))
        z += self.coef_[0] * features[:, 0] + self.coef_[1] * features[:, 1] + self.coef_[2]
        return z[0]





def dp_plane(data, stop_error):
    stop_error = int(stop_error)
    mo = data['mo'].values
    x = data['t'].values
    y = data['pos'].values
    z = data['sort_value'].values
    y_range = [int(min(y)), int(max(y)) + 1]
    train_ = np.column_stack((mo, x, y, z))

    x_ = np.floor(x / 1800)
    grouped_train = {}

    for i, group_key in enumerate(x_):
        if (group_key, group_key + 1) not in grouped_train.keys():
            grouped_train[(group_key, group_key + 1)] = []

        grouped_train[(group_key, group_key + 1)].append(train_[i])

    model_list = {}

    for key, train_set in grouped_train.items():

        dp_reg = DP(stop_error, y_range)

        dp_reg.fit(train_set)
        model = dp_reg.RL

        for item in model:
            model_list[
                (key[0] * 1800, key[1] * 1800, train_set[item[0][0]][2], train_set[item[0][1]][2])] = item[1].coef_

    return model_list


class DP:
    def __init__(self, stop_error, y_range):
        self.stop_error = stop_error
        self.RL = []
        self.y_range = y_range

    def fit(self, points):
        start = 0
        end = len(points) - 1
        self._DP(points, start, end)

    def _DP(self, points, start, end):
        global ERROR_PLANE
        features = np.array([arr[1:3] for arr in points])[start:end + 1]

        target_ = [int(arr[3]) for arr in points][start:end + 1]
        target = np.array(target_)
        model = spatial_function()

        model.fit(features, target)
        max_error = -1
        split_point = end

        dist_ = []
        for i in range(start, end + 1):
            distance = self._cal_distance(points[i], model)
            dist_.append([distance, i])
            if distance > max_error:
                max_error = distance
        split_points = sorted(dist_, key=lambda x: x[0], reverse=True)[:6]
        for j in range(len(split_points)):
            if split_points[j][1] != start and split_points[j][1] != start + 1 and split_points[j][1] != start + 2 and \
                    split_points[j][1] != end and split_points[j][1] != end - 1:
                split_point = split_points[j][1]
        if max_error >= self.stop_error:
            if abs(end - start + 1) >= 6:
                self._DP(points, start, split_point - 1)
                self._DP(points, split_point, end)
            elif abs(end - start + 1) == 5:
                self._DP(points, start, start + 2)
                self._DP(points, end - 2, end)
            else:
                self.RL.append([(start, end), model, max_error])



        else:
            if abs(end - start + 1) >= 3:
                self.RL.append([(start, end), model, max_error])


    def _cal_distance(self, pt, model):

        pre = model.predict(np.array([[pt[1], pt[2]]]))

        z = pt[3]

        dist = abs(z - pre)
        return dist.astype(int)





def whole_part1(file_period_path, stop_error, zsr, train_value):
    stop_error = int(stop_error)
    zsr = float(zsr)
    m = 0
    # 由于pos范围小，所以先获取该区域的pos范围
    if train_value == "1":
        results = None

        files = os.listdir(file_period_path)
        files.sort(key=lambda x: int(x.split("_")[1]))
        files.sort(key=lambda x: int(x.split("_")[0]))
        cid_num = len(files)
        #cid_list_igonre=[20,21,22,23,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,53,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79]
        """cid_list_igonre = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
                           33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 51, 57, 58, 59, 60, 61,
                           62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79]"""
        cid_list_igonre=[53]
        for file in files:
            print(file)
            cid = int(os.path.splitext(file)[0].split("_")[1])
            zone_path = os.path.join(file_period_path, file)

            data = pd.read_csv(zone_path, usecols=range(4), names=['mo', 't', 'pos', 'sort_value'])
            if len(data) == 0:
                continue
            else:

                if cid not in cid_list_igonre:
                    model_list = dp_plane(data, stop_error)
                    m += len(model_list)

    return m


if __name__ == '__main__':
    segment_partition_pkl = "E:\chengxu\experiment\pkl文件\\assignments125.pkl"
    sort_segment_pkl = "E:\chengxu\experiment\pkl文件\\sort_segment.pkl"
    file_path = 'E:\dataset\\txt_simulation4-1_point_1'
    sort_file_path_random = "E:\dataset\\txt_simulation4-1_period_sort_random_实验\\0"
    # sort_file_path = "E:\dataset\\txt_simulation4-1_period_sort1\\0"
    output_file_paths_random = 'E:\dataset\\txt_simulation4-1_period_random'
    output_file_paths_partition = 'E:\dataset\\txt_simulation4-1_period_all'
    sort_file_path_partition = "E:\dataset\\txt_simulation4-1_period_sort_all\\0"

    """time_partition = {0: [[0, 43200]], 1: [[43200, 86400]]}
    time_mapping = {0: {0: 0}, 1: {0: 43200}}
    W = {0: 43200, 1: 43200}

    segment_partition = load_from_file(segment_partition_pkl)

    segment_partition = seg_partition(segment_partition)
    sort_segment = load_from_file(sort_segment_pkl)
    seg_mapping_sort, seg_mapping_partition, SM = time_seg_partition(time_partition, segment_partition, sort_segment)

    inner_partition_all_pd(time_partition, segment_partition, seg_mapping_partition, time_mapping,
                           seg_mapping_sort, file_path,
                           output_file_paths_random, W)
    sort(output_file_paths_random, sort_file_path_random)"""

    stop_error = 600
    zsr = 1.05
    total_plane_random = whole_part1(sort_file_path_random, stop_error, zsr, "1")
    total_plane = whole_part1(sort_file_path_partition, stop_error, zsr, "1")

    print(f'total_plane_random={total_plane_random}')
    print(f'total_plane={total_plane}')
