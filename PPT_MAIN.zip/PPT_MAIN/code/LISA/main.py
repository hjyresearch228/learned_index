import os
import sys
import time

import numpy as np

from utils import file_viewer
from utils import np_utils
from utils.core.config import Config
from utils.layout_utils import generate_grid_cells
from utils.common_utils import *

from solution.LISA import LISA
from solution.piecewise_linear_curve_fit import PiecewiseModel

sys.path.append('../')


def build_LISA(data_pth: str):
    """
    :param data_pth: 数据文件绝对路径
    :return: 元组（构建后的模型对象，一维映射值序列，排序后的数据序列）
    """
    Config()  # 加载配置信息

    print(f'home_dir = {Config().home_dir}')
    print(f'data_pth = {data_pth}')

    if data_pth.endswith('.txt'):
        np_utils.convert_txt_to_npy(data_pth)  # 可修改
        data_pth = data_pth.replace('.txt', '.npy')

    assert data_pth.endswith('.npy'), AssertionError('$ build_LISA: file type ERROR.')

    raw_data = np.load(data_pth)

    t_0 = time.time()

    my_idx, one_dm_mps, sorted_data = _load_bulk(raw_data,
                                                 Config().data_dir,
                                                 Config().model_dir_init,
                                                 Config().models_dir)

    print(f'$$ bulid time: {round(time.time() - t_0, 5)} s')
    return my_idx, one_dm_mps, sorted_data


def _load_bulk(data_raw, data_dir: str, model_init_dir: str, models_dir: str):
    """
    读取数据，并建立模型
    :param data_raw: 原始数据
    :param data_dir: 数据文件夹路径
    :param model_init_dir: LISA目录
    :param models_dir: 线性模型目录
    :return:元组（构建后的模型对象，一维映射值序列，排序后的数据序列）
    """
    params_pth = os.path.join(data_dir, 'cell_params.npy')
    sorted_dt_pth = os.path.join(data_dir, 'sorted_data.npy')
    borders_pth = os.path.join(data_dir, 'cell_borders.npy')
    measures_pth = os.path.join(data_dir, 'cell_measures.npy')
    cell_ids_pth = os.path.join(data_dir, 'cell_ids.npy')
    params_num_pth = os.path.join(data_dir, 'param_nums.npy')

    load_file = False
    if os.path.exists(params_pth) and os.path.exists(sorted_dt_pth) \
            and os.path.exists(borders_pth) and os.path.exists(measures_pth):
        load_file = True  # 检查数据和参数文件是否已经存在，若存在则不进行预处理

    if load_file:
        params = np.load(params_pth)
        cl_bds = np.load(borders_pth)
        cl_ms = np.load(measures_pth)
        cl_ids = np.load(cell_ids_pth)
        para_nums = np.load(params_num_pth)
    else:
        _ = generate_grid_cells(data_raw,
                                Config().T_each_dim,
                                Config().n_piecewise_models,
                                Config().min_value,
                                Config().max_value,
                                Config().eta)

        sorted_dt, orig_one_dm_mps, params, cl_bds, cl_ms, cl_ids, para_nums = _

        np.save(sorted_dt_pth, sorted_dt)
        np.save(params_pth, params)
        np.save(params_num_pth, para_nums)
        np.save(borders_pth, cl_bds)
        np.save(measures_pth, cl_ms)
        np.save(cell_ids_pth, cl_ids)

    # 创建模型对象
    my_idx = LISA(params=params,
                  param_part_nums=para_nums,
                  cell_borders=cl_bds,
                  cell_measures=cl_ms,
                  cell_ids=cl_ids,
                  data_dim=Config().data_dim,
                  shd_size=Config().page_size,
                  sigma=Config().sigma)

    my_idx.set_model_dir(model_init_dir)

    one_dim_mps = None
    sorted_dt = np.load(sorted_dt_pth)

    one_dim_mps_pth = os.path.join(data_dir, 'one_dm_mps.npy')
    col_split_idxs_pth = os.path.join(data_dir, 'col_split_idxs.npy')

    if os.path.exists(one_dim_mps_pth) and os.path.exists(col_split_idxs_pth):
        col_split_idxs = np.load(col_split_idxs_pth)
    else:
        res_ = my_idx.monotone_mps_and_col_split_idxs_for_sorted_dt(sorted_dt)
        one_dim_mps, col_split_idxs = res_  # 获取一维映射值序列和分组索引序列

        np.save(one_dim_mps_pth, one_dim_mps)
        np.save(col_split_idxs_pth, col_split_idxs)

    n_models = col_split_idxs.shape[0]
    piece_params_dir = os.path.join(models_dir, 'piecewise')
    piece_linear_fit = my_idx.check_and_load_linear_models_params(piece_params_dir, n_models)

    # ------------------------------------构建分段线性模型SP------------------------------------
    if not piece_linear_fit:
        if one_dim_mps is None:
            one_dim_mps = np.load(one_dim_mps_pth)
        sigma = Config().sigma
        file_viewer.detect_and_create_dir(piece_params_dir)

        print(
            f'-----------------------------------SP_model: {n_models}-----------------------------------')
        start = 0
        for i_ in range(n_models):  # 为每个分区训练一个线性回归模型
            if i_ > 0:
                start = col_split_idxs[i_ - 1]
            end = col_split_idxs[i_]
            one_dim_input = one_dim_mps[start:end]
            pm = PiecewiseModel(i_, one_dim_input, sigma)
            model_dir = os.path.join(piece_params_dir, str(i_))
            if not os.path.exists(model_dir):
                pm.train()
                file_viewer.detect_and_create_dir(model_dir)
                pm.save(model_dir)
            print(f'linear_model_{i_}: trained.')
        print(f'-----------------------------------SP_model: trained-----------------------------------')

    my_idx.check_and_load_linear_models_params(piece_params_dir, n_models)  # 保存SP模型参数到LISA中
    builded_LISA = my_idx.check_and_load_params()  # 检查LISA是否已经构建

    # ------------------------------------构建LISA------------------------------------
    if not builded_LISA:
        if one_dim_mps is None:
            one_dim_mps = np.load(one_dim_mps_pth)
        print('-----------------------------------LISA: building-----------------------------------')
        my_idx.generate_pages(sorted_dt, one_dim_mps, col_split_idxs)
        print('-----------------------------------LISA: builded-----------------------------------')
        print('-----------------------------------LISA: saving-----------------------------------')
        my_idx.save()
        print('-----------------------------------LISA: saved-----------------------------------')

    if one_dim_mps is None:
        one_dim_mps = np.load(one_dim_mps_pth)

    sorted_dt = np.load(sorted_dt_pth)

    return my_idx, one_dim_mps, sorted_dt

def main_lisa():
    PPT_sim_dir = r'D:\BaiduNetdiskDownload\PPT数据\txt_simulation4-1_point_1'
    # data_src = r'C:\Users\mzq\Desktop\my_LISA\test\test_300w.txt'
    # data_src = r'D:\BaiduNetdiskDownload\模拟数据\sumo_pos_time.npy'
    # data_src = r'D:\BaiduNetdiskDownload\PPT数据\成都数据-分期txt\period_0.txt'
    data_src = fr'{PPT_sim_dir}\0.txt'  # ppt-sim
    #data_insert_src = fr'{PPT_sim_dir}\1.txt'  # ppt-insert

    result = build_LISA(data_src)
    my_LISA = result[0]

    # 检查参数是否不全为0
    # check_alphas = np.any(my_LISA.Alphas)
    # check_betas = np.any(my_LISA.Betas)
    # print(f'check alphas and betas: {check_alphas, check_betas}')

    # # 测试数据
    # data_0 = np.array([10109.705473551227, 5797.414273722779])
    #
    # data_1 = np.array([[10109.705473551227, 5797.414273722779], [10109.705473551228, 5797.414273722780],
    #                    [10109.705473551229, 5797.414273722781], [10109.705473551230, 5797.414273722781],
    #                    [10109.705473551230, 5797.414273722782], [10109.705473551231, 5797.414273722783],
    #                    [10109.705473551231, 5797.414273722784], [10109.705473551232, 5797.414273722785],
    #                    [10109.705473551233, 5797.414273722786], [10109.705473551235, 5797.414273722787],])
    # test_dt = data_1
    # if test_dt.ndim == 1:
    #     data = test_dt.reshape(1, 2)

    np_utils.convert_txt_to_npy(data_insert_src)
    data_to_insert = np.load(data_insert_src)

    # my_LISA.insert_data(data_to_insert)  # 插入测试
    # my_LISA.delete_data(test_dt)  # 删除测试

    # # 范围查询测试
    # low_bound = np.array([101, 1407103200])  # 6:00 - 1407103200  12:00 - 1407124800  24:00 - 1407168000
    # high_bound = np.array([102, 1407168000])
    # qr_1 = np.array([low_bound, high_bound])
    #
    # low_bound = np.array([102, 1407103200])
    # high_bound = np.array([103, 1407168000])
    # qr_2 = np.array([low_bound, high_bound])
    #
    # # 1589.0070479916208, 1407066345
    # low_bound = np.array([34320.47, 0])
    # high_bound = np.array([34320.48, 20])
    # qr_3 = np.array([low_bound, high_bound])
    #
    # # 44546.70936697924,12290.0  44546.793765036964,12292.0
    # low_bound = np.array([44546.70, 12290.0])
    # high_bound = np.array([44546.79, 12291.0])
    # qr_ = np.array([low_bound, high_bound])
    #
    # # qr_list = [qr_1, qr_2]
    # qr_list = [qr_]
    # for qr in qr_list:
    #     qry_data, IO, t_use = my_LISA.range_query(qr)
    #     print(f'query result: {qry_data.shape[0]} \n {qry_data}')
    #     print(f'query result: {qry_data.shape[0]}')
    #     print(f'query I/O: {IO}')

    # my_LISA.save()
if __name__ == '__main__':
    PPT_sim_dir = r'D:\BaiduNetdiskDownload\PPT数据\txt_simulation4-1_point_1'
    # data_src = r'C:\Users\mzq\Desktop\my_LISA\test\test_300w.txt'
    # data_src = r'D:\BaiduNetdiskDownload\模拟数据\sumo_pos_time.npy'
    # data_src = r'D:\BaiduNetdiskDownload\PPT数据\成都数据-分期txt\period_0.txt'
    data_src = fr'{PPT_sim_dir}\0.txt'  # ppt-sim
    data_insert_src = fr'{PPT_sim_dir}\1.txt'  # ppt-insert

    result = build_LISA(data_src)
    my_LISA = result[0]

    # 检查参数是否不全为0
    # check_alphas = np.any(my_LISA.Alphas)
    # check_betas = np.any(my_LISA.Betas)
    # print(f'check alphas and betas: {check_alphas, check_betas}')

    # # 测试数据
    # data_0 = np.array([10109.705473551227, 5797.414273722779])
    #
    # data_1 = np.array([[10109.705473551227, 5797.414273722779], [10109.705473551228, 5797.414273722780],
    #                    [10109.705473551229, 5797.414273722781], [10109.705473551230, 5797.414273722781],
    #                    [10109.705473551230, 5797.414273722782], [10109.705473551231, 5797.414273722783],
    #                    [10109.705473551231, 5797.414273722784], [10109.705473551232, 5797.414273722785],
    #                    [10109.705473551233, 5797.414273722786], [10109.705473551235, 5797.414273722787],])
    # test_dt = data_1
    # if test_dt.ndim == 1:
    #     data = test_dt.reshape(1, 2)

    np_utils.convert_txt_to_npy(data_insert_src)
    data_to_insert = np.load(data_insert_src)

    # my_LISA.insert_data(data_to_insert)  # 插入测试
    # my_LISA.delete_data(test_dt)  # 删除测试

    # # 范围查询测试
    # low_bound = np.array([101, 1407103200])  # 6:00 - 1407103200  12:00 - 1407124800  24:00 - 1407168000
    # high_bound = np.array([102, 1407168000])
    # qr_1 = np.array([low_bound, high_bound])
    #
    # low_bound = np.array([102, 1407103200])
    # high_bound = np.array([103, 1407168000])
    # qr_2 = np.array([low_bound, high_bound])
    #
    # # 1589.0070479916208, 1407066345
    # low_bound = np.array([34320.47, 0])
    # high_bound = np.array([34320.48, 20])
    # qr_3 = np.array([low_bound, high_bound])
    #
    # # 44546.70936697924,12290.0  44546.793765036964,12292.0
    # low_bound = np.array([44546.70, 12290.0])
    # high_bound = np.array([44546.79, 12291.0])
    # qr_ = np.array([low_bound, high_bound])
    #
    # # qr_list = [qr_1, qr_2]
    # qr_list = [qr_]
    # for qr in qr_list:
    #     qry_data, IO, t_use = my_LISA.range_query(qr)
    #     print(f'query result: {qry_data.shape[0]} \n {qry_data}')
    #     print(f'query result: {qry_data.shape[0]}')
    #     print(f'query I/O: {IO}')

    # my_LISA.save()

    pass
