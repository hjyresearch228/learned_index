import os
import shutil
import struct

def load_list(path):
    with open(path, 'r') as reader:
        lines = reader.readlines()
    res = [s.strip() for s in lines]
    return res

def detect_and_create_dir(dir: str):
    if not os.path.exists(dir):
        os.makedirs(dir)

def detect_and_delete_dir(dir: str):
    if os.path.exists(dir):
        shutil.rmtree(dir)

def detect_and_delete_empty_dir(dir: str):
    if os.path.exists(dir):
        os.removedirs(dir)

def save_bytes_file(src: str, buffer: bytes):
    with open(src, 'wb+') as writer:
        writer.write(buffer)

def load_bytes_file(src: str, fmt: str) -> tuple:
    with open(src, 'rb') as reader:
        content = reader.read()
    tuple_ = struct.unpack(fmt, content)
    return tuple_

def load_bytes_list(src: str, fmt: str) -> list:
    with open(src, 'rb') as reader:
        content = reader.read()
    ele_num = int(len(content) / 4)  # 元素个数 = 总长度 / 元素大小
    tuple_ = struct.unpack(fmt * ele_num, content)
    return list(tuple_)


