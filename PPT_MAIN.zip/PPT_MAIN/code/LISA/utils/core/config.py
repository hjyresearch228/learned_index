"""配置文件"""

import os
import sys
from src.utils import file_viewer

PAGE_SIZE = 8192  # 块大小
DATA_SIZE = 36  # 单个数据点大小

sys.path.append("../../../")

class Config(object):
    """Configuration class."""

    class __Singleton(object):
        """Singleton design pattern."""

        def __init__(self):

            self.data_dim = 2  # 数据维度
            self.T_each_dim = 240  # 每个维度的分割组数

            self.n_piecewise_models = 100
            self.page_size = int(PAGE_SIZE / DATA_SIZE)  # 每个分片存储的平均键数

            self.min_value = 0  # 每个维度的数值下界
            self.max_value = 1e50  # 每个维度的数值上界

            self.sigma = 100
            self.eta = 0.01  #
            self.lr = 1e-1
            self.tau = 50  # number of nodes in each dim

            # self.home_dir = os.path.join(os.path.expanduser("~"), os.path.join('workspace/LISA'))
            self.home_dir = os.path.abspath(os.path.dirname(__file__)).replace('\\src\\utils\\core', '')
            self.models_dir = os.path.join(self.home_dir, 'models')
            self.data_dir = os.path.join(self.home_dir, 'data')
            self.model_dir_init = os.path.join(self.models_dir, 'LISA_Init')

            file_viewer.detect_and_create_dir(self.home_dir)
            file_viewer.detect_and_create_dir(self.models_dir)
            file_viewer.detect_and_create_dir(self.data_dir)
            file_viewer.detect_and_create_dir(self.model_dir_init)

            print('------------------------------------Config is initialized------------------------------------')

    instance = None

    def __new__(cls):
        """Return singleton instance."""
        if not Config.instance:
            Config.instance = Config.__Singleton()
        return Config.instance

    def __getattr__(self, name):
        """Get singleton instance's attribute."""
        return getattr(self.instance, name)

    def __setattr__(self, name):
        """Set singleton instance's attribute."""
        return setattr(self.instance, name)
