from src.utils.np_utils import check_unique
from src.utils.common_utils import *


def generate_grid_cells(data: np.ndarray, t: int, n_models: int,
                        min_val_per_dim: float, max_val_per_dim: float, eta) -> tuple:
    """
    生成网格
    :param data: 多维数据
    :param t: 每个维度划分为t个部分
    :param n_models: 线性回归模型个数，数值上等于所有一维映射值的分组组数
    :param min_val_per_dim: 每个维度的下界
    :param max_val_per_dim: 每个维度的上界
    :param eta: 比例系数
    :return:元组（按网格排序的数据，一维映射值列表，参数列表，所有网格的下边界，所有网格的测度，所有数据对应的网格id，每部分参数的个数列表）
    """
    print('$ generate_grid_cells')

    data_num = data.shape[0]  # 数据总个数
    data_dim = data.shape[1]  # 数据维数

    split_bounds_list = []  # 上分割点列表，行号代表维度
    sp_idx_list = []
    for j in range(data_dim):
        split_bounds_list.append([])
        sp_idx_list.append([])

    _partition(data, dim=0, start=0, end=data_num, t_parts=t, split_pts_list=split_bounds_list,
               split_idx_list=sp_idx_list, max_val_per_dim=max_val_per_dim)

    sp_idx_list[1][-1][-1] = sp_idx_list[0][0][-1]  # 补上最后一个点的索引

    borders, cell_measures = _create_borders(split_bounds_list)

    one_dim_dt_sort = np.sort(data[:, 0])  # 对数据的最后一维进行排序

    first_dm_sp_bds, _ = _get_sp_pts_and_idxs(one_dim_dt_sort, t, max_value=max_val_per_dim)

    cell_ids = np.zeros(shape=[data.shape[0]], dtype=NP_IDX_TYPE)  # 所有数据所对应的网格编号
    mp_vals = np.zeros(shape=[data.shape[0]], dtype=NP_DATA_TYPE)  # 所有映射值

    cell_id = 0
    start = 0
    for i, sp_idxs in enumerate(sp_idx_list[-1]):  # 根据最后一个维度的分组来遍历所有网格

        for j in range(sp_idxs.shape[0]):
            end = sp_idxs[j] + 1

            assert (end > start), print(f'slice error: end <= start')

            border_cur = borders[cell_id]
            cell_m_cur = cell_measures[cell_id]  # 获取当前网格的勒贝格测度
            assert (cell_m_cur > 0), print('error: cell_measure is zero.')

            part_data = data[start:end]
            part_m_cur = part_data - border_cur  # 计算当前部分的一维测度
            h_m_cur = np.prod(part_m_cur, axis=1)  # 计算整体测度

            part_m = h_m_cur / cell_m_cur  # 勒贝格测度之比
            part_m[part_m == 0] = 1e-6
            assert (part_m > 0).all()

            prt_m_new = np.array(part_m)
            idxs = np.argsort(part_m)
            for i_, idx in enumerate(idxs):
                n_ = (i_ + 1) * 1e-5
                prt_m_new[idx] = n_  # 对测度之比进行数值规范化：0.00001~0.99999按照大小次序赋值

            part_mappings = prt_m_new + cell_id  # 映射值 = 测度之比 + 网格编号
            assert check_unique(part_mappings)

            part_idxes = np.argsort(part_mappings)
            data[start:end] = part_data[part_idxes]  # 对数据排序

            cell_ids[start:end] = cell_id

            mp_vals[start:end] = part_mappings[part_idxes]

            start = end
            cell_id += 1

    assert check_unique(mp_vals), AssertionError('mappings NOT unique.')
    assert check_order(mp_vals), AssertionError('mappings NOT ordered.')

    max_mp = mp_vals.max()  # 映射值上界

    split_mps = np.zeros(shape=[n_models], dtype=NP_DATA_TYPE)  # 映射值分割点序列
    split_mps[-1] = max_mp + 1

    offset = int(mp_vals.shape[0] / n_models)
    for i_ in range(1, n_models):
        idx = i_ * offset
        m = (mp_vals[idx] + mp_vals[idx - 1]) / 2
        split_mps[i_ - 1] = m

    sp_idxs = np.searchsorted(mp_vals, split_mps, side='right')

    model_sp_mps = np.zeros(shape=[sp_idxs.shape[0]])
    model_sp_mps[0:-1] = mp_vals[sp_idxs[:-1]]
    model_sp_mps[-1] = max_mp + 1

    n_cells = 0  # 网格总数
    params = []  # 总参数列表：分为四个部分

    # 第一部分：所有维度（除了第一个维）网格划分的分割点
    for one_dm_bds in split_bounds_list[1:]:
        for bounds in one_dm_bds:
            params.extend(bounds.tolist())
            params.append(-1)  # -1作为分组结束标志
            n_cells += len(bounds)

    p1 = len(params)
    print(f'params part1: {p1}')

    # 第二部分：第一个维度的网格分割点
    list_ = first_dm_sp_bds.tolist()
    params.extend(list_)

    p2 = len(params) - p1
    print(f'params part2: {p2}')

    # 第三部分：模型分割点
    list_ = model_sp_mps.tolist()
    params.extend(list_)

    p3 = len(params) - p2 - p1
    print(f'params part3: {p3}')

    # 第四部分：网格总数，eta，每个维度的最小值，每个维度的最大值，线性模型个数
    params.append(n_cells)
    params.append(eta)
    params.append(min_val_per_dim)
    params.append(max_val_per_dim)
    params.append(n_models)
    params.append(t + 0.5)
    params.append(data_dim + 0.5)

    p4 = len(params) - p3 - p2 - p1
    print(f'params part4: {p4}')

    param_nums = [p1, p2, p3, p4]

    print('$ generate_grid_cells: CHECK ORDER')
    check_order(mp_vals)
    print('$ generate_grid_cells: CHECK ORDER DONE')
    params = np.array(params, dtype=NP_DATA_TYPE)
    print('$$ generate_grid_cells')

    return data, mp_vals, params, borders, cell_measures, cell_ids, param_nums


def _create_borders(split_points_list: list) -> tuple:
    """创建边界以及所有网格的勒贝格测度，其中边界指网格的下边界"""

    n_cells = 0  # 网格总数
    for part in split_points_list[-1]:
        n_cells += len(part)

    dim_ = len(split_points_list)
    borders = np.zeros(shape=[n_cells, dim_], dtype=NP_DATA_TYPE)
    cell_ms = np.ones(shape=[n_cells], dtype=NP_DATA_TYPE)

    # 计算第一个维度的上分割点序列
    first_dm_sp_pts = split_points_list[0][0]
    first_f_sp_pts = np.zeros_like(first_dm_sp_pts, dtype=NP_DATA_TYPE)
    first_f_sp_pts[1:] = first_dm_sp_pts[:-1]
    # 计算第一个维度的测度序列
    f_lens = first_dm_sp_pts - first_f_sp_pts

    start = 0
    for i_, last_dm_sp_pts in enumerate(split_points_list[-1]):
        l = len(last_dm_sp_pts)  # 当前分组的长度
        last_dm = len(split_points_list) - 1

        f_sp_pts = np.zeros_like(last_dm_sp_pts, dtype=NP_DATA_TYPE)  # 当前分组的前向分割点
        f_sp_pts[1:] = last_dm_sp_pts[:-1]
        lens = last_dm_sp_pts - f_sp_pts

        borders[start:start + l, last_dm] = f_sp_pts
        cell_ms[start:start + l] *= lens

        last_dm -= 1  # 处理上一个维度的分组边界
        while last_dm > 0:
            j_ = i_
            for last_dm_sp_pts_ in split_points_list[last_dm][i_]:
                f_sp_pts_ = np.zeros_like(last_dm_sp_pts_, dtype=NP_DATA_TYPE)  # 当前分组的前向分割点
                f_sp_pts_[1:] = last_dm_sp_pts_[:-1]
                borders[start:start + l, last_dm] = f_sp_pts_  # 处理d-1维，有bug
            last_dm -= 1

        # 处理第一个维度
        first_d_sp = first_f_sp_pts[i_]  # 获取当前组中第一个维度的分割值
        for _ in range(l):
            borders[start + _, last_dm] = first_d_sp  # 加入边界
        cell_ms[start:start + l] *= f_lens[i_]  # 更新勒贝格测度

        start += l
    return borders, cell_ms


def _partition(data: np.ndarray, dim: int, start: int, end: int, t_parts: int,
               split_pts_list: list, split_idx_list: list, max_val_per_dim: float):
    """
    分割函数：递归地对数据的所有维度进行分割
    :param data: 多维数据
    :param dim: 维度索引
    :param start: 待分割数据起点
    :param end: 待分割数据终点
    :param t_parts: 分割组数
    :param split_pts_list: 分割点序列（全局）
    :param split_idx_list: 分割点下标序列（全局）
    :param max_val_per_dim: 每个维度的最大值
    :return:
    """
    part_data = data[start:end]
    one_dm_data = part_data[:, dim]
    sorted_idxs = np.argsort(one_dm_data)
    data[start:end] = part_data[sorted_idxs]
    one_dm_data = data[start:end, dim]

    split_points, split_idxs = _get_sp_pts_and_idxs(one_dm_data, T=t_parts, max_value=max_val_per_dim)

    # 检查索引是否重复
    assert check_unique(split_points)

    split_pts_list[dim].append(split_points)
    split_idxs += start
    split_idx_list[dim].append(split_idxs)

    next_dm_st = start
    for i in range(split_idxs.shape[0]):
        next_dm_ed = split_idxs[i]

        if dim < data.shape[1] - 1:
            data_num_ = next_dm_ed - next_dm_st + 1
            t_parts_ = t_parts
            while data_num_ / t_parts_ < 10 and t_parts_ > 1:  # 计算下一个维度的划分组数，保证每组至少有10个数据点
                t_parts_ -= 1
            _partition(data, dim + 1, next_dm_st, next_dm_ed + 1, t_parts_, split_pts_list, split_idx_list,
                       max_val_per_dim)
        next_dm_st = next_dm_ed + 1


def _get_sp_pts_and_idxs(x_data: np.ndarray, T: int, max_value=None) -> tuple:
    """
    :param x_data: 有序的一维数据
    :param T: 分组个数
    :param max_value: 数据最大值
    :return: 元组（分割点列表，分割点索引列表）
    """
    x_split_pts = []
    x_split_idxs = []
    n_data = x_data.shape[0]

    if max_value is None:
        max_value = x_data[-1] + 0.01

    t_every_part = int(n_data / T)  # 计算每组的数据个数
    t_remainder = n_data % T  # 计算剩余的数据个数

    for i in range(t_remainder):
        if i == T - 1:
            x_split_pts.append(max_value)
            x_split_idxs.append(n_data - 1)
            continue
        idx = int((i + 1) * (t_every_part + 1))
        sp_pt = x_data[idx - 1]
        x_split_pts.append(sp_pt)
        x_split_idxs.append(idx - 1)

    for i in range(t_remainder, T):
        if i == T - 1:
            x_split_pts.append(max_value)
            x_split_idxs.append(n_data - 1)
            continue
        idx = int((i + 1) * t_every_part + t_remainder)
        if idx >= len(x_data):
            break
        sp_pt = x_data[idx - 1]
        x_split_pts.append(sp_pt)
        x_split_idxs.append(idx - 1)

    x_split_idxs = np.array(x_split_idxs, dtype=NP_IDX_TYPE)
    x_split_pts = np.array(x_split_pts, dtype=NP_DATA_TYPE)

    # 重复分割点合并
    repeat_ids = []
    for i in range(len(x_split_pts) - 2):
        pt_pre = x_split_pts[i]
        pt_po = x_split_pts[i + 1]
        if pt_po == pt_pre:
            repeat_ids.append(i)

    new_sp_pts = np.delete(x_split_pts, repeat_ids)
    new_sp_idxs = np.delete(x_split_idxs, repeat_ids)

    return new_sp_pts, new_sp_idxs
