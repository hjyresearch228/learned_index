import sys

from src.utils.common_utils import *

sys.path.append('../../')

# np.set_printoptions(suppress=True)

def cartesian_product(arrays: list):
    """计算多个数组的笛卡尔积"""
    la = len(arrays)
    dtype_ = arrays[0].dtype
    arr = np.empty([len(a) for a in arrays] + [la], dtype=dtype_)
    for i, a in enumerate(np.ix_(*arrays)):
        arr[..., i] = a
    return arr.reshape(-1, la)


def convert_txt_to_npy(src: str):
    """txt格式：每行数据按 ',' 分隔"""
    data = np.loadtxt(src, dtype=str)
    row = data.shape[0]
    data_new = []
    for i_ in range(row):
        r_ = data[i_].split(',')
        item = [float(_) for _ in r_]
        # data_new.append(item)
        data_new.append([item[1], item[2]])  # 可修改

    dst = src.replace('.txt', '')
    np.save(f'{dst}.npy', data_new)


def convert_npy_to_txt(src: str, dst: str):
    """
    将.npy文件转换为.txt文件
    :param src: .npy文件路径
    :param dst: .txt文件路径
    """
    print('$ convert_npy_to_txt')

    data = np.load(src)
    print(f'data.shape = {data.shape}')
    shape_len = len(data.shape)
    data = data.tolist()

    with open(dst, 'w') as writer:
        if shape_len == 1:
            for x in data:
                writer.write('%.10f\n' % x)
        else:
            for row_data in data:
                writer.write(' '.join(['%.10f' % i for i in row_data]) + '\n')

    print('$$ convert_npy_to_txt: done')


def check_multi_dim_data_order(data, labels=None):
    if labels is not None:
        idxes = np.argsort(labels)
        data = data[idxes]

    N = data.shape[0]
    flag = True
    for i in range(N):
        x_i = data[i, 0]
        y_i = data[i, 1]
        for j in range(i, N):
            x_j = data[j, 0]
            y_j = data[j, 1]
            if x_i > x_j and y_i > y_j:
                print(f'i = {i} ,data[i] = {data[i]}, j = {j}, data[j] = {data[j]}')
                flag = False

    return flag


def check_split_points(data: np.ndarray):
    """检查分割点是否有序"""
    flag = True
    if len(data.shape) == 1:
        data = np.reshape(data, (1, -1))

    N = data.shape[0]
    for i in range(N):
        data_i = data[i]
        for j in range(data_i.shape[0] - 1):
            if data_i[j] >= data_i[j + 1]:
                print(f'i = {i},  data_i[j] = {data_i[j]}, j = {j}, data_i[j + 1] = {data_i[j + 1]}')
                flag = False

    return flag


def check_unique(data: np.ndarray):
    _ = np.unique(data)
    return len(_) == len(data)
