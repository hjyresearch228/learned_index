import os
import sys

from src.utils import np_utils
from src.utils import file_viewer
from src.utils.common_utils import *
from src.utils.core.config import Config

sys.path.append('../..')


class PiecewiseModel:

    def __init__(self, id, sorted_mappings, sigma=100):
        self.id = id
        self.min_value = sorted_mappings.min()
        # print 'min_Value =', self.min_value
        self.sorted_mappings = sorted_mappings - self.min_value
        # self.sorted_mappings = sorted_mappings
        self.sorted_mappings_reshape = np.reshape(self.sorted_mappings, [-1, 1])

        self.positions = np.arange(0, self.sorted_mappings.shape[0], dtype=NP_IDX_TYPE)
        self.sigma = sigma

        self.alphas = None
        self.betas = np.zeros(shape=[self.sigma], dtype=NP_DATA_TYPE)
        self.init_alphas = np.zeros(shape=[self.sigma], dtype=NP_DATA_TYPE)
        self.init_betas = np.zeros(shape=[self.sigma], dtype=NP_DATA_TYPE)

    def train(self):

        n_each_cell = int(self.sorted_mappings.shape[0] / self.sigma)
        split_idxs = np.arange(0, self.sigma, dtype=NP_IDX_TYPE) * n_each_cell

        self.betas = self.sorted_mappings[split_idxs].reshape([-1])
        self.init_betas = self.sorted_mappings[split_idxs].reshape([-1])
        self.init_alphas = self._cal_init_alphas(self.init_betas)

        k = 0  # 迭代次数

        while True:
            betas = self.betas
            # assert betas is not None
            alphas_1, A = self._cal_alphas(betas)
            # assert A is not None
            if A is None or alphas_1 is None:
                break

            loss_1 = self._cal_loss(A, alphas_1)
            init_loss = loss_1

            alphas = alphas_1
            if not self._check_if_alphas_and_betas_valid(alphas_1, betas):
                alphas = self._cal_alphas_with_monotone_constrain(betas, alphas_1)
                init_loss = self._cal_loss(A, alphas)

                if not self._check_if_alphas_and_betas_valid(alphas, betas):
                    self.alphas = None
                    self.betas = None

            G = -np.sign(A).transpose()
            r = A.dot(alphas).clip(min=0, max=self.positions.shape[0]) - self.positions
            K = np.diag(alphas)
            g = 2 * K.dot((G.dot(r))) / self.sorted_mappings.shape[0]
            G_square = np.matmul(G, G.transpose())
            Y = 2 * np.matmul(np.matmul(K, G_square), K) / self.sorted_mappings.shape[0]

            # try:
            #     s = -np.linalg.inv(Y).dot(g)
            # except:
            #     s = -g

            second_grad_flag = True
            if np.linalg.cond(Y) < 1 / sys.float_info.epsilon:
                s = -np.linalg.inv(Y).dot(g)
            else:
                second_grad_flag = False
                s = -g

            lr, loss, betas_, alphas_ = self._lr_search(s, betas, init_loss)

            if lr > 0:
                self.betas = betas_
                self.alphas = alphas_
                # betas += lr * s
                # self.betas = np.sort(betas)
                # self.alphas, _ = self._cal_alphas(self.betas)

            else:
                if not second_grad_flag:
                    # self.A = A
                    # self.alphas = alphas
                    # print 'loss =', init_loss
                    break
                else:
                    s = -g
                    # lr, loss = self._lr_search(s, betas, init_loss)
                    lr, loss, betas_, alphas_ = self._lr_search(s, betas, init_loss)

                    if lr > 0:
                        self.betas = betas_
                        self.alphas = alphas_
                        # betas += lr * s
                        # self.betas = np.sort(betas)
                        # self.alphas, _ = self._cal_alphas(self.betas)
                    else:
                        # print 'loss =', init_loss

                        # all_pred_idxes = self._predict_idxs(self.sorted_mappings)
                        # diff = np.abs(all_pred_idxes - self.positions)
                        # print 'avg_diff =', np.average(diff)
                        break

            # if k % 100 == 0:
            #     print '---------------col_id =', self.id, ', k =', k, '----------------'
            #     print 'xloss =', loss

            k += 1
            if k >= 10000:
                break

    def save(self, model_dir):

        alphas_path = os.path.join(model_dir, 'alphas.npy')
        betas_path = os.path.join(model_dir, 'betas.npy')

        if self.alphas is None or self.betas is None:
            np.save(alphas_path, self.init_alphas)
            np.save(betas_path, self.init_betas)
            return

        if self.alphas.all() and self.betas.all():
            np.save(alphas_path, self.alphas)
            np.save(betas_path, self.betas)
        else:
            np.save(alphas_path, self.init_alphas)
            np.save(betas_path, self.init_betas)

    # --------------------------------------------------------------------------------------------------

    def _cal_alphas(self, betas, mappings=None, positions=None) -> tuple:
        """计算参数α"""
        if mappings is None or positions is None:
            mappings = self.sorted_mappings_reshape
            positions = self.positions

        A = self.ReLu(np.tile(mappings, [1, self.sigma]) - betas.transpose())
        symm = np.matmul(A.transpose(), A)
        # print 'symm.shape =', symm.shape

        if np.linalg.cond(symm) < 1 / sys.float_info.epsilon:
            left_part = np.linalg.inv(symm)
            right_part = A.transpose().dot(positions)
            alphas = left_part.dot(right_part)
            # alphas = np.linalg.lstsq(A, positions)[0]
            # print alphas
            return alphas, A

        return None, None

    def _predict_idxs(self, mappings=None, betas=None, alphas=None):
        if betas is None:
            betas = self.betas
        if mappings is None:
            mappings = self.sorted_mappings
        if alphas is None:
            alphas = self.alphas
        A = self.ReLu(np.tile(np.reshape(mappings, [-1, 1]), [1, self.sigma]) - betas.transpose())
        # A = self.ReLu(np.tile(self.sorted_mappings_reshape, [1, self.sigma]) - betas.transpose())
        pred_idxes = A.dot(alphas)
        return pred_idxes

    def _cal_loss(self, A, alphas) -> int or float:
        # A = self.ReLu(np.tile(self.sorted_mappings, [1, self.sigma]) - betas.transpose())

        # r = A.dot(alphas).clip(min=0, max=self.sorted_mappings.shape[0] - 1) - self.positions
        r = A.dot(alphas).clip(min=0, max=self.sorted_mappings.shape[0]) - self.positions

        # print '-----r.max =', np.abs(r).max()
        loss = np.sum(r * r)
        return loss

    def _lr_search(self, s, init_betas, init_loss: float) -> tuple:
        """
        更新迭代步长lr
        :param s: 搜索方向
        :param init_betas: 初始参数β序列
        :param init_loss: 初始损失
        :return: 元组（步长，最小损失，β，α）
        """

        lrs = [0.0001, 0.001, 0.01, 0.05, 0.1, 0.5, 1, 2, 4, 8]

        losses = []
        beta_list = []
        alpha_list = []

        for lr in lrs:
            betas = init_betas + lr * s
            betas = np.sort(betas)
            # betas[0] = init_betas[0]

            alphas, A = self._cal_alphas(betas)
            # alphas_2 = self._cal_alphas_with_monotone_constrain(betas, alphas)
            if alphas is None or A is None:
                loss = init_loss + 1
            else:
                alphas_cumsum = np.cumsum(alphas)
                if alphas_cumsum.min() > 0:
                    loss = self._cal_loss(A, alphas)
                else:
                    loss = init_loss + 1
            losses.append(loss)
            beta_list.append(betas)
            alpha_list.append(alphas)

        losses = np.array(losses)
        lrs = np.array(lrs)
        idx = np.argmin(losses, axis=0)
        min_loss = losses[idx]

        if min_loss < init_loss:
            return lrs[idx], min_loss, beta_list[idx], alpha_list[idx]

        return -1, -1, None, None

    def _cal_alphas_with_monotone_constrain(self, betas, old_alphas):

        pred_positions = self._predict_idxs(betas, betas, old_alphas).clip(min=0, max=self.sorted_mappings.shape[0])
        pred_positions = np.sort(pred_positions)
        assert (abs(pred_positions[0]) < 1e-4)

        alphas = np.zeros(shape=[self.sigma], dtype=np.float64)
        for i in range(1, pred_positions.shape[0]):
            v_ = 0
            beta_i = betas[i]
            for j in range(i - 1):
                v_ += alphas[j] * (beta_i - betas[j])
            alphas[i - 1] = (pred_positions[i] - v_) / (beta_i - betas[i - 1])

        max_mp = self.sorted_mappings[-1]
        alphas[-1] = (self.sorted_mappings.shape[0] - 1) / (max_mp - betas[-1])

        alphas_cumsum = np.cumsum(alphas)
        if alphas_cumsum[-1] < 0:
            alphas[-1] = -alphas_cumsum[-2]

        pred_idxs = self._predict_idxs(self.sorted_mappings, betas, alphas).clip(min=0,
                                                                                 max=self.sorted_mappings.shape[0])
        # print(f'pred_idxs: {pred_idxs[0:100].tolist()}')

        act_idxs = np.arange(0, self.sorted_mappings.shape[0], dtype=NP_DATA_TYPE)

        diff = (pred_idxs - act_idxs)
        # print 'all_loss =', np.sum(diff * diff)

        return alphas

    def _cal_init_alphas(self, betas):

        idxs = np.searchsorted(self.sorted_mappings, betas, side='right')
        pred_positions = (idxs - 0.5).clip(min=0)
        alphas = np.zeros(shape=[self.sigma], dtype=NP_DATA_TYPE)

        for i in range(1, pred_positions.shape[0]):
            v = 0
            beta_i = betas[i]
            for j in range(i - 1):
                v += alphas[j] * (beta_i - betas[j])
            diff = (beta_i - betas[i - 1])
            if diff <= 0:
                alphas[i - 1] = 0
            else:
                alphas[i - 1] = (pred_positions[i] - v) / diff

        v = 0
        for j in range(1, self.sigma):
            v += alphas[j] * (betas[j] - betas[j - 1])

        max_mp = self.sorted_mappings[-1]
        d_ = max_mp - betas[-1]
        if d_ == 0:
            d_ = 1e-6
        alphas[-1] = (self.sorted_mappings.shape[0] - 1) / (d_)

        alphas_cumsum = np.cumsum(alphas)
        if alphas_cumsum[-1] < 0:
            print('******************************************')
            alphas[-1] = -alphas_cumsum[-2]

        return alphas

    @staticmethod
    def _check_if_alphas_and_betas_valid(alphas, betas):
        betas_diff = betas[1:] - betas[0:-1]
        flag = (betas_diff.min() > 0)

        if not flag:
            return flag

        alphas_cumsum = np.cumsum(alphas)
        min_slope = alphas_cumsum.min()
        # print 'min_slope =', min_slope

        if not min_slope:
            return False

        return True

    @staticmethod
    def ReLu(A: np.ndarray):
        """ReLu = max(0, X)"""
        A[A < 0] = 0
        return A
