import os
import struct
import sys
import math
import _pickle as cPickle
import time

import numpy as np

from src.utils import file_viewer
from src.utils.core.config import Config
from src.utils.np_utils import *
from src.utils import layout_utils
from src.utils.common_utils import *
from src.solution.piecewise_linear_curve_fit import PiecewiseModel

sys.path.append('../../')


class LISA:
    Alphas = None  # 分段线性模型的α参数列表
    Betas = None  # 分段线性模型的β参数列表

    pages = None  # 存储每个分片的数据序列
    shard_infos = None  # 本地模型L序列(分片信息)：[shard_1, shard_2, ...]  shard_i = [[页号序列], [页首映射值序列(第一页除外)]]

    m_counts = None  # 分片存储的键值个数序列
    col_min_mappings = None  # 分组映射值中的最小值序列
    shard_ids_for_sorted_data = None  # 有序数据对应的分片id序列
    col_ids_for_sorted_data = None  # 有序数据对应的分组id序列
    shard_nums_per_col = None  # 每个分组的分片数量

    # IO = 0  # 记录I/O次数
    memory_page_ids = []  # 内存缓冲区中的页id
    memory_page_data = {}  # 内存中的数据{页id：数据}

    def __init__(self, name='LISA', data_dim=2, params=None, param_part_nums=None,
                 cell_borders=None, cell_measures=None, cell_ids=None, shd_size=-1, sigma=100):
        self.data_dim = data_dim
        self.name = name
        self.model_dir = os.path.join(Config().models_dir, self.name)

        self.borders = cell_borders
        self.cell_measures = cell_measures
        self.cell_ids = cell_ids
        self.page_size = shd_size

        self.param_part_nums = param_part_nums
        self.params = params
        if params is not None:
            self._params_dump()

        self.m_counts = []
        self.sigma = sigma

        self.memory_page_ids = []
        self.memory_page_data = {}

        self.n_threads = 32
        self.IO = 0
        self.Alphas = None
        self.Betas = None
        self.shard_infos = None
        self.pages = None
        self.col_min_mappings = None
        self.shard_ids_for_sorted_data = None
        self.col_ids_for_sorted_data = None
        self.shard_nums_per_col = None

    def set_model_dir(self, model_dir: str):
        self.model_dir = model_dir

    def set_params(self, params):
        self.params = params

    def set_page_size(self, page_size: int):
        self.page_size = page_size

    def generate_pages(self, sorted_data: np.ndarray, one_dm_mps: np.ndarray, col_split_idxs: np.ndarray):
        """
        生成磁盘页号
        :param sorted_data: 有序数据
        :param one_dm_mps: 一维映射值序列
        :param col_split_idxs: 映射值分组序列，每组映射值训练一个线性模型
        :return:
        """
        n_cols = col_split_idxs.shape[0]  # 映射值分组个数/线性模型个数
        col_sp_shd_ids = [0]

        self.shard_infos = []
        self.pages = []  # 存储每个分片对应的数据

        start = 0
        n_shards = 0  # 已分配的分片个数
        col_min_mps = []  # 存储每组的最小值

        self.shard_ids_for_sorted_data = np.zeros(shape=[sorted_data.shape[0]], dtype=NP_IDX_TYPE)
        self.col_ids_for_sorted_data = np.zeros(shape=[sorted_data.shape[0]], dtype=NP_IDX_TYPE)

        page_id = 0
        shard_id = 0
        for i in range(n_cols):
            end = col_split_idxs[i]
            self.col_ids_for_sorted_data[start:end] = i

            one_dm_input = one_dm_mps[start:end]  # 将当前组映射值作为输入
            min_mp = one_dm_input.min()
            col_min_mps.append(min_mp)

            pred_idxs = self._cal_pred_idxs_one_col(one_dm_input - min_mp, i)  # 对当前组，预测数组索引号

            shd_lyt_list = self._shards_layout(pred_idxs, self.page_size)

            n_shards += len(shd_lyt_list)
            col_sp_shd_ids.append(n_shards)
            min_pred_idx = int(pred_idxs.min() / self.page_size)

            print(f'section: {i}, shards_num: {len(shd_lyt_list)}, min_predict_idx: {min_pred_idx}')

            ety_start = start
            for ety_count in shd_lyt_list:
                shard_info = [[], []]  # [页号序列，页首映射值序列(第一页除外)]
                # 处理空的分片
                if ety_count == 0:
                    self.shard_infos.append(shard_info)
                    shard_id += 1
                    continue

                ety_end = ety_start + ety_count
                self.shard_ids_for_sorted_data[ety_start:ety_end] = shard_id  # 为数据分配分片

                pages = sorted_data[ety_start:ety_end]  # 获取对应的总数据量，作为一组页面
                one_dm_pages = one_dm_mps[ety_start:ety_end]  # 获取映射值的总数据量，作为一组页面
                # 若键值个数少于阈值，则存储在同一页面中
                if ety_count <= self.page_size:
                    self.pages.append(pages)
                    shard_info[0].append(page_id)
                    page_id += 1
                # 否则分配多个连续的页
                else:
                    n_pages = int(ety_count / self.page_size)  # 计算要分配的页面数量
                    if ety_count % self.page_size:
                        n_pages += 1
                    b_k = 0
                    for k in range(n_pages):  # 分配连续的页面（即page_id连续）
                        e_k = b_k + self.page_size
                        if e_k > ety_count:
                            e_k = ety_count
                        page = pages[b_k:e_k]
                        self.pages.append(page)
                        shard_info[0].append(page_id)
                        page_id += 1
                        if k > 0:  # k = 0号页的首个映射值未添加
                            shard_info[1].append(one_dm_pages[b_k])  # 加入每个页的首个映射值
                        b_k = e_k

                self.shard_infos.append(shard_info)
                shard_id += 1
                ety_start = ety_end
            start = end

        print(f'shards_num_total: {n_shards}')
        assert (self.m_counts == []), print(f'error: LISA self.m_counts NOT empty.')

        for page in self.pages:
            self.m_counts.append(page.shape[0])

        self.col_split_shard_ids = np.array(col_sp_shd_ids, dtype=NP_IDX_TYPE)
        self._cal_shd_nums_per_col()
        self.col_min_mappings = np.array(col_min_mps, dtype=NP_DATA_TYPE)

    def insert_data(self, points: np.ndarray):
        """插入数据"""
        print(f'--------------------------LISA:$ INSERT data{points.shape}')

        if points.ndim == 1:
            points = points.reshape(1, 2)

        pt_mps = self._monotone_mapping(points)

        offset = 10000
        n = int(pt_mps.shape[0] / offset)
        if n * offset < pt_mps.shape[0]:
            n += 1

        shard_ids = np.zeros(shape=[pt_mps.shape[0]], dtype=NP_IDX_TYPE)
        # 为待插入数据预测分片id
        for i_ in range(n):
            start = i_ * offset
            end = start + offset
            if end > pt_mps.shape[0]:
                end = pt_mps.shape[0]
            shard_ids[start:end] = self._predict_shard_ids(pt_mps[start:end])
        # 将数据插入到对应的分片中
        for i_ in range(points.shape[0]):
            point = points[i_]
            point_mapping = pt_mps[i_]
            shard_id = shard_ids[i_]
            self._insert_within_shard(point, point_mapping, shard_id)
            print(f'inserted: data # {i_} in shard # {shard_id}')

        print(f'--------------------------LISA:$$ INSERT DONE.')

    def delete_data(self, points):
        """批量删除数据"""
        print(f'LISA:$ deleting data{points.shape}')
        if points.ndim == 1:
            points = points.reshape(1, 2)

        pt_mps = self._monotone_mapping(points)

        offset = 10000
        n = int(pt_mps.shape[0] / offset)
        if n * offset < pt_mps.shape[0]:
            n += 1

        shard_ids = np.zeros(shape=[pt_mps.shape[0]], dtype=NP_IDX_TYPE)
        for i_ in range(n):
            start = i_ * offset
            end = start + offset
            if end > pt_mps.shape[0]:
                end = pt_mps.shape[0]
            shard_ids[start:end] = self._predict_shard_ids(pt_mps[start:end])

        for i_ in range(points.shape[0]):
            point = points[i_]
            point_mapping = pt_mps[i_]
            shard_id = shard_ids[i_]
            self._del_within_shard(point, point_mapping, shard_id)
            print(f'deleted: data_{i_} from shard_{shard_id}')

        print(f'LISA:$$ delete DONE.')

    def range_query(self, query_range: np.ndarray):
        """单次范围查询"""
        print(
            f'--------------------------LISA:$ RANGE QUERY: [{query_range[0]}, {query_range[1]}]--------------------------')
        t_0 = time.time()
        qr_res = []
        pg_ids = []
        sub_qrs = self._split_rectangles(rect=query_range)  # 按网格划分小矩形

        for sub_qr in sub_qrs:  # sub_qr = [l, u]  其中，l为下界，u为上界
            mps = self._monotone_mapping(np.array(sub_qr))  # 获取上界和下界的映射值
            shd_ids = self._predict_shard_ids(mps)  # 预测分片id
            prt_pg_ids = self._get_page_ids_based_on_shard(shd_ids)  # 获取页号
            pg_ids = list(set(pg_ids) | set(prt_pg_ids))

        pg_ids.sort()
        print(f'query page ids: {pg_ids}')

        # 文件版本
        IO_count = 0
        for pg_id in pg_ids:
            pg, IO = self._get_data_from_disk(pg_id, 16, 'dd')  # 获取数据列表
            for dt in pg:
                if type(dt) != np.ndarray:
                    dt = np.array(dt)
                if self._check_in_rect(data=dt, rect=query_range):
                    qr_res.append(list(dt))
            IO_count += IO

        # # 内存版本
        # for pg_id in pg_ids:
        #     pg = self.pages[pg_id]  # 遍历页以获得查询数据
        #     for dt in pg:
        #         if type(dt) != np.ndarray:
        #             dt = np.array(dt)
        #         if self._check_in_rect(data=dt, rect=query_range):
        #             qr_res.append(list(dt))

        res = np.array(qr_res)
        t_1 = round(time.time() - t_0, 5)
        print(f'time use: {t_1} s')
        print('--------------------------LISA:$$ RANGE QUERY DONE.--------------------------')
        return res, IO_count, t_1

    def save(self):
        file_viewer.detect_and_delete_dir(self.model_dir)
        file_viewer.detect_and_create_dir(self.model_dir)

        meta_infos_path = os.path.join(self.model_dir, 'meta_infos.npy')  # 模型预设参数信息
        col_params_path = os.path.join(self.model_dir, 'col_params.npy')  # 模型参数*
        col_min_mappings_path = os.path.join(self.model_dir, 'col_min_mappings.npy')  # 分组映射值中的最小值映射序列
        shard_params_path = os.path.join(self.model_dir, 'shard_params.npy')  # 分段线性模型SP参数*

        page_npy_path = os.path.join(self.model_dir, 'page_data.npy')  # 数据
        page_data_path = os.path.join(self.model_dir, 'page_data.idx')  # 数据

        m_counts_path = os.path.join(self.model_dir, 'm_counts.npy')  # 分片存储的键值个数序列
        local_models_path = os.path.join(self.model_dir, 'local_models.pkl')  # 本地模型L序列*

        np.save(page_npy_path, np.concatenate(self.pages, axis=0))
        pages_data = np.concatenate(self.pages, axis=0)

        buffer = b''
        pages_data_list = list(pages_data.flatten())
        ele_num = len(pages_data_list)
        buffer = struct.pack('d' * ele_num, *pages_data_list)
        file_viewer.save_bytes_file(page_data_path, buffer)  # 将数据保存至排序数组中

        np.save(m_counts_path, np.array(self.m_counts, dtype=NP_IDX_TYPE))

        print('page_number =', len(self.m_counts))

        meta_infos = [self.page_size, self.sigma]
        meta_infos.extend(self.col_split_shard_ids.tolist())
        np.save(meta_infos_path, np.array(meta_infos, dtype=NP_IDX_TYPE))

        np.save(col_params_path, self.params)
        np.save(col_min_mappings_path, self.col_min_mappings)

        shard_params = np.concatenate([self.Alphas, self.Betas], axis=0)
        print('shard_params.shape =', shard_params.shape)
        np.save(shard_params_path, shard_params)
        with open(local_models_path, 'wb') as writer:
            cPickle.dump(self.shard_infos, writer)

        shard_ids_path = os.path.join(self.model_dir, 'shard_ids.npy')
        np.save(shard_ids_path, self.shard_ids_for_sorted_data)

        col_ids_path = os.path.join(self.model_dir, 'col_ids.npy')
        np.save(col_ids_path, self.col_ids_for_sorted_data)

        all_path = os.path.join(self.model_dir, 'all.npy')
        all_without_addrs_path = os.path.join(self.model_dir, 'all_without_addrs.npy')
        all_params = []
        all_params_without_addrs = []

        empty_flag = -(len(self.m_counts) + 1)
        shd_total_num = 0
        for shard_id, shard in enumerate(self.shard_infos):
            shard_pg_ids = shard[0]
            shard_sp_mps = shard[1]

            if len(shard_pg_ids) == 0:
                all_params.append(empty_flag)
                shd_total_num += 1
                continue

            for i in range(len(shard_sp_mps)):
                all_params.append(shard_pg_ids[i])
                all_params.append(shard_sp_mps[i])
                all_params_without_addrs.append(shard_sp_mps[i])
                # a += 1
            all_params.append(shard_pg_ids[-1])
            # a +=1
        print(f'-------shard total number = {shd_total_num}, page number = {len(self.m_counts)}', )

        tmp_ = np.reshape(shard_params, [-1]).tolist()
        all_params.extend(tmp_)
        all_params_without_addrs.extend(tmp_)

        tmp_ = self.params.tolist()
        all_params.extend(tmp_)
        all_params_without_addrs.extend(tmp_)
        all_params = np.array(all_params)
        all_params_without_addrs = np.array(all_params_without_addrs)

        np.save(all_path, all_params)
        np.save(all_without_addrs_path, all_params_without_addrs)

    def monotone_mps_and_col_split_idxs_for_sorted_dt(self, sorted_points: np.ndarray) -> tuple:
        """将排序后的数据映射到一维，并获取分组索引序列"""
        mps = self._monotone_mapping(sorted_points, bulid_mode=True)
        col_idxs = np.searchsorted(self.model_split_mappings_omit_tail, mps, side='right')
        N = col_idxs[-1]
        col_split_idxs = [0] * (N + 1)

        for i in range(col_idxs.shape[0]):
            idx_ = col_idxs[i]
            col_split_idxs[idx_] += 1

            # if col_split_idxs[idx_] > 3:
            #     print(f'idx_ = {idx_}, i = {i}')

        count = col_split_idxs[0]
        for i in range(1, N + 1):
            count += col_split_idxs[i]
            col_split_idxs[i] = count

        col_split_idxs = np.array(col_split_idxs)
        mps = mps.astype(NP_DATA_TYPE)

        return mps, col_split_idxs

    def check_and_load_params(self):
        """检查参数，若参数全部存在则加载并返回True，否则返回False"""
        all_files = []

        meta_infos_path = os.path.join(self.model_dir, 'meta_infos.npy')
        params_path = os.path.join(self.model_dir, 'col_params.npy')
        col_min_mappings_path = os.path.join(self.model_dir, 'col_min_mappings.npy')
        shard_params_path = os.path.join(self.model_dir, 'shard_params.npy')

        page_npy_path = os.path.join(self.model_dir, 'page_data.npy')  # 内存版
        page_data_path = os.path.join(self.model_dir, 'page_data.idx')  # 文件版

        m_counts_path = os.path.join(self.model_dir, 'm_counts.npy')
        local_models_path = os.path.join(self.model_dir, 'local_models.pkl')

        all_files.append(meta_infos_path)
        all_files.append(params_path)
        all_files.append(col_min_mappings_path)
        all_files.append(shard_params_path)
        all_files.append(page_data_path)
        all_files.append(m_counts_path)
        all_files.append(local_models_path)

        for file in all_files:
            if not os.path.exists(file):
                return False

        m_counts = np.load(m_counts_path)

        # data_size = page_data.shape[0]
        self.n_pages = m_counts.shape[0]

        # 文件版本：将数据文件路径保存至索引中
        self.pages_pth = page_data_path

        # 内存版本：将数据加入索引中
        page_data = np.load(page_npy_path)
        self.pages = []
        start = 0
        for i in range(self.n_pages):
            end = start + m_counts[i]
            self.pages.append(page_data[start:end])
            start = end

        self.m_counts = m_counts.tolist()
        print('n_pages =', len(self.m_counts))

        self.params = np.load(params_path)
        self._params_dump()

        self.col_min_mappings = np.load(col_min_mappings_path)

        meta_infos = np.load(meta_infos_path)
        self.page_size = meta_infos[0]
        self.sigma = meta_infos[1]
        self.col_split_shard_ids = meta_infos[2:]
        self._cal_shd_nums_per_col()

        shard_params = np.load(shard_params_path)
        n_cols = int(shard_params.shape[0] / 2)
        self.Alphas = shard_params[:n_cols]
        self.Betas = shard_params[n_cols:]

        with open(local_models_path, 'rb') as reader:
            self.shard_infos = cPickle.load(reader)

        print('n_shards =', len(self.shard_infos))

        shard_ids_path = os.path.join(self.model_dir, 'shard_ids.npy')
        self.shard_ids_for_sorted_data = np.load(shard_ids_path)

        col_ids_path = os.path.join(self.model_dir, 'col_ids.npy')
        self.col_ids_for_sorted_data = np.load(col_ids_path)

        return True

    def check_and_load_linear_models_params(self, piecewise_models_dir: str, model_num: int):
        """检查并加载分段线性模型的参数"""
        self.Alphas = np.zeros(shape=[model_num, self.sigma], dtype=NP_DATA_TYPE)
        self.Betas = np.zeros(shape=[model_num, self.sigma], dtype=NP_DATA_TYPE)

        for i in range(model_num):
            model_dir = os.path.join(piecewise_models_dir, str(i))
            alphas_path = os.path.join(model_dir, 'alphas.npy')
            betas_path = os.path.join(model_dir, 'betas.npy')

            if os.path.exists(alphas_path) and os.path.exists(betas_path):
                self.Alphas[i] = np.load(alphas_path)
                self.Betas[i] = np.load(betas_path)
            else:
                return False

        return True

    def _split_rectangles(self, rect: np.ndarray) -> list:
        """按网格分割矩形边界"""
        sub_rects = []
        first_ranges = []  # 存储第一个维度的范围序列
        other_ranges = []  # 存储其他所有维度的范围序列
        sp_pts = []  # 存储每个维度的分割点序列

        fr_range = np.array([rect[0][0], rect[1][0]])
        fr_dm_sp_pts = self._get_split_points_based_on_cell_bounds(fr_range, 0)
        sp_pts.append(fr_dm_sp_pts)
        n_parts = len(fr_dm_sp_pts)

        for dm in range(1, self.data_dim):
            bd_0 = rect[0][dm]
            bd_1 = rect[1][dm]
            val_range = np.array([bd_0, bd_1])
            one_dm_sp_pts = self._get_split_points_based_on_cell_bounds(val_range, dm, n_parts)
            sp_pts.append(one_dm_sp_pts)

        first_dm_bds = sp_pts[0]
        for i_ in range(len(first_dm_bds) - 1):
            rg_ = np.array([first_dm_bds[i_], first_dm_bds[i_ + 1]])
            first_ranges.append(rg_)

        for one_dm_bds in sp_pts[1:]:
            one_dm_rgs = []
            for prt_bds in one_dm_bds:
                prt_rgs = []
                for i_ in range(len(prt_bds) - 1):
                    rg_ = np.array([prt_bds[i_], prt_bds[i_ + 1]])
                    prt_rgs.append(rg_)
                one_dm_rgs.append(prt_rgs)

            other_ranges.append(one_dm_rgs)

        for i_, fr_rg in enumerate(first_ranges):
            for dm_rgs in other_ranges:  # 遍历其他维度
                l_ = [fr_rg[0]]
                u_ = [fr_rg[1]]
                for rg in dm_rgs[i_]:
                    l_.append(rg[0])
                    u_.append(rg[1])
                    sub_qr = [np.array(l_), np.array(u_)]
                    sub_rects.append(sub_qr)
                    l_ = [fr_rg[0]]
                    u_ = [fr_rg[1]]

        return sub_rects

    def _get_split_points_based_on_cell_bounds(self, range: np.ndarray, dimension: int, n_parts=100):
        """根据网格获取分割点序列"""
        low_bd = range[0]
        up_bd = range[1]
        cell_bounds = None

        if dimension == 0:
            sp_pts = [low_bd]
            cell_bounds = self.first_dim_split_points_omit_tail
            for cl_bd in cell_bounds:
                if low_bd < cl_bd < up_bd:
                    sp_pts.append(cl_bd)
                if cl_bd >= up_bd:
                    break
            sp_pts.append(up_bd)

            return sp_pts

        else:
            sp_pts = []
            cell_bounds = self.split_points_omit_head_tail[dimension - 1]
            for i_, part_cl_bds in enumerate(cell_bounds):
                if i_ == n_parts - 1:
                    break
                prt_sp_pts = [low_bd]  # 存储每个分区的分割点序列
                for cl_bd in part_cl_bds:
                    if low_bd < cl_bd < up_bd:
                        prt_sp_pts.append(cl_bd)
                    if cl_bd >= up_bd:
                        break
                prt_sp_pts.append(up_bd)
                sp_pts.append(prt_sp_pts)

            return sp_pts

    def _get_page_ids_based_on_shard(self, shard_ids: np.ndarray) -> np.ndarray:
        """根据分片获取页号"""
        pg_ids = []
        for shd_id in shard_ids:
            prt_pg_ids = self.shard_infos[shd_id][0]
            pg_ids.extend(prt_pg_ids)
        return np.array(pg_ids, dtype=NP_IDX_TYPE)

    def _check_in_rect(self, data: np.ndarray, rect: np.ndarray) -> bool:
        l_bd = rect[0]
        u_bd = rect[1]
        for dm in range(self.data_dim):
            low_bd = l_bd[dm]
            up_bd = u_bd[dm]
            if data[dm] < low_bd or data[dm] > up_bd:
                return False

        return True

    def _params_dump(self):
        """
        参数分为 4部分：
        1.所有维度(最后一维除外)的网格划分点
        2.最后一维的网格划分点
        3.线性模型分割点
        4.离散参数
        """
        # -----------------------------------------第四部分：各种参数-----------------------------------------
        self.data_dim = int(self.params[-1])
        self.t_parts_per_dim = int(self.params[-2])
        self.n_piecewise_models = int(self.params[-3])
        self.max_val_per_dim = self.params[-4]
        self.min_val_per_dim = self.params[-5]
        self.eta = self.params[-6]
        self.n_cells = self.params[-7]

        self.split_bounds = []
        self.front_split_points = []
        self.split_points_omit_head_tail = []
        self.cell_lens = []

        t = self.param_part_nums[1]  # 每个维度实际划分的网格数（可能小于预定义的数量）
        n_cls = self.n_cells  # 网格总数
        pms = self.params
        # -----------------------------------------第一部分：所有维度（除第一维）分割点-----------------------------------------
        start = 0
        for j in range(1, self.data_dim):
            one_dm_bds_2d = []

            while n_cls:
                end = start
                while pms[end] >= 0:  # 找到分组结束标志（-1）
                    end += 1
                    if end == len(pms):
                        break
                if end == len(pms):
                    break
                bounds = pms[start: end]
                one_dm_bds_2d.append(bounds)
                start = end + 1
                n_cls -= 1

            pre_bd = 0
            one_dm_bds_list = []  # 单个维度的所有上边界值列表
            one_dm_cl_lens = []  # 单个维度的所有网格测度列表
            one_dm_sp_pts_om_hd_tl = []  # 单个维度的所有分割点（头尾除外）
            one_dm_fr_sp_pts = []  # 单个维度的所有前分割点

            for bds in one_dm_bds_2d:
                one_dm_part_bds_ = []
                one_dm_part_cl_lens_ = []
                for b_ in bds:
                    bd_ = b_ - pre_bd
                    one_dm_part_bds_.append(b_)
                    one_dm_part_cl_lens_.append(bd_)

                pre_bd = 0
                # 当前分区下的序列
                one_dm_part_bds_ = np.array(one_dm_part_bds_, dtype=NP_DATA_TYPE)
                one_dm_prt_fr_sp_pts_ = np.zeros_like(one_dm_part_bds_, dtype=NP_DATA_TYPE)
                one_dm_prt_sp_pts_om_hd_tl_ = one_dm_part_bds_[:-1]
                one_dm_prt_fr_sp_pts_[1:] = one_dm_prt_sp_pts_om_hd_tl_
                one_dm_part_cl_lens_ = np.array(one_dm_part_cl_lens_, dtype=NP_DATA_TYPE)
                # 加入总序列中
                one_dm_bds_list.append(one_dm_part_bds_)
                one_dm_fr_sp_pts.append(one_dm_prt_fr_sp_pts_)
                one_dm_sp_pts_om_hd_tl.append(one_dm_prt_sp_pts_om_hd_tl_)
                one_dm_cl_lens.append(one_dm_part_cl_lens_)

            self.split_bounds.append(one_dm_bds_list)
            self.front_split_points.append(one_dm_fr_sp_pts)
            self.split_points_omit_head_tail.append(one_dm_sp_pts_om_hd_tl)
            self.cell_lens.append(one_dm_cl_lens)

        # -----------------------------------------第二部分：第一维的分割点-----------------------------------------
        end = start + t

        self.first_dim_split_bounds = np.array(self.params[start:end], dtype=NP_DATA_TYPE)

        self.first_dim_front_split_points = np.zeros_like(self.first_dim_split_bounds, dtype=NP_DATA_TYPE)

        self.first_dim_split_points_omit_tail = self.first_dim_split_bounds[:-1]

        self.first_dim_front_split_points[1:] = self.first_dim_split_points_omit_tail

        self.first_dim_cell_lens = self.first_dim_split_bounds - self.first_dim_front_split_points

        # -----------------------------------------第三部分：模型分割点-----------------------------------------
        start = end
        end = start + self.n_piecewise_models
        assert (end == len(self.params) - 7)

        self.model_split_mappings = self.params[start:end]
        self.model_split_mappings_omit_tail = self.model_split_mappings[:-1]

    def _cal_pred_idxs_one_col(self, mappings: np.ndarray, col_id: int, idx=-1, offset=-1):
        """对每个区间调用线性回归模型，预测数组索引号"""
        alphas = self.Alphas[col_id]
        betas = self.Betas[col_id]

        A = PiecewiseModel.ReLu(np.tile(np.reshape(mappings, [-1, 1]), [1, self.sigma]) - betas.transpose())
        pred_idxs = A.dot(alphas)

        if idx >= 0:
            print('%%%col_id =', col_id)
            print(pred_idxs[idx] / self.page_size)
            print(pred_idxs[idx] / self.page_size + offset)

        return pred_idxs

    @staticmethod
    def _shards_layout(pred_idxs: np.ndarray, T: int) -> list:
        """
        预测当前分组的分片号以及对应的键值个数
        :param pred_idxs: 预测的数组索引号序列
        :param T: 每个页面的平均键数
        :return:列表 [索引为分片号，数值为键值个数]
        """
        n_mp = pred_idxs.shape[0]  # 映射值个数
        pred_idxs = (pred_idxs / T).astype(NP_IDX_TYPE)
        shard_id_mx = pred_idxs.max()

        pred_idxs = np.clip(pred_idxs, a_min=0, a_max=shard_id_mx)

        # 计算每个分片中的元素个数
        entry_count = [0] * (shard_id_mx + 1)
        for i in range(n_mp):
            idx = pred_idxs[i]
            entry_count[idx] += 1

        n_entry_last_shd = entry_count[shard_id_mx]
        if n_entry_last_shd < T and shard_id_mx > 0:  # 若最后一个分片中的键值少于T，则将其并入前面的分片中
            shard_id_mx -= 1
            while True:
                n_entry_last_shd += entry_count[shard_id_mx]
                if n_entry_last_shd >= T:
                    break
                if shard_id_mx == 0:
                    break
                shard_id_mx -= 1

            entry_count[shard_id_mx] = n_entry_last_shd
            entry_count = entry_count[0:shard_id_mx + 1]

        return entry_count

    def _cal_shd_nums_per_col(self):
        self.shard_nums_per_col = np.zeros(shape=[self.col_split_shard_ids.shape[0] - 1], dtype=NP_IDX_TYPE)
        for i in range(self.shard_nums_per_col.shape[0]):
            self.shard_nums_per_col[i] = self.col_split_shard_ids[i + 1] - self.col_split_shard_ids[i]

    def _monotone_mapping(self, data: np.ndarray, bulid_mode=False):
        """
        :param data: 数据
        :param bulid_mode: 阶段标志，True表示构建阶段
        :return: 一维映射值序列
        """
        cell_ids = None  # 存储所有数据的网格索引
        if bulid_mode:
            cell_ids = self.cell_ids
        else:
            if data.ndim == 1:
                data = data.reshape(1, 2)
            cell_ids = []
            for row in data:
                idx_ = self._get_border_idx(row)
                cell_ids.append(idx_)
            cell_ids = np.array(cell_ids)

        part_m_cur = data - self.borders[cell_ids]  # 计算当前数据的一维测度
        h_m_cur = np.prod(part_m_cur, axis=1)  # 计算整体的勒贝格测度
        part_m = h_m_cur / self.cell_measures[cell_ids]  # 勒贝格测度之比
        part_m[part_m == 0] = 1e-6
        mps = np.zeros(shape=part_m.shape[0], dtype=NP_DATA_TYPE)

        # # 检查是否有负值
        # for i_, _ in enumerate(part_m):
        #     if _ < 0:
        #         print(f'i_ = {i_}, cell_id = {cell_ids[i_]}')
        assert (part_m >= 0).all()

        # 计算每个数据的映射值
        cell_ids = np.array(cell_ids)
        if bulid_mode:  # 构建阶段：将测度之比转化为偏移量：按照大小次序在0.00001~0.99999中赋值
            for i in range(cell_ids.max() + 1):
                cell_id = cell_ids[i]
                idx = np.argwhere(cell_ids == cell_id).T[0]
                prt_m_ = part_m[idx]
                prt_m = max(prt_m_, 1e-6)  # 规范数值
                prt_m_new = np.array(prt_m)

                idxs_ = np.argsort(prt_m_new)
                exp_ = 7
                for i_, idx_ in enumerate(idxs_):
                    frac_ = 10 ** (exp_ * -1)
                    prt_m_new[idx_] = (i_ + 1) * frac_

                prt_mps = prt_m_new + cell_id  # 映射值 = 偏移量 + 网格编号
                mps[idx] = prt_mps
        else:
            for i in range(len(cell_ids)):
                cell_id = cell_ids[i]
                # idx = np.argwhere(cell_ids == cell_id).T[0]
                prt_m_ = part_m[i]
                prt_m = max(prt_m_, 1e-6)  # 规范数值
                prt_m_new = np.array(prt_m)

                prt_mp = prt_m_new + cell_id  # 映射值 = 偏移量 + 网格编号
                mps[i] = prt_mp

        if not check_unique(mps):
            mps = np.array([mp + i_ * 1e-6 for i_, mp in enumerate(mps)])

        assert check_unique(mps), AssertionError('mappings NOT unique.')
        assert check_order(mps), AssertionError('mappings NOT ordered.')

        return mps

    def _get_border_idx(self, data_row) -> int:
        """返回数据行的边界索引（限定2维数据）"""
        axis_0 = data_row[0]
        axis_1 = data_row[1]
        pre_bd = 0
        pre_bg = 0
        end_bd = 0  # 存储最后一组边界的起点下标
        begin = 0  # 指向每个分组的首个下标
        for end, bd in enumerate(self.borders):
            if end == len(self.borders) - 1:
                end_bd = begin  # 记录最后一组的起点下标
                break
            if bd[0] != pre_bd:
                pre_bg = begin
                begin = end
                pre_bd = bd[0]
            if bd[0] >= axis_0:
                ed = 0
                for j, part_bd in enumerate(self.borders[pre_bg:end, :]):
                    if part_bd[1] > axis_1:
                        return pre_bg + j - 1  # 返回不超过数据的最大边界
                    ed = j
                return pre_bg + ed  # 数据超过当前分组的所有边界，则返回最后一个边界

        # 若第一个维度超过所有边界，则在最后一组边界中查找
        for i, part_bd in enumerate(self.borders[end_bd:, :]):
            if part_bd[1] >= axis_1:
                return end_bd + i - 1  # 返回不超过数据的最大边界

        return len(self.borders) - 1  # 数据超过最后一个分组的所有边界，则返回最后一个边界

    def _predict_shard_ids(self, mappings) -> np.ndarray:
        """预测多个映射值的分片id"""
        col_idxes = np.searchsorted(self.model_split_mappings_omit_tail, mappings, side='right')

        trans_mappings = mappings - self.col_min_mappings[col_idxes]

        shd_id_offsets = self.col_split_shard_ids[col_idxes]
        max_predict_idxes = self.shard_nums_per_col[col_idxes] - 1

        all_alphas = self.Alphas[col_idxes]
        all_betas = self.Betas[col_idxes]

        all_A = PiecewiseModel.ReLu((trans_mappings - all_betas.transpose()).transpose())
        pred_shd_ids = (np.sum(all_A * all_alphas, axis=1) / self.page_size).astype(NP_IDX_TYPE).clip(min=0,
                                                                                                      max=max_predict_idxes)
        pred_shd_ids += shd_id_offsets

        pred_shd_ids_uni = np.unique(pred_shd_ids)
        return pred_shd_ids_uni

    def _predict_within_shard(self, mapping, shard_id, side):
        # print 'shard_id =', shard_id
        shard_info = self.shard_infos[shard_id]
        shard_split_mappings = shard_info[1]
        if len(shard_info[0]) == 0:
            return -1
        if len(shard_split_mappings) == 0:
            return 0
        else:
            idx = np.searchsorted(shard_split_mappings, mapping, side=side)
            return idx

    def _get_query_page_ids(self, query_ranges, step=-1) -> list:
        """获取范围查询的页号列表"""
        lower_mappings, upper_mappings, n_pts_per_qr = self._get_query_ranges_mappings(query_ranges)

        if step <= 0:
            lower_shard_ids = self._predict_shard_ids(lower_mappings)
            upper_shard_ids = self._predict_shard_ids(upper_mappings)
        else:
            n_iters = int(lower_mappings.shape[0] / step)
            if step * n_iters < lower_mappings.shape[0]:
                n_iters += 1

            l_sids_list = []
            u_sids_list = []
            # print '----n_iters =', n_iters
            for i in range(n_iters):
                start = i * step
                end = start + step
                if end > lower_mappings.shape[0]:
                    end = lower_mappings.shape[0]

                small_lower_shard_ids = self._predict_shard_ids(lower_mappings[start:end])
                small_upper_shard_ids = self._predict_shard_ids(upper_mappings[start:end])

                l_sids_list.append(small_lower_shard_ids)
                u_sids_list.append(small_upper_shard_ids)
            lower_shard_ids = np.concatenate(l_sids_list, axis=0)
            upper_shard_ids = np.concatenate(u_sids_list, axis=0)

        start = 0
        qr_pg_ids = []
        for i in range(len(n_pts_per_qr)):
            page_nos = []
            end = start + n_pts_per_qr[i]
            if end > start:
                query_lower_shard_ids = lower_shard_ids[start:end]
                query_upper_shard_ids = upper_shard_ids[start:end]
                query_lower_mappings = lower_mappings[start:end]
                query_upper_mappings = upper_mappings[start:end]
                for j in range(query_lower_shard_ids.shape[0]):
                    lower_shard_id = query_lower_shard_ids[j]
                    upper_shard_id = query_upper_shard_ids[j]

                    lower_shard_split_mappings = self.shard_infos[lower_shard_id][1]
                    upper_shard_split_mappings = self.shard_infos[upper_shard_id][1]
                    for _ in range(len(lower_shard_split_mappings)):
                        __ = lower_shard_split_mappings[_]

                    for _ in range(len(upper_shard_split_mappings)):
                        __ = upper_shard_split_mappings[_]

                    # shard_split_mappings
                    lower_idx = self._predict_within_shard(query_lower_mappings[j], lower_shard_id, 'left')
                    upper_idx = self._predict_within_shard(query_upper_mappings[j], upper_shard_id, 'right')
                    if lower_shard_id == upper_shard_id:
                        if lower_idx >= 0:
                            page_nos.extend(self.shard_infos[lower_shard_id][0][lower_idx:upper_idx + 1])
                    else:
                        if lower_idx >= 0:
                            page_nos.extend(self.shard_infos[lower_shard_id][0][lower_idx:])
                        for k in range(lower_shard_id + 1, upper_shard_id):
                            page_nos.extend(self.shard_infos[k][0])
                        if upper_idx >= 0:
                            page_nos.extend(self.shard_infos[upper_shard_id][0][0:upper_idx + 1])
                    # for k in range(lower_shard_id, upper_shard_id + 1):
                    #     page_nos.extend(self.shard_infos[k][0])
            page_nos = set(page_nos)
            qr_pg_ids.append(page_nos)

            start = end

        return qr_pg_ids

    def _append_data_in_page(self, page, point):
        return np.r_[page, point.reshape([-1, self.data_dim])]

    def _split_page(self, page, point):
        """页的分裂"""
        page = self._append_data_in_page(page, point)
        page_mps = self._monotone_mapping(page, bulid_mode=True)
        idxs = np.argsort(page_mps)
        page_mps = page_mps[idxs]
        page = page[idxs]
        N = int((page.shape[0] + 1) / 2)
        return page[0:N], page[N:], page_mps[0], page_mps[N], page_mps[-1]

    def _insert_within_shard(self, point, point_mapping, shard_id):
        """插入数据到磁盘页，同时插入映射值到分片中"""
        shard = self.shard_infos[shard_id]
        shd_pg_ids = shard[0]
        shd_sp_mps = shard[1]
        # 若分片中没有页面，则分配新的页面存储数据
        if len(shd_pg_ids) == 0:
            new_page = np.reshape(point, [1, -1])
            shd_pg_ids.append(len(self.m_counts))
            # 内存实现
            self.pages.append(new_page)
            # # 文件实现
            # self._save_data_to_disk(point)

            self.m_counts.append(1)
            return

        pg_idx_in_this_shd = None
        if len(shd_sp_mps) == 0:
            pg_idx_in_this_shd = 0
        else:
            pg_idx_in_this_shd = np.searchsorted(shd_sp_mps, point_mapping, side='right')

        page_id = shd_pg_ids[pg_idx_in_this_shd]

        page = self.pages[page_id]  # 内存实现
        # page, IO = self._get_data_from_disk(page_id, 8, 'ff')  # 文件实现

        # 检查页内数据，判断是否要进行页分裂
        if page.shape[0] < self.page_size:
            # 内存实现
            self.pages[page_id] = self._append_data_in_page(page, point)
            self.m_counts[page_id] += 1
        else:
            page_1, page_2, left_sp_mp, mid_sp_mp, right_sp_mp = self._split_page(page, point)
            self.pages[page_id] = page_1
            self.m_counts[page_id] = page_1.shape[0]

            self.pages.append(page_2)
            self.m_counts.append(page_2.shape[0])

            if pg_idx_in_this_shd == len(shd_sp_mps):  # last page
                if pg_idx_in_this_shd != 0:
                    shd_sp_mps[pg_idx_in_this_shd - 1] = left_sp_mp
                shd_sp_mps.insert(pg_idx_in_this_shd, mid_sp_mp)
            elif pg_idx_in_this_shd == 0:
                shd_sp_mps[0] = right_sp_mp
                shd_sp_mps.insert(0, mid_sp_mp)
            else:
                shd_sp_mps[pg_idx_in_this_shd - 1] = left_sp_mp
                shd_sp_mps[pg_idx_in_this_shd] = right_sp_mp
                shd_sp_mps.insert(pg_idx_in_this_shd, mid_sp_mp)

            shd_pg_ids.insert(pg_idx_in_this_shd + 1, len(self.m_counts) - 1)

    def _del_record_from_page(self, page_id, point):
        page = self.pages[page_id]
        idx = -1
        for i in range(page.shape[0]):
            flag = True
            for j in range(self.data_dim):
                if point[j] != page[i][j]:
                    flag = False
                    break
            if flag:
                idx = i
                break
        if idx < 0:
            raise ValueError('Data to be deleted is NOT found.')
        if page.shape[0] == 1:
            self.pages[page_id] = np.zeros(shape=[0, self.data_dim], dtype=NP_DATA_TYPE)
            self.m_counts[page_id] = 0
            return 0

        if idx == 0:
            new_page = page[1:]
        elif idx == page.shape[0] - 1:
            new_page = page[0:-1]
        else:
            new_page = np.concatenate([page[0:idx], page[idx + 1:]], axis=0)
        self.pages[page_id] = new_page
        self.m_counts[page_id] = new_page.shape[0]
        return new_page.shape[0]

    def _del_within_shard(self, point, point_mapping, shard_id):
        shard = self.shard_infos[shard_id]

        shd_pg_ids = shard[0]
        shd_sp_mps = shard[1]

        if len(shd_pg_ids) == 0:
            return

        page_idx_left = np.searchsorted(shd_sp_mps, point_mapping, side='left')
        page_idx_right = np.searchsorted(shd_sp_mps, point_mapping, side='right')

        page_idx = -1
        n_records_left = -1
        for i in range(page_idx_left, page_idx_right + 1):
            page_id = shd_pg_ids[i]
            n_records_left = self._del_record_from_page(page_id, point)
            if n_records_left >= 0:
                page_idx = i
                break

        if n_records_left < 0:
            return
        if len(shd_pg_ids) == 1:
            if self.m_counts[shd_pg_ids[0]] == 0:
                shard[0] = []
            return

        if len(shd_pg_ids) == 2:
            page_id_1 = shd_pg_ids[0]
            page_id_2 = shd_pg_ids[1]
            n1 = self.m_counts[page_id_1]
            n2 = self.m_counts[page_id_2]
            if (n1 + n2) <= self.page_size:
                new_page = np.concatenate([self.pages[page_id_1], self.pages[page_id_2]], axis=0)
                self.pages[page_id_1] = new_page
                self.pages[page_id_2] = np.zeros(shape=[0, self.data_dim], dtype=NP_DATA_TYPE)
                self.m_counts[page_id_1] = n1 + n2
                self.m_counts[page_id_2] = 0
                shard[0] = shd_pg_ids[0:-1]
                shard[1] = []
        else:
            left_idx = -1
            if page_idx == 0:
                if self.m_counts[shd_pg_ids[0]] + self.m_counts[shd_pg_ids[1]] <= self.page_size:
                    left_idx = 0
            elif page_idx == len(shd_pg_ids) - 1:
                max_idx = len(shd_pg_ids) - 1
                if self.m_counts[shd_pg_ids[max_idx - 1]] + self.m_counts[shd_pg_ids[max_idx]] <= self.page_size:
                    left_idx = max_idx - 1
            else:
                if self.m_counts[shd_pg_ids[page_idx]] + self.m_counts[shd_pg_ids[page_idx - 1]] <= self.page_size:
                    left_idx = page_idx - 1
                elif self.m_counts[shd_pg_ids[page_idx]] + self.m_counts[shd_pg_ids[page_idx + 1]] <= self.page_size:
                    left_idx = page_idx

            if left_idx >= 0:
                page_id_1 = shd_pg_ids[left_idx]
                page_id_2 = shd_pg_ids[left_idx + 1]
                n1 = self.m_counts[page_id_1]
                n2 = self.m_counts[page_id_2]
                # 页的合并
                new_page = np.concatenate([self.pages[page_id_1], self.pages[page_id_2]], axis=0)
                self.pages[page_id_1] = new_page
                self.pages[page_id_2] = np.zeros(shape=[0, self.data_dim], dtype=NP_DATA_TYPE)
                self.m_counts[page_id_1] = n1 + n2
                self.m_counts[page_id_2] = 0
                shd_pg_ids.remove(page_id_2)
                shd_sp_mps.remove(shd_sp_mps[left_idx])
                shd_pg_ids[left_idx] = page_id_1

    def _get_data_from_disk(self, page_id: int, unpack_size: int, fmt: str):
        """获取一个页面中的数据，注意数据存储在磁盘块上。"""
        IO = 0
        # 先在缓冲区中查找元素
        if page_id in self.memory_page_ids:
            res_data = self.memory_page_data[page_id]
            return res_data, IO

        # 若内存中无数据，则读文件块，并加入缓冲区
        res_data = []
        data_num = self.m_counts[page_id]
        offset = 0  # 页起始指针
        pre_data_num = 0  # 该页之前的所有数据量
        for i_ in range(page_id):
            pre_data_num += self.m_counts[i_]
        offset += pre_data_num * unpack_size

        with open(self.pages_pth, 'rb') as reader:
            reader.seek(offset)
            data_size = data_num * unpack_size  # 每个数据大小8B
            content = reader.read(data_size)
            IO += 1  # I/O次数加1

        bytes_tuples = []
        for i in range(0, len(content), unpack_size):
            part_bytes = content[i: i + unpack_size]
            tuple_ = struct.unpack(fmt, part_bytes)
            bytes_tuples.append(tuple_)
        for tuple_ in bytes_tuples:
            pos, t = tuple_
            list_ = [pos, t]
            res_data.append(list_)

        # ele_num = int(len(content) / 4)  # 元素个数 = 总长度 / 元素大小
        # tuple_ = struct.unpack('f' * ele_num, content)
        # for i_ in range(0, len(tuple_), 2):
        #     pos = tuple_[i_]
        #     t = tuple_[i_ + 1]
        #     list_ = [pos, t]
        #     res_data.append(list_)

        # 检查缓冲区是否已满，若满，则删除头部页
        if len(self.memory_page_ids) >= 512:
            del_id = self.memory_page_ids[0]
            self.memory_page_ids.pop(0)
            self.memory_page_data.pop(del_id, 'ERROR: delete page id not found.')

        # 更新缓冲区数据
        self.memory_page_ids.append(page_id)
        self.memory_page_data[page_id] = res_data

        return res_data, IO

    def _save_data_to_disk(self, data: np.ndarray):

        pass

    # ----------------------------------------------------unused----------------------------------------------------

    def sampling(self, N):
        return np.random.uniform(low=self.min_val_per_dim, high=self.max_val_per_dim, size=[N, self.data_dim])

    def cal_page_split_mappings(self):
        pg_num = len(self.pages)
        self.page_split_mappings = np.zeros(shape=[pg_num], dtype=NP_DATA_TYPE)
        for i in range(pg_num - 1):
            pg_mps = self._monotone_mapping(self.pages[i + 1])
            self.page_split_mappings[i] = pg_mps[0]

    def rebuild_sorted_data(self):
        # sorted_data = np.zeros(shape=[data_size, self.data_dim],dtype=np_data_type())
        sorted_data = []
        for shard_id, shard in enumerate(self.shard_infos):
            shard_page_nos = shard[0]

            for page_no in shard_page_nos:
                page = self.pages[page_no]
                page_mps = self._monotone_mapping(page)

                idxes = np.argsort(page_mps)
                page = page[idxes]

                sorted_data.append(page)
        sorted_data = np.concatenate(sorted_data, axis=0)
        return sorted_data

    # ----------------------------------------------------bug----------------------------------------------------

    def range_query_multi(self, query_ranges: np.ndarray) -> tuple:
        """
        范围查询
        :param query_ranges: 查询边界序列
        :return: 元组（每个查询的页数，每个查询的数据个数）
        """
        query_page_ids = self._get_query_page_ids(query_ranges)
        # print 'query_page_ids = ', query_page_ids
        n_dt_per_qr = np.zeros(shape=[query_ranges.shape[0]], dtype=NP_IDX_TYPE)
        n_pg_per_qr = np.zeros(shape=[query_ranges.shape[0]], dtype=NP_IDX_TYPE)

        for i in range(len(query_page_ids)):
            part_page_ids = query_page_ids[i]
            n_pg_per_qr[i] = len(part_page_ids)
            one_qr_results = []
            for page_id in part_page_ids:
                page = self.pages[page_id]
                one_qr_results.append(page)

            if len(one_qr_results) > 0:
                one_qr_results = np.concatenate(one_qr_results, axis=0)
                one_qr_results = self._overlap(one_qr_results, query_ranges[i])
                n_dt_per_qr[i] = one_qr_results.shape[0]

        return n_pg_per_qr, n_dt_per_qr

    @staticmethod
    def upper_bound(sorted_array, point):
        return np.clip((np.sign(point - sorted_array).astype(np.int64) + 1), a_min=0, a_max=1).sum()

    def _get_intersect_shard(self, query_range, dim, cell_idx_base, low_m, up_m, lower_mappings, upper_mappings):
        """递归获取与查询边界的上下界映射值"""
        if dim == 0:
            return

        low_val = query_range[dim - 1]
        up_val = query_range[dim]

        # 遍历第一个维度的第 cell_idx_base 个网格的分割点序列
        if dim == 1:
            t = self.param_part_nums[1]
            low_m *= self.eta
            up_m *= self.eta
            base = low_m + cell_idx_base * t
            lower_mp = base + low_val / self.max_val_per_dim * (t - 1)
            upper_mp = base + up_val / self.max_val_per_dim * (t - 1)
            lower_mappings.append(lower_mp)
            upper_mappings.append(upper_mp)
            return

        # 若不是第一个维度，则遍历对应维度的第 cell_idx_base 个网格的分割点序列
        else:
            sp_pts_om_hd_tl = self.split_points_omit_head_tail[dim - 1][cell_idx_base]
            split_bounds = self.split_bounds[dim - 1][cell_idx_base]
            fron_sp_pts = self.front_split_points[dim - 1][cell_idx_base]
            cell_lens = self.cell_lens[dim - 1][cell_idx_base]

            low_idx = np.searchsorted(sp_pts_om_hd_tl, low_val, side='right')
            up_idx = np.searchsorted(sp_pts_om_hd_tl, up_val, side='right')

            new_qr_ = np.copy(query_range)
            next_cl_idx = cell_idx_base + 1

            if (low_idx == up_idx).all():
                new_low_m = low_m * (low_val - fron_sp_pts[low_idx]) / cell_lens[low_idx]
                new_up_m = up_m * (up_val - fron_sp_pts[up_idx]) / cell_lens[up_idx]
                self._get_intersect_shard(new_qr_, dim - 1, cell_idx_base * self.t_parts_per_dim + low_idx,
                                          new_low_m, new_up_m, lower_mappings, upper_mappings)
            else:
                new_qr_[dim + self.data_dim] = split_bounds[low_idx]
                new_low_m = low_m * (low_val - fron_sp_pts[low_idx]) / cell_lens[low_idx]
                self._get_intersect_shard(new_qr_, dim - 1, cell_idx_base * self.t_parts_per_dim + low_idx,
                                          new_low_m, up_m, lower_mappings, upper_mappings)

                for next_one_dim_id in range(low_idx + 1, up_idx):
                    new_qr_ = np.copy(query_range)
                    new_qr_[dim] = split_bounds[next_one_dim_id - 1]
                    new_qr_[dim + self.data_dim] = split_bounds[next_one_dim_id]
                    self._get_intersect_shard(new_qr_, dim - 1,
                                              cell_idx_base * self.t_parts_per_dim + next_one_dim_id,
                                              0, up_m, lower_mappings, upper_mappings)

                new_qr_ = np.copy(query_range)
                new_qr_[dim] = split_bounds[up_idx - 1]
                new_up_m = up_m * (up_val - fron_sp_pts[up_idx]) / cell_lens[up_idx]
                self._get_intersect_shard(new_qr_, dim + 1, cell_idx_base * self.t_parts_per_dim + up_idx,
                                          0, new_up_m, lower_mappings, upper_mappings)

    def _get_query_ranges_mappings(self, query_ranges: np.ndarray):
        """
        分别获取矩形边界上界和下界的一维映射值
        :param query_ranges: 查询边界序列
        :return: 元组（下界映射值，上界映射值，边界中点个数列表）
        """
        n_pts_per_qr = []
        low_mps = []
        up_mps = []
        n_last = 0
        for i in range(query_ranges.shape[0]):
            query_range = query_ranges[i]
            one_qr_low_mps = []
            one_qr_up_mps = []
            dim = self.data_dim - 1  # 从最后一维开始划分
            self._get_intersect_shard(query_range, dim, 0, 1, 1, one_qr_low_mps, one_qr_up_mps)

            low_mps.extend(one_qr_low_mps)
            up_mps.extend(one_qr_up_mps)

            self._union_continuous_cells(one_qr_low_mps, one_qr_up_mps, low_mps, up_mps)

            n_pts_per_qr.append(len(up_mps) - n_last)
            n_last = len(up_mps)

        lower_mappings = np.array(low_mps, dtype=NP_DATA_TYPE)
        upper_mappings = np.array(up_mps, dtype=NP_DATA_TYPE)

        return lower_mappings, upper_mappings, n_pts_per_qr

    def _union_continuous_cells(self, low_mappings, high_mappings, all_low_mappings, all_high_mappings):
        # n_cells = len(cell_ids)
        # for i in range(n_cells):
        #     all_low_mappings.append(low_mappings[i])
        #     all_high_mappings.append(high_mappings[i])
        n_cells = len(low_mappings)
        if n_cells > 0:
            # last_id = cell_ids[0]
            l_m = low_mappings[0]
            h_m = high_mappings[0]
            for i in range(1, n_cells):
                # curr_id = cell_ids[i]
                curr_low_mapping = low_mappings[i]
                assert (curr_low_mapping >= h_m)
                if curr_low_mapping - h_m < 1e-5:
                    h_m = high_mappings[i]
                else:
                    all_low_mappings.append(l_m)
                    all_high_mappings.append(h_m)
                    l_m = curr_low_mapping
                    h_m = high_mappings[i]
            all_low_mappings.append(l_m)
            all_high_mappings.append(h_m)

    def _overlap(self, data, query_range):
        """获取矩形边界范围内的数据"""
        qr_kys = data[(data[:, 0] >= query_range[0]) & (data[:, 0] <= query_range[self.data_dim])]
        for i in range(1, self.data_dim):
            if qr_kys.shape[0] > 0:
                qr_kys = qr_kys[
                    (qr_kys[:, i] >= query_range[i]) & (qr_kys[:, i] <= query_range[i + self.data_dim])]
            else:
                break
        return qr_kys

    pass
