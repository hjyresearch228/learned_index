"""查询实验：I/O次数，时间"""
import random
import os
import numpy as np
import pandas as pd

from main import build_LISA


def generate_query_data(dir: str, query_file):
    file_list = os.listdir(dir)
    for file_ in file_list:
        ff = os.path.splitext(file_)[0]
        query_path = query_file + "\\" + ff + ".txt"
        with open(query_path, 'w') as f:
            pass
        file_path = os.path.join(dir, file_)

        data_df = pd.read_csv(file_path, delimiter=',', header=None, names=['pos', 't'])
        data_df = data_df[1:]
        max_pos = data_df['pos'].astype(float).max()
        min_pos = data_df['pos'].astype(float).min()
        max_t = data_df['t'].astype(float).max()
        min_t = data_df['t'].astype(float).min()
        area = (max_t - min_t) * (max_pos - min_pos)
        print(area)
        list_ = [0.00001, 0.00004, 0.00008, 0.00016]
        with open(query_path, 'a') as fff:
            for l_ in list_:
                area_part = area * l_
                print(area_part)
                for i in range(25):
                    lt = random.uniform(min_t, max_t - area_part ** 0.5)
                    lp = random.uniform(min_pos, max_pos - area_part ** 0.5)
                    # 计算右上角坐标
                    rt = lt + area_part ** 0.5
                    rp = lp + area_part ** 0.5
                    fff.write(f'{lp},{rp},{lt},{rt}\n')


def get_queries_for_one_pd(src: str) -> list:
    """获取单期数据的查询序列，参数为单期数据的查询框文件"""
    query_list = []
    with open(src, 'r') as reader:
        query_lines = reader.readlines()
    for i, query_line in enumerate(query_lines):
        query_str_list = query_line.replace('\n', '').split(',')
        query_list_ = [float(str_) for str_ in query_str_list]

        # pos_btm, pos_top, t_btm, t_top = query_list_  # tom

        t_btm, pos_btm, t_top, pos_top = query_list_  # ppt

        # t, pos = query_list_  # ppt point query
        # pos_btm, t_btm = pos, t
        # pos_top, t_top = pos, t

        btm = np.array([pos_btm, t_btm])
        top = np.array([pos_top, t_top])
        qr_ = np.array([btm, top])
        query_list.append(qr_)
    # random.shuffle(query_list)
    return query_list


def get_right_query_result(data_path: str, query_range: np.ndarray):
    """正确的查询结果，返回数据个数"""
    data = np.load(data_path)
    low_bd, high_bd = query_range
    pos_low, t_low = low_bd
    pos_high, t_high = high_bd

    pos_arr = data[:, 0]
    idx_ = np.argwhere((pos_arr <= pos_high) & (pos_arr >= pos_low)).flatten()
    data_ = data[idx_]
    t_arr = data_[:, 1]
    idx_ = np.argwhere((t_arr <= t_high) & (t_arr >= t_low)).flatten()

    data_res = data_[idx_]
    return len(idx_)


if __name__ == '__main__':
    # data_src = r'C:\Users\mzq\Desktop\my_LISA\test\test_300w.txt'
    # data_src = r'D:\BaiduNetdiskDownload\PPT数据\成都数据-分期txt\period_0.txt'  # ppt-chd
    data_src = r'E:\dataset\txt_simulation4-1_point_1\0.txt'  # ppt-sim

    # data_npy = r'D:\BaiduNetdiskDownload\chd_data\chd_pos_t_1_refined.npy'
    # data_npy = r'D:\BaiduNetdiskDownload\PPT数据\成都数据-分期txt\period_0.npy'  # ppt-chd
    data_npy = r'E:\dataset\txt_simulation4-1_point_1\0.npy'  # ppt-sim

    _ = r'C:\Users\mzq\Desktop\新建文件夹'
    # query_src = r'C:\Users\mzq\Desktop\范围查询\chd_query\chd_range_query_1.txt'
    # query_src = r'C:\Users\mzq\Desktop\range_query\chd\chd_pos_t_0_refined.txt'  # ppt-chd
    query_src = r'E:\dataset\sim_data_query_20_1\0.txt'  # ppt-sim
    # query_src = r'C:\Users\mzq\Desktop\sim_point_query\0.txt'  # ppt-sim
    # query_src = r'C:\Users\mzq\Desktop\chd_range_query\period_0.txt'  # ppt-chd

    # generate_query_data(_, query_src)

    qr_list = get_queries_for_one_pd(query_src)

    result = build_LISA(data_src)
    my_LISA = result[0]

    IO_list = []
    time_list = []
    recall_list = []
    result_num = 0
    for qr in qr_list:
        qry_data, IO, t_use = my_LISA.range_query(qr)
        # print(f'query result: {qry_data.shape[0]} \n {qry_data}')
        # print(f'query result: {qry_data.shape[0]}')
        # print(f'query I/O: {IO}')
        cur_num = qry_data.shape[0]
        #real_num = get_right_query_result(data_npy, qr)
        """if real_num == 0:
            if cur_num == real_num:
                recall = 1
            else:
                recall = 0
        else:
            recall = cur_num / real_num

        result_num += real_num"""
        #recall_list.append(recall)
        IO_list.append(IO)
        time_list.append(t_use)

    avg_IO = round(np.mean(IO_list), 3)
    avg_time = round(np.mean(time_list), 3)
    avg_recall = round(np.mean(recall_list), 3)
    print(f'average I/O: {avg_IO}')
    print(f'average time: {avg_time} s')
    print(f'average recall: {avg_recall}')
    print(f'total data number: {result_num}')
    pass
